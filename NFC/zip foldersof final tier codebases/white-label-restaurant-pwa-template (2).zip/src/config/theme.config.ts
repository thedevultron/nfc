import type { ThemeConfig } from "../types/config.types";

/**
 * ============================================================================
 * THEME CONFIG — /src/config/theme.config.ts
 * ============================================================================
 * Change colors, radius, density, or light/dark default here ONLY.
 * These values are injected as CSS custom properties in <AppShell /> and
 * every component in the app consumes them via `var(--color-*)` classes —
 * so a full re-brand of the PWA requires editing NOTHING else.
 * ============================================================================
 */
export const themeConfig: ThemeConfig = {
  // Core brand color (HSL triplet, no hsl() wrapper) — emerald green
  primaryColor: "142.1 76.2% 36.3%",
  primaryForeground: "0 0% 100%",

  // Secondary accent — warm gold, used for "Best Seller" / "Chef's Special"
  accentColor: "38 92% 50%",
  accentForeground: "20 14% 8%",

  // Surfaces
  backgroundColor: "240 10% 4%",
  surfaceColor: "240 8% 9%",
  surfaceElevated: "240 7% 13%",
  mutedColor: "240 5% 20%",
  mutedForeground: "240 5% 65%",
  borderColor: "240 6% 20%",
  destructiveColor: "0 72% 51%",

  radius: "1.1rem",
  density: "comfortable",
  enableGlassmorphism: true,
  defaultMode: "dark",
  fontFamily: "'Plus Jakarta Sans', 'Inter', system-ui, sans-serif",
};
