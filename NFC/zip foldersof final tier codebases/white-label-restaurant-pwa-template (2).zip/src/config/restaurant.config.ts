import type { RestaurantConfig } from "../types/config.types";

/**
 * ============================================================================
 * RESTAURANT CONFIG — /src/config/restaurant.config.ts
 * ============================================================================
 * This is the SINGLE SOURCE OF TRUTH for a client deployment: brand copy,
 * contact links, WiFi credentials, feature toggles and webhook endpoints.
 * Swap this file (and menuData.ts + theme.config.ts) to white-label the
 * entire PWA for a new restaurant — zero component code changes required.
 * ============================================================================
 */
export const restaurantConfig: RestaurantConfig = {
  brand: {
    name: "Aura Bistro & Lounge",
    subtitle: "Modern Culinary Experience",
    tagline: "Seasonal plates, crafted cocktails & good vibes only.",
    address: "12 Marina Walk, Downtown District",
    googleReviewUrl: "https://maps.google.com/?cid=000000000000000000",
    whatsappNumber: "+919876543210",
    instagramHandle: "@aurabistro",
    wifi: { ssid: "Aura_Guest_5G", pass: "Bistro@2026" },
    openHours: "Mon–Sun · 11:00 AM – 12:00 AM",
  },

  // Toggle features per-client without touching any component
  features: {
    enableBookings: true,
    enableReviews: true,
    enableWifi: true,
    enableDirectOrdering: true,
    enableFavorites: true,
    enablePWAInstallPrompt: true,
  },

  // NFC tag / QR code on the table can inject a `?table=04&mode=dine-in` param
  defaultTouchpoint: {
    mode: "dine-in",
    tableLabel: "Table 04",
  },

  reservation: {
    timeSlots: [
      "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM",
      "7:00 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM",
    ],
    maxGuests: 12,
  },

  // Point these at your live n8n instance — see /src/services/n8n.service.ts
  n8nWebhooks: {
    reservationUrl: "https://your-n8n-instance.com/webhook/reservation",
    feedbackUrl: "https://your-n8n-instance.com/webhook/feedback",
    orderUrl: "https://your-n8n-instance.com/webhook/order",
    reviewUrl: "https://your-n8n-instance.com/webhook/review",
  },
};
