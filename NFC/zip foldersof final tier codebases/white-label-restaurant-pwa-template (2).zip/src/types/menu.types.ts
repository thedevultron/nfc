/**
 * ============================================================================
 * MENU / CART / RESERVATION / FEEDBACK SCHEMA — /src/types/menu.types.ts
 * ============================================================================
 */

/** Any valid lucide-react icon name, kept as a string so config stays data-only */
export type LucideIconName = string;

export type DietaryTag = "veg" | "non-veg" | "vegan" | "chef-special";

export interface MenuCategory {
  id: string;
  label: string;
  icon: LucideIconName;
}

export interface MenuItem {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  icon: LucideIconName;
  dietary: DietaryTag[];
  spiceLevel: 0 | 1 | 2 | 3;
  isBestSeller?: boolean;
  isAvailable: boolean;
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
  notes?: string;
}

export interface ReservationPayload {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  notes?: string;
}

export interface FeedbackPayload {
  rating: number;
  name?: string;
  message: string;
}

export interface OrderPayload {
  items: { name: string; quantity: number; price: number; notes?: string }[];
  total: number;
  touchpoint: string;
  specialInstructions?: string;
}

export type TouchpointMode = "dine-in" | "takeaway" | "delivery";
