/**
 * ============================================================================
 * CONFIG SCHEMA — /src/types/config.types.ts
 * ============================================================================
 * These interfaces define the "contract" that /src/config/* files must follow.
 * Nothing in this file should ever need to change for a new client deployment.
 * ============================================================================
 */

export type UIDensity = "compact" | "comfortable" | "spacious";
export type ThemeMode = "light" | "dark";

export interface ThemeConfig {
  /** HSL triplet WITHOUT the hsl() wrapper, e.g. "142.1 76.2% 36.3%" */
  primaryColor: string;
  primaryForeground: string;
  /** Secondary accent used for badges like "Chef's Special" / "Best Seller" */
  accentColor: string;
  accentForeground: string;
  backgroundColor: string;
  surfaceColor: string;
  surfaceElevated: string;
  mutedColor: string;
  mutedForeground: string;
  borderColor: string;
  destructiveColor: string;
  radius: string;
  density: UIDensity;
  enableGlassmorphism: boolean;
  defaultMode: ThemeMode;
  fontFamily: string;
}

export interface RestaurantBrand {
  name: string;
  subtitle: string;
  tagline: string;
  address: string;
  googleReviewUrl: string;
  whatsappNumber: string;
  instagramHandle?: string;
  wifi: {
    ssid: string;
    pass: string;
  };
  openHours: string;
}

export interface RestaurantFeatures {
  enableBookings: boolean;
  enableReviews: boolean;
  enableWifi: boolean;
  enableDirectOrdering: boolean;
  enableFavorites: boolean;
  enablePWAInstallPrompt: boolean;
}

export interface N8nWebhooks {
  reservationUrl: string;
  feedbackUrl: string;
  orderUrl: string;
  reviewUrl: string;
}

export interface RestaurantConfig {
  brand: RestaurantBrand;
  features: RestaurantFeatures;
  n8nWebhooks: N8nWebhooks;
  /** Table / touchpoint context injected by NFC tag or QR string param */
  defaultTouchpoint: {
    mode: "dine-in" | "takeaway" | "delivery";
    tableLabel: string;
  };
  reservation: {
    timeSlots: string[];
    maxGuests: number;
  };
}
