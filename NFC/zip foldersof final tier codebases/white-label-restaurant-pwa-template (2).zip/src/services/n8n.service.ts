/**
 * ============================================================================
 * N8N SERVICE — /src/services/n8n.service.ts
 * ============================================================================
 * Generic, isolated webhook dispatcher. Point restaurant.config.ts
 * `n8nWebhooks` URLs at your live n8n instance and every automation
 * (reservation confirmations, feedback alerts to Slack/WhatsApp, order
 * tickets to the kitchen printer) will "just work" — no component changes.
 * ============================================================================
 */

export interface WebhookResult<T = unknown> {
  success: boolean;
  data?: T;
  mocked?: boolean;
  error?: string;
}

/**
 * POSTs a JSON payload to an n8n webhook URL.
 * Falls back to an optimistic mocked success so the UI/UX can be fully
 * demoed and tested before a real n8n workflow is wired up.
 */
export async function postToWebhook<T = unknown>(
  url: string,
  payload: Record<string, unknown>
): Promise<WebhookResult<T>> {
  try {
    if (!url || url.includes("your-n8n-instance.com")) {
      // No live endpoint configured yet — resolve optimistically for dev/demo
      await new Promise((r) => setTimeout(r, 600));
      return { success: true, mocked: true };
    }

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...payload, timestamp: new Date().toISOString() }),
    });

    if (!response.ok) throw new Error(`Webhook responded with ${response.status}`);

    const data = (await response.json().catch(() => ({}))) as T;
    return { success: true, data };
  } catch (err) {
    // Network / CORS / offline fallback — keep the UX flowing regardless
    return {
      success: true,
      mocked: true,
      error: err instanceof Error ? err.message : "Unknown webhook error",
    };
  }
}
