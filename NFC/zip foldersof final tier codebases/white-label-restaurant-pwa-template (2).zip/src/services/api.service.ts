import { restaurantConfig } from "../config/restaurant.config";
import { postToWebhook } from "./n8n.service";
import type {
  FeedbackPayload,
  OrderPayload,
  ReservationPayload,
} from "../types/menu.types";

/**
 * ============================================================================
 * API SERVICE — /src/services/api.service.ts
 * ============================================================================
 * Domain-friendly async functions consumed by feature components. Internally
 * these are wired to /src/services/n8n.service.ts and read their target URLs
 * straight from /src/config/restaurant.config.ts — components never know or
 * care whether the backend is n8n, a REST API, or a mock.
 * ============================================================================
 */
export const apiService = {
  async sendReservation(payload: ReservationPayload) {
    return postToWebhook(restaurantConfig.n8nWebhooks.reservationUrl, {
      type: "reservation",
      ...payload,
    });
  },

  async sendFeedback(payload: FeedbackPayload) {
    return postToWebhook(restaurantConfig.n8nWebhooks.feedbackUrl, {
      type: "feedback",
      ...payload,
    });
  },

  async sendOrder(payload: OrderPayload) {
    return postToWebhook(restaurantConfig.n8nWebhooks.orderUrl, {
      type: "order",
      ...payload,
    });
  },

  async sendReviewSignal(rating: number) {
    return postToWebhook(restaurantConfig.n8nWebhooks.reviewUrl, {
      type: "review-click",
      rating,
    });
  },
};
