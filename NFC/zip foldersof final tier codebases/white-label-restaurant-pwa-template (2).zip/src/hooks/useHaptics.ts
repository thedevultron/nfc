import { useCallback } from "react";

/**
 * ============================================================================
 * useHaptics — /src/hooks/useHaptics.ts
 * ============================================================================
 * Wraps navigator.vibrate so every tap, filter switch, add-to-cart, and
 * drawer trigger across the app gets consistent native-feeling haptics.
 * Silently no-ops on devices/browsers without vibration support (e.g. iOS
 * Safari), so it's always safe to call.
 * ============================================================================
 */
export type HapticPattern = "light" | "medium" | "heavy" | "success" | "error";

const PATTERNS: Record<HapticPattern, number | number[]> = {
  light: 10,
  medium: 18,
  heavy: 30,
  success: [10, 40, 12],
  error: [20, 30, 20, 30],
};

export function useHaptics() {
  const vibrate = useCallback((pattern: HapticPattern = "light") => {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate(PATTERNS[pattern]);
      } catch {
        /* no-op */
      }
    }
  }, []);

  return { vibrate };
}
