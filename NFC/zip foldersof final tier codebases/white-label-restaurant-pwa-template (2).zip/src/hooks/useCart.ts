import { useCallback, useMemo, useState } from "react";
import type { CartItem, MenuItem } from "../types/menu.types";
import { useHaptics } from "./useHaptics";

/**
 * ============================================================================
 * useCart — /src/hooks/useCart.ts
 * ============================================================================
 * Local cart state: items, quantities, totals, drawer open/close control,
 * and special instructions. Consumed by <CartSheet /> and <MenuList />.
 * ============================================================================
 */
export function useCart() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [instructions, setInstructions] = useState("");
  const { vibrate } = useHaptics();

  const addItem = useCallback(
    (item: MenuItem) => {
      if (!item.isAvailable) return;
      vibrate("light");
      setItems((prev) => {
        const existing = prev.find((ci) => ci.item.id === item.id);
        if (existing) {
          return prev.map((ci) =>
            ci.item.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
          );
        }
        return [...prev, { item, quantity: 1 }];
      });
    },
    [vibrate]
  );

  const decrementItem = useCallback(
    (itemId: string) => {
      vibrate("light");
      setItems((prev) => {
        const existing = prev.find((ci) => ci.item.id === itemId);
        if (existing && existing.quantity <= 1) {
          return prev.filter((ci) => ci.item.id !== itemId);
        }
        return prev.map((ci) =>
          ci.item.id === itemId ? { ...ci, quantity: ci.quantity - 1 } : ci
        );
      });
    },
    [vibrate]
  );

  const removeItem = useCallback(
    (itemId: string) => {
      vibrate("medium");
      setItems((prev) => prev.filter((ci) => ci.item.id !== itemId));
    },
    [vibrate]
  );

  const clearCart = useCallback(() => {
    setItems([]);
    setInstructions("");
  }, []);

  const getQuantity = useCallback(
    (itemId: string) => items.find((ci) => ci.item.id === itemId)?.quantity ?? 0,
    [items]
  );

  const totalItems = useMemo(
    () => items.reduce((sum, ci) => sum + ci.quantity, 0),
    [items]
  );

  const subtotal = useMemo(
    () => items.reduce((sum, ci) => sum + ci.quantity * ci.item.price, 0),
    [items]
  );

  return {
    items,
    isOpen,
    open: () => setIsOpen(true),
    close: () => setIsOpen(false),
    setIsOpen,
    addItem,
    decrementItem,
    removeItem,
    clearCart,
    getQuantity,
    totalItems,
    subtotal,
    instructions,
    setInstructions,
  };
}

export type UseCartReturn = ReturnType<typeof useCart>;
