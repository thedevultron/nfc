import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AppShell } from "./components/layout/AppShell";
import { Header } from "./components/layout/Header";
import { BottomNav, type MainTab } from "./components/layout/BottomNav";
import { MenuList } from "./components/features/MenuList";
import { CartSheet } from "./components/features/CartSheet";
import { WifiModal } from "./components/features/WifiModal";
import { ReviewModal } from "./components/features/ReviewModal";
import { ReservationSheet } from "./components/features/ReservationSheet";
import { useCart } from "./hooks/useCart";
import { restaurantConfig } from "./config/restaurant.config";

/**
 * ============================================================================
 * APP.TSX — Layout integration only.
 * ============================================================================
 * This file wires layout + features + state together with Framer Motion
 * transitions. It reads NOTHING hardcoded about the client's brand, menu,
 * or feature set — all of that lives in /src/config. To white-label this
 * template for a new restaurant, you only ever touch:
 *   1. /src/config/theme.config.ts
 *   2. /src/config/restaurant.config.ts
 *   3. /src/config/menuData.ts
 * ============================================================================
 */
export default function App() {
  const [activeTab, setActiveTab] = useState<MainTab>("menu");
  const [wifiOpen, setWifiOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  const cart = useCart();
  const { defaultTouchpoint } = restaurantConfig;

  const toggleFavorite = (id: string) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <AppShell>
      <Header
        touchpointMode={defaultTouchpoint.mode}
        tableLabel={defaultTouchpoint.tableLabel}
        onOpenWifi={() => setWifiOpen(true)}
        onOpenReview={() => setReviewOpen(true)}
        onOpenBooking={() => setBookingOpen(true)}
      />

      <AnimatePresence mode="wait">
        <motion.main
          key={activeTab}
          initial={{ opacity: 0, x: activeTab === "favorites" ? 24 : -24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: activeTab === "favorites" ? -24 : 24 }}
          transition={{ type: "spring", stiffness: 400, damping: 32 }}
          className="flex flex-1 flex-col overflow-hidden"
        >
          <MenuList
            cart={cart}
            favorites={favorites}
            onToggleFavorite={toggleFavorite}
            favoritesOnly={activeTab === "favorites"}
          />
        </motion.main>
      </AnimatePresence>

      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        cartCount={cart.totalItems}
        onOpenCart={cart.open}
        onOpenBooking={() => setBookingOpen(true)}
      />

      <CartSheet cart={cart} touchpointLabel={defaultTouchpoint.tableLabel} />
      <WifiModal open={wifiOpen} onOpenChange={setWifiOpen} />
      <ReviewModal open={reviewOpen} onOpenChange={setReviewOpen} />
      <ReservationSheet open={bookingOpen} onOpenChange={setBookingOpen} />
    </AppShell>
  );
}
