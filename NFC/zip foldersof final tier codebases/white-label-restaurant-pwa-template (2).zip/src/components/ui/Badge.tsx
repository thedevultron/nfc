import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../utils/cn";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide",
  {
    variants: {
      variant: {
        primary: "bg-[var(--color-primary)]/15 text-[var(--color-primary)]",
        accent: "bg-[var(--color-accent)]/20 text-[var(--color-accent)]",
        muted: "bg-white/5 text-[var(--color-muted-foreground)]",
        destructive: "bg-[var(--color-destructive)]/15 text-[var(--color-destructive)]",
        outline: "border border-[var(--color-border)] text-[var(--color-foreground)]",
      },
    },
    defaultVariants: { variant: "muted" },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
