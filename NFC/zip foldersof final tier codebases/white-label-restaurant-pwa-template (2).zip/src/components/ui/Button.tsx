import * as React from "react";
import { motion, type HTMLMotionProps } from "framer-motion";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../utils/cn";

/**
 * Shared UI primitive — visual variants only. Colors reference the CSS
 * custom properties injected by <AppShell /> from theme.config.ts.
 */
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[var(--radius)] text-sm font-semibold transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-40 select-none",
  {
    variants: {
      variant: {
        primary:
          "bg-[var(--color-primary)] text-[var(--color-primary-foreground)] shadow-lg shadow-black/20",
        accent:
          "bg-[var(--color-accent)] text-[var(--color-accent-foreground)] shadow-lg shadow-black/20",
        secondary:
          "bg-[var(--color-surface-elevated)] text-[var(--color-foreground)] border border-[var(--color-border)]",
        ghost: "bg-transparent text-[var(--color-foreground)] hover:bg-white/5",
        outline:
          "bg-transparent border border-[var(--color-border)] text-[var(--color-foreground)]",
        destructive: "bg-[var(--color-destructive)] text-white",
      },
      size: {
        sm: "h-9 px-3 text-xs",
        md: "h-12 px-5",
        lg: "h-14 px-6 text-base",
        icon: "h-12 w-12 shrink-0",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  }
);

export interface ButtonProps
  extends Omit<HTMLMotionProps<"button">, "ref">,
    VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, children, ...props }, ref) => {
    return (
      <motion.button
        ref={ref}
        whileTap={{ scale: 0.94 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        className={cn(buttonVariants({ variant, size }), className)}
        {...props}
      >
        {children}
      </motion.button>
    );
  }
);
Button.displayName = "Button";
