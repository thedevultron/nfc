import * as LucideIcons from "lucide-react";
import type { LucideProps } from "lucide-react";
import { Sparkle } from "lucide-react";

/**
 * Resolves an icon by NAME (string, as stored in config/menuData.ts) to the
 * actual lucide-react component. This is what makes icons 100% data-driven —
 * changing "Flame" to "Soup" in menuData.ts is all it takes, no imports.
 */
export function Icon({ name, ...props }: { name: string } & LucideProps) {
  const LucideIcon = (LucideIcons as unknown as Record<string, React.ComponentType<LucideProps>>)[
    name
  ];
  if (!LucideIcon) return <Sparkle {...props} />;
  return <LucideIcon {...props} />;
}
