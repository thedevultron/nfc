import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Minus, Plus, SquarePen, Trash2, ShoppingBag, CheckCircle2, Loader2 } from "lucide-react";
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter,
} from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Textarea } from "../ui/Input";
import { apiService } from "../../services/api.service";
import { restaurantConfig } from "../../config/restaurant.config";
import { useHaptics } from "../../hooks/useHaptics";
import type { UseCartReturn } from "../../hooks/useCart";

interface CartSheetProps {
  cart: UseCartReturn;
  touchpointLabel: string;
}

export function CartSheet({ cart, touchpointLabel }: CartSheetProps) {
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  const { vibrate } = useHaptics();

  const handlePlaceOrder = async () => {
    vibrate("medium");
    setStatus("submitting");

    const orderPayload = {
      items: cart.items.map((ci) => ({
        name: ci.item.name,
        quantity: ci.quantity,
        price: ci.item.price,
      })),
      total: cart.subtotal,
      touchpoint: touchpointLabel,
      specialInstructions: cart.instructions,
    };

    await apiService.sendOrder(orderPayload);

    if (restaurantConfig.features.enableDirectOrdering) {
      const lines = cart.items.map(
        (ci) => `• ${ci.quantity}x ${ci.item.name} — $${(ci.quantity * ci.item.price).toFixed(2)}`
      );
      const message = [
        `New order — ${touchpointLabel}`,
        ...lines,
        `Total: $${cart.subtotal.toFixed(2)}`,
        cart.instructions ? `Notes: ${cart.instructions}` : "",
      ]
        .filter(Boolean)
        .join("\n");

      const waUrl = `https://wa.me/${restaurantConfig.brand.whatsappNumber.replace(/[^\d]/g, "")}?text=${encodeURIComponent(message)}`;
      window.open(waUrl, "_blank");
    }

    vibrate("success");
    setStatus("success");
    setTimeout(() => {
      cart.clearCart();
      cart.close();
      setStatus("idle");
    }, 1800);
  };

  return (
    <Drawer open={cart.isOpen} onOpenChange={cart.setIsOpen}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Your Order</DrawerTitle>
          <DrawerDescription>{touchpointLabel}</DrawerDescription>
        </DrawerHeader>

        <div className="flex-1 overflow-y-auto px-5">
          <AnimatePresence mode="wait">
            {status === "success" ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center gap-3 py-16 text-center"
              >
                <CheckCircle2 size={48} className="text-[var(--color-primary)]" />
                <p className="font-bold">Order sent to the kitchen!</p>
                <p className="text-sm text-[var(--color-muted-foreground)]">We'll have it ready shortly.</p>
              </motion.div>
            ) : cart.items.length === 0 ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center gap-2 py-16 text-center text-[var(--color-muted-foreground)]"
              >
                <ShoppingBag size={32} />
                <p className="text-sm font-medium">Your cart is empty.</p>
              </motion.div>
            ) : (
              <motion.div key="items" className="space-y-3 py-2">
                {cart.items.map((ci) => (
                  <motion.div
                    layout
                    key={ci.item.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    className="flex items-center justify-between gap-3 rounded-[var(--radius)] border border-[var(--color-border)] bg-[var(--color-surface-elevated)] p-3"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold">{ci.item.name}</p>
                      <p className="text-xs text-[var(--color-muted-foreground)]">
                        ${ci.item.price.toFixed(2)} each
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <motion.button
                        whileTap={{ scale: 0.85 }}
                        onClick={() => cart.decrementItem(ci.item.id)}
                        className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-surface)]"
                      >
                        <Minus size={13} />
                      </motion.button>
                      <span className="w-4 text-center text-sm font-bold">{ci.quantity}</span>
                      <motion.button
                        whileTap={{ scale: 0.85 }}
                        onClick={() => cart.addItem(ci.item)}
                        className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-primary)] text-[var(--color-primary-foreground)]"
                      >
                        <Plus size={13} />
                      </motion.button>
                      <button
                        onClick={() => cart.removeItem(ci.item.id)}
                        className="ml-1 flex h-8 w-8 items-center justify-center text-[var(--color-destructive)]"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </motion.div>
                ))}

                <div className="pt-2">
                  <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-[var(--color-muted-foreground)]">
                    <SquarePen size={13} /> Special instructions
                  </label>
                  <Textarea
                    rows={2}
                    placeholder="e.g. No onions, extra spicy, allergy notes..."
                    value={cart.instructions}
                    onChange={(e) => cart.setInstructions(e.target.value)}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {cart.items.length > 0 && status !== "success" && (
          <DrawerFooter>
            <div className="mb-3 flex items-center justify-between text-sm">
              <span className="text-[var(--color-muted-foreground)]">Subtotal</span>
              <span className="text-lg font-extrabold">${cart.subtotal.toFixed(2)}</span>
            </div>
            <Button
              variant="primary"
              size="lg"
              className="w-full"
              disabled={status === "submitting"}
              onClick={handlePlaceOrder}
            >
              {status === "submitting" ? (
                <>
                  <Loader2 size={18} className="animate-spin" /> Placing order...
                </>
              ) : (
                <>
                  <ShoppingBag size={18} /> Place Order via Kitchen
                </>
              )}
            </Button>
          </DrawerFooter>
        )}
      </DrawerContent>
    </Drawer>
  );
}
