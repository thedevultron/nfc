import { useState } from "react";
import { motion } from "framer-motion";
import { Users, Minus, Plus, CalendarDays, CheckCircle2, Loader2, Clock } from "lucide-react";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Input, Textarea } from "../ui/Input";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService } from "../../services/api.service";
import { useHaptics } from "../../hooks/useHaptics";

interface ReservationSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const todayISO = () => new Date().toISOString().split("T")[0];

export function ReservationSheet({ open, onOpenChange }: ReservationSheetProps) {
  const { vibrate } = useHaptics();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState(todayISO());
  const [time, setTime] = useState(restaurantConfig.reservation.timeSlots[0]);
  const [guests, setGuests] = useState(2);
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");

  const reset = () => {
    setName("");
    setPhone("");
    setDate(todayISO());
    setTime(restaurantConfig.reservation.timeSlots[0]);
    setGuests(2);
    setNotes("");
    setStatus("idle");
  };

  const canSubmit = name.trim() && phone.trim() && date && time;

  const handleSubmit = async () => {
    if (!canSubmit) return;
    vibrate("medium");
    setStatus("submitting");
    await apiService.sendReservation({ name, phone, date, time, guests, notes });
    vibrate("success");
    setStatus("success");
    setTimeout(() => {
      reset();
      onOpenChange(false);
    }, 1800);
  };

  return (
    <Drawer
      open={open}
      onOpenChange={(o) => {
        onOpenChange(o);
        if (!o) setTimeout(reset, 300);
      }}
    >
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Reserve a Table</DrawerTitle>
          <DrawerDescription>We'll confirm your booking instantly.</DrawerDescription>
        </DrawerHeader>

        <div className="flex-1 space-y-4 overflow-y-auto px-5 pb-2">
          {status === "success" ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center gap-3 py-12 text-center"
            >
              <CheckCircle2 size={44} className="text-[var(--color-primary)]" />
              <p className="font-bold">Reservation request sent!</p>
              <p className="text-sm text-[var(--color-muted-foreground)]">
                {name}, we'll text {phone} to confirm your table for {guests} on {date} at {time}.
              </p>
            </motion.div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} />
                <Input placeholder="Phone number" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>

              <div>
                <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-[var(--color-muted-foreground)]">
                  <CalendarDays size={13} /> Date
                </label>
                <Input type="date" min={todayISO()} value={date} onChange={(e) => setDate(e.target.value)} />
              </div>

              <div>
                <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-[var(--color-muted-foreground)]">
                  <Clock size={13} /> Time slot
                </label>
                <div className="flex flex-wrap gap-2">
                  {restaurantConfig.reservation.timeSlots.map((slot) => {
                    const isActive = time === slot;
                    return (
                      <button
                        key={slot}
                        onClick={() => {
                          vibrate("light");
                          setTime(slot);
                        }}
                        className={`relative rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
                          isActive
                            ? "bg-[var(--color-primary)] text-[var(--color-primary-foreground)]"
                            : "border border-[var(--color-border)] bg-[var(--color-surface)] text-[var(--color-muted-foreground)]"
                        }`}
                      >
                        {slot}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-[var(--color-muted-foreground)]">
                  <Users size={13} /> Guests
                </label>
                <div className="flex items-center justify-between rounded-[var(--radius)] border border-[var(--color-border)] bg-[var(--color-surface-elevated)] px-4 py-2.5">
                  <span className="text-sm font-medium">Party size</span>
                  <div className="flex items-center gap-3">
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => {
                        vibrate("light");
                        setGuests((g) => Math.max(1, g - 1));
                      }}
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-surface)]"
                    >
                      <Minus size={14} />
                    </motion.button>
                    <span className="w-5 text-center text-sm font-bold">{guests}</span>
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => {
                        vibrate("light");
                        setGuests((g) => Math.min(restaurantConfig.reservation.maxGuests, g + 1));
                      }}
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-primary)] text-[var(--color-primary-foreground)]"
                    >
                      <Plus size={14} />
                    </motion.button>
                  </div>
                </div>
              </div>

              <Textarea
                rows={2}
                placeholder="Occasion, seating preference, allergies..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </>
          )}
        </div>

        {status !== "success" && (
          <DrawerFooter>
            <Button
              variant="primary"
              size="lg"
              className="w-full"
              disabled={!canSubmit || status === "submitting"}
              onClick={handleSubmit}
            >
              {status === "submitting" ? (
                <>
                  <Loader2 size={18} className="animate-spin" /> Booking...
                </>
              ) : (
                <>
                  <CalendarDays size={17} /> Confirm Reservation
                </>
              )}
            </Button>
          </DrawerFooter>
        )}
      </DrawerContent>
    </Drawer>
  );
}
