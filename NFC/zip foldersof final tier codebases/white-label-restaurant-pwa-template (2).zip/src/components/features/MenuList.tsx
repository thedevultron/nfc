import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Search, Flame, Ban, Plus, Minus, Award, Leaf, Beef, CircleDot, Heart, X,
} from "lucide-react";
import { menuCategories, menuItems } from "../../config/menuData";
import { Icon } from "../ui/Icon";
import { Badge } from "../ui/Badge";
import { useHaptics } from "../../hooks/useHaptics";
import type { UseCartReturn } from "../../hooks/useCart";
import type { DietaryTag, MenuItem } from "../../types/menu.types";

const DIETARY_FILTERS: { key: DietaryTag; label: string; icon: typeof Leaf; color: string }[] = [
  { key: "veg", label: "Veg", icon: CircleDot, color: "text-emerald-400" },
  { key: "non-veg", label: "Non-Veg", icon: Beef, color: "text-rose-400" },
  { key: "vegan", label: "Vegan", icon: Leaf, color: "text-lime-400" },
  { key: "chef-special", label: "Chef's Special", icon: Award, color: "text-amber-400" },
];

interface MenuListProps {
  cart: UseCartReturn;
  favorites: Set<string>;
  onToggleFavorite: (id: string) => void;
  favoritesOnly?: boolean;
}

export function MenuList({ cart, favorites, onToggleFavorite, favoritesOnly }: MenuListProps) {
  const [activeCategory, setActiveCategory] = useState(menuCategories[0].id);
  const [query, setQuery] = useState("");
  const [activeFilters, setActiveFilters] = useState<DietaryTag[]>([]);
  const { vibrate } = useHaptics();

  const toggleFilter = (tag: DietaryTag) => {
    vibrate("light");
    setActiveFilters((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  };

  const filteredItems = useMemo(() => {
    let list = menuItems;
    if (favoritesOnly) list = list.filter((i) => favorites.has(i.id));
    if (!favoritesOnly) list = list.filter((i) => i.categoryId === activeCategory);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (i) => i.name.toLowerCase().includes(q) || i.description.toLowerCase().includes(q)
      );
    }
    if (activeFilters.length) {
      list = list.filter((i) => activeFilters.every((f) => i.dietary.includes(f)));
    }
    return list;
  }, [activeCategory, query, activeFilters, favoritesOnly, favorites]);

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar pb-6">
      {/* Search + Dietary Filters */}
      <div className="sticky top-0 z-20 space-y-3 bg-[var(--color-background)] px-5 pb-3 pt-4">
        <div className="relative">
          <Search
            size={17}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[var(--color-muted-foreground)]"
          />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search dishes, drinks..."
            className="h-12 w-full rounded-[var(--radius)] border border-[var(--color-border)] bg-[var(--color-surface)] pl-11 pr-9 text-sm outline-none focus:border-[var(--color-primary)]"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--color-muted-foreground)]"
            >
              <X size={16} />
            </button>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {DIETARY_FILTERS.map((f) => {
            const isActive = activeFilters.includes(f.key);
            return (
              <motion.button
                key={f.key}
                whileTap={{ scale: 0.92 }}
                onClick={() => toggleFilter(f.key)}
                className={`flex min-h-[36px] shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                  isActive
                    ? "border-[var(--color-primary)] bg-[var(--color-primary)]/15 text-[var(--color-primary)]"
                    : "border-[var(--color-border)] bg-[var(--color-surface)] text-[var(--color-muted-foreground)]"
                }`}
              >
                <f.icon size={13} className={isActive ? "text-[var(--color-primary)]" : f.color} />
                {f.label}
              </motion.button>
            );
          })}
        </div>

        {/* Category nav */}
        {!favoritesOnly && (
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {menuCategories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    vibrate("light");
                    setActiveCategory(cat.id);
                  }}
                  className="relative flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold"
                >
                  {isActive && (
                    <motion.div
                      layoutId="categoryIndicator"
                      className="absolute inset-0 rounded-full bg-[var(--color-primary)]"
                      transition={{ type: "spring", stiffness: 400, damping: 28 }}
                    />
                  )}
                  <Icon
                    name={cat.icon}
                    size={14}
                    className={`relative z-10 ${isActive ? "text-[var(--color-primary-foreground)]" : "text-[var(--color-muted-foreground)]"}`}
                  />
                  <span className={`relative z-10 ${isActive ? "text-[var(--color-primary-foreground)]" : "text-[var(--color-muted-foreground)]"}`}>
                    {cat.label}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Dish cards */}
      <div className="space-y-3 px-5 pt-2">
        <AnimatePresence mode="popLayout">
          {filteredItems.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-2 py-16 text-center text-[var(--color-muted-foreground)]"
            >
              <Heart size={28} />
              <p className="text-sm font-medium">
                {favoritesOnly ? "No saved dishes yet — tap the heart on any dish." : "No dishes match your filters."}
              </p>
            </motion.div>
          )}
          {filteredItems.map((item) => (
            <DishCard
              key={item.id}
              item={item}
              quantity={cart.getQuantity(item.id)}
              isFavorite={favorites.has(item.id)}
              onAdd={() => cart.addItem(item)}
              onRemove={() => cart.decrementItem(item.id)}
              onToggleFavorite={() => onToggleFavorite(item.id)}
            />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

function DishCard({
  item,
  quantity,
  isFavorite,
  onAdd,
  onRemove,
  onToggleFavorite,
}: {
  item: MenuItem;
  quantity: number;
  isFavorite: boolean;
  onAdd: () => void;
  onRemove: () => void;
  onToggleFavorite: () => void;
}) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ type: "spring", stiffness: 400, damping: 30 }}
      className={`relative flex gap-3 rounded-[var(--radius)] border border-[var(--color-border)] bg-[var(--color-surface)] p-3 ${
        !item.isAvailable ? "opacity-60" : ""
      }`}
    >
      <div className="relative flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-[var(--color-surface-elevated)]">
        <Icon name={item.icon} size={30} className="text-[var(--color-primary)]" />
        {!item.isAvailable && (
          <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-black/60">
            <Ban size={22} className="text-red-400" />
          </div>
        )}
      </div>

      <div className="flex min-w-0 flex-1 flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-sm font-bold leading-tight">{item.name}</h3>
            <button
              onClick={onToggleFavorite}
              className="shrink-0 -m-2 flex h-8 w-8 items-center justify-center"
              aria-label="Save to favorites"
            >
              <Heart
                size={16}
                className={isFavorite ? "fill-[var(--color-accent)] text-[var(--color-accent)]" : "text-[var(--color-muted-foreground)]"}
              />
            </button>
          </div>
          <p className="mt-0.5 line-clamp-2 text-xs text-[var(--color-muted-foreground)]">{item.description}</p>

          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            {item.isBestSeller && <Badge variant="accent">Best Seller</Badge>}
            {!item.isAvailable && <Badge variant="destructive">Sold Out</Badge>}
            {item.dietary.includes("chef-special") && <Badge variant="primary">Chef's Special</Badge>}
            {item.spiceLevel > 0 && (
              <span className="inline-flex items-center gap-0.5">
                {Array.from({ length: item.spiceLevel }).map((_, i) => (
                  <Flame key={i} size={11} className="text-orange-500" />
                ))}
              </span>
            )}
          </div>
        </div>

        <div className="mt-2 flex items-center justify-between">
          <span className="text-sm font-extrabold text-[var(--color-primary)]">${item.price.toFixed(2)}</span>

          {quantity === 0 ? (
            <motion.button
              whileTap={{ scale: 0.9 }}
              disabled={!item.isAvailable}
              onClick={onAdd}
              transition={{ type: "spring", stiffness: 400, damping: 25 }}
              className="flex h-9 min-w-[48px] items-center justify-center gap-1 rounded-full bg-[var(--color-primary)] px-3 text-xs font-bold text-[var(--color-primary-foreground)] disabled:bg-[var(--color-muted)] disabled:text-[var(--color-muted-foreground)]"
            >
              <Plus size={14} /> Add
            </motion.button>
          ) : (
            <div className="flex items-center gap-2 rounded-full bg-[var(--color-surface-elevated)] px-1">
              <motion.button
                whileTap={{ scale: 0.85 }}
                onClick={onRemove}
                className="flex h-8 w-8 items-center justify-center rounded-full text-[var(--color-foreground)]"
              >
                <Minus size={14} />
              </motion.button>
              <motion.span
                key={quantity}
                initial={{ scale: 0.6, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 500, damping: 20 }}
                className="w-4 text-center text-sm font-bold"
              >
                {quantity}
              </motion.span>
              <motion.button
                whileTap={{ scale: 0.85 }}
                onClick={onAdd}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-primary)] text-[var(--color-primary-foreground)]"
              >
                <Plus size={14} />
              </motion.button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
