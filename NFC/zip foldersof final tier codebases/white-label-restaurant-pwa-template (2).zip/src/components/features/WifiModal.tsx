import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Wifi, Copy, Check, Eye, EyeOff } from "lucide-react";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from "../ui/Drawer";
import { restaurantConfig } from "../../config/restaurant.config";
import { useHaptics } from "../../hooks/useHaptics";

interface WifiModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WifiModal({ open, onOpenChange }: WifiModalProps) {
  const { wifi } = restaurantConfig.brand;
  const [showPass, setShowPass] = useState(false);
  const [copied, setCopied] = useState(false);
  const { vibrate } = useHaptics();

  const wifiQrString = `WIFI:T:WPA;S:${wifi.ssid};P:${wifi.pass};;`;

  const handleCopy = () => {
    vibrate("light");
    navigator.clipboard?.writeText(wifi.pass);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent>
        <DrawerHeader className="text-center">
          <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-[var(--color-primary)]/15">
            <Wifi size={22} className="text-[var(--color-primary)]" />
          </div>
          <DrawerTitle className="text-center">Instant WiFi Access</DrawerTitle>
          <DrawerDescription className="text-center">Scan or enter the details manually.</DrawerDescription>
        </DrawerHeader>

        <div className="flex flex-col items-center gap-5 px-5 pb-safe pt-2">
          <div className="rounded-2xl bg-white p-4">
            <QRCodeSVG value={wifiQrString} size={160} />
          </div>

          <div className="w-full space-y-3">
            <div className="flex items-center justify-between rounded-[var(--radius)] border border-[var(--color-border)] bg-[var(--color-surface-elevated)] px-4 py-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-[var(--color-muted-foreground)]">Network</p>
                <p className="text-sm font-bold">{wifi.ssid}</p>
              </div>
            </div>
            <div className="flex items-center justify-between rounded-[var(--radius)] border border-[var(--color-border)] bg-[var(--color-surface-elevated)] px-4 py-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-[var(--color-muted-foreground)]">Password</p>
                <p className="text-sm font-bold tracking-wide">
                  {showPass ? wifi.pass : "•".repeat(wifi.pass.length)}
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setShowPass((s) => !s)}
                  className="flex h-9 w-9 items-center justify-center rounded-full text-[var(--color-muted-foreground)]"
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
                <button
                  onClick={handleCopy}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--color-primary)]/15 text-[var(--color-primary)]"
                >
                  {copied ? <Check size={16} /> : <Copy size={16} />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
