import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ExternalLink, Send, CheckCircle2, Loader2 } from "lucide-react";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Textarea, Input } from "../ui/Input";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService } from "../../services/api.service";
import { useHaptics } from "../../hooks/useHaptics";

interface ReviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * Smart Review Filter — routes happy guests (4-5★) to the public Google
 * review link, and routes anything less to a private manager feedback form,
 * protecting the public rating while still capturing actionable feedback.
 */
export function ReviewModal({ open, onOpenChange }: ReviewModalProps) {
  const [rating, setRating] = useState(0);
  const [hovered, setHovered] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [name, setName] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  const { vibrate } = useHaptics();

  const reset = () => {
    setRating(0);
    setFeedback("");
    setName("");
    setStatus("idle");
  };

  const handleRate = (val: number) => {
    vibrate("medium");
    setRating(val);
    apiService.sendReviewSignal(val);
  };

  const handleFeedbackSubmit = async () => {
    vibrate("medium");
    setStatus("submitting");
    await apiService.sendFeedback({ rating, name, message: feedback });
    vibrate("success");
    setStatus("success");
    setTimeout(() => {
      reset();
      onOpenChange(false);
    }, 1800);
  };

  const isHappyPath = rating >= 4;

  return (
    <Drawer
      open={open}
      onOpenChange={(o) => {
        onOpenChange(o);
        if (!o) setTimeout(reset, 300);
      }}
    >
      <DrawerContent>
        <DrawerHeader className="text-center">
          <DrawerTitle className="text-center">How was your experience?</DrawerTitle>
          <DrawerDescription className="text-center">Your feedback helps us improve.</DrawerDescription>
        </DrawerHeader>

        <div className="px-5 pb-safe pt-2">
          {status === "success" ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center gap-3 py-12 text-center"
            >
              <CheckCircle2 size={44} className="text-[var(--color-primary)]" />
              <p className="font-bold">Thank you for your feedback!</p>
              <p className="text-sm text-[var(--color-muted-foreground)]">
                It's been sent straight to our management team.
              </p>
            </motion.div>
          ) : (
            <>
              <div className="flex justify-center gap-2 py-4">
                {[1, 2, 3, 4, 5].map((val) => (
                  <motion.button
                    key={val}
                    whileTap={{ scale: 0.8 }}
                    onMouseEnter={() => setHovered(val)}
                    onMouseLeave={() => setHovered(0)}
                    onClick={() => handleRate(val)}
                    transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    className="flex h-11 w-11 items-center justify-center"
                  >
                    <Star
                      size={32}
                      className={
                        val <= (hovered || rating)
                          ? "fill-[var(--color-accent)] text-[var(--color-accent)]"
                          : "text-[var(--color-muted-foreground)]"
                      }
                    />
                  </motion.button>
                ))}
              </div>

              <AnimatePresence mode="wait">
                {rating > 0 && (
                  <motion.div
                    key={isHappyPath ? "happy" : "sad"}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  >
                    {isHappyPath ? (
                      <div className="space-y-3 text-center">
                        <p className="text-sm text-[var(--color-muted-foreground)]">
                          We're thrilled you loved it! Mind sharing it publicly?
                        </p>
                        <Button
                          variant="accent"
                          size="lg"
                          className="w-full"
                          onClick={() => {
                            vibrate("success");
                            window.open(restaurantConfig.brand.googleReviewUrl, "_blank");
                          }}
                        >
                          <ExternalLink size={17} /> Post Public Review on Google
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <p className="text-center text-sm text-[var(--color-muted-foreground)]">
                          Tell the manager what we can improve — this stays private.
                        </p>
                        <Input
                          placeholder="Your name (optional)"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                        />
                        <Textarea
                          rows={4}
                          placeholder="What could we have done better?"
                          value={feedback}
                          onChange={(e) => setFeedback(e.target.value)}
                        />
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          )}
        </div>

        {rating > 0 && rating < 4 && status !== "success" && (
          <DrawerFooter>
            <Button
              variant="primary"
              size="lg"
              className="w-full"
              disabled={!feedback.trim() || status === "submitting"}
              onClick={handleFeedbackSubmit}
            >
              {status === "submitting" ? (
                <>
                  <Loader2 size={18} className="animate-spin" /> Sending...
                </>
              ) : (
                <>
                  <Send size={17} /> Send Private Feedback
                </>
              )}
            </Button>
          </DrawerFooter>
        )}
      </DrawerContent>
    </Drawer>
  );
}
