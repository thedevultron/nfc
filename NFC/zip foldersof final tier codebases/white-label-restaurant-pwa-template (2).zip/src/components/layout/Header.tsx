import { motion } from "framer-motion";
import { Wifi, MessageCircle, Star, CalendarClock, Radio, Download } from "lucide-react";
import { restaurantConfig } from "../../config/restaurant.config";
import { usePWAInstall } from "../../hooks/usePWAInstall";
import { useHaptics } from "../../hooks/useHaptics";
import type { TouchpointMode } from "../../types/menu.types";

interface HeaderProps {
  touchpointMode: TouchpointMode;
  tableLabel: string;
  onOpenWifi: () => void;
  onOpenReview: () => void;
  onOpenBooking: () => void;
}

const MODE_LABEL: Record<TouchpointMode, string> = {
  "dine-in": "Tap Mode Active",
  takeaway: "Takeaway Mode",
  delivery: "Delivery Mode",
};

/**
 * Dynamic Action Header — reads brand + feature toggles from
 * restaurant.config.ts so quick actions appear/disappear per client without
 * touching this component.
 */
export function Header({ touchpointMode, tableLabel, onOpenWifi, onOpenReview, onOpenBooking }: HeaderProps) {
  const { brand, features } = restaurantConfig;
  const { canInstall, promptInstall } = usePWAInstall();
  const { vibrate } = useHaptics();

  const whatsappHref = `https://wa.me/${brand.whatsappNumber.replace(/[^\d]/g, "")}?text=${encodeURIComponent(
    `Hi ${brand.name}! I'd like some assistance.`
  )}`;

  const actions = [
    features.enableWifi && {
      key: "wifi",
      label: "WiFi",
      icon: Wifi,
      onClick: () => {
        vibrate("light");
        onOpenWifi();
      },
    },
    features.enableDirectOrdering && {
      key: "whatsapp",
      label: "WhatsApp",
      icon: MessageCircle,
      onClick: () => {
        vibrate("light");
        window.open(whatsappHref, "_blank");
      },
    },
    features.enableReviews && {
      key: "review",
      label: "Review",
      icon: Star,
      onClick: () => {
        vibrate("light");
        onOpenReview();
      },
    },
    features.enableBookings && {
      key: "booking",
      label: "Book",
      icon: CalendarClock,
      onClick: () => {
        vibrate("light");
        onOpenBooking();
      },
    },
  ].filter(Boolean) as { key: string; label: string; icon: typeof Wifi; onClick: () => void }[];

  return (
    <header className="safe-top glass sticky top-0 z-30 border-b border-[var(--color-border)] px-5 pb-4 pt-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight">{brand.name}</h1>
          <p className="text-xs text-[var(--color-muted-foreground)]">{brand.subtitle}</p>
        </div>

        {features.enablePWAInstallPrompt && canInstall && (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => promptInstall()}
            className="flex h-11 w-11 items-center justify-center rounded-full bg-[var(--color-primary)]/15 text-[var(--color-primary)]"
            aria-label="Install app"
          >
            <Download size={18} />
          </motion.button>
        )}
      </div>

      <motion.div
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-3 inline-flex items-center gap-2 rounded-full bg-[var(--color-primary)]/15 px-3 py-1.5 text-[11px] font-bold text-[var(--color-primary)]"
      >
        <Radio size={12} className="animate-pulse" />
        {tableLabel} · {MODE_LABEL[touchpointMode]}
      </motion.div>

      <div className="mt-4 grid grid-cols-4 gap-2.5">
        {actions.map((action, i) => (
          <motion.button
            key={action.key}
            onClick={action.onClick}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05, type: "spring", stiffness: 400, damping: 25 }}
            whileTap={{ scale: 0.92 }}
            className="flex min-h-[64px] flex-col items-center justify-center gap-1.5 rounded-[var(--radius)] border border-[var(--color-border)] bg-[var(--color-surface)] py-2 active:bg-[var(--color-surface-elevated)]"
          >
            <action.icon size={19} className="text-[var(--color-primary)]" />
            <span className="text-[10px] font-semibold text-[var(--color-muted-foreground)]">
              {action.label}
            </span>
          </motion.button>
        ))}
      </div>
    </header>
  );
}
