import { motion } from "framer-motion";
import { UtensilsCrossed, Heart, ShoppingBag, CalendarClock } from "lucide-react";
import { useHaptics } from "../../hooks/useHaptics";
import { restaurantConfig } from "../../config/restaurant.config";

export type MainTab = "menu" | "favorites";

interface BottomNavProps {
  activeTab: MainTab;
  onTabChange: (tab: MainTab) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenBooking: () => void;
}

/**
 * Fixed bottom nav with a shared-layout sliding indicator (layoutId) between
 * page tabs, plus quick-action buttons for Cart & Booking with live badges.
 */
export function BottomNav({ activeTab, onTabChange, cartCount, onOpenCart, onOpenBooking }: BottomNavProps) {
  const { vibrate } = useHaptics();
  const { features } = restaurantConfig;

  const tabs: { key: MainTab; label: string; icon: typeof UtensilsCrossed }[] = [
    { key: "menu", label: "Menu", icon: UtensilsCrossed },
    ...(features.enableFavorites ? [{ key: "favorites" as MainTab, label: "Saved", icon: Heart }] : []),
  ];

  return (
    <nav className="safe-bottom glass sticky bottom-0 z-30 grid grid-cols-4 items-center gap-1 border-t border-[var(--color-border)] px-3 pb-safe pt-2">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.key;
        return (
          <button
            key={tab.key}
            onClick={() => {
              vibrate("light");
              onTabChange(tab.key);
            }}
            className="relative flex min-h-[48px] flex-col items-center justify-center gap-1 rounded-2xl py-1.5"
          >
            {isActive && (
              <motion.div
                layoutId="bottomNavIndicator"
                className="absolute inset-0 rounded-2xl bg-[var(--color-primary)]/15"
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              />
            )}
            <tab.icon
              size={20}
              className={`relative z-10 transition-colors ${isActive ? "text-[var(--color-primary)]" : "text-[var(--color-muted-foreground)]"}`}
              fill={tab.key === "favorites" && isActive ? "currentColor" : "none"}
            />
            <span
              className={`relative z-10 text-[10px] font-bold transition-colors ${isActive ? "text-[var(--color-primary)]" : "text-[var(--color-muted-foreground)]"}`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}

      {features.enableBookings && (
        <button
          onClick={() => {
            vibrate("light");
            onOpenBooking();
          }}
          className="flex min-h-[48px] flex-col items-center justify-center gap-1 rounded-2xl py-1.5 text-[var(--color-muted-foreground)]"
        >
          <CalendarClock size={20} />
          <span className="text-[10px] font-bold">Book</span>
        </button>
      )}

      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => {
          vibrate("medium");
          onOpenCart();
        }}
        className="relative flex min-h-[48px] flex-col items-center justify-center gap-1 rounded-2xl py-1.5 text-[var(--color-muted-foreground)]"
      >
        <div className="relative">
          <ShoppingBag size={20} />
          {cartCount > 0 && (
            <motion.span
              key={cartCount}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 500, damping: 20 }}
              className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-[var(--color-accent)] text-[9px] font-bold text-[var(--color-accent-foreground)]"
            >
              {cartCount}
            </motion.span>
          )}
        </div>
        <span className="text-[10px] font-bold">Cart</span>
      </motion.button>
    </nav>
  );
}
