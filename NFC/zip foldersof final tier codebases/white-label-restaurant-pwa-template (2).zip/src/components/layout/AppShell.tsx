import * as React from "react";
import { themeConfig } from "../../config/theme.config";

/**
 * ============================================================================
 * APP SHELL — /src/components/layout/AppShell.tsx
 * ============================================================================
 * Converts /src/config/theme.config.ts into live CSS custom properties for
 * the whole tree. This is the ONLY place theme.config.ts values get read —
 * every other component simply consumes `var(--color-*)` / `var(--radius)`.
 * Re-skinning the entire PWA for a new client = editing theme.config.ts only.
 * ============================================================================
 */
export function AppShell({ children }: { children: React.ReactNode }) {
  const t = themeConfig;

  const styleVars = {
    "--color-primary": `hsl(${t.primaryColor})`,
    "--color-primary-foreground": `hsl(${t.primaryForeground})`,
    "--color-accent": `hsl(${t.accentColor})`,
    "--color-accent-foreground": `hsl(${t.accentForeground})`,
    "--color-background": `hsl(${t.backgroundColor})`,
    "--color-surface": `hsl(${t.surfaceColor})`,
    "--color-surface-elevated": `hsl(${t.surfaceElevated})`,
    "--color-muted": `hsl(${t.mutedColor})`,
    "--color-muted-foreground": `hsl(${t.mutedForeground})`,
    "--color-border": `hsl(${t.borderColor})`,
    "--color-destructive": `hsl(${t.destructiveColor})`,
    "--color-foreground": t.defaultMode === "dark" ? "#fafafa" : "#0a0a0b",
    "--radius": t.radius,
    "--font-sans": t.fontFamily,
  } as React.CSSProperties;

  return (
    <div
      className={t.defaultMode === "dark" ? "dark" : ""}
      style={styleVars}
      data-density={t.density}
    >
      <div className="relative mx-auto flex min-h-[100dvh] w-full max-w-md flex-col overflow-hidden bg-[var(--color-background)] text-[var(--color-foreground)] shadow-2xl md:my-4 md:min-h-[calc(100dvh-2rem)] md:rounded-[2rem] md:border md:border-[var(--color-border)]">
        {children}
      </div>
    </div>
  );
}
