import { useEffect, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { Shell } from "./components/layout/Shell";
import { TopBar } from "./components/layout/TopBar";
import { Header } from "./components/layout/Header";
import { Ticker } from "./components/layout/Ticker";
import { BottomNav, type NavTab } from "./components/layout/BottomNav";
import { Footer } from "./components/layout/Footer";
import { MenuList } from "./components/features/MenuList";
import { CartSheet } from "./components/features/CartSheet";
import { ReservationSheet } from "./components/features/ReservationSheet";
import { ReviewModal } from "./components/features/ReviewModal";
import { WifiModal } from "./components/features/WifiModal";
import { Toaster, toast } from "./components/ui/Toaster";
import { Button } from "./components/ui/Button";
import { DynamicIcon } from "./components/ui/DynamicIcon";
import { useCart } from "./hooks/useCart";
import { usePWAInstall } from "./hooks/usePWAInstall";
import { buildConciergeLink } from "./services/api.service";
import { restaurantConfig } from "./config/restaurant.config";
import type { ServiceMode } from "./types/menu.types";

/* ──────────────────────────────────────────────────────────────────────────
 *  APP ROOT — pure composition.
 *  The shell wires config-driven features to their sheets/modals; every
 *  visual/behavioural detail lives in /config, /services, /hooks and the
 *  component modules. New client = new config files, zero edits here.
 * ────────────────────────────────────────────────────────────────────────── */

export default function App() {
  const cart = useCart();
  const pwa = usePWAInstall();

  const [mode, setMode] = useState<ServiceMode>("dinein");
  const [activeTab, setActiveTab] = useState<NavTab>("menu");
  const [wifiOpen, setWifiOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reservationOpen, setReservationOpen] = useState(false);

  // PWA: register the service worker in production builds only.
  useEffect(() => {
    if (import.meta.env.PROD && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("sw.js").catch(() => {
        /* optional enhancement */
      });
    }
  }, []);

  const navigate = (tab: NavTab) => {
    switch (tab) {
      case "menu":
        setActiveTab("menu");
        window.scrollTo({ top: 0, behavior: "smooth" });
        break;
      case "info":
        setActiveTab("info");
        requestAnimationFrame(() =>
          document.getElementById("info")?.scrollIntoView({ behavior: "smooth", block: "start" }),
        );
        break;
      case "cart":
        cart.open();
        break;
      case "book":
        setReservationOpen(true);
        break;
      case "review":
        setReviewOpen(true);
        break;
    }
  };

  const openWhatsApp = () => {
    window.open(buildConciergeLink(mode, restaurantConfig.service.defaultTableId), "_blank", "noopener");
    toast("Opening WhatsApp concierge…", "MessageCircle", "accent");
  };

  return (
    <MotionConfig reducedMotion="user">
      <Shell>
        <TopBar />
        <Header
          mode={mode}
          onModeChange={(m) => {
            setMode(m);
            toast(m === "dinein" ? `Table ${restaurantConfig.service.defaultTableId} mode active` : "Switched to takeaway", "Nfc", "default");
          }}
          onWifi={() => setWifiOpen(true)}
          onWhatsApp={openWhatsApp}
          onReview={() => setReviewOpen(true)}
          onBook={() => setReservationOpen(true)}
        />
        <Ticker />
        <MenuList cart={cart} />
        <Footer onWifi={() => setWifiOpen(true)} />

        <BottomNav active={activeTab} cartCount={cart.count} onNavigate={navigate} />

        {/* Feature overlays */}
        <CartSheet cart={cart} mode={mode} />
        <ReservationSheet open={reservationOpen} onClose={() => setReservationOpen(false)} />
        <ReviewModal open={reviewOpen} onClose={() => setReviewOpen(false)} />
        <WifiModal open={wifiOpen} onClose={() => setWifiOpen(false)} />

        <InstallPrompt pwa={pwa} />
        <Toaster />
      </Shell>
    </MotionConfig>
  );
}

/* ── Native install prompt banner (PWA) ────────────────────────────────── */

function InstallPrompt({ pwa }: { pwa: ReturnType<typeof usePWAInstall> }) {
  const [dismissed, setDismissed] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(() => setVisible(true), 1400);
    return () => window.clearTimeout(t);
  }, []);

  const eligible =
    restaurantConfig.features.enableInstallPrompt && !pwa.installed && !dismissed && (pwa.canInstall || pwa.isIOS);

  const install = async () => {
    const accepted = await pwa.promptInstall();
    if (accepted) toast("Installing app…", "Download", "success");
    else setDismissed(true);
  };

  return (
    <AnimatePresence>
      {eligible && visible && (
        <motion.div
          initial={{ opacity: 0, y: 28, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 24, scale: 0.96 }}
          transition={{ type: "spring", stiffness: 380, damping: 28 }}
          className="fixed inset-x-0 bottom-[calc(5.75rem+env(safe-area-inset-bottom))] z-40 px-4"
        >
          <div className="glass mx-auto flex max-w-md items-center gap-3 rounded-[calc(var(--radius)*0.95)] border border-primary/30 p-3 shadow-[0_20px_50px_-20px_hsl(160_50%_3%/0.9)]">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-[calc(var(--radius)*0.65)] bg-primary/14 text-primary">
              <DynamicIcon name={pwa.isIOS ? "Smartphone" : "Download"} size={20} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[0.84rem] font-bold leading-tight">Add {restaurantConfig.brand.name} to your phone</p>
              <p className="truncate text-[0.7rem] text-mute">
                {pwa.isIOS ? "Tap Share → “Add to Home Screen”" : "One tap — full screen menu, works offline"}
              </p>
            </div>
            {!pwa.isIOS && (
              <Button size="sm" onClick={install}>
                Install
              </Button>
            )}
            <button
              aria-label="Dismiss install prompt"
              onClick={() => setDismissed(true)}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-mute hover:bg-raise hover:text-ink"
            >
              <DynamicIcon name="X" size={16} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
