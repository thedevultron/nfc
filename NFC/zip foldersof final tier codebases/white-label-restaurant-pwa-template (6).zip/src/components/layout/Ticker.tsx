import { menuItems } from "../../config/menuData";
import { DynamicIcon } from "../ui/DynamicIcon";
import { formatPrice } from "../../utils/format";

/* ──────────────────────────────────────────────────────────────────────────
 *  SPECIALS TICKER — ambient marquee of Best Seller dishes (data-driven).
 *  Pauses under prefers-reduced-motion.
 * ────────────────────────────────────────────────────────────────────────── */

export function Ticker() {
  const specials = menuItems.filter((i) => i.bestSeller && i.isAvailable);
  const loop = [...specials, ...specials];

  return (
    <div className="relative mt-4 overflow-hidden border-y border-line/70 bg-surface/50 py-2.5">
      <div className="ticker flex w-max items-center">
        {loop.map((item, idx) => (
          <span key={`${item.id}-${idx}`} className="mr-7 flex items-center gap-2 whitespace-nowrap" aria-hidden={idx >= specials.length}>
            <span className="text-accent">
              <DynamicIcon name="Sparkles" size={13} />
            </span>
            <span className="text-[0.72rem] font-bold uppercase tracking-[0.14em] text-ink/85">{item.name}</span>
            <span className="font-display text-[0.78rem] font-semibold italic text-accent">{formatPrice(item.price)}</span>
          </span>
        ))}
      </div>
      {/* edge fades */}
      <div aria-hidden className="pointer-events-none absolute inset-y-0 left-0 w-10 bg-gradient-to-r from-bg to-transparent" />
      <div aria-hidden className="pointer-events-none absolute inset-y-0 right-0 w-10 bg-gradient-to-l from-bg to-transparent" />
    </div>
  );
}
