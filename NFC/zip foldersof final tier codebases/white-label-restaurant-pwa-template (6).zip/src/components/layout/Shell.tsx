import { useLayoutEffect, type ReactNode } from "react";
import { applyTheme } from "../../config/theme.config";

/* ──────────────────────────────────────────────────────────────────────────
 *  SHELL — boots the theme from /config/theme.config.ts and renders the
 *  ambient layered background (tinted glows, grain, slow orbit ring) behind
 *  a centered mobile-app column. Components never set global chrome.
 * ────────────────────────────────────────────────────────────────────────── */

const GRAIN =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")";

export function Shell({ children }: { children: ReactNode }) {
  // Single side-effect: project config tokens → CSS variables.
  useLayoutEffect(() => {
    applyTheme();
  }, []);

  return (
    <div className="min-h-dvh bg-bg font-body text-ink antialiased">
      {/* ── Ambient layered background (fixed, behind everything) ─────── */}
      <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[34rem] w-[34rem] -translate-x-1/2 rounded-full bg-primary/14 blur-[110px]" />
        <div className="absolute -bottom-52 -right-32 h-[30rem] w-[30rem] rounded-full bg-accent/10 blur-[120px]" />
        <div className="absolute -left-40 top-1/3 h-[24rem] w-[24rem] rounded-full bg-primary/8 blur-[100px]" />
        {/* slow orbit ring — keeps the surface alive without noise */}
        <div className="orbit-ring absolute -right-28 -top-28 h-80 w-80 rounded-full border border-dashed border-primary/15" />
        <div className="orbit-ring-reverse absolute -bottom-24 -left-24 h-64 w-64 rounded-full border border-dashed border-accent/12" />
        <div className="absolute inset-0 opacity-[0.05] mix-blend-overlay" style={{ backgroundImage: GRAIN }} />
      </div>

      {/* ── App column ────────────────────────────────────────────────── */}
      <div className="relative mx-auto w-full max-w-md sm:border-x sm:border-line/60 sm:shadow-[0_0_120px_-40px_hsl(var(--primary)/0.25)]">
        {children}
      </div>
    </div>
  );
}
