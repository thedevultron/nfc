import { restaurantConfig } from "../../config/restaurant.config";
import { DynamicIcon } from "../ui/DynamicIcon";
import { useHaptics } from "../../hooks/useHaptics";

/* ──────────────────────────────────────────────────────────────────────────
 *  FOOTER / INFO PANEL — address, hours, phone, WiFi snapshot.
 *  Every row is config-driven; the "Info" nav tab scrolls here.
 * ────────────────────────────────────────────────────────────────────────── */

export function Footer({ onWifi }: { onWifi: () => void }) {
  const { brand, service, hours, features } = restaurantConfig;
  const haptics = useHaptics();
  const mapsUrl = `https://maps.google.com/?q=${encodeURIComponent(brand.address)}`;

  return (
    <footer id="info" className="mt-10 border-t border-line/70 bg-surface/40 px-5 pb-40 pt-8">
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-[calc(var(--radius)*0.6)] bg-primary/14 font-display text-base font-bold text-primary">
          {brand.monogram}
        </span>
        <div>
          <p className="font-display text-lg font-semibold leading-tight">{brand.name}</p>
          <p className="text-[0.64rem] font-semibold uppercase tracking-[0.18em] text-mute">{brand.subtitle}</p>
        </div>
      </div>

      <div className="mt-5 space-y-3.5 text-sm">
        <a href={mapsUrl} target="_blank" rel="noreferrer" className="group flex items-start gap-3 text-ink/90">
          <span className="mt-0.5 text-primary"><DynamicIcon name="MapPin" size={17} /></span>
          <span className="underline-offset-4 group-hover:underline">{brand.address}</span>
        </a>
        <a href={`tel:${brand.phone.replace(/\s/g, "")}`} className="group flex items-center gap-3 text-ink/90">
          <span className="text-primary"><DynamicIcon name="Phone" size={17} /></span>
          <span className="underline-offset-4 group-hover:underline">{brand.phone}</span>
        </a>
        {features.enableWifi && (
          <button onClick={() => { haptics.tap(); onWifi(); }} className="group flex w-full items-center gap-3 text-left text-ink/90">
            <span className="text-primary"><DynamicIcon name="Wifi" size={17} /></span>
            <span className="underline-offset-4 group-hover:underline">
              Guest WiFi · <span className="font-semibold">{brand.wifi.ssid}</span>
            </span>
            <span className="ml-auto text-mute"><DynamicIcon name="ChevronRight" size={16} /></span>
          </button>
        )}
      </div>

      <div className="mt-6 rounded-[calc(var(--radius)*0.9)] border border-line bg-raise/50 p-4">
        <p className="flex items-center gap-2 text-[0.68rem] font-bold uppercase tracking-[0.16em] text-mute">
          <DynamicIcon name="Clock" size={14} /> Opening Hours
        </p>
        <ul className="mt-3 space-y-1.5">
          {hours.map((h) => (
            <li key={h.days} className="flex justify-between text-[0.82rem]">
              <span className="text-mute">{h.days}</span>
              <span className="font-semibold tabular-nums">{h.hours}</span>
            </li>
          ))}
        </ul>
      </div>

      <p className="mt-6 text-center text-[0.66rem] leading-relaxed text-mute">
        White-label PWA template · re-skin entirely from <span className="font-semibold text-ink/70">/src/config</span>
        <br />
        {brand.name} · Table {service.defaultTableId} experience · v1.0
      </p>
    </footer>
  );
}
