import { motion } from "framer-motion";
import { restaurantConfig } from "../../config/restaurant.config";

/* ──────────────────────────────────────────────────────────────────────────
 *  TOP BAR — icon-driven monogram tile + brand name + live status pill.
 *  Everything (name, subtitle, monogram letter, status line) is read from
 *  restaurant.config — nothing here is hard-coded.
 * ────────────────────────────────────────────────────────────────────────── */

export function TopBar() {
  const { brand, service } = restaurantConfig;

  return (
    <motion.header
      initial={{ opacity: 0, y: -12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 26 }}
      className="flex items-center gap-3 px-5 pb-2 pt-[max(env(safe-area-inset-top),1.25rem)]"
    >
      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-[calc(var(--radius)*0.85)] bg-primary font-display text-[1.5rem] font-bold text-primary-ink shadow-[0_10px_28px_-10px_hsl(var(--primary)/0.6)]">
        {brand.monogram}
      </div>
      <div className="min-w-0">
        <h1 className="truncate font-display text-[1.28rem] font-semibold leading-tight tracking-[-0.02em]">
          {brand.name}
        </h1>
        <p className="truncate text-[0.68rem] font-semibold uppercase tracking-[0.18em] text-mute">
          {brand.subtitle}
        </p>
      </div>

      <div className="ml-auto flex shrink-0 items-center gap-1.5 rounded-full border border-line bg-surface/70 py-1.5 pl-2.5 pr-3 text-[0.7rem] font-bold text-ink">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
        </span>
        <span className="whitespace-nowrap">{service.kitchenStatus}</span>
      </div>
    </motion.header>
  );
}
