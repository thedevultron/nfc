import { AnimatePresence, motion } from "framer-motion";
import { restaurantConfig } from "../../config/restaurant.config";
import { DynamicIcon } from "../ui/DynamicIcon";
import { useHaptics } from "../../hooks/useHaptics";
import { cn } from "../../utils/cn";

/* ──────────────────────────────────────────────────────────────────────────
 *  FIXED BOTTOM NAV — icon-driven, safe-area aware.
 *  Tabs are derived from feature flags (Book / Review disappear when their
 *  feature is off). Cart sits center-stage as a raised primary action with
 *  an animated count badge; the active-tab pill slides via layoutId.
 * ────────────────────────────────────────────────────────────────────────── */

export type NavTab = "menu" | "book" | "cart" | "review" | "info";

interface BottomNavProps {
  active: NavTab;
  cartCount: number;
  onNavigate: (tab: NavTab) => void;
}

export function BottomNav({ active, cartCount, onNavigate }: BottomNavProps) {
  const { features } = restaurantConfig;
  const haptics = useHaptics();

  const left: { id: NavTab; icon: string; label: string }[] = [{ id: "menu", icon: "Utensils", label: "Menu" }];
  if (features.enableBookings) left.push({ id: "book", icon: "CalendarDays", label: "Book" });

  const right: { id: NavTab; icon: string; label: string }[] = [];
  if (features.enableReviews) right.push({ id: "review", icon: "Star", label: "Rate" });
  right.push({ id: "info", icon: "Info", label: "Info" });

  const renderTab = (tab: { id: NavTab; icon: string; label: string }) => {
    const isActive = active === tab.id;
    return (
      <motion.button
        key={tab.id}
        whileTap={{ scale: 0.88 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => {
          haptics.tick();
          onNavigate(tab.id);
        }}
        aria-label={tab.label}
        className="relative flex min-h-[56px] flex-1 flex-col items-center justify-center gap-1"
      >
        {isActive && (
          <motion.span
            layoutId="nav-pill"
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="absolute top-1 h-9 w-14 rounded-full bg-primary/14"
          />
        )}
        <span className={cn("relative transition-colors", isActive ? "text-primary" : "text-mute")}>
          <DynamicIcon name={tab.icon} size={21} />
        </span>
        <span className={cn("relative text-[0.6rem] font-bold uppercase tracking-[0.1em]", isActive ? "text-primary" : "text-mute")}>
          {tab.label}
        </span>
      </motion.button>
    );
  };

  return (
    <nav className="fixed inset-x-0 bottom-0 z-50">
      <div className="glass mx-auto flex max-w-md items-stretch border-t border-line px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-1.5 sm:border-x">
        {left.map(renderTab)}

        {/* Raised cart action */}
        <div className="relative flex w-20 justify-center">
          <motion.button
            whileTap={{ scale: 0.9 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            onClick={() => {
              haptics.select();
              onNavigate("cart");
            }}
            aria-label={`Open cart, ${cartCount} items`}
            className="relative -mt-7 grid h-16 w-16 place-items-center rounded-full bg-primary text-primary-ink shadow-[0_14px_34px_-10px_hsl(var(--primary)/0.65)] ring-4 ring-bg"
          >
            <DynamicIcon name="ShoppingBag" size={25} />
            <AnimatePresence>
              {cartCount > 0 && (
                <motion.span
                  key={cartCount}
                  initial={{ scale: 0.4, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.4, opacity: 0 }}
                  transition={{ type: "spring", stiffness: 500, damping: 22 }}
                  className="absolute -right-1 -top-1 grid h-6 min-w-6 place-items-center rounded-full bg-accent px-1 text-[0.68rem] font-extrabold text-accent-ink"
                >
                  {cartCount}
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
        </div>

        {right.map(renderTab)}
      </div>
    </nav>
  );
}
