import { motion } from "framer-motion";
import { restaurantConfig } from "../../config/restaurant.config";
import { DynamicIcon } from "../ui/DynamicIcon";
import { useHaptics } from "../../hooks/useHaptics";
import type { ServiceMode } from "../../types/menu.types";
import { cn } from "../../utils/cn";

/* ──────────────────────────────────────────────────────────────────────────
 *  MODULE A · DYNAMIC ACTION HEADER
 *  • NFC touchpoint context badge — reflects the current interaction mode
 *    ("Table 04 · Tap Mode Active" vs "Takeaway Mode") with a segmented
 *    mode switch whose thumb slides via layoutId.
 *  • Quick-action grid — built ENTIRELY from feature flags in config;
 *    disabled features simply never render. Icons are Lucide only.
 * ────────────────────────────────────────────────────────────────────────── */

interface HeaderProps {
  mode: ServiceMode;
  onModeChange: (mode: ServiceMode) => void;
  onWifi: () => void;
  onWhatsApp: () => void;
  onReview: () => void;
  onBook: () => void;
}

export function Header({ mode, onModeChange, onWifi, onWhatsApp, onReview, onBook }: HeaderProps) {
  const { brand, service, features } = restaurantConfig;
  const haptics = useHaptics();

  const actions: {
    id: string;
    icon: string;
    label: string;
    sub: string;
    tone: "primary" | "accent";
    run: () => void;
  }[] = [];

  if (features.enableWifi)
    actions.push({ id: "wifi", icon: "Wifi", label: "Instant WiFi", sub: brand.wifi.ssid, tone: "primary", run: onWifi });
  if (features.enableWhatsApp)
    actions.push({ id: "wa", icon: "MessageCircle", label: "WhatsApp", sub: "Concierge chat", tone: "accent", run: onWhatsApp });
  if (features.enableReviews)
    actions.push({ id: "rate", icon: "Star", label: "Rate Visit", sub: "30-sec review", tone: "accent", run: onReview });
  if (features.enableBookings)
    actions.push({ id: "book", icon: "CalendarDays", label: "Book Table", sub: "Reserve tonight", tone: "primary", run: onBook });

  return (
    <section className="px-5 pt-3">
      {/* ── NFC touchpoint context card ─────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 26, delay: 0.06 }}
        className="relative overflow-hidden rounded-[calc(var(--radius)*1.1)] border border-primary/25 bg-surface/80 p-4"
      >
        <div aria-hidden className="absolute -right-10 -top-14 h-36 w-36 rounded-full bg-primary/12 blur-2xl" />
        <div className="relative flex items-center gap-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-[calc(var(--radius)*0.7)] bg-primary/14 text-primary">
            <DynamicIcon name="Nfc" size={22} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[0.95rem] font-bold tracking-[-0.01em]">
              {mode === "dinein" ? `Table ${service.defaultTableId} · Tap Mode Active` : "Takeaway Mode"}
            </p>
            <p className="truncate text-[0.75rem] text-mute">
              {mode === "dinein" ? "NFC touchpoint paired — orders route to your table" : "Orders routed to the pickup counter"}
            </p>
          </div>

          {/* segmented mode switch */}
          <div className="flex shrink-0 rounded-full border border-line bg-raise/80 p-1" role="tablist" aria-label="Service mode">
            {(["dinein", "takeaway"] as const).map((m) => (
              <button
                key={m}
                role="tab"
                aria-selected={mode === m}
                onClick={() => {
                  haptics.tick();
                  onModeChange(m);
                }}
                className={cn(
                  "relative min-h-[36px] rounded-full px-2.5 text-[0.68rem] font-bold uppercase tracking-[0.06em] transition-colors",
                  mode === m ? "text-primary-ink" : "text-mute hover:text-ink",
                )}
              >
                {mode === m && (
                  <motion.span
                    layoutId="mode-thumb"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    className="absolute inset-0 rounded-full bg-primary"
                  />
                )}
                <span className="relative">{m === "dinein" ? "Dine-In" : "Takeaway"}</span>
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* ── Quick action grid (config-driven, icon-only aesthetic) ──── */}
      <div className="mt-3 grid grid-cols-4 gap-2.5">
        {actions.map((a, i) => (
          <motion.button
            key={a.id}
            initial={{ opacity: 0, y: 18, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ type: "spring", stiffness: 400, damping: 25, delay: 0.1 + i * 0.05 }}
            whileTap={{ scale: 0.92 }}
            whileHover={{ y: -3 }}
            onClick={() => {
              haptics.tap();
              a.run();
            }}
            className="glass group flex min-h-[86px] flex-col items-center justify-center gap-2 rounded-[calc(var(--radius)*0.95)] border border-line p-2 text-center"
          >
            <span
              className={cn(
                "grid h-11 w-11 place-items-center rounded-[calc(var(--radius)*0.7)] transition-transform duration-200 group-active:scale-90",
                a.tone === "primary" ? "bg-primary/14 text-primary" : "bg-accent/16 text-accent",
              )}
            >
              <DynamicIcon name={a.icon} size={21} />
            </span>
            <span className="leading-none">
              <span className="block text-[0.72rem] font-bold">{a.label}</span>
              <span className="mt-1 block max-w-full truncate text-[0.62rem] text-mute">{a.sub}</span>
            </span>
          </motion.button>
        ))}
      </div>
    </section>
  );
}
