import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService, buildOrderWhatsAppLink } from "../../services/api.service";
import { Drawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Stepper } from "../ui/Stepper";
import { DynamicIcon } from "../ui/DynamicIcon";
import { toast } from "../ui/Toaster";
import { useHaptics } from "../../hooks/useHaptics";
import { formatPrice } from "../../utils/format";
import type { CartApi } from "../../hooks/useCart";
import type { ServiceMode } from "../../types/menu.types";

/* ──────────────────────────────────────────────────────────────────────────
 *  MODULE C · DYNAMIC CART SHEET
 *  Slide-up drawer with live quantity editing, per-line totals, special
 *  instructions, tax line from config, and two dispatch paths:
 *  "Send to Kitchen" (n8n order webhook) and "Order via WhatsApp"
 *  (URL-encoded order summary → wa.me deep link).
 * ────────────────────────────────────────────────────────────────────────── */

const spring = { type: "spring", stiffness: 400, damping: 28 } as const;

export function CartSheet({ cart, mode }: { cart: CartApi; mode: ServiceMode }) {
  const { service, features } = restaurantConfig;
  const haptics = useHaptics();
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "success">("idle");
  const [orderRef, setOrderRef] = useState("");

  const tax = Math.round(cart.subtotal * service.taxRate);
  const total = cart.subtotal + tax;

  const totals = { subtotal: cart.subtotal, tax, total };

  const placeKitchenOrder = async () => {
    haptics.select();
    setStatus("sending");
    const ref = `AURA-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    await apiService.sendOrder({
      orderRef: ref,
      tableId: service.defaultTableId,
      mode,
      lines: cart.lines.map((l) => ({ name: l.item.name, qty: l.qty, price: l.item.price, total: l.item.price * l.qty })),
      notes,
      ...totals,
    });
    setOrderRef(ref);
    setStatus("success");
    haptics.success();
  };

  const placeWhatsAppOrder = () => {
    haptics.success();
    window.open(buildOrderWhatsAppLink(cart.lines, totals, notes, mode, service.defaultTableId), "_blank", "noopener");
    toast("Order summary opened in WhatsApp", "MessageCircle", "success");
  };

  const finish = () => {
    cart.clear();
    setNotes("");
    setStatus("idle");
    cart.close();
    toast("Order sent to the kitchen", "ChefHat", "success");
  };

  return (
    <Drawer open={cart.isOpen} onOpenChange={(o) => { if (!o && status !== "sending") cart.close(); }} title="Your Tray" icon="ShoppingBag">
      {status === "success" ? (
        <motion.div
          key="success"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={spring}
          className="flex flex-col items-center pb-6 pt-4 text-center"
        >
          <motion.span
            initial={{ scale: 0.5, rotate: -12 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 16, delay: 0.08 }}
            className="grid h-20 w-20 place-items-center rounded-full bg-primary/16 text-primary"
          >
            <DynamicIcon name="Check" size={38} strokeWidth={2.5} />
          </motion.span>
          <h3 className="mt-4 font-display text-2xl font-semibold">Order fired to the kitchen</h3>
          <p className="mt-1.5 max-w-[260px] text-sm text-mute">
            Reference <span className="font-bold text-accent">{orderRef}</span>
            {" · "}
            {mode === "dinein" ? `serving to Table ${service.defaultTableId}` : "ready for counter pickup"}.
          </p>
          <div className="mt-5 w-full max-w-[300px] rounded-[calc(var(--radius)*0.8)] border border-line bg-raise/50 p-3.5 text-left text-[0.8rem]">
            {cart.lines.map((l) => (
              <div key={l.item.id} className="flex justify-between py-0.5">
                <span className="text-mute">{l.qty} × {l.item.name}</span>
                <span className="font-semibold tabular-nums">{formatPrice(l.item.price * l.qty)}</span>
              </div>
            ))}
            <div className="mt-1.5 flex justify-between border-t border-line pt-2 font-bold">
              <span>Total</span>
              <span className="tabular-nums">{formatPrice(total)}</span>
            </div>
          </div>
          <Button className="mt-6 w-full max-w-[300px]" onClick={finish}>
            <DynamicIcon name="UtensilsCrossed" size={18} /> Back to the menu
          </Button>
        </motion.div>
      ) : cart.lines.length === 0 ? (
        <div className="flex flex-col items-center pb-8 pt-6 text-center">
          <motion.span
            animate={{ y: [0, -6, 0] }}
            transition={{ repeat: Infinity, duration: 2.6, ease: "easeInOut" }}
            className="grid h-20 w-20 place-items-center rounded-full bg-raise text-mute"
          >
            <DynamicIcon name="ShoppingBag" size={34} />
          </motion.span>
          <h3 className="mt-4 font-display text-xl font-semibold">Your tray is empty</h3>
          <p className="mt-1 max-w-[240px] text-sm text-mute">Tap the + on any dish and it lands here, ready to fire to the kitchen.</p>
          <Button variant="soft" className="mt-5" onClick={cart.close}>
            <DynamicIcon name="Utensils" size={17} /> Browse the menu
          </Button>
        </div>
      ) : (
        <div className="pb-4">
          {/* Lines */}
          <ul className="space-y-2">
            <AnimatePresence initial={false}>
              {cart.lines.map((line) => (
                <motion.li
                  key={line.item.id}
                  layout
                  initial={{ opacity: 0, x: -18 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 24, transition: { duration: 0.16 } }}
                  transition={spring}
                  className="flex items-center gap-3 rounded-[calc(var(--radius)*0.8)] border border-line bg-raise/50 p-2.5"
                >
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[calc(var(--radius)*0.55)] bg-primary/12 text-primary">
                    <DynamicIcon name={line.item.icon} size={18} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[0.86rem] font-bold">{line.item.name}</p>
                    <p className="text-[0.72rem] text-mute">{formatPrice(line.item.price)} each</p>
                  </div>
                  <span className="w-14 text-right font-display text-[0.95rem] font-bold tabular-nums">
                    {formatPrice(line.item.price * line.qty)}
                  </span>
                  <Stepper
                    size="sm"
                    value={line.qty}
                    onIncrement={() => cart.increment(line.item.id)}
                    onDecrement={() => cart.decrement(line.item.id)}
                  />
                  <button
                    aria-label={`Remove ${line.item.name}`}
                    onClick={() => { haptics.tick(); cart.remove(line.item.id); }}
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-mute transition-colors hover:bg-danger/12 hover:text-danger"
                  >
                    <DynamicIcon name="Trash2" size={15} />
                  </button>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>

          {/* Notes */}
          <label className="mt-4 block">
            <span className="flex items-center gap-1.5 text-[0.72rem] font-bold uppercase tracking-[0.14em] text-mute">
              <DynamicIcon name="SquarePen" size={13} /> Special instructions
            </span>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={140}
              rows={2}
              placeholder="Less spice, no onion, birthday candle…"
              className="mt-2 w-full resize-none rounded-[calc(var(--radius)*0.7)] border border-line bg-raise/60 p-3.5 text-[0.88rem] outline-none transition-colors placeholder:text-mute focus:border-primary/60"
            />
            <span className="mt-1 block text-right text-[0.62rem] text-mute">{notes.length}/140</span>
          </label>

          {/* Totals */}
          <div className="mt-3 space-y-1.5 rounded-[calc(var(--radius)*0.8)] border border-line bg-raise/50 p-4 text-sm">
            <div className="flex justify-between text-mute">
              <span>Subtotal</span><span className="tabular-nums">{formatPrice(cart.subtotal)}</span>
            </div>
            <div className="flex justify-between text-mute">
              <span>GST ({Math.round(service.taxRate * 100)}%)</span><span className="tabular-nums">{formatPrice(tax)}</span>
            </div>
            <div className="flex items-baseline justify-between border-t border-line pt-2">
              <span className="font-bold">Total</span>
              <motion.span
                key={total}
                initial={{ scale: 1.12, color: "hsl(var(--accent))" }}
                animate={{ scale: 1, color: "hsl(var(--ink))" }}
                transition={{ duration: 0.35 }}
                className="font-display text-[1.45rem] font-bold tabular-nums"
              >
                {formatPrice(total)}
              </motion.span>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-4 space-y-2.5">
            {features.enableDirectOrdering && (
              <Button size="lg" full disabled={status === "sending"} onClick={placeKitchenOrder}>
                {status === "sending" ? (
                  <>
                    <span className="animate-spin"><DynamicIcon name="RefreshCw" size={18} /></span> Firing to kitchen…
                  </>
                ) : (
                  <>
                    <DynamicIcon name="ChefHat" size={19} /> Place Order via Kitchen
                  </>
                )}
              </Button>
            )}
            {features.enableWhatsApp && (
              <Button
                size="lg"
                full
                variant={features.enableDirectOrdering ? "outline" : "primary"}
                onClick={placeWhatsAppOrder}
              >
                <DynamicIcon name="MessageCircle" size={18} /> Order via WhatsApp
              </Button>
            )}
          </div>
        </div>
      )}
    </Drawer>
  );
}
