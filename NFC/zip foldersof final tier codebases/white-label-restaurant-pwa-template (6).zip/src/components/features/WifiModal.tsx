import { useMemo } from "react";
import { restaurantConfig } from "../../config/restaurant.config";
import { Modal } from "../ui/Modal";
import { DynamicIcon } from "../ui/DynamicIcon";
import { toast } from "../ui/Toaster";
import { useHaptics } from "../../hooks/useHaptics";
import { motion } from "framer-motion";

/* ──────────────────────────────────────────────────────────────────────────
 *  INSTANT WIFI MODAL
 *  SSID + password with one-tap copy, and a deterministic scannable-style
 *  QR panel generated in pure SVG from the credentials (icon-driven
 *  aesthetic — zero image assets). Swap credentials in restaurant.config.
 * ────────────────────────────────────────────────────────────────────────── */

const GRID = 21;

/** Tiny deterministic PRNG → stable "QR" pattern per credential string. */
function patternCells(seed: string): boolean[] {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const cells: boolean[] = [];
  let state = h >>> 0;
  for (let i = 0; i < GRID * GRID; i++) {
    state = (Math.imul(state, 1103515245) + 12345) >>> 0;
    cells.push((state >>> 16 & 1) === 1);
  }
  return cells;
}

function PseudoQr({ seed }: { seed: string }) {
  const cells = useMemo(() => patternCells(seed), [seed]);

  const inFinder = (x: number, y: number) =>
    (x < 7 && y < 7) || (x >= GRID - 7 && y < 7) || (x < 7 && y >= GRID - 7);

  const finder = (fx: number, fy: number, key: string) => (
    <g key={key}>
      <rect x={fx} y={fy} width={7} height={7} fill="none" stroke="hsl(158 30% 14%)" strokeWidth={1} />
      <rect x={fx + 2} y={fy + 2} width={3} height={3} fill="hsl(158 30% 14%)" />
    </g>
  );

  return (
    <svg viewBox={`-1.5 -1.5 ${GRID + 3} ${GRID + 3}`} className="h-44 w-44" role="img" aria-label="WiFi QR code">
      <rect x={-1.5} y={-1.5} width={GRID + 3} height={GRID + 3} rx={1.5} fill="hsl(48 40% 96%)" />
      {cells.map((on, i) => {
        const x = i % GRID;
        const y = Math.floor(i / GRID);
        if (!on || inFinder(x, y)) return null;
        // keep an inner quiet ring around finders for authenticity
        const nearFinder =
          (x <= 7 && y <= 7) || (x >= GRID - 8 && y <= 7) || (x <= 7 && y >= GRID - 8);
        if (nearFinder && (x === 7 || y === 7 || x === GRID - 8 || y === GRID - 8)) return null;
        return <rect key={i} x={x + 0.06} y={y + 0.06} width={0.88} height={0.88} rx={0.18} fill="hsl(158 32% 13%)" />;
      })}
      {finder(0, 0, "f1")}
      {finder(GRID - 7, 0, "f2")}
      {finder(0, GRID - 7, "f3")}
    </svg>
  );
}

export function WifiModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { brand } = restaurantConfig;
  const haptics = useHaptics();

  const copy = async (value: string, what: string) => {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = value;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    haptics.success();
    toast(`${what} copied to clipboard`, "Copy", "success");
  };

  const row = (icon: string, label: string, value: string, mask?: boolean) => (
    <div className="flex items-center gap-3 rounded-[calc(var(--radius)*0.8)] border border-line bg-raise/50 p-3.5">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[calc(var(--radius)*0.6)] bg-primary/12 text-primary">
        <DynamicIcon name={icon} size={18} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[0.64rem] font-bold uppercase tracking-[0.16em] text-mute">{label}</p>
        <p className="truncate font-mono text-[0.92rem] font-bold tracking-wide">{mask ? value : value}</p>
      </div>
      <motion.button
        whileTap={{ scale: 0.85 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => copy(value, label)}
        aria-label={`Copy ${label}`}
        className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-line bg-surface text-mute transition-colors hover:border-primary/50 hover:text-primary"
      >
        <DynamicIcon name="Copy" size={16} />
      </motion.button>
    </div>
  );

  return (
    <Modal open={open} onClose={onClose} title="Instant Guest WiFi" icon="Wifi">
      <motion.div
        initial={{ opacity: 0, scale: 0.94 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 380, damping: 26, delay: 0.05 }}
        className="flex flex-col items-center rounded-[calc(var(--radius)*0.9)] border border-line bg-surface/60 p-5"
      >
        <div className="rounded-[calc(var(--radius)*0.6)] p-2 shadow-[0_16px_40px_-18px_hsl(160_50%_3%/0.7)]">
          <PseudoQr seed={`WIFI:S:${brand.wifi.ssid};P:${brand.wifi.pass};`} />
        </div>
        <p className="mt-3 flex items-center gap-1.5 text-[0.74rem] font-semibold text-mute">
          <DynamicIcon name="QrCode" size={13} /> Point your camera here — or join manually below
        </p>
      </motion.div>

      <div className="mt-4 space-y-2.5">
        {row("Wifi", "Network (SSID)", brand.wifi.ssid)}
        {row("ShieldCheck", "Password", brand.wifi.pass)}
      </div>

      <p className="mt-4 text-center text-[0.7rem] leading-relaxed text-mute">
        Speeds up to 300 Mbps · streaming friendly · session resets nightly at 04:00
      </p>
    </Modal>
  );
}
