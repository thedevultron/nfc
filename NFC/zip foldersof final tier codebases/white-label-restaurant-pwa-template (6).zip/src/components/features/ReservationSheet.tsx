import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService } from "../../services/api.service";
import { Drawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Stepper } from "../ui/Stepper";
import { DynamicIcon } from "../ui/DynamicIcon";
import { toast } from "../ui/Toaster";
import { useHaptics } from "../../hooks/useHaptics";
import { cn } from "../../utils/cn";

/* ──────────────────────────────────────────────────────────────────────────
 *  MODULE E · TABLE RESERVATION DRAWER
 *  14-day date strip + config-driven time-slot groups + guest stepper.
 *  Submit → apiService.sendReservation → n8n reservation webhook with an
 *  immediate optimistic success state (reference + summary chips).
 * ────────────────────────────────────────────────────────────────────────── */

const spring = { type: "spring", stiffness: 400, damping: 28 } as const;

interface DayOption {
  iso: string;
  weekday: string;
  day: number;
  month: string;
  isToday: boolean;
}

export function ReservationSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { service, reservationSlots } = restaurantConfig;
  const haptics = useHaptics();

  const days = useMemo<DayOption[]>(() => {
    return Array.from({ length: 14 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() + i);
      return {
        iso: d.toISOString().slice(0, 10),
        weekday: d.toLocaleDateString("en", { weekday: "short" }),
        day: d.getDate(),
        month: d.toLocaleDateString("en", { month: "short" }),
        isToday: i === 0,
      };
    });
  }, []);

  const [dateIso, setDateIso] = useState(days[0].iso);
  const [time, setTime] = useState<string | null>(null);
  const [guests, setGuests] = useState(2);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "success">("idle");
  const [ref, setRef] = useState("");

  const selectedDay = days.find((d) => d.iso === dateIso) ?? days[0];
  const valid = name.trim().length > 1 && phone.trim().length >= 8 && time !== null;

  const submit = async () => {
    if (!valid || !time) return;
    haptics.select();
    setStatus("sending");
    const reference = `TBL-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    // Optimistic: the UI flips to success as soon as the webhook resolves
    // (mock latency in template mode, real round-trip once configured).
    await apiService.sendReservation({
      name: name.trim(),
      phone: phone.trim(),
      date: dateIso,
      time,
      guests,
      tableId: service.defaultTableId,
      notes: notes.trim(),
    });
    setRef(reference);
    setStatus("success");
    haptics.success();
    toast("Table request dispatched", "CalendarDays", "success");
  };

  const reset = () => {
    setStatus("idle");
    setTime(null);
    setNotes("");
    onClose();
  };

  return (
    <Drawer open={open} onOpenChange={(o) => { if (!o) (status === "success" ? reset() : onClose()); }} title="Book a Table" icon="CalendarDays">
      {status === "success" ? (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={spring} className="flex flex-col items-center pb-6 pt-4 text-center">
          <motion.span
            initial={{ scale: 0.5, rotate: -10 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 15, delay: 0.08 }}
            className="grid h-20 w-20 place-items-center rounded-full bg-primary/16 text-primary"
          >
            <DynamicIcon name="Check" size={38} strokeWidth={2.5} />
          </motion.span>
          <h3 className="mt-4 font-display text-2xl font-semibold">Table requested</h3>
          <p className="mt-1.5 max-w-[270px] text-sm text-mute">
            Reference <span className="font-bold text-accent">{ref}</span> — we'll confirm on{" "}
            <span className="font-semibold text-ink">{phone}</span> shortly.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            {[
              { icon: "CalendarDays", label: `${selectedDay.weekday}, ${selectedDay.day} ${selectedDay.month}` },
              { icon: "Clock", label: time ?? "" },
              { icon: "Users", label: `${guests} guest${guests > 1 ? "s" : ""}` },
            ].map((chip) => (
              <span key={chip.icon} className="flex items-center gap-1.5 rounded-full border border-line bg-raise/60 px-3 py-1.5 text-[0.76rem] font-bold">
                <span className="text-primary"><DynamicIcon name={chip.icon} size={13} /></span>
                {chip.label}
              </span>
            ))}
          </div>
          <Button className="mt-6 w-full max-w-[300px]" onClick={reset}>
            <DynamicIcon name="Check" size={17} /> Done
          </Button>
        </motion.div>
      ) : (
        <div className="pb-4">
          {/* Date strip */}
          <p className="flex items-center gap-1.5 text-[0.72rem] font-bold uppercase tracking-[0.14em] text-mute">
            <DynamicIcon name="CalendarDays" size={13} /> Pick a day
          </p>
          <div className="scrollbar-hide -mx-5 mt-2.5 flex gap-2 overflow-x-auto px-5 pb-1">
            {days.map((d) => {
              const active = d.iso === dateIso;
              return (
                <motion.button
                  key={d.iso}
                  whileTap={{ scale: 0.92 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  onClick={() => { haptics.tick(); setDateIso(d.iso); }}
                  className={cn(
                    "relative flex w-[62px] shrink-0 flex-col items-center rounded-[calc(var(--radius)*0.75)] border py-2.5 transition-colors",
                    active ? "border-primary bg-primary text-primary-ink shadow-[0_10px_24px_-10px_hsl(var(--primary)/0.6)]" : "border-line bg-surface/70 text-ink hover:border-primary/40",
                  )}
                >
                  <span className={cn("text-[0.6rem] font-bold uppercase tracking-[0.1em]", active ? "text-primary-ink/80" : "text-mute")}>
                    {d.isToday ? "Today" : d.weekday}
                  </span>
                  <span className="font-display text-[1.35rem] font-bold leading-tight">{d.day}</span>
                  <span className={cn("text-[0.6rem] font-semibold uppercase", active ? "text-primary-ink/80" : "text-mute")}>{d.month}</span>
                </motion.button>
              );
            })}
          </div>

          {/* Time slots */}
          <div className="mt-4 space-y-3.5">
            {reservationSlots.map((group) => (
              <div key={group.label}>
                <p className="flex items-center gap-1.5 text-[0.72rem] font-bold uppercase tracking-[0.14em] text-mute">
                  <DynamicIcon name={group.icon} size={13} /> {group.label}
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {group.slots.map((slot) => {
                    const active = time === slot;
                    return (
                      <motion.button
                        key={slot}
                        whileTap={{ scale: 0.92 }}
                        transition={{ type: "spring", stiffness: 400, damping: 25 }}
                        onClick={() => { haptics.tick(); setTime(slot); }}
                        className={cn(
                          "min-h-[48px] min-w-[70px] rounded-full border px-3.5 text-[0.84rem] font-bold tabular-nums transition-colors",
                          active ? "border-primary bg-primary text-primary-ink shadow-[0_8px_20px_-8px_hsl(var(--primary)/0.55)]" : "border-line bg-surface/70 text-ink/85 hover:border-primary/40",
                        )}
                      >
                        {slot}
                      </motion.button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Guests */}
          <div className="mt-5 flex items-center justify-between rounded-[calc(var(--radius)*0.8)] border border-line bg-raise/50 p-3.5">
            <span className="flex items-center gap-2 text-[0.86rem] font-bold">
              <span className="text-primary"><DynamicIcon name="Users" size={18} /></span> Guests
            </span>
            <Stepper
              value={guests}
              onIncrement={() => setGuests((g) => Math.min(12, g + 1))}
              onDecrement={() => setGuests((g) => Math.max(1, g - 1))}
            />
          </div>

          {/* Details */}
          <div className="mt-4 grid grid-cols-1 gap-2.5">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Full name"
              className="h-12 w-full rounded-[calc(var(--radius)*0.65)] border border-line bg-raise/60 px-3.5 text-[0.88rem] outline-none transition-colors placeholder:text-mute focus:border-primary/60"
            />
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              type="tel"
              inputMode="tel"
              placeholder="Phone for confirmation"
              className="h-12 w-full rounded-[calc(var(--radius)*0.65)] border border-line bg-raise/60 px-3.5 text-[0.88rem] outline-none transition-colors placeholder:text-mute focus:border-primary/60"
            />
            <input
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Occasion, seating preference… (optional)"
              className="h-12 w-full rounded-[calc(var(--radius)*0.65)] border border-line bg-raise/60 px-3.5 text-[0.88rem] outline-none transition-colors placeholder:text-mute focus:border-primary/60"
            />
          </div>

          <AnimatePresence>
            {!valid && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="mt-2.5 text-center text-[0.72rem] text-mute"
              >
                {time ? "Add your name & phone to confirm" : "Choose a time slot to continue"}
              </motion.p>
            )}
          </AnimatePresence>

          <Button size="lg" full className="mt-4" disabled={!valid || status === "sending"} onClick={submit}>
            {status === "sending" ? (
              <>
                <span className="animate-spin"><DynamicIcon name="RefreshCw" size={18} /></span> Reserving…
              </>
            ) : (
              <>
                <DynamicIcon name="CalendarDays" size={19} /> Confirm Table for {guests}
              </>
            )}
          </Button>
        </div>
      )}
    </Drawer>
  );
}
