import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService } from "../../services/api.service";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { DynamicIcon } from "../ui/DynamicIcon";
import { toast } from "../ui/Toaster";
import { useHaptics } from "../../hooks/useHaptics";

/* ──────────────────────────────────────────────────────────────────────────
 *  MODULE D · SMART REVIEW & FEEDBACK FILTER
 *  ★ 4–5 stars → high-visibility "Post Public Review on Google" CTA that
 *    deep-links to the configured Google Maps review URL.
 *  ★ 1–3 stars → seamlessly morphs into a PRIVATE feedback form routed to
 *    management via the n8n feedback webhook (protects the public rating).
 * ────────────────────────────────────────────────────────────────────────── */

const spring = { type: "spring", stiffness: 400, damping: 28 } as const;

export function ReviewModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { brand, service } = restaurantConfig;
  const haptics = useHaptics();
  const [rating, setRating] = useState(0);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [phase, setPhase] = useState<"rate" | "private" | "sending" | "sent">("rate");

  // reset whenever the sheet reopens
  useEffect(() => {
    if (open) {
      setRating(0);
      setName("");
      setMessage("");
      setPhase("rate");
    }
  }, [open]);

  const choose = (stars: number) => {
    haptics.tick();
    setRating(stars);
    if (stars < 4) setPhase("private");
  };

  const sendPrivateFeedback = async () => {
    if (!message.trim()) return;
    haptics.select();
    setPhase("sending");
    await apiService.sendFeedback({
      rating,
      name: name.trim() || "Anonymous guest",
      message: message.trim(),
      tableId: service.defaultTableId,
    });
    setPhase("sent");
    haptics.success();
    toast("Feedback reached the manager", "ShieldCheck", "success");
  };

  const postPublicReview = () => {
    haptics.success();
    window.open(brand.googleReviewUrl, "_blank", "noopener");
    toast("Thanks! Opening Google review…", "Star", "accent");
  };

  return (
    <Modal open={open} onClose={onClose} title="How was your visit?" icon="Star">
      {/* Star selector */}
      <div className="flex items-center justify-center gap-1.5 py-2">
        {[1, 2, 3, 4, 5].map((s) => {
          const filled = s <= rating;
          return (
            <motion.button
              key={s}
              aria-label={`${s} star${s > 1 ? "s" : ""}`}
              whileTap={{ scale: 0.8 }}
              animate={filled ? { scale: [1, 1.25, 1], rotate: [0, -8, 0] } : { scale: 1 }}
              transition={{ type: "spring", stiffness: 400, damping: 18 }}
              onClick={() => choose(s)}
              className="grid h-12 w-12 place-items-center"
            >
              <DynamicIcon
                name="Star"
                size={34}
                strokeWidth={1.8}
                className={filled ? "text-accent" : "text-line"}
                fill={filled ? "hsl(var(--accent))" : "none"}
                style={{ transition: "color .2s" }}
              />
            </motion.button>
          );
        })}
      </div>
      <p className="text-center text-[0.8rem] font-semibold text-mute">
        {rating === 0 ? "Tap a star — it routes your feedback smartly" : `You rated ${rating}/5`}
      </p>

      <div className="mt-4 min-h-[180px]">
        <AnimatePresence mode="wait">
          {/* ── High ratings → public Google review ─────────────────── */}
          {rating >= 4 && phase === "rate" && (
            <motion.div
              key="public"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={spring}
              className="rounded-[calc(var(--radius)*0.9)] border border-accent/30 bg-accent/8 p-4 text-center"
            >
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-accent/18 text-accent">
                <DynamicIcon name="Heart" size={22} />
              </span>
              <p className="mt-2.5 font-display text-lg font-semibold leading-snug">
                Wonderful — tell the world?
              </p>
              <p className="mt-1 text-[0.8rem] text-mute">
                Public reviews keep our chefs smiling and the pass humming.
              </p>
              <Button variant="accent" size="lg" full className="mt-4" onClick={postPublicReview}>
                <DynamicIcon name="ExternalLink" size={18} /> Post Public Review on Google
              </Button>
              <button
                onClick={onClose}
                className="mt-2.5 min-h-[44px] text-[0.78rem] font-semibold text-mute hover:text-ink"
              >
                Maybe later
              </button>
            </motion.div>
          )}

          {/* ── Low ratings → private manager feedback ──────────────── */}
          {(phase === "private" || phase === "sending") && rating > 0 && rating < 4 && (
            <motion.div
              key="private"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={spring}
            >
              <div className="rounded-[calc(var(--radius)*0.9)] border border-line bg-raise/50 p-4">
                <p className="flex items-center gap-2 text-[0.72rem] font-bold uppercase tracking-[0.14em] text-primary">
                  <DynamicIcon name="ShieldCheck" size={14} /> Private — never posted publicly
                </p>
                <p className="mt-2 font-display text-lg font-semibold leading-snug">
                  Tell the manager what we can improve
                </p>
                <p className="mt-1 text-[0.8rem] text-mute">
                  This goes straight to the team's phone — give us a chance to make it right.
                </p>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name (optional)"
                  className="mt-3.5 h-12 w-full rounded-[calc(var(--radius)*0.65)] border border-line bg-surface px-3.5 text-[0.88rem] outline-none transition-colors placeholder:text-mute focus:border-primary/60"
                />
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={3}
                  maxLength={280}
                  placeholder="What missed the mark tonight?"
                  className="mt-2 w-full resize-none rounded-[calc(var(--radius)*0.65)] border border-line bg-surface p-3.5 text-[0.88rem] outline-none transition-colors placeholder:text-mute focus:border-primary/60"
                />
                <Button full className="mt-3" disabled={!message.trim() || phase === "sending"} onClick={sendPrivateFeedback}>
                  {phase === "sending" ? (
                    <>
                      <span className="animate-spin"><DynamicIcon name="RefreshCw" size={17} /></span> Sending…
                    </>
                  ) : (
                    <>
                      <DynamicIcon name="Send" size={17} /> Send to Manager
                    </>
                  )}
                </Button>
                <button
                  onClick={() => { haptics.tick(); setPhase("rate"); setRating(0); }}
                  className="mx-auto mt-2 block min-h-[40px] text-[0.76rem] font-semibold text-mute hover:text-ink"
                >
                  Change my rating
                </button>
              </div>
            </motion.div>
          )}

          {/* ── Private feedback received ───────────────────────────── */}
          {phase === "sent" && (
            <motion.div
              key="sent"
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={spring}
              className="flex flex-col items-center rounded-[calc(var(--radius)*0.9)] border border-primary/30 bg-primary/8 p-5 text-center"
            >
              <motion.span
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                className="grid h-14 w-14 place-items-center rounded-full bg-primary/16 text-primary"
              >
                <DynamicIcon name="ShieldCheck" size={26} />
              </motion.span>
              <p className="mt-3 font-display text-lg font-semibold">Received by the team</p>
              <p className="mt-1 max-w-[260px] text-[0.8rem] text-mute">
                Thank you for the honesty — a manager will reach out before you leave tonight.
              </p>
              <Button variant="soft" className="mt-4" onClick={onClose}>Done</Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Modal>
  );
}
