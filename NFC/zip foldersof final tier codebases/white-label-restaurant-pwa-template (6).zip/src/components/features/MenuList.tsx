import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { menuCategories, menuItems } from "../../config/menuData";
import { DynamicIcon } from "../ui/DynamicIcon";
import { Badge } from "../ui/Badge";
import { Stepper } from "../ui/Stepper";
import { useHaptics } from "../../hooks/useHaptics";
import { formatPrice } from "../../utils/format";
import { cn } from "../../utils/cn";
import type { CartApi } from "../../hooks/useCart";
import type { DietTag, MenuItem } from "../../types/menu.types";

/* ──────────────────────────────────────────────────────────────────────────
 *  MODULE B · HIGH-CONVERTING DIGITAL MENU
 *  • Sticky category rail (Lucide icons, sliding layoutId pill)
 *  • Instant search + dietary toggle pills (Veg / Non-Veg / Vegan / Chef's)
 *  • Dish cards: icon medallion, spice Flames, Best Seller badge, sold-out
 *    state (Ban), spring-physics add button → animated inline counter.
 *  100% data-driven from /config/menuData.ts.
 * ────────────────────────────────────────────────────────────────────────── */

type DietFilter = DietTag | "chef";

const DIET_META: Record<DietTag, { icon: string; label: string; tone: "primary" | "accent" | "danger"; pill: string; medal: string }> = {
  veg: { icon: "CircleDot", label: "Veg", tone: "primary", pill: "text-primary", medal: "bg-primary/12 text-primary" },
  vegan: { icon: "Leaf", label: "Vegan", tone: "accent", pill: "text-accent", medal: "bg-accent/16 text-accent" },
  nonveg: { icon: "Beef", label: "Non-Veg", tone: "danger", pill: "text-danger", medal: "bg-danger/14 text-danger" },
};

export function MenuList({ cart }: { cart: CartApi }) {
  const haptics = useHaptics();
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [dietFilters, setDietFilters] = useState<DietFilter[]>([]);

  const toggleDiet = (f: DietFilter) => {
    haptics.tick();
    setDietFilters((prev) => (prev.includes(f) ? prev.filter((x) => x !== f) : [...prev, f]));
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menuItems.filter((item) => {
      if (activeCategory !== "all" && item.category !== activeCategory) return false;
      if (q && !`${item.name} ${item.description}`.toLowerCase().includes(q)) return false;
      if (dietFilters.length) {
        const ok = dietFilters.every((f) => (f === "chef" ? item.bestSeller : item.diet === f));
        if (!ok) return false;
      }
      return true;
    });
  }, [activeCategory, query, dietFilters]);

  const visibleCategories = menuCategories.filter((c) => filtered.some((i) => i.category === c.id));

  return (
    <section className="px-5 pt-6">
      {/* Section header — strong type contrast */}
      <div className="mb-4 flex items-end justify-between">
        <div>
          <p className="text-[0.66rem] font-bold uppercase tracking-[0.22em] text-accent">Digital Menu</p>
          <h2 className="font-display text-[2rem] font-semibold leading-none tracking-[-0.02em]">
            Tonight's <em className="italic text-primary">carte</em>
          </h2>
        </div>
        <p className="pb-1 text-[0.72rem] font-semibold text-mute">
          {filtered.length} dish{filtered.length === 1 ? "" : "es"}
        </p>
      </div>

      {/* ── Sticky search + filters + category rail ─────────────────── */}
      <div className="glass sticky top-0 z-40 -mx-5 mb-4 border-b border-line/70 px-5 pb-3 pt-2">
        {/* Search + dietary pills */}
        <div className="flex items-center gap-2">
          <label className="relative flex h-12 flex-1 items-center">
            <span className="pointer-events-none absolute left-3.5 text-mute">
              <DynamicIcon name="Search" size={17} />
            </span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search dishes…"
              className="h-12 w-full rounded-[calc(var(--radius)*0.8)] border border-line bg-raise/70 pl-10 pr-10 text-[0.9rem] outline-none transition-colors placeholder:text-mute focus:border-primary/60"
            />
            {query && (
              <button
                aria-label="Clear search"
                onClick={() => { haptics.tick(); setQuery(""); }}
                className="absolute right-2 grid h-8 w-8 place-items-center rounded-full text-mute hover:bg-surface hover:text-ink"
              >
                <DynamicIcon name="X" size={15} />
              </button>
            )}
          </label>
        </div>

        <div className="scrollbar-hide -mx-5 mt-2.5 flex gap-2 overflow-x-auto px-5">
          {([
            { id: "veg" as DietFilter, icon: "CircleDot", label: "Veg" },
            { id: "nonveg" as DietFilter, icon: "Beef", label: "Non-Veg" },
            { id: "vegan" as DietFilter, icon: "Leaf", label: "Vegan" },
            { id: "chef" as DietFilter, icon: "Award", label: "Chef's Special" },
          ]).map((f) => {
            const active = dietFilters.includes(f.id);
            return (
              <motion.button
                key={f.id}
                whileTap={{ scale: 0.93 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                onClick={() => toggleDiet(f.id)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2.5 text-[0.74rem] font-bold transition-colors",
                  active
                    ? "border-primary/60 bg-primary/14 text-primary"
                    : "border-line bg-surface/60 text-mute hover:text-ink",
                )}
              >
                <DynamicIcon name={f.icon} size={14} />
                {f.label}
              </motion.button>
            );
          })}
        </div>

        {/* Category rail */}
        <div className="scrollbar-hide -mx-5 mt-2.5 flex gap-1.5 overflow-x-auto px-5">
          {[{ id: "all", label: "All", icon: "Utensils" }, ...menuCategories].map((c) => {
            const active = activeCategory === c.id;
            return (
              <motion.button
                key={c.id}
                whileTap={{ scale: 0.94 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                onClick={() => { haptics.tick(); setActiveCategory(c.id); }}
                className={cn(
                  "relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-3 text-[0.78rem] font-bold transition-colors",
                  active ? "text-primary-ink" : "text-mute hover:text-ink",
                )}
              >
                {active && (
                  <motion.span
                    layoutId="cat-pill"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    className="absolute inset-0 rounded-full bg-primary shadow-[0_8px_20px_-8px_hsl(var(--primary)/0.6)]"
                  />
                )}
                <span className="relative flex items-center gap-1.5">
                  <DynamicIcon name={c.icon} size={15} />
                  {c.label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* ── Dish sections ───────────────────────────────────────────── */}
      {visibleCategories.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <span className="grid h-16 w-16 place-items-center rounded-full bg-raise text-mute">
            <DynamicIcon name="SearchX" size={28} />
          </span>
          <p className="mt-4 font-display text-lg font-semibold">No dishes match</p>
          <p className="mt-1 max-w-[220px] text-sm text-mute">Try a different craving or clear the filters.</p>
          <button
            onClick={() => { haptics.tick(); setQuery(""); setDietFilters([]); setActiveCategory("all"); }}
            className="mt-4 flex min-h-[44px] items-center gap-1.5 rounded-full bg-primary/12 px-4 text-sm font-bold text-primary"
          >
            <DynamicIcon name="RefreshCw" size={15} /> Clear all filters
          </button>
        </div>
      ) : (
        visibleCategories.map((cat) => {
          const items = filtered.filter((i) => i.category === cat.id);
          return (
            <div key={cat.id} className="mb-6">
              <div className="mb-3 flex items-center gap-2.5">
                <span className="grid h-8 w-8 place-items-center rounded-[calc(var(--radius)*0.55)] bg-raise text-primary">
                  <DynamicIcon name={cat.icon} size={16} />
                </span>
                <h3 className="font-display text-[1.15rem] font-semibold tracking-[-0.01em]">{cat.label}</h3>
                <span className="text-[0.7rem] font-bold text-mute">{items.length}</span>
                <span aria-hidden className="h-px flex-1 bg-line/80" />
              </div>
              <div className="space-y-2.5">
                {items.map((item, idx) => (
                  <DishCard
                    key={item.id}
                    item={item}
                    index={idx}
                    qty={cart.qtyFor(item.id)}
                    justAdded={cart.justAddedId === item.id}
                    onAdd={() => { haptics.tap(); cart.add(item); }}
                    onIncrement={() => cart.increment(item.id)}
                    onDecrement={() => cart.decrement(item.id)}
                  />
                ))}
              </div>
            </div>
          );
        })
      )}
    </section>
  );
}

/* ── Dish card ─────────────────────────────────────────────────────────── */

interface DishCardProps {
  item: MenuItem;
  index: number;
  qty: number;
  justAdded: boolean;
  onAdd: () => void;
  onIncrement: () => void;
  onDecrement: () => void;
}

function DishCard({ item, index, qty, justAdded, onAdd, onIncrement, onDecrement }: DishCardProps) {
  const diet = DIET_META[item.diet];
  const soldOut = !item.isAvailable;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ type: "spring", stiffness: 300, damping: 27, delay: Math.min(index * 0.04, 0.2) }}
      className={cn(
        "relative flex gap-3.5 rounded-[calc(var(--radius)*0.95)] border border-line bg-surface/80 p-3.5 transition-colors hover:border-primary/35",
        soldOut && "opacity-90",
      )}
    >
      {/* Icon medallion */}
      <span
        className={cn(
          "relative grid h-[52px] w-[52px] shrink-0 place-items-center rounded-[calc(var(--radius)*0.7)]",
          soldOut ? "bg-raise text-mute" : diet.medal,
        )}
      >
        <DynamicIcon name={soldOut ? "Ban" : item.icon} size={23} />
        {item.spice > 0 && !soldOut && (
          <span className="absolute -bottom-1.5 left-1/2 flex -translate-x-1/2 gap-[1px] rounded-full border border-line bg-surface px-1 py-[2px]">
            {Array.from({ length: item.spice }).map((_, i) => (
              <span key={i} className="text-danger"><DynamicIcon name="Flame" size={9} /></span>
            ))}
          </span>
        )}
      </span>

      {/* Copy */}
      <div className={cn("min-w-0 flex-1", soldOut && "opacity-60 saturate-50")}>
        <div className="flex items-start gap-2">
          <h4 className="min-w-0 flex-1 truncate text-[0.98rem] font-bold tracking-[-0.01em]">{item.name}</h4>
          {item.bestSeller && !soldOut && (
            <Badge tone="accent" className="shrink-0"><DynamicIcon name="Award" size={10} /> Best Seller</Badge>
          )}
          {soldOut && <Badge tone="danger" className="shrink-0"><DynamicIcon name="Ban" size={10} /> Sold Out</Badge>}
        </div>
        <p className="mt-0.5 line-clamp-2 text-[0.78rem] leading-snug text-mute">{item.description}</p>
        <div className="mt-2 flex flex-wrap items-center gap-x-2.5 gap-y-1">
          <span className={cn("flex items-center gap-1 text-[0.68rem] font-bold", diet.pill)}>
            <DynamicIcon name={diet.icon} size={12} /> {diet.label}
          </span>
          <span className="flex items-center gap-1 text-[0.68rem] font-semibold text-mute">
            <DynamicIcon name="Clock" size={12} /> {item.time}
          </span>
          <span className="ml-auto font-display text-[1.05rem] font-bold tracking-[-0.01em]">{formatPrice(item.price)}</span>
        </div>
      </div>

      {/* Add / quantity control column */}
      <div className="flex shrink-0 flex-col items-end justify-end">
        <div className="relative">
          <AnimatePresence mode="popLayout" initial={false}>
            {soldOut ? (
              <motion.span
                key="sold"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="grid h-12 w-12 place-items-center rounded-full border border-line bg-raise text-mute"
              >
                <DynamicIcon name="X" size={18} />
              </motion.span>
            ) : qty === 0 ? (
              <motion.button
                key="add"
                aria-label={`Add ${item.name} to cart`}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.7, opacity: 0 }}
                whileTap={{ scale: 0.85 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                onClick={onAdd}
                className="relative grid h-12 w-12 place-items-center rounded-full bg-primary text-primary-ink shadow-[0_10px_24px_-8px_hsl(var(--primary)/0.6)]"
              >
                {justAdded && (
                  <motion.span
                    initial={{ scale: 0.6, opacity: 0.8 }}
                    animate={{ scale: 1.7, opacity: 0 }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                    className="absolute inset-0 rounded-full border-2 border-primary"
                  />
                )}
                <DynamicIcon name="Plus" size={20} />
              </motion.button>
            ) : (
              <motion.div
                key="qty"
                initial={{ scale: 0.7, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.7, opacity: 0 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
              >
                <Stepper size="sm" value={qty} onIncrement={onIncrement} onDecrement={onDecrement} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.article>
  );
}
