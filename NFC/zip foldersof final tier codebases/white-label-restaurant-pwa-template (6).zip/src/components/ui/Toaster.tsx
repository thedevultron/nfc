import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { DynamicIcon } from "./DynamicIcon";

/* ──────────────────────────────────────────────────────────────────────────
 *  TOASTER — tiny module-level pub/sub so any feature can raise a toast
 *  without prop-drilling. Call `toast("Added to tray", "Check")`.
 * ────────────────────────────────────────────────────────────────────────── */

interface ToastMsg {
  id: number;
  text: string;
  icon?: string;
  tone?: "default" | "success" | "accent";
}

let pushToast: ((t: Omit<ToastMsg, "id">) => void) | null = null;

export function toast(text: string, icon: string = "Sparkles", tone: ToastMsg["tone"] = "default") {
  pushToast?.({ text, icon, tone });
}

export function Toaster() {
  const [items, setItems] = useState<ToastMsg[]>([]);

  useEffect(() => {
    let seq = 0;
    pushToast = (t) => {
      const id = ++seq;
      setItems((prev) => [...prev.slice(-2), { ...t, id }]);
      window.setTimeout(() => setItems((prev) => prev.filter((x) => x.id !== id)), 2400);
    };
    return () => {
      pushToast = null;
    };
  }, []);

  const toneClass = (tone: ToastMsg["tone"]) =>
    tone === "success"
      ? "text-primary"
      : tone === "accent"
        ? "text-accent"
        : "text-mute";

  return (
    <div className="pointer-events-none fixed inset-x-0 top-[max(env(safe-area-inset-top),1rem)] z-[80] flex flex-col items-center gap-2 px-4">
      <AnimatePresence>
        {items.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, y: -18, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.96 }}
            transition={{ type: "spring", stiffness: 400, damping: 28 }}
            className="glass flex items-center gap-2.5 rounded-full border border-line py-2.5 pl-3.5 pr-5 text-sm font-semibold shadow-[0_16px_40px_-16px_hsl(160_50%_3%/0.8)]"
          >
            <span className={toneClass(t.tone)}>
              <DynamicIcon name={t.icon ?? "Sparkles"} size={17} />
            </span>
            {t.text}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
