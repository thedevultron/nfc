import { Drawer as VaulDrawer } from "vaul";
import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { DynamicIcon } from "./DynamicIcon";
import { useHaptics } from "../../hooks/useHaptics";

/* ──────────────────────────────────────────────────────────────────────────
 *  BOTTOM SHEET DRAWER (vaul)
 *  Native-feel drag-to-dismiss with spring physics. Corner radius derives
 *  from the theme radius token; glass flag flips backdrop blur on/off.
 * ────────────────────────────────────────────────────────────────────────── */

interface DrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  icon: string;
  children: ReactNode;
  /** Accent line under the handle — small brand touch */
  accentBar?: boolean;
}

export function Drawer({ open, onOpenChange, title, icon, children, accentBar = true }: DrawerProps) {
  const haptics = useHaptics();

  return (
    <VaulDrawer.Root
      open={open}
      onOpenChange={(next) => {
        if (next) haptics.select();
        onOpenChange(next);
      }}
      shouldScaleBackground
    >
      <VaulDrawer.Portal>
        <VaulDrawer.Overlay className="fixed inset-0 z-[60] bg-[hsl(160_40%_3%/0.72)] backdrop-blur-[2px]" />
        <VaulDrawer.Content
          className="fixed inset-x-0 bottom-0 z-[61] mx-auto flex max-h-[92dvh] w-full max-w-md flex-col overflow-hidden
                     rounded-t-[calc(var(--radius)*1.5)] border-t border-line bg-surface
                     shadow-[0_-24px_80px_-20px_hsl(160_50%_3%/0.9)] outline-none
                     pb-[max(env(safe-area-inset-bottom),0.75rem)]"
        >
          <VaulDrawer.Title className="sr-only">{title}</VaulDrawer.Title>
          <VaulDrawer.Description className="sr-only">{title} panel</VaulDrawer.Description>
          <div className="flex shrink-0 flex-col items-center pt-3">
            <div className="h-1.5 w-12 rounded-full bg-line" />
            {accentBar && <div className="mt-1 h-[3px] w-24 rounded-full bg-primary/70" />}
          </div>

          <motion.header
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 400, damping: 28, delay: 0.05 }}
            className="flex shrink-0 items-center gap-3 px-5 pb-4 pt-3"
          >
            <span className="grid h-11 w-11 place-items-center rounded-[calc(var(--radius)*0.7)] bg-primary/14 text-primary">
              <DynamicIcon name={icon} size={21} />
            </span>
            <h2 className="font-display text-[1.35rem] font-semibold tracking-[-0.02em]">{title}</h2>
            <button
              aria-label="Close sheet"
              onClick={() => onOpenChange(false)}
              className="ml-auto grid h-12 w-12 -mr-2 place-items-center rounded-full text-mute transition-colors hover:bg-raise hover:text-ink"
            >
              <DynamicIcon name="X" size={20} />
            </button>
          </motion.header>

          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-2">{children}</div>
        </VaulDrawer.Content>
      </VaulDrawer.Portal>
    </VaulDrawer.Root>
  );
}
