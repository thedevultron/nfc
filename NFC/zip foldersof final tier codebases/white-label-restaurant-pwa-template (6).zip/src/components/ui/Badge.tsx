import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

/* ──────────────────────────────────────────────────────────────────────────
 *  BADGE — small semantic pill (dietary tags, statuses, "Best Seller").
 * ────────────────────────────────────────────────────────────────────────── */

type Tone = "primary" | "accent" | "mute" | "danger" | "line";

const TONES: Record<Tone, string> = {
  primary: "bg-primary/14 text-primary",
  accent: "bg-accent/16 text-accent",
  mute: "bg-raise text-mute",
  danger: "bg-danger/14 text-danger",
  line: "border border-line text-mute",
};

export function Badge({
  tone = "mute",
  className,
  children,
}: {
  tone?: Tone;
  className?: string;
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-[3px] text-[0.66rem] font-bold uppercase tracking-[0.08em]",
        TONES[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
