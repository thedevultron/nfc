import { AnimatePresence, motion } from "framer-motion";
import { DynamicIcon } from "./DynamicIcon";
import { useHaptics } from "../../hooks/useHaptics";
import { cn } from "../../utils/cn";

/* ──────────────────────────────────────────────────────────────────────────
 *  QUANTITY STEPPER — shared by cart lines, reservation guests and the
 *  inline dish-card counter. Animated digit roll + haptic ticks.
 * ────────────────────────────────────────────────────────────────────────── */

interface StepperProps {
  value: number;
  onIncrement: () => void;
  onDecrement: () => void;
  size?: "sm" | "md";
  className?: string;
}

export function Stepper({ value, onIncrement, onDecrement, size = "md", className }: StepperProps) {
  const haptics = useHaptics();
  const btn = size === "sm" ? "h-9 w-9" : "h-11 w-11";
  const icon = size === "sm" ? 15 : 17;

  return (
    <div
      className={cn(
        "flex items-center gap-1 rounded-full border border-line bg-raise/80 p-1",
        className,
      )}
      onClick={(e) => e.stopPropagation()}
    >
      <motion.button
        aria-label="Decrease quantity"
        whileTap={{ scale: 0.85 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => {
          haptics.tick();
          onDecrement();
        }}
        className={cn(btn, "grid place-items-center rounded-full text-mute transition-colors hover:bg-surface hover:text-ink")}
      >
        <DynamicIcon name="Minus" size={icon} />
      </motion.button>

      <span className="relative grid h-6 w-7 place-items-center overflow-hidden">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.span
            key={value}
            initial={{ y: 14, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -14, opacity: 0 }}
            transition={{ type: "spring", stiffness: 500, damping: 32 }}
            className="text-sm font-bold tabular-nums"
          >
            {value}
          </motion.span>
        </AnimatePresence>
      </span>

      <motion.button
        aria-label="Increase quantity"
        whileTap={{ scale: 0.85 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => {
          haptics.tick();
          onIncrement();
        }}
        className={cn(btn, "grid place-items-center rounded-full bg-primary text-primary-ink shadow-sm")}
      >
        <DynamicIcon name="Plus" size={icon} />
      </motion.button>
    </div>
  );
}
