import { AnimatePresence, motion } from "framer-motion";
import type { ReactNode } from "react";
import { DynamicIcon } from "./DynamicIcon";
import { useHaptics } from "../../hooks/useHaptics";

/* ──────────────────────────────────────────────────────────────────────────
 *  CENTERED MODAL — spring pop for focused flows (Review filter, WiFi).
 * ────────────────────────────────────────────────────────────────────────── */

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  icon: string;
  children: ReactNode;
}

export function Modal({ open, onClose, title, icon, children }: ModalProps) {
  const haptics = useHaptics();

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[70] grid place-items-end justify-items-center sm:place-items-center">
          <motion.button
            aria-label="Close dialog"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 cursor-default bg-[hsl(160_40%_3%/0.72)] backdrop-blur-[2px]"
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            initial={{ opacity: 0, y: 60, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            onPointerDown={() => haptics.tick()}
            className="relative z-10 max-h-[88dvh] w-full max-w-md overflow-y-auto overscroll-contain
                       rounded-t-[calc(var(--radius)*1.5)] border border-line bg-surface
                       p-6 shadow-[0_40px_120px_-30px_hsl(160_50%_2%/0.95)]
                       sm:rounded-[calc(var(--radius)*1.2)]
                       pb-[max(env(safe-area-inset-bottom),1.5rem)]"
          >
            <header className="mb-4 flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-[calc(var(--radius)*0.7)] bg-accent/16 text-accent">
                <DynamicIcon name={icon} size={21} />
              </span>
              <h2 className="font-display text-[1.35rem] font-semibold tracking-[-0.02em]">{title}</h2>
              <button
                aria-label="Close"
                onClick={onClose}
                className="ml-auto grid h-12 w-12 -mr-2 place-items-center rounded-full text-mute transition-colors hover:bg-raise hover:text-ink"
              >
                <DynamicIcon name="X" size={20} />
              </button>
            </header>
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
