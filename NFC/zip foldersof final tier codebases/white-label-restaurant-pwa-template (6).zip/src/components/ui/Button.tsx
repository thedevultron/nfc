import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "../../utils/cn";

/* ──────────────────────────────────────────────────────────────────────────
 *  BUTTON — spring-physics press feedback on every variant.
 *  Variants read theme tokens only, so a config re-skin restyles all CTAs.
 * ────────────────────────────────────────────────────────────────────────── */

type Variant = "primary" | "accent" | "soft" | "outline" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";

const VARIANTS: Record<Variant, string> = {
  primary: "bg-primary text-primary-ink shadow-[0_8px_24px_-10px_hsl(var(--primary)/0.55)] hover:brightness-110",
  accent: "bg-accent text-accent-ink shadow-[0_8px_24px_-10px_hsl(var(--accent)/0.5)] hover:brightness-105",
  soft: "bg-primary/12 text-primary hover:bg-primary/20",
  outline: "border border-line bg-surface/60 text-ink hover:border-primary/50 hover:text-primary",
  ghost: "text-mute hover:text-ink hover:bg-raise",
  danger: "bg-danger/12 text-danger hover:bg-danger/20",
};

const SIZES: Record<Size, string> = {
  sm: "h-9 px-3.5 text-[0.8rem] gap-1.5 rounded-[calc(var(--radius)*0.6)]",
  md: "h-12 px-5 text-[0.92rem] gap-2 rounded-[calc(var(--radius)*0.8)]",
  lg: "h-14 px-6 text-base gap-2 rounded-[calc(var(--radius)*0.9)]",
};

interface ButtonProps extends HTMLMotionProps<"button"> {
  variant?: Variant;
  size?: Size;
  full?: boolean;
}

export function Button({
  variant = "primary",
  size = "md",
  full,
  className,
  children,
  disabled,
  ...rest
}: ButtonProps) {
  return (
    <motion.button
      whileTap={disabled ? undefined : { scale: 0.96 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      className={cn(
        "inline-flex min-h-[48px] select-none items-center justify-center font-semibold tracking-[-0.01em]",
        "transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary",
        "disabled:pointer-events-none disabled:opacity-40",
        VARIANTS[variant],
        SIZES[size],
        full && "w-full",
        className,
      )}
      disabled={disabled}
      {...rest}
    >
      {children}
    </motion.button>
  );
}
