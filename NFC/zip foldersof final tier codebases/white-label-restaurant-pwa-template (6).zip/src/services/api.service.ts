import { restaurantConfig } from "../config/restaurant.config";
import { dispatchWebhook, type WebhookResult } from "./n8n.service";
import type { CartLine, FeedbackPayload, OrderPayload, ReservationPayload, ServiceMode } from "../types/menu.types";
import { formatPrice } from "../utils/format";

/* ──────────────────────────────────────────────────────────────────────────
 *  DOMAIN API SERVICE
 *  ────────────────────────────────────────────────────────────────────────
 *  Clean async endpoints the UI calls. Each one shapes its payload and
 *  routes through the n8n transport using the URLs from restaurant.config.
 *  Swap endpoints in config — never here.
 * ────────────────────────────────────────────────────────────────────────── */

export const apiService = {
  async sendReservation(payload: Omit<ReservationPayload, "createdAt">): Promise<WebhookResult> {
    const body: ReservationPayload = { ...payload, createdAt: new Date().toISOString() };
    return dispatchWebhook(restaurantConfig.n8nWebhooks.reservationUrl, body);
  },

  async sendFeedback(payload: Omit<FeedbackPayload, "createdAt">): Promise<WebhookResult> {
    const body: FeedbackPayload = { ...payload, createdAt: new Date().toISOString() };
    return dispatchWebhook(restaurantConfig.n8nWebhooks.feedbackUrl, body);
  },

  async sendOrder(payload: Omit<OrderPayload, "placedAt">): Promise<WebhookResult> {
    const body: OrderPayload = { ...payload, placedAt: new Date().toISOString() };
    return dispatchWebhook(restaurantConfig.n8nWebhooks.orderUrl, body);
  },
};

/* ── WhatsApp deep-link builders (also config-driven) ─────────────────── */

const digits = (phone: string) => phone.replace(/[^\d]/g, "");

export function buildWhatsAppLink(message: string): string {
  return `https://wa.me/${digits(restaurantConfig.brand.whatsappNumber)}?text=${encodeURIComponent(message)}`;
}

/** Concierge / general inquiry link used by the quick-action grid. */
export function buildConciergeLink(mode: ServiceMode, tableId: string): string {
  const ctx = mode === "dinein" ? `Table ${tableId} (Dine-In)` : "Takeaway";
  return buildWhatsAppLink(`Hi ${restaurantConfig.brand.name}! 👋\n${ctx} — I have a quick question.`);
}

/** Formats the full cart into an encoded order message for wa.me. */
export function buildOrderWhatsAppLink(
  lines: CartLine[],
  totals: { subtotal: number; tax: number; total: number },
  notes: string,
  mode: ServiceMode,
  tableId: string,
): string {
  const head =
    mode === "dinein"
      ? `*New Order — ${restaurantConfig.brand.name}*\nTable ${tableId} · Dine-In`
      : `*New Order — ${restaurantConfig.brand.name}*\nTakeaway · Counter Pickup`;
  const body = lines
    .map((l) => `${l.qty} × ${l.item.name} — ${formatPrice(l.item.price * l.qty)}`)
    .join("\n");
  const foot = [
    notes.trim() ? `\nNotes: ${notes.trim()}` : "",
    `\nSubtotal: ${formatPrice(totals.subtotal)}`,
    `Tax: ${formatPrice(totals.tax)}`,
    `*Total: ${formatPrice(totals.total)}*`,
  ].join("\n");
  return buildWhatsAppLink(`${head}\n────────────\n${body}${foot}`);
}
