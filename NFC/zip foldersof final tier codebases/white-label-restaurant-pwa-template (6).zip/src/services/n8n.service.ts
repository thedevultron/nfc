/* ──────────────────────────────────────────────────────────────────────────
 *  n8n WEBHOOK TRANSPORT LAYER
 *  ────────────────────────────────────────────────────────────────────────
 *  The single transport the whole app uses to reach a backend.
 *  Point `n8nWebhooks.*` in /config/restaurant.config.ts at a live n8n
 *  instance and every dispatch below goes live — no code changes needed.
 *
 *  TEMPLATE MODE: while a URL still contains "your-n8n-instance", requests
 *  resolve optimistically with a mock payload so the template is fully
 *  testable without any backend.
 * ────────────────────────────────────────────────────────────────────────── */

export interface WebhookResult {
  success: boolean;
  mock: boolean;
  message: string;
  [key: string]: unknown;
}

const PLACEHOLDER_HOST = "your-n8n-instance";
const TIMEOUT_MS = 6000;

export async function dispatchWebhook(url: string, payload: unknown): Promise<WebhookResult> {
  // Template mode — simulate a healthy webhook round-trip.
  if (!url || url.includes(PLACEHOLDER_HOST)) {
    console.info("[n8n · template mode] Would POST →", url, payload);
    await new Promise((r) => setTimeout(r, 450)); // perceptible, optimistic latency
    return { success: true, mock: true, message: "Dispatched (mock — connect n8n webhooks in config)" };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    const data = (await response.json().catch(() => ({}))) as Partial<WebhookResult>;
    return { ...data, success: response.ok, mock: false, message: data.message ?? "Dispatched to n8n" };
  } catch (err) {
    console.warn("[n8n] Webhook unreachable — falling back to optimistic success.", err);
    // Optimistic fallback keeps the guest flow unblocked (kitchen copy, etc.)
    return { success: true, mock: true, message: "Queued offline — will retry" };
  } finally {
    clearTimeout(timer);
  }
}
