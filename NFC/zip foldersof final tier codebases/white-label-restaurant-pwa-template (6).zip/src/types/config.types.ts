/* ──────────────────────────────────────────────────────────────────────────
 * SCHEMAS FOR ALL WHITE-LABEL CONFIGURATION
 * Every knob a client deployment touches lives behind these interfaces.
 * UI components ONLY consume these shapes — never hard-coded values.
 * ────────────────────────────────────────────────────────────────────────── */

export type ThemeMode = "dark" | "light";

/** Visual density preset — scales the whole type/spacing rhythm via root font-size. */
export type UIDensity = "compact" | "cozy" | "airy";

export interface ThemeConfig {
  /** Brand primary — any CSS color string, e.g. "hsl(152 62% 46%)" or "#0E9F6E" */
  primaryColor: string;
  /** Secondary warm accent (badges, highlights, "Best Seller", ticker) */
  accentColor: string;
  /** Hue (0–360) used to derive the tinted-neutral surface stack (bg, cards, lines) */
  baseHue: number;
  /** Global corner radius — e.g. "0.75rem". Every card/button re-derives from it. */
  radius: string;
  /** Toggles frosted glass surfaces → falls back to solid opaque surfaces */
  enableGlassmorphism: boolean;
  defaultMode: ThemeMode;
  /** Font stacks — loaded via <link> in index.html, wired here as CSS vars */
  fonts: { display: string; body: string };
  density: UIDensity;
}

export interface WifiConfig {
  ssid: string;
  pass: string;
}

/**
 * Feature flags — flipping any of these adds/removes UI everywhere at once
 * (quick-action grid, bottom nav tabs, cart actions, sheets).
 */
export interface FeatureToggles {
  enableBookings: boolean;
  enableReviews: boolean;
  enableWifi: boolean;
  enableWhatsApp: boolean;
  enableDirectOrdering: boolean;
  enableInstallPrompt: boolean;
}

/** n8n (or any) webhook endpoints — the only integration surface. */
export interface WebhookEndpoints {
  reservationUrl: string;
  feedbackUrl: string;
  orderUrl: string;
}

export interface OpeningHours {
  days: string;
  hours: string;
}

export interface SlotGroup {
  label: string;
  /** Lucide icon name rendered next to the group label */
  icon: string;
  slots: string[];
}

export interface RestaurantConfig {
  brand: {
    name: string;
    subtitle: string;
    /** Single letter (or short glyph) used for the icon-driven monogram tile */
    monogram: string;
    googleReviewUrl: string;
    /** Full international format, digits only — e.g. "+919876543210" */
    whatsappNumber: string;
    phone: string;
    address: string;
    wifi: WifiConfig;
  };
  service: {
    /** ISO currency code used by Intl.NumberFormat — e.g. "INR", "USD", "AED" */
    currency: string;
    locale: string;
    /** e.g. 0.05 → 5% GST line in the cart sheet */
    taxRate: number;
    /** NFC table identifier shown in the Tap-Mode context badge */
    defaultTableId: string;
    /** Live status line rendered in the top bar pill */
    kitchenStatus: string;
  };
  hours: OpeningHours[];
  reservationSlots: SlotGroup[];
  features: FeatureToggles;
  n8nWebhooks: WebhookEndpoints;
}
