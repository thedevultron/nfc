/* ──────────────────────────────────────────────────────────────────────────
 * SCHEMAS FOR MENU, CART, RESERVATIONS, ORDERS & FEEDBACK
 * ────────────────────────────────────────────────────────────────────────── */

export type DietTag = "veg" | "nonveg" | "vegan";

/** Lucide icon name string — resolved at render time by <DynamicIcon /> */
export type IconName = string;

export interface MenuCategory {
  id: string;
  label: string;
  icon: IconName;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  /** Must match a MenuCategory.id */
  category: string;
  diet: DietTag;
  /** 0–3 rendered as Flame indicators on the dish card */
  spice: 0 | 1 | 2 | 3;
  bestSeller?: boolean;
  /** false → greyed card, "Sold Out" Ban badge, add-to-cart disabled */
  isAvailable: boolean;
  /** Icon shown in the dish medallion */
  icon: IconName;
  /** Kitchen estimate, e.g. "12 min" */
  time: string;
}

export interface CartLine {
  item: MenuItem;
  qty: number;
}

export type ServiceMode = "dinein" | "takeaway";

export interface OrderLinePayload {
  name: string;
  qty: number;
  price: number;
  total: number;
}

export interface OrderPayload {
  orderRef: string;
  tableId: string;
  mode: ServiceMode;
  lines: OrderLinePayload[];
  notes: string;
  subtotal: number;
  tax: number;
  total: number;
  placedAt: string;
}

export interface ReservationPayload {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  tableId: string;
  notes: string;
  createdAt: string;
}

export interface FeedbackPayload {
  rating: number;
  name: string;
  message: string;
  tableId: string;
  createdAt: string;
}
