import type { RestaurantConfig } from "../types/config.types";

/* ──────────────────────────────────────────────────────────────────────────
 *  RESTAURANT CONFIG  ·  WHITE-LABEL BUSINESS LAYER
 *  ────────────────────────────────────────────────────────────────────────
 *  Everything identity-, feature- and integration-specific lives here:
 *    • brand.*          → name, subtitle, monogram letter, review link,
 *      WhatsApp number, WiFi credentials, address, phone.
 *    • service.*        → currency/locale (Intl formatted everywhere), tax
 *      rate for the cart sheet, NFC table id, live-status pill text.
 *    • features.*       → flipping a flag adds/removes the matching UI in
 *      the quick-action grid, bottom nav and cart actions. Zero code edits.
 *    • n8nWebhooks.*    → point these at a live n8n instance and every
 *      reservation / feedback / order dispatches there automatically.
 *      While they contain "your-n8n-instance" the app runs in TEMPLATE MODE
 *      (optimistic mock responses, logged to console).
 * ────────────────────────────────────────────────────────────────────────── */

export const restaurantConfig: RestaurantConfig = {
  brand: {
    name: "Aura Bistro & Lounge",
    subtitle: "Modern Culinary Experience",
    monogram: "A",
    googleReviewUrl: "https://maps.google.com/?cid=aura-bistro-lounge",
    whatsappNumber: "+919876543210",
    phone: "+91 98765 43210",
    address: "12 Indigo Lane, Fort District, Mumbai 400001",
    wifi: { ssid: "Aura_Guest_5G", pass: "Bistro@2026" },
  },
  service: {
    currency: "INR",
    locale: "en-IN",
    taxRate: 0.05,
    defaultTableId: "04",
    kitchenStatus: "Open · till 23:30",
  },
  hours: [
    { days: "Mon – Thu", hours: "12:00 – 23:00" },
    { days: "Fri – Sat", hours: "12:00 – 01:00" },
    { days: "Sunday", hours: "11:00 – 23:30" },
  ],
  reservationSlots: [
    { label: "Lunch", icon: "Sun", slots: ["12:00", "12:30", "13:00", "13:30", "14:30"] },
    { label: "Sunset", icon: "Sunset", slots: ["17:00", "17:30", "18:00", "18:30"] },
    { label: "Dinner", icon: "Moon", slots: ["19:00", "19:30", "20:00", "20:30", "21:00", "21:30"] },
  ],
  features: {
    enableBookings: true,
    enableReviews: true,
    enableWifi: true,
    enableWhatsApp: true,
    enableDirectOrdering: true,
    enableInstallPrompt: true,
  },
  n8nWebhooks: {
    reservationUrl: "https://your-n8n-instance.com/webhook/reservation",
    feedbackUrl: "https://your-n8n-instance.com/webhook/feedback",
    orderUrl: "https://your-n8n-instance.com/webhook/order",
  },
};
