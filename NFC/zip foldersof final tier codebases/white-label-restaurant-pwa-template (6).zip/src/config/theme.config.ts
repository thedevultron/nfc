import type { ThemeConfig } from "../types/config.types";

/* ──────────────────────────────────────────────────────────────────────────
 *  THEME CONFIG  ·  WHITE-LABEL SKIN LAYER
 *  ────────────────────────────────────────────────────────────────────────
 *  Deploying for a new client? Edit ONLY this file:
 *    • primaryColor / accentColor  → recolors every button, badge, glow,
 *      active tab, stepper, selection state across the entire app.
 *    • baseHue                     → retints the neutral stack (background,
 *      cards, borders, text) so surfaces match the brand temperature.
 *    • radius                      → global corner rounding (cards derive it,
 *      drawers/sheets multiply it).
 *    • fonts                       → display + body stacks (load them in
 *      index.html; nothing else references font names).
 *    • density                     → "compact" | "cozy" | "airy" scales the
 *      root font-size; every rem-based spacing/size follows.
 *    • enableGlassmorphism=false   → frosted surfaces become solid.
 *  No component file needs to be opened. Ever.
 * ────────────────────────────────────────────────────────────────────────── */

export const themeConfig: ThemeConfig = {
  primaryColor: "hsl(152 62% 46%)", // emerald — brand primary
  accentColor: "hsl(38 92% 60%)", // candlelight amber — highlights & badges
  baseHue: 158, // deep forest-tinted neutrals
  radius: "1.1rem",
  enableGlassmorphism: true,
  defaultMode: "dark",
  fonts: {
    display: '"Fraunces", "Georgia", serif',
    body: '"DM Sans", "Segoe UI", sans-serif',
  },
  density: "cozy",
};

const DENSITY_FONT_SIZE: Record<ThemeConfig["density"], string> = {
  compact: "15px",
  cozy: "16px",
  airy: "17.5px",
};

/**
 * Projects the config above into CSS custom properties on <html>.
 * Called once on app boot — Tailwind utilities read these vars, so the whole
 * skin re-derives from this single file.
 */
export function applyTheme(t: ThemeConfig = themeConfig): void {
  const el = document.documentElement;
  const dark = t.defaultMode === "dark";
  const h = t.baseHue;

  // Tinted neutral stack — derived from baseHue so it always matches the brand.
  el.style.setProperty("--background", dark ? `hsl(${h} 26% 7%)` : `hsl(${h} 30% 96%)`);
  el.style.setProperty("--surface", dark ? `hsl(${h} 18% 10.5%)` : `hsl(${h} 26% 99%)`);
  el.style.setProperty("--raise", dark ? `hsl(${h} 15% 13.5%)` : `hsl(${h} 22% 93%)`);
  el.style.setProperty("--line", dark ? `hsl(${h} 12% 19%)` : `hsl(${h} 14% 85%)`);
  el.style.setProperty("--ink", dark ? `hsl(${h - 110 < 0 ? h + 250 : h - 110} 26% 93%)` : `hsl(${h} 30% 12%)`);
  el.style.setProperty("--mute", dark ? `hsl(${h} 9% 62%)` : `hsl(${h} 10% 44%)`);
  el.style.setProperty("--danger", "hsl(4 72% 58%)");

  // Brand colors — straight from this file.
  el.style.setProperty("--primary", t.primaryColor);
  el.style.setProperty("--accent", t.accentColor);
  el.style.setProperty("--primary-ink", dark ? "hsl(160 45% 8%)" : "hsl(160 45% 10%)");
  el.style.setProperty("--accent-ink", "hsl(30 60% 12%)");

  el.style.setProperty("--radius", t.radius);
  el.style.setProperty("--stack-display", t.fonts.display);
  el.style.setProperty("--stack-body", t.fonts.body);

  el.dataset.mode = t.defaultMode;
  el.dataset.glass = String(t.enableGlassmorphism);
  el.dataset.density = t.density;
  el.style.fontSize = DENSITY_FONT_SIZE[t.density];
}
