import { restaurantConfig } from "../config/restaurant.config";

/* Currency formatting is derived from restaurant.config (currency + locale)
 * so a client switch (INR → USD → AED) updates every price in the app. */
const formatter = new Intl.NumberFormat(restaurantConfig.service.locale, {
  style: "currency",
  currency: restaurantConfig.service.currency,
  maximumFractionDigits: 0,
});

export function formatPrice(value: number): string {
  return formatter.format(value);
}
