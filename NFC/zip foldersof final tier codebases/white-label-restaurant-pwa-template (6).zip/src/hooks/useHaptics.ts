import { useCallback } from "react";

/* ──────────────────────────────────────────────────────────────────────────
 *  HAPTIC FEEDBACK HOOK
 *  Native mobile vibration (navigator.vibrate) wired to every meaningful
 *  touch: item adds, filter taps, star ratings, drawer triggers, sends.
 *  Safely no-ops on desktop / unsupported browsers.
 * ────────────────────────────────────────────────────────────────────────── */

const canVibrate = () => typeof navigator !== "undefined" && "vibrate" in navigator;

function buzz(pattern: number | number[]) {
  if (!canVibrate()) return;
  try {
    navigator.vibrate(pattern);
  } catch {
    /* ignored — haptics are progressive enhancement */
  }
}

export function useHaptics() {
  /** Light tick — list item / filter pill taps */
  const tick = useCallback(() => buzz(6), []);
  /** Standard tap — button presses, add-to-cart */
  const tap = useCallback(() => buzz(10), []);
  /** Selection settle — drawer opens, star chosen */
  const select = useCallback(() => buzz([8, 30, 8]), []);
  /** Success confirmation — order placed, copied, sent */
  const success = useCallback(() => buzz([12, 40, 18]), []);
  /** Error / sold-out attempt */
  const error = useCallback(() => buzz([40, 60, 40]), []);

  return { tick, tap, select, success, error };
}
