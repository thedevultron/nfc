import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { menuItems } from "../config/menuData";
import type { CartLine, MenuItem } from "../types/menu.types";

/* ──────────────────────────────────────────────────────────────────────────
 *  CART STATE HOOK
 *  Local cart: lines, totals, drawer controls, "just added" flash id for the
 *  animated counter. Hydrated from / persisted to localStorage per table so
 *  an accidental refresh never loses a guest's tray.
 * ────────────────────────────────────────────────────────────────────────── */

const STORAGE_KEY = "white-label-pwa.cart.v1";

/** Re-map persisted ids onto the live menu data (config-driven). */
const MENU_INDEX = new Map<string, MenuItem>(menuItems.map((i) => [i.id, i]));

function hydrate(): CartLine[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as { id: string; qty: number }[];
    return parsed
      .filter((p) => typeof p?.id === "string" && p.qty > 0 && MENU_INDEX.has(p.id))
      .map((p) => ({ item: MENU_INDEX.get(p.id)!, qty: p.qty }));
  } catch {
    return [];
  }
}

export function useCart() {
  const [lines, setLines] = useState<CartLine[]>(hydrate);
  const [isOpen, setIsOpen] = useState(false);
  const [justAddedId, setJustAddedId] = useState<string | null>(null);
  const flashTimer = useRef<number | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lines.map((l) => ({ id: l.item.id, qty: l.qty }))));
    } catch {
      /* private mode etc. */
    }
  }, [lines]);

  const flash = useCallback((id: string) => {
    setJustAddedId(id);
    if (flashTimer.current) window.clearTimeout(flashTimer.current);
    flashTimer.current = window.setTimeout(() => setJustAddedId(null), 650);
  }, []);

  const add = useCallback(
    (item: MenuItem) => {
      setLines((prev) => {
        const found = prev.find((l) => l.item.id === item.id);
        return found
          ? prev.map((l) => (l.item.id === item.id ? { ...l, qty: l.qty + 1 } : l))
          : [...prev, { item, qty: 1 }];
      });
      flash(item.id);
    },
    [flash],
  );

  const increment = useCallback((id: string) => {
    setLines((prev) => prev.map((l) => (l.item.id === id ? { ...l, qty: l.qty + 1 } : l)));
  }, []);

  const decrement = useCallback((id: string) => {
    setLines((prev) =>
      prev
        .map((l) => (l.item.id === id ? { ...l, qty: l.qty - 1 } : l))
        .filter((l) => l.qty > 0),
    );
  }, []);

  const remove = useCallback((id: string) => {
    setLines((prev) => prev.filter((l) => l.item.id !== id));
  }, []);

  const clear = useCallback(() => setLines([]), []);

  const qtyFor = useCallback(
    (id: string) => lines.find((l) => l.item.id === id)?.qty ?? 0,
    [lines],
  );

  const { count, subtotal } = useMemo(
    () => ({
      count: lines.reduce((n, l) => n + l.qty, 0),
      subtotal: lines.reduce((n, l) => n + l.qty * l.item.price, 0),
    }),
    [lines],
  );

  return {
    lines,
    count,
    subtotal,
    isOpen,
    open: useCallback(() => setIsOpen(true), []),
    close: useCallback(() => setIsOpen(false), []),
    add,
    increment,
    decrement,
    remove,
    clear,
    qtyFor,
    justAddedId,
  };
}

export type CartApi = ReturnType<typeof useCart>;
