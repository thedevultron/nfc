import { restaurantConfig } from "@/config/restaurant.config";
import type { OrderPayload } from "@/types/menu.types";

export function formatMoney(amount: number) {
  const { currencySymbol, locale } = restaurantConfig.brand;
  try {
    const formatted = new Intl.NumberFormat(locale, {
      maximumFractionDigits: 0,
    }).format(amount);
    return `${currencySymbol}${formatted}`;
  } catch {
    return `${currencySymbol}${amount}`;
  }
}

export function formatWhatsAppOrder(payload: OrderPayload) {
  const { brand } = restaurantConfig;
  const header = `*${brand.name} — New Order*`;
  const where =
    payload.mode === "dine-in"
      ? `Table ${payload.tableNumber ?? "—"} · Dine-in`
      : "Takeaway";
  const lines = payload.items
    .map(
      (i) =>
        `• ${i.quantity}× ${i.name} — ${formatMoney(i.price * i.quantity)}`,
    )
    .join("\n");
  const notes = payload.notes?.trim()
    ? `\n_Notes:_ ${payload.notes.trim()}`
    : "";
  return `${header}\n${where}\n\n${lines}\n\nSubtotal ${formatMoney(payload.subtotal)}\nTax ${formatMoney(payload.tax)}\n*Total ${formatMoney(payload.total)}*${notes}`;
}

export function whatsappHref(text: string) {
  const num = restaurantConfig.brand.whatsappNumber.replace(/[^\d]/g, "");
  return `https://wa.me/${num}?text=${encodeURIComponent(text)}`;
}

export function wifiQrValue() {
  const { ssid, pass, security } = restaurantConfig.brand.wifi;
  return `WIFI:T:${security};S:${ssid};P:${pass};;`;
}

export function todayISODate() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function formatPrettyDate(iso: string) {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString(restaurantConfig.brand.locale, {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}
