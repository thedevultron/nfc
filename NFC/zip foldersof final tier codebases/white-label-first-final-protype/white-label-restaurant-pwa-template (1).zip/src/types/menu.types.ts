/**
 * MENU / CART / BOOKING / FEEDBACK SCHEMAS
 * ----------------------------------------------------------------------------
 * All feature modules consume these types. Swap /src/config/menuData.ts
 * to re-catalogue an entire venue without touching UI code.
 */

export type DietaryTag = "veg" | "non-veg" | "vegan" | "gluten-free";

export type SpiceLevel = 0 | 1 | 2 | 3;

export interface MenuCategory {
  id: string;
  name: string;
  /** PascalCase Lucide icon name, resolved by <DynamicIcon />. */
  icon: string;
  description?: string;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  categoryId: string;
  /** Lucide icon representing the dish on its card. */
  icon: string;
  dietary: DietaryTag[];
  spiceLevel: SpiceLevel;
  isBestSeller: boolean;
  isChefsSpecial: boolean;
  isAvailable: boolean;
  prepMinutes?: number;
}

export interface CartLine {
  item: MenuItem;
  quantity: number;
}

export interface OrderPayload {
  tableNumber: string | null;
  mode: "dine-in" | "takeaway";
  items: Array<{
    id: string;
    name: string;
    quantity: number;
    price: number;
  }>;
  notes: string;
  subtotal: number;
  tax: number;
  total: number;
  placedAt: string;
}

export interface ReservationPayload {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  notes: string;
  placedAt: string;
}

export type FeedbackCategory = "food" | "service" | "ambience" | "wait";

export interface FeedbackPayload {
  rating: number;
  categories: FeedbackCategory[];
  comment: string;
  tableNumber: string | null;
  placedAt: string;
}

export interface ApiResult {
  success: boolean;
  message: string;
  mock?: boolean;
}

export type AppTab = "menu" | "book" | "cart" | "more";

export type ServiceMode = "dine-in" | "takeaway";
