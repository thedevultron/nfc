/**
 * WHITE-LABEL SCHEMA
 * ----------------------------------------------------------------------------
 * Client deployments should ONLY mutate files in /src/config.
 * These interfaces are the contract those config files must satisfy.
 * Changing a color, feature flag, webhook, or Lucide icon name in config
 * re-skins and re-wires the entire PWA with zero component edits.
 */

export type ColorMode = "dark" | "light";

/** Density tightens spacing & type scale for compact cafe kiosks. */
export type UiDensity = "comfortable" | "compact";

export interface ThemeConfig {
  /** Any valid CSS color. Applied as --color-primary at runtime. */
  primaryColor: string;
  /** Accent used for Chef's Specials, gold badges, and highlights. */
  accentColor: string;
  /** CSS border-radius token, e.g. "0.75rem" or "1.25rem". */
  radius: string;
  /** When true, surfaces use backdrop-blur glass panels. */
  enableGlassmorphism: boolean;
  defaultMode: ColorMode;
  /** Display / heading font family (loaded in index.html). */
  fontDisplay: string;
  /** Body / UI font family. */
  fontBody: string;
  density: UiDensity;
}

export interface WifiConfig {
  ssid: string;
  pass: string;
  /** WPA | WEP | nopass — used to encode the WIFI: QR payload. */
  security: "WPA" | "WEP" | "nopass";
}

export interface BrandConfig {
  name: string;
  subtitle: string;
  /** Lucide icon name shown beside the wordmark (e.g. "ChefHat"). */
  icon: string;
  tagline: string;
  address: string;
  phone: string;
  hours: string;
  googleReviewUrl: string;
  /** E.164, no spaces. Used to build wa.me deep links. */
  whatsappNumber: string;
  /** Prefills the WhatsApp concierge message. */
  whatsappGreeting: string;
  wifi: WifiConfig;
  currencySymbol: string;
  /** Applied on cart subtotal. Set 0 to hide tax line. */
  taxPercent: number;
  locale: string;
}

export interface FeatureFlags {
  enableBookings: boolean;
  enableReviews: boolean;
  enableWifi: boolean;
  enableDirectOrdering: boolean;
  enableWhatsApp: boolean;
  enablePwaInstall: boolean;
}

export interface N8nWebhooks {
  reservationUrl: string;
  feedbackUrl: string;
  orderUrl: string;
}

export interface RestaurantConfig {
  brand: BrandConfig;
  features: FeatureFlags;
  n8nWebhooks: N8nWebhooks;
  /**
   * Default NFC table shown when ?table= is absent.
   * Set null to boot directly into Takeaway Mode.
   */
  defaultTable: string | null;
}
