/**
 * DOMAIN API FACADE
 * ----------------------------------------------------------------------------
 * Feature modules call these methods only. Webhook URLs live in
 * /src/config/restaurant.config.ts — never hard-code endpoints in UI.
 */
import { restaurantConfig } from "@/config/restaurant.config";
import { postWebhook } from "@/services/n8n.service";
import type {
  ApiResult,
  FeedbackPayload,
  OrderPayload,
  ReservationPayload,
} from "@/types/menu.types";

export const apiService = {
  async sendReservation(payload: ReservationPayload): Promise<ApiResult> {
    console.log(
      "Sending reservation to n8n:",
      restaurantConfig.n8nWebhooks.reservationUrl,
      payload,
    );
    return postWebhook(restaurantConfig.n8nWebhooks.reservationUrl, {
      type: "reservation",
      venue: restaurantConfig.brand.name,
      ...payload,
    });
  },

  async sendFeedback(payload: FeedbackPayload): Promise<ApiResult> {
    console.log(
      "Sending feedback to n8n:",
      restaurantConfig.n8nWebhooks.feedbackUrl,
      payload,
    );
    return postWebhook(restaurantConfig.n8nWebhooks.feedbackUrl, {
      type: "feedback",
      venue: restaurantConfig.brand.name,
      ...payload,
    });
  },

  async sendOrder(payload: OrderPayload): Promise<ApiResult> {
    console.log(
      "Sending order to n8n:",
      restaurantConfig.n8nWebhooks.orderUrl,
      payload,
    );
    return postWebhook(restaurantConfig.n8nWebhooks.orderUrl, {
      type: "order",
      venue: restaurantConfig.brand.name,
      ...payload,
    });
  },
};
