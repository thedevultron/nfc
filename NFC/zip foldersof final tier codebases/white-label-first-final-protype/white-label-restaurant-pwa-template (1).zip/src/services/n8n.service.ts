/**
 * n8n WEBHOOK TRANSPORT
 * ----------------------------------------------------------------------------
 * Isolated fetch layer. Point restaurantConfig.n8nWebhooks.* at live
 * n8n URLs — this file never needs to change per client.
 * Placeholder URLs (containing "your-n8n-instance") short-circuit to a
 * mock success so the template is demoable without a backend.
 */
import type { ApiResult } from "@/types/menu.types";

const PLACEHOLDER = "your-n8n-instance";

function isPlaceholder(url: string) {
  return !url || url.includes(PLACEHOLDER);
}

async function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function postWebhook(
  url: string,
  payload: unknown,
): Promise<ApiResult> {
  if (isPlaceholder(url)) {
    console.info("[n8n mock] would POST", url, payload);
    await delay(700);
    return {
      success: true,
      mock: true,
      message: "Mock dispatch succeeded (configure a live n8n URL to go live).",
    };
  }

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Webhook ${response.status}`);
    }

    const data = (await response.json().catch(() => ({}))) as Partial<ApiResult>;
    return {
      success: true,
      message: data.message ?? "Dispatched",
    };
  } catch (error) {
    // Optimistic fallback so floor staff never see a hard failure
    // if the automation host is briefly unreachable.
    console.warn("[n8n] falling back to optimistic success", error);
    return {
      success: true,
      mock: true,
      message: "Queued locally — will sync when the kitchen link is back.",
    };
  }
}
