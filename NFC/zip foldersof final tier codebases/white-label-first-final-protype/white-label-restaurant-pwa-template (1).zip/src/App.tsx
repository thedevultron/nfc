import { AnimatePresence, motion } from "framer-motion";
import { ThemeProvider } from "@/components/layout/ThemeProvider";
import { Shell } from "@/components/layout/Shell";
import { CartProvider } from "@/hooks/useCart";
import { SheetsProvider } from "@/hooks/useSheets";

export default function App() {
  return (
    <ThemeProvider>
      <CartProvider>
        <SheetsProvider>
          <AnimatePresence>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.45 }}
              className="min-h-dvh bg-background text-foreground"
            >
              <Shell />
            </motion.div>
          </AnimatePresence>
        </SheetsProvider>
      </CartProvider>
    </ThemeProvider>
  );
}
