/**
 * CLIENT THEME TOKENS
 * ----------------------------------------------------------------------------
 * Edit THIS file to re-skin the entire PWA:
 *  - primaryColor / accentColor drive buttons, pills, glows, and focus rings
 *  - radius is applied to every card, sheet, and chip
 *  - enableGlassmorphism toggles frosted surfaces vs solid panels
 *  - defaultMode switches the global dark/light palette
 *  - density compact | comfortable scales paddings & type
 * No component source needs to change.
 */
import type { ThemeConfig } from "@/types/config.types";

export const themeConfig: ThemeConfig = {
  primaryColor: "hsl(142.1 76.2% 36.3%)",
  accentColor: "hsl(38 72% 52%)",
  radius: "0.85rem",
  enableGlassmorphism: true,
  defaultMode: "dark",
  fontDisplay: "Fraunces",
  fontBody: "Outfit",
  density: "comfortable",
};
