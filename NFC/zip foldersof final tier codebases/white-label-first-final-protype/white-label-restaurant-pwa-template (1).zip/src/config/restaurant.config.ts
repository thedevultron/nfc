/**
 * CLIENT BUSINESS CONFIG
 * ----------------------------------------------------------------------------
 * Swap brand copy, WhatsApp number, Google review URL, WiFi credentials,
 * feature flags, and n8n webhook URLs here. Feature flags hide entire
 * modules (booking, reviews, wifi, cart) without deleting components.
 *
 * NFC: append ?table=12 to the URL and the header badge becomes
 * "Table 12 | Tap Mode Active". Leave defaultTable null for takeaway-only.
 */
import type { RestaurantConfig } from "@/types/config.types";

export const restaurantConfig: RestaurantConfig = {
  brand: {
    name: "Aura Bistro & Lounge",
    subtitle: "Modern Culinary Experience",
    icon: "ChefHat",
    tagline: "Seasonal plates, slow fire, and a room that glows after dusk.",
    address: "14 Marine Drive, Colaba, Mumbai 400001",
    phone: "+91 22 6654 2100",
    hours: "Lunch 12:00–15:30  ·  Dinner 18:30–23:30",
    googleReviewUrl: "https://maps.google.com/?q=Aura+Bistro+Lounge+Mumbai",
    whatsappNumber: "+919876543210",
    whatsappGreeting:
      "Hello Aura Bistro! I'd like to ask about today's menu and a table.",
    wifi: { ssid: "Aura_Guest_5G", pass: "Bistro@2026", security: "WPA" },
    currencySymbol: "₹",
    taxPercent: 5,
    locale: "en-IN",
  },
  features: {
    enableBookings: true,
    enableReviews: true,
    enableWifi: true,
    enableDirectOrdering: true,
    enableWhatsApp: true,
    enablePwaInstall: true,
  },
  n8nWebhooks: {
    reservationUrl: "https://your-n8n-instance.com/webhook/reservation",
    feedbackUrl: "https://your-n8n-instance.com/webhook/feedback",
    orderUrl: "https://your-n8n-instance.com/webhook/order",
  },
  defaultTable: "04",
};
