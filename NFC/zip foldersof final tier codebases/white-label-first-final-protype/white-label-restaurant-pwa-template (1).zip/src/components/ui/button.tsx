import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { motion, type HTMLMotionProps } from "framer-motion";
import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/utils/cn";

export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-colors select-none disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/70 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-primary text-primary-foreground shadow-[0_8px_24px_-8px_var(--color-primary)] hover:brightness-110",
        gold: "bg-accent text-accent-foreground shadow-[0_8px_24px_-8px_var(--color-accent)] hover:brightness-110",
        outline:
          "border border-border bg-transparent text-foreground hover:bg-foreground/5",
        ghost: "text-foreground hover:bg-foreground/8",
        surface:
          "bg-card text-foreground border border-border hover:border-primary/40",
        destructive: "bg-rose-600 text-white hover:bg-rose-500",
      },
      size: {
        default: "h-12 min-h-12 px-5 text-sm rounded-[var(--radius)]",
        sm: "h-10 min-h-10 px-3.5 text-sm rounded-[calc(var(--radius)-2px)]",
        lg: "h-14 min-h-14 px-6 text-base rounded-[var(--radius)]",
        icon: "h-12 w-12 min-h-12 min-w-12 rounded-[var(--radius)]",
        chip: "h-10 min-h-10 px-3.5 text-xs rounded-full",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  },
);

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

type Props = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
    motionless?: boolean;
  };

export const Button = forwardRef<HTMLButtonElement, Props>(
  (
    { className, variant, size, asChild, motionless, children, ...props },
    ref,
  ) => {
    const classes = cn(buttonVariants({ variant, size }), className);
    if (asChild) {
      return (
        <Slot className={classes} ref={ref} {...props}>
          {children}
        </Slot>
      );
    }
    if (motionless) {
      return (
        <button ref={ref} className={classes} {...props}>
          {children}
        </button>
      );
    }
    return (
      <motion.button
        ref={ref}
        className={classes}
        whileTap={{ scale: 0.94 }}
        transition={spring}
        {...(props as HTMLMotionProps<"button">)}
      >
        {children}
      </motion.button>
    );
  },
);
Button.displayName = "Button";
