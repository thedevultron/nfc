import { Star } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/utils/cn";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

export function StarRating({
  value,
  onChange,
  size = 32,
}: {
  value: number;
  onChange: (n: number) => void;
  size?: number;
}) {
  return (
    <div className="flex items-center justify-center gap-2" role="radiogroup" aria-label="Rating">
      {[1, 2, 3, 4, 5].map((n) => {
        const active = n <= value;
        return (
          <motion.button
            key={n}
            type="button"
            role="radio"
            aria-checked={active}
            whileTap={{ scale: 0.85 }}
            transition={spring}
            onClick={() => onChange(n)}
            className="flex h-12 w-12 min-h-12 min-w-12 items-center justify-center"
          >
            <Star
              size={size}
              className={cn(
                "transition-colors",
                active
                  ? "fill-accent text-accent"
                  : "fill-transparent text-foreground/25",
              )}
            />
          </motion.button>
        );
      })}
    </div>
  );
}
