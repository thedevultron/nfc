import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-[var(--radius)] border border-border bg-card text-foreground",
        "glass:bg-card/70 glass:backdrop-blur-xl",
        className,
      )}
      {...props}
    />
  );
}
