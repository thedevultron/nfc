/**
 * Resolves PascalCase Lucide names from /src/config so clients can
 * swap category / dish / brand icons without importing components.
 */
import { icons, type LucideProps } from "lucide-react";
import { cn } from "@/utils/cn";

export type IconName = keyof typeof icons;

export function DynamicIcon({
  name,
  className,
  ...props
}: { name: string } & LucideProps) {
  const Icon = icons[name as IconName];
  if (!Icon) {
    const Fallback = icons.Utensils;
    return <Fallback className={cn("shrink-0", className)} {...props} />;
  }
  return <Icon className={cn("shrink-0", className)} {...props} />;
}
