import { cva, type VariantProps } from "class-variance-authority";
import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider",
  {
    variants: {
      variant: {
        default: "bg-primary/15 text-primary",
        gold: "bg-accent/15 text-accent",
        outline: "border border-border text-muted",
        sold: "bg-rose-500/15 text-rose-400",
        veg: "bg-emerald-500/15 text-emerald-400",
        nonveg: "bg-rose-500/15 text-rose-400",
        vegan: "bg-lime-500/15 text-lime-400",
        muted: "bg-foreground/8 text-muted",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export function Badge({
  className,
  variant,
  ...props
}: HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>) {
  return (
    <span className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}
