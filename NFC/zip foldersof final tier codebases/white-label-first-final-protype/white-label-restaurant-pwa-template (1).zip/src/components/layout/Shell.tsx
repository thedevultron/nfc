/**
 * App chrome. Feature modules mount here; client theming never edits this file.
 */
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";
import { TopBar } from "@/components/layout/TopBar";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { MenuList } from "@/components/features/MenuList";
import { MorePanel } from "@/components/features/MorePanel";
import { CartSheet } from "@/components/features/CartSheet";
import { ReservationSheet } from "@/components/features/ReservationSheet";
import { ReviewModal } from "@/components/features/ReviewModal";
import { WifiSheet } from "@/components/features/WifiSheet";
import { PWAInstallBanner } from "@/components/features/PWAInstallBanner";
import { useCart } from "@/hooks/useCart";
import { restaurantConfig } from "@/config/restaurant.config";
import { formatMoney } from "@/lib/format";
import type { AppTab } from "@/types/menu.types";

export function Shell() {
  const [tab, setTab] = useState<AppTab>("menu");
  const cart = useCart();
  const showMenuChrome = tab === "menu" || tab === "cart" || tab === "book";

  return (
    <div className="relative mx-auto min-h-dvh w-full max-w-lg overflow-x-hidden">
      <Ambient />

      <TopBar />
      {showMenuChrome && tab !== "more" && <Header />}

      <main className="relative pb-36">
        <AnimatePresence mode="wait">
          {tab === "more" ? (
            <motion.div
              key="more"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22 }}
            >
              <MorePanel />
            </motion.div>
          ) : (
            <motion.div
              key="menu"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22 }}
            >
              <MenuList />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {restaurantConfig.features.enableDirectOrdering &&
        cart.itemCount > 0 &&
        !cart.isOpen && (
          <motion.button
            type="button"
            initial={{ y: 24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            onClick={cart.openCart}
            className="fixed inset-x-4 z-30 bottom-[5.5rem] flex h-14 min-h-14 items-center justify-between rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-[0_12px_32px_-8px_var(--color-primary)]"
          >
            <span className="flex items-center gap-2">
              <ShoppingBag size={16} />
              {cart.itemCount} {cart.itemCount === 1 ? "item" : "items"}
            </span>
            <span className="tabular-nums">{formatMoney(cart.total)} · View bag</span>
          </motion.button>
        )}

      <PWAInstallBanner />
      <BottomNav tab={tab} onTab={setTab} />

      <CartSheet />
      {restaurantConfig.features.enableBookings && <ReservationSheet />}
      {restaurantConfig.features.enableReviews && <ReviewModal />}
      {restaurantConfig.features.enableWifi && <WifiSheet />}
    </div>
  );
}

function Ambient() {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
    >
      <div className="absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-primary/25 blur-[110px]" />
      <div className="absolute bottom-24 -right-16 h-64 w-64 rounded-full bg-accent/15 blur-[90px]" />
      <div className="absolute bottom-1/3 -left-20 h-52 w-52 rounded-full bg-primary/10 blur-[80px]" />
    </div>
  );
}
