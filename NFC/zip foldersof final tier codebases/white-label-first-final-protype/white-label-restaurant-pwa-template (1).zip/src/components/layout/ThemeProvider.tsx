/**
 * Pushes theme.config tokens onto :root so every Tailwind / CSS variable
 * consumer restyles instantly when a client edits /src/config/theme.config.ts.
 */
import { useEffect, type ReactNode } from "react";
import { themeConfig } from "@/config/theme.config";

export function ThemeProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--color-primary", themeConfig.primaryColor);
    root.style.setProperty("--color-accent", themeConfig.accentColor);
    root.style.setProperty("--radius", themeConfig.radius);
    root.style.setProperty("--font-display", `"${themeConfig.fontDisplay}", serif`);
    root.style.setProperty("--font-sans", `"${themeConfig.fontBody}", system-ui, sans-serif`);
    root.dataset.theme = themeConfig.defaultMode;
    root.dataset.density = themeConfig.density;
    root.classList.toggle("glass", themeConfig.enableGlassmorphism);
    document.body.style.fontFamily = `"${themeConfig.fontBody}", system-ui, sans-serif`;
  }, []);

  return children;
}
