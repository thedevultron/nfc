import { Calendar, Info, ShoppingBag, Utensils } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { restaurantConfig } from "@/config/restaurant.config";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { useSheets } from "@/hooks/useSheets";
import { cn } from "@/utils/cn";
import type { AppTab } from "@/types/menu.types";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

interface Props {
  tab: AppTab;
  onTab: (t: AppTab) => void;
}

export function BottomNav({ tab, onTab }: Props) {
  const { itemCount, openCart } = useCart();
  const { openSheet } = useSheets();
  const haptics = useHaptics();
  const { features } = restaurantConfig;

  const items = [
    { id: "menu" as const, label: "Menu", icon: Utensils, show: true },
    {
      id: "book" as const,
      label: "Reserve",
      icon: Calendar,
      show: features.enableBookings,
    },
    {
      id: "cart" as const,
      label: "Cart",
      icon: ShoppingBag,
      show: features.enableDirectOrdering,
    },
    { id: "more" as const, label: "More", icon: Info, show: true },
  ].filter((i) => i.show);

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 px-3 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2">
      <div className="glass-panel mx-auto flex max-w-lg items-center justify-around rounded-full px-2 py-1.5">
        {items.map((item) => {
          const active = tab === item.id;
          const Icon = item.icon;
          return (
            <motion.button
              key={item.id}
              type="button"
              whileTap={{ scale: 0.9 }}
              transition={spring}
              onClick={() => {
                haptics.select();
                if (item.id === "cart") {
                  openCart();
                  onTab("cart");
                  return;
                }
                if (item.id === "book") {
                  openSheet("reservation");
                  onTab("book");
                  return;
                }
                onTab(item.id);
              }}
              className={cn(
                "relative flex h-12 min-h-12 min-w-16 flex-1 flex-col items-center justify-center gap-0.5 rounded-full px-3 text-[10px] font-semibold",
                active ? "text-primary" : "text-muted",
              )}
            >
              {active && (
                <motion.span
                  layoutId="tab-glow"
                  className="absolute inset-0 rounded-full bg-primary/12"
                  transition={spring}
                />
              )}
              <span className="relative">
                <Icon size={20} />
                {item.id === "cart" && itemCount > 0 && (
                  <AnimatePresence>
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -right-2.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground"
                    >
                      {itemCount}
                    </motion.span>
                  </AnimatePresence>
                )}
              </span>
              <span className="relative">{item.label}</span>
            </motion.button>
          );
        })}
      </div>
    </nav>
  );
}
