/**
 * Dynamic Action Header — NFC context lives in TopBar.
 * Quick-action tiles are gated by restaurantConfig.features so a client
 * can hide WiFi / WhatsApp / Reviews / Booking without touching this file.
 */
import { Calendar, MessageCircle, Star, Wifi } from "lucide-react";
import { motion } from "framer-motion";
import { restaurantConfig } from "@/config/restaurant.config";
import { useSheets } from "@/hooks/useSheets";
import { whatsappHref } from "@/lib/format";
import { cn } from "@/utils/cn";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

interface Action {
  key: string;
  label: string;
  hint: string;
  icon: typeof Wifi;
  enabled: boolean;
  onClick: () => void;
}

export function Header() {
  const { openSheet } = useSheets();
  const { features, brand } = restaurantConfig;

  const actions: Action[] = [
    {
      key: "wifi",
      label: "WiFi",
      hint: "Instant join",
      icon: Wifi,
      enabled: features.enableWifi,
      onClick: () => openSheet("wifi"),
    },
    {
      key: "wa",
      label: "WhatsApp",
      hint: "Concierge",
      icon: MessageCircle,
      enabled: features.enableWhatsApp,
      onClick: () => {
        window.open(whatsappHref(brand.whatsappGreeting), "_blank", "noopener");
      },
    },
    {
      key: "review",
      label: "Review",
      hint: "Rate us",
      icon: Star,
      enabled: features.enableReviews,
      onClick: () => openSheet("review"),
    },
    {
      key: "book",
      label: "Book",
      hint: "Reserve",
      icon: Calendar,
      enabled: features.enableBookings,
      onClick: () => openSheet("reservation"),
    },
  ].filter((a) => a.enabled);

  if (actions.length === 0) return null;

  return (
    <section className="px-4 pb-3">
      <div
        className={cn(
          "grid gap-2",
          actions.length === 1 && "grid-cols-1",
          actions.length === 2 && "grid-cols-2",
          actions.length === 3 && "grid-cols-3",
          actions.length >= 4 && "grid-cols-4",
        )}
      >
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <motion.button
              key={action.key}
              type="button"
              whileTap={{ scale: 0.94 }}
              transition={spring}
              onClick={action.onClick}
              className="glass-panel flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-[var(--radius)] px-1 py-3"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/12 text-primary">
                <Icon size={18} />
              </span>
              <span className="text-[11px] font-semibold leading-none text-foreground">
                {action.label}
              </span>
              <span className="text-[9px] uppercase tracking-wider text-muted">
                {action.hint}
              </span>
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}
