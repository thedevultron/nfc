import { Nfc, ShoppingBag, Utensils } from "lucide-react";
import { motion } from "framer-motion";
import { restaurantConfig } from "@/config/restaurant.config";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { DynamicIcon } from "@/components/ui/icon";
import { cn } from "@/utils/cn";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

export function TopBar() {
  const { mode, tableNumber, setMode, itemCount, openCart } = useCart();
  const haptics = useHaptics();
  const dineIn = mode === "dine-in";

  return (
    <header className="sticky top-0 z-30 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2">
      <div className="glass-panel flex items-center gap-3 rounded-[var(--radius)] px-3 py-2.5">
        <div className="flex h-11 w-11 min-h-11 min-w-11 items-center justify-center rounded-[calc(var(--radius)-4px)] bg-primary/15 text-primary">
          <DynamicIcon name={restaurantConfig.brand.icon} size={22} />
        </div>

        <div className="min-w-0 flex-1">
          <h1 className="font-display truncate text-[15px] font-semibold leading-tight tracking-tight text-foreground">
            {restaurantConfig.brand.name}
          </h1>
          <p className="truncate text-[11px] text-muted">
            {restaurantConfig.brand.subtitle}
          </p>
        </div>

        {restaurantConfig.features.enableDirectOrdering && (
          <motion.button
            type="button"
            whileTap={{ scale: 0.92 }}
            transition={spring}
            onClick={openCart}
            className="relative flex h-12 w-12 min-h-12 min-w-12 items-center justify-center rounded-full text-foreground"
            aria-label="Open cart"
          >
            <ShoppingBag size={20} />
            {itemCount > 0 && (
              <span className="absolute right-2 top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                {itemCount}
              </span>
            )}
          </motion.button>
        )}
      </div>

      <motion.button
        type="button"
        whileTap={{ scale: 0.98 }}
        transition={spring}
        onClick={() => {
          haptics.select();
          if (dineIn) setMode("takeaway");
          else setMode("dine-in", tableNumber ?? "04");
        }}
        className={cn(
          "mt-2 flex h-12 w-full min-h-12 items-center justify-center gap-2 rounded-full border px-4 text-xs font-semibold tracking-wide",
          dineIn
            ? "border-primary/30 bg-primary/10 text-primary"
            : "border-accent/30 bg-accent/10 text-accent",
        )}
      >
        {dineIn ? <Nfc size={16} /> : <Utensils size={16} />}
        {dineIn
          ? `Table ${tableNumber ?? "—"}  ·  Tap Mode Active`
          : "Takeaway Mode"}
        <span className="ml-1 text-[10px] font-medium uppercase tracking-widest opacity-70">
          switch
        </span>
      </motion.button>
    </header>
  );
}
