import {
  Calendar,
  Clock,
  Download,
  Info,
  MapPin,
  MessageCircle,
  Phone,
  Smartphone,
  Star,
  Wifi,
} from "lucide-react";
import { motion } from "framer-motion";
import { restaurantConfig } from "@/config/restaurant.config";
import { useSheets } from "@/hooks/useSheets";
import { usePWAInstall } from "@/hooks/usePWAInstall";
import { whatsappHref } from "@/lib/format";
import { DynamicIcon } from "@/components/ui/icon";
import { Button } from "@/components/ui/button";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

export function MorePanel() {
  const { openSheet } = useSheets();
  const pwa = usePWAInstall();
  const { brand, features } = restaurantConfig;

  return (
    <div className="px-4 pb-8 pt-2">
      <div className="glass-panel mb-4 flex items-start gap-3 rounded-[var(--radius)] p-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-[calc(var(--radius)-4px)] bg-primary/15 text-primary">
          <DynamicIcon name={brand.icon} size={22} />
        </div>
        <div>
          <h2 className="font-display text-xl font-semibold leading-tight">
            {brand.name}
          </h2>
          <p className="mt-1 text-sm leading-relaxed text-muted">{brand.tagline}</p>
        </div>
      </div>

      <ul className="mb-4 space-y-2 text-sm">
        <InfoRow icon={MapPin} label={brand.address} />
        <InfoRow icon={Clock} label={brand.hours} />
        <InfoRow icon={Phone} label={brand.phone} href={`tel:${brand.phone}`} />
      </ul>

      <div className="grid gap-2">
        {features.enableWifi && (
          <ActionRow
            icon={Wifi}
            title="Guest WiFi"
            hint={brand.wifi.ssid}
            onClick={() => openSheet("wifi")}
          />
        )}
        {features.enableReviews && (
          <ActionRow
            icon={Star}
            title="Leave a review"
            hint="Smart public / private split"
            onClick={() => openSheet("review")}
          />
        )}
        {features.enableBookings && (
          <ActionRow
            icon={Calendar}
            title="Reserve a table"
            hint="Date, time, party size"
            onClick={() => openSheet("reservation")}
          />
        )}
        {features.enableWhatsApp && (
          <ActionRow
            icon={MessageCircle}
            title="WhatsApp concierge"
            hint="Pre-filled chat"
            onClick={() =>
              window.open(whatsappHref(brand.whatsappGreeting), "_blank", "noopener")
            }
          />
        )}
      </div>

      {features.enablePwaInstall && (
        <div className="mt-5 rounded-[var(--radius)] border border-dashed border-primary/40 bg-primary/8 p-4">
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
            <Smartphone size={16} className="text-primary" />
            {pwa.isInstalled ? "Running as an app" : "Add to Home Screen"}
          </div>
          <p className="mb-3 text-xs leading-relaxed text-muted">
            {pwa.isInstalled
              ? "You're in standalone mode — full-screen, home-bar safe."
              : "Install this PWA for one-tap ordering from the lock screen."}
          </p>
          {pwa.canInstall && (
            <Button className="w-full" onClick={() => pwa.install()}>
              <Download size={16} />
              Install app
            </Button>
          )}
          {!pwa.canInstall && !pwa.isInstalled && (
            <p className="text-[11px] text-muted">
              On iPhone: Share → Add to Home Screen. On Android the native
              prompt appears when the browser is ready.
            </p>
          )}
        </div>
      )}

      <p className="mt-6 flex items-center justify-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-muted">
        <Info size={11} /> White-label PWA · config-driven
      </p>
    </div>
  );
}

function InfoRow({
  icon: Icon,
  label,
  href,
}: {
  icon: typeof MapPin;
  label: string;
  href?: string;
}) {
  const inner = (
    <>
      <Icon size={16} className="mt-0.5 shrink-0 text-primary" />
      <span>{label}</span>
    </>
  );
  if (href) {
    return (
      <li>
        <a
          href={href}
          className="flex min-h-12 items-start gap-3 rounded-[var(--radius)] px-1 py-2 text-foreground"
        >
          {inner}
        </a>
      </li>
    );
  }
  return (
    <li className="flex min-h-12 items-start gap-3 rounded-[var(--radius)] px-1 py-2 text-foreground">
      {inner}
    </li>
  );
}

function ActionRow({
  icon: Icon,
  title,
  hint,
  onClick,
}: {
  icon: typeof Wifi;
  title: string;
  hint: string;
  onClick: () => void;
}) {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.98 }}
      transition={spring}
      onClick={onClick}
      className="glass-panel flex min-h-14 w-full items-center gap-3 rounded-[var(--radius)] px-4 py-3 text-left"
    >
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/12 text-primary">
        <Icon size={18} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-semibold">{title}</span>
        <span className="block text-xs text-muted">{hint}</span>
      </span>
    </motion.button>
  );
}
