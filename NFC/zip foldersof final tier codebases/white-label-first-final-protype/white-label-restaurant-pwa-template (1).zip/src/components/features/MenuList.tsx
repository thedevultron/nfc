import { useMemo, useState } from "react";
import { Award, Beef, CircleDot, Leaf, Search, X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { menuCategories, menuItems } from "@/config/menuData";
import { useHaptics } from "@/hooks/useHaptics";
import { DynamicIcon } from "@/components/ui/icon";
import { DishCard } from "@/components/features/DishCard";
import { Input } from "@/components/ui/input";
import { cn } from "@/utils/cn";
import type { DietaryTag } from "@/types/menu.types";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

type FilterKey = DietaryTag | "special" | null;

const FILTERS: { key: FilterKey; label: string; icon: typeof Leaf }[] = [
  { key: "veg", label: "Veg", icon: CircleDot },
  { key: "non-veg", label: "Non-Veg", icon: Beef },
  { key: "vegan", label: "Vegan", icon: Leaf },
  { key: "special", label: "Chef's", icon: Award },
];

export function MenuList() {
  const haptics = useHaptics();
  const [category, setCategory] = useState(menuCategories[0]?.id ?? "");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterKey>(null);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menuItems.filter((item) => {
      if (category && item.categoryId !== category) return false;
      if (q && !`${item.name} ${item.description}`.toLowerCase().includes(q)) {
        return false;
      }
      if (filter === "special") return item.isChefsSpecial;
      if (filter === "veg" || filter === "non-veg" || filter === "vegan" || filter === "gluten-free") {
        return item.dietary.includes(filter);
      }
      return true;
    });
  }, [category, query, filter]);

  const activeCat = menuCategories.find((c) => c.id === category);

  return (
    <div className="flex flex-col">
      <div className="sticky top-[7.5rem] z-20 space-y-2 bg-background/80 px-4 py-2 backdrop-blur-xl">
        <div className="relative">
          <Search
            size={16}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted"
          />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search plates, spices, sips…"
            className="h-12 pl-10 pr-10"
            aria-label="Search menu"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center text-muted"
              aria-label="Clear search"
            >
              <X size={16} />
            </button>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {FILTERS.map((f) => {
            const Icon = f.icon;
            const on = filter === f.key;
            return (
              <motion.button
                key={f.key}
                type="button"
                whileTap={{ scale: 0.94 }}
                transition={spring}
                onClick={() => {
                  haptics.select();
                  setFilter(on ? null : f.key);
                }}
                className={cn(
                  "relative flex h-10 min-h-10 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-xs font-semibold",
                  on ? "text-primary-foreground" : "text-muted",
                )}
              >
                {on && (
                  <motion.span
                    layoutId="diet-pill"
                    className="absolute inset-0 rounded-full bg-primary"
                    transition={spring}
                  />
                )}
                {!on && (
                  <span className="absolute inset-0 rounded-full border border-border bg-foreground/4" />
                )}
                <Icon size={13} className="relative" />
                <span className="relative">{f.label}</span>
              </motion.button>
            );
          })}
        </div>
      </div>

      <div className="sticky top-[14.25rem] z-20 bg-background/80 px-4 py-2 backdrop-blur-xl">
        <div className="flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {menuCategories.map((cat) => {
            const on = category === cat.id;
            return (
              <motion.button
                key={cat.id}
                type="button"
                whileTap={{ scale: 0.94 }}
                transition={spring}
                onClick={() => {
                  haptics.select();
                  setCategory(cat.id);
                }}
                className={cn(
                  "relative flex h-12 min-h-12 shrink-0 items-center gap-2 rounded-full px-4 text-sm font-medium",
                  on ? "text-primary-foreground" : "text-foreground/80",
                )}
              >
                {on && (
                  <motion.span
                    layoutId="cat-pill"
                    className="absolute inset-0 rounded-full bg-primary"
                    transition={spring}
                  />
                )}
                {!on && (
                  <span className="absolute inset-0 rounded-full border border-border bg-card/60" />
                )}
                <DynamicIcon name={cat.icon} size={16} className="relative" />
                <span className="relative">{cat.name}</span>
              </motion.button>
            );
          })}
        </div>
      </div>

      <div className="px-4 pb-4 pt-1">
        {activeCat && (
          <div className="mb-3 flex items-baseline justify-between">
            <h2 className="font-display text-lg font-semibold text-foreground">
              {activeCat.name}
            </h2>
            <span className="text-xs text-muted">
              {visible.length} {visible.length === 1 ? "plate" : "plates"}
            </span>
          </div>
        )}

        <AnimatePresence mode="popLayout">
          {visible.length === 0 ? (
            <motion.p
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-16 text-center text-sm text-muted"
            >
              Nothing matches that filter. Try another chip.
            </motion.p>
          ) : (
            <motion.div layout className="flex flex-col gap-2.5">
              {visible.map((item) => (
                <DishCard key={item.id} item={item} />
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
