import { useMemo, useState } from "react";
import {
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Users,
} from "lucide-react";
import { motion } from "framer-motion";
import {
  Drawer,
  DrawerBody,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { restaurantConfig } from "@/config/restaurant.config";
import { useSheets } from "@/hooks/useSheets";
import { useHaptics } from "@/hooks/useHaptics";
import { apiService } from "@/services/api.service";
import { formatPrettyDate, todayISODate } from "@/lib/format";
import { cn } from "@/utils/cn";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

const SLOTS = [
  "12:00",
  "12:30",
  "13:00",
  "13:30",
  "18:30",
  "19:00",
  "19:30",
  "20:00",
  "20:30",
  "21:00",
  "21:30",
  "22:00",
];

function monthMatrix(year: number, month: number) {
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [
    ...Array.from({ length: first }, () => null),
    ...Array.from({ length: days }, (_, i) => i + 1),
  ];
  return cells;
}

export function ReservationSheet() {
  const { open, closeSheet } = useSheets();
  const haptics = useHaptics();
  const now = new Date();
  const [cursor, setCursor] = useState({
    y: now.getFullYear(),
    m: now.getMonth(),
  });
  const [date, setDate] = useState(todayISODate());
  const [time, setTime] = useState("19:30");
  const [guests, setGuests] = useState(2);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const cells = useMemo(
    () => monthMatrix(cursor.y, cursor.m),
    [cursor.y, cursor.m],
  );
  const label = new Date(cursor.y, cursor.m, 1).toLocaleDateString(
    restaurantConfig.brand.locale,
    { month: "long", year: "numeric" },
  );

  const today = todayISODate();

  const submit = async () => {
    if (!name.trim() || !phone.trim() || submitting) return;
    setSubmitting(true);
    await apiService.sendReservation({
      name: name.trim(),
      phone: phone.trim(),
      date,
      time,
      guests,
      notes,
      placedAt: new Date().toISOString(),
    });
    haptics.success();
    setSubmitting(false);
    setDone(true);
  };

  const handleOpen = (next: boolean) => {
    if (!next) {
      closeSheet();
      if (done) {
        setDone(false);
        setName("");
        setPhone("");
        setNotes("");
      }
    }
  };

  return (
    <Drawer open={open === "reservation"} onOpenChange={handleOpen}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle className="flex items-center gap-2">
            <Calendar size={18} className="text-primary" />
            Reserve a table
          </DrawerTitle>
          <DrawerDescription>
            {formatPrettyDate(date)} · {time} · {guests}{" "}
            {guests === 1 ? "guest" : "guests"}
          </DrawerDescription>
        </DrawerHeader>

        <DrawerBody>
          {done ? (
            <div className="flex flex-col items-center py-10 text-center">
              <CheckCircle2 size={48} className="text-primary" />
              <p className="mt-4 font-display text-xl font-semibold">
                You're on the book
              </p>
              <p className="mt-1 max-w-xs text-sm text-muted">
                {name}, we have {guests} at {time} on {formatPrettyDate(date)}.
                A confirmation will follow shortly.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <button
                    type="button"
                    className="flex h-12 w-12 items-center justify-center"
                    onClick={() =>
                      setCursor((c) => {
                        const d = new Date(c.y, c.m - 1, 1);
                        return { y: d.getFullYear(), m: d.getMonth() };
                      })
                    }
                    aria-label="Previous month"
                  >
                    <ChevronLeft size={18} />
                  </button>
                  <span className="font-display text-sm font-semibold">
                    {label}
                  </span>
                  <button
                    type="button"
                    className="flex h-12 w-12 items-center justify-center"
                    onClick={() =>
                      setCursor((c) => {
                        const d = new Date(c.y, c.m + 1, 1);
                        return { y: d.getFullYear(), m: d.getMonth() };
                      })
                    }
                    aria-label="Next month"
                  >
                    <ChevronRight size={18} />
                  </button>
                </div>
                <div className="grid grid-cols-7 gap-1 text-center text-[10px] uppercase tracking-wider text-muted">
                  {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
                    <span key={`${d}-${i}`} className="py-1">
                      {d}
                    </span>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {cells.map((day, i) => {
                    if (!day) return <span key={`e-${i}`} />;
                    const iso = `${cursor.y}-${String(cursor.m + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
                    const past = iso < today;
                    const on = iso === date;
                    return (
                      <motion.button
                        key={iso}
                        type="button"
                        disabled={past}
                        whileTap={past ? undefined : { scale: 0.9 }}
                        transition={spring}
                        onClick={() => {
                          haptics.select();
                          setDate(iso);
                        }}
                        className={cn(
                          "flex h-11 min-h-11 items-center justify-center rounded-full text-sm",
                          past && "opacity-30",
                          on && "bg-primary font-semibold text-primary-foreground",
                          !on && !past && "hover:bg-foreground/8",
                        )}
                      >
                        {day}
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted">
                  Time
                </p>
                <div className="flex flex-wrap gap-2">
                  {SLOTS.map((slot) => {
                    const on = slot === time;
                    return (
                      <motion.button
                        key={slot}
                        type="button"
                        whileTap={{ scale: 0.94 }}
                        transition={spring}
                        onClick={() => {
                          haptics.select();
                          setTime(slot);
                        }}
                        className={cn(
                          "relative h-11 min-h-11 min-w-16 rounded-full px-3 text-sm font-medium",
                          on
                            ? "bg-primary text-primary-foreground"
                            : "border border-border text-foreground",
                        )}
                      >
                        {slot}
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-between rounded-[var(--radius)] border border-border px-4 py-2">
                <span className="flex items-center gap-2 text-sm font-medium">
                  <Users size={16} className="text-primary" /> Guests
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    variant="surface"
                    size="icon"
                    className="h-12 w-12"
                    onClick={() => setGuests((g) => Math.max(1, g - 1))}
                  >
                    –
                  </Button>
                  <span className="w-6 text-center text-lg font-bold tabular-nums">
                    {guests}
                  </span>
                  <Button
                    size="icon"
                    className="h-12 w-12"
                    onClick={() => setGuests((g) => Math.min(16, g + 1))}
                  >
                    +
                  </Button>
                </div>
              </div>

              <div className="grid gap-3">
                <Input
                  placeholder="Your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
                <Input
                  placeholder="Mobile number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  inputMode="tel"
                  autoComplete="tel"
                />
                <Textarea
                  placeholder="Occasion, seating preference…"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                />
              </div>
            </div>
          )}
        </DrawerBody>

        {!done && (
          <DrawerFooter>
            <Button
              size="lg"
              onClick={submit}
              disabled={submitting || !name.trim() || !phone.trim()}
            >
              {submitting ? (
                <Loader2 className="animate-spin" size={18} />
              ) : (
                <Calendar size={18} />
              )}
              Confirm reservation
            </Button>
          </DrawerFooter>
        )}
      </DrawerContent>
    </Drawer>
  );
}
