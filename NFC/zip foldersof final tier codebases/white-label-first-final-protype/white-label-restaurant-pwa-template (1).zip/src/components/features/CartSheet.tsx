import { useState } from "react";
import {
  CheckCircle2,
  Loader2,
  MessageCircle,
  Minus,
  Plus,
  ShoppingBag,
  SquarePen,
  Trash2,
  UtensilsCrossed,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Drawer,
  DrawerBody,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { DynamicIcon } from "@/components/ui/icon";
import { restaurantConfig } from "@/config/restaurant.config";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { apiService } from "@/services/api.service";
import { formatMoney, formatWhatsAppOrder, whatsappHref } from "@/lib/format";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

export function CartSheet() {
  const cart = useCart();
  const haptics = useHaptics();
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const place = async (viaWhatsApp: boolean) => {
    if (cart.lines.length === 0 || submitting) return;
    setSubmitting(true);
    const payload = cart.toOrderPayload();
    await apiService.sendOrder(payload);
    if (viaWhatsApp && restaurantConfig.features.enableWhatsApp) {
      window.open(whatsappHref(formatWhatsAppOrder(payload)), "_blank", "noopener");
    }
    haptics.success();
    setSubmitting(false);
    setDone(true);
  };

  const handleOpen = (open: boolean) => {
    if (!open) {
      cart.closeCart();
      if (done) {
        cart.clear();
        setDone(false);
      }
    }
  };

  return (
    <Drawer open={cart.isOpen} onOpenChange={handleOpen}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle className="flex items-center gap-2">
            <ShoppingBag size={18} className="text-primary" />
            Your order
          </DrawerTitle>
          <DrawerDescription>
            {cart.mode === "dine-in"
              ? `Table ${cart.tableNumber ?? "—"} · sending to the kitchen`
              : "Takeaway · packed to go"}
          </DrawerDescription>
        </DrawerHeader>

        <DrawerBody>
          <AnimatePresence mode="wait">
            {done ? (
              <motion.div
                key="ok"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex flex-col items-center py-10 text-center"
              >
                <CheckCircle2 size={48} className="text-primary" />
                <p className="mt-4 font-display text-xl font-semibold">
                  Order dispatched
                </p>
                <p className="mt-1 max-w-xs text-sm text-muted">
                  The pass has your ticket. A runner will be with you shortly.
                </p>
              </motion.div>
            ) : cart.lines.length === 0 ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center py-12 text-center"
              >
                <ShoppingBag size={40} className="text-muted" />
                <p className="mt-3 text-sm text-muted">
                  Your bag is empty. Add a plate from the menu.
                </p>
              </motion.div>
            ) : (
              <motion.div key="list" className="space-y-3">
                {cart.lines.map((line) => (
                  <motion.div
                    layout
                    key={line.item.id}
                    className="flex items-center gap-3 rounded-[var(--radius)] border border-border bg-card/50 p-3"
                  >
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/12 text-primary">
                      <DynamicIcon name={line.item.icon} size={18} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">
                        {line.item.name}
                      </p>
                      <p className="text-xs text-muted">
                        {formatMoney(line.item.price)} each
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <motion.button
                        type="button"
                        whileTap={{ scale: 0.9 }}
                        transition={spring}
                        onClick={() => cart.decrement(line.item.id)}
                        className="flex h-10 w-10 min-h-10 min-w-10 items-center justify-center rounded-full bg-foreground/8"
                      >
                        {line.quantity === 1 ? (
                          <Trash2 size={14} />
                        ) : (
                          <Minus size={14} />
                        )}
                      </motion.button>
                      <span className="w-6 text-center text-sm font-bold tabular-nums">
                        {line.quantity}
                      </span>
                      <motion.button
                        type="button"
                        whileTap={{ scale: 0.9 }}
                        transition={spring}
                        onClick={() => cart.addItem(line.item)}
                        className="flex h-10 w-10 min-h-10 min-w-10 items-center justify-center rounded-full bg-primary text-primary-foreground"
                      >
                        <Plus size={14} />
                      </motion.button>
                    </div>
                  </motion.div>
                ))}

                <label className="block pt-1">
                  <span className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted">
                    <SquarePen size={12} /> Special instructions
                  </span>
                  <Textarea
                    rows={3}
                    value={cart.notes}
                    onChange={(e) => cart.setNotes(e.target.value)}
                    placeholder="Allergies, spice, packing notes…"
                  />
                </label>

                <div className="space-y-1.5 rounded-[var(--radius)] border border-border bg-foreground/4 px-4 py-3 text-sm">
                  <div className="flex justify-between text-muted">
                    <span>Subtotal</span>
                    <span className="tabular-nums">{formatMoney(cart.subtotal)}</span>
                  </div>
                  {restaurantConfig.brand.taxPercent > 0 && (
                    <div className="flex justify-between text-muted">
                      <span>Tax ({restaurantConfig.brand.taxPercent}%)</span>
                      <span className="tabular-nums">{formatMoney(cart.tax)}</span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-border pt-2 font-semibold">
                    <span>Total</span>
                    <span className="tabular-nums text-primary">
                      {formatMoney(cart.total)}
                    </span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </DrawerBody>

        {!done && cart.lines.length > 0 && (
          <DrawerFooter>
            <Button
              size="lg"
              onClick={() => place(false)}
              disabled={submitting}
            >
              {submitting ? (
                <Loader2 className="animate-spin" size={18} />
              ) : (
                <UtensilsCrossed size={18} />
              )}
              Place order with kitchen · {formatMoney(cart.total)}
            </Button>
            {restaurantConfig.features.enableWhatsApp && (
              <Button
                variant="outline"
                onClick={() => place(true)}
                disabled={submitting}
              >
                <MessageCircle size={16} />
                Send via WhatsApp
              </Button>
            )}
          </DrawerFooter>
        )}
      </DrawerContent>
    </Drawer>
  );
}
