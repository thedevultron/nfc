import { useState } from "react";
import {
  ExternalLink,
  Heart,
  Loader2,
  Send,
  Star,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Drawer,
  DrawerBody,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { StarRating } from "@/components/ui/star-rating";
import { restaurantConfig } from "@/config/restaurant.config";
import { useSheets } from "@/hooks/useSheets";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { apiService } from "@/services/api.service";
import { cn } from "@/utils/cn";
import type { FeedbackCategory } from "@/types/menu.types";

const CATS: { id: FeedbackCategory; label: string }[] = [
  { id: "food", label: "Food" },
  { id: "service", label: "Service" },
  { id: "ambience", label: "Ambience" },
  { id: "wait", label: "Wait time" },
];

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

export function ReviewModal() {
  const { open, closeSheet } = useSheets();
  const { tableNumber } = useCart();
  const haptics = useHaptics();
  const [rating, setRating] = useState(0);
  const [cats, setCats] = useState<FeedbackCategory[]>([]);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const publicPath = rating >= 4;
  const privatePath = rating > 0 && rating < 4;

  const toggleCat = (id: FeedbackCategory) => {
    haptics.select();
    setCats((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id],
    );
  };

  const sendPrivate = async () => {
    if (submitting) return;
    setSubmitting(true);
    await apiService.sendFeedback({
      rating,
      categories: cats,
      comment,
      tableNumber,
      placedAt: new Date().toISOString(),
    });
    haptics.success();
    setSubmitting(false);
    setDone(true);
  };

  const handleOpen = (next: boolean) => {
    if (!next) {
      closeSheet();
      if (done) {
        setDone(false);
        setRating(0);
        setCats([]);
        setComment("");
      }
    }
  };

  return (
    <Drawer open={open === "review"} onOpenChange={handleOpen}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle className="flex items-center gap-2">
            <Star size={18} className="text-accent" />
            How was Aura tonight?
          </DrawerTitle>
          <DrawerDescription>
            Honest notes help the floor team more than a public post.
          </DrawerDescription>
        </DrawerHeader>

        <DrawerBody>
          {done ? (
            <div className="flex flex-col items-center py-10 text-center">
              <Heart size={44} className="fill-primary text-primary" />
              <p className="mt-4 font-display text-xl font-semibold">
                Thank you
              </p>
              <p className="mt-1 max-w-xs text-sm text-muted">
                Your note went privately to the manager — never to a public
                wall.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              <StarRating
                value={rating}
                onChange={(n) => {
                  haptics.tap();
                  setRating(n);
                  setDone(false);
                }}
              />

              <AnimatePresence mode="wait">
                {publicPath && (
                  <motion.div
                    key="public"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="space-y-3 rounded-[var(--radius)] border border-accent/30 bg-accent/8 p-4 text-center"
                  >
                    <p className="font-display text-lg font-semibold">
                      We're glowing.
                    </p>
                    <p className="text-sm text-muted">
                      A public review on Google helps other diners find the
                      room.
                    </p>
                    <Button
                      variant="gold"
                      className="w-full"
                      onClick={() =>
                        window.open(
                          restaurantConfig.brand.googleReviewUrl,
                          "_blank",
                          "noopener",
                        )
                      }
                    >
                      <ExternalLink size={16} />
                      Post public review on Google
                    </Button>
                  </motion.div>
                )}

                {privatePath && (
                  <motion.div
                    key="private"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="space-y-3"
                  >
                    <p className="text-sm text-muted">
                      Tell the manager what we can improve — this stays
                      in-house.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {CATS.map((c) => {
                        const on = cats.includes(c.id);
                        return (
                          <motion.button
                            key={c.id}
                            type="button"
                            whileTap={{ scale: 0.94 }}
                            transition={spring}
                            onClick={() => toggleCat(c.id)}
                            className={cn(
                              "h-11 min-h-11 rounded-full px-4 text-sm font-medium",
                              on
                                ? "bg-primary text-primary-foreground"
                                : "border border-border",
                            )}
                          >
                            {c.label}
                          </motion.button>
                        );
                      })}
                    </div>
                    <Textarea
                      rows={4}
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="What should we fix next service?"
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </DrawerBody>

        {privatePath && !done && (
          <DrawerFooter>
            <Button size="lg" onClick={sendPrivate} disabled={submitting}>
              {submitting ? (
                <Loader2 className="animate-spin" size={18} />
              ) : (
                <Send size={16} />
              )}
              Send private note
            </Button>
          </DrawerFooter>
        )}
      </DrawerContent>
    </Drawer>
  );
}
