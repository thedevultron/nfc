import { Download, X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { restaurantConfig } from "@/config/restaurant.config";
import { usePWAInstall } from "@/hooks/usePWAInstall";
import { Button } from "@/components/ui/button";

export function PWAInstallBanner() {
  const pwa = usePWAInstall();
  if (!restaurantConfig.features.enablePwaInstall) return null;

  return (
    <AnimatePresence>
      {pwa.canInstall && !pwa.dismissed && (
        <motion.div
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          className="pointer-events-auto fixed inset-x-3 z-30 bottom-[5.5rem]"
        >
          <div className="glass-panel flex items-center gap-3 rounded-[var(--radius)] px-3 py-2.5">
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">Add to Home Screen</p>
              <p className="text-[11px] text-muted">One tap, full-screen ordering.</p>
            </div>
            <Button size="sm" onClick={() => pwa.install()}>
              <Download size={14} />
              Install
            </Button>
            <button
              type="button"
              onClick={pwa.dismiss}
              className="flex h-12 w-12 min-h-12 min-w-12 items-center justify-center text-muted"
              aria-label="Dismiss"
            >
              <X size={16} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
