import { useState } from "react";
import { Check, Copy, QrCode, Wifi } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import {
  Drawer,
  DrawerBody,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { restaurantConfig } from "@/config/restaurant.config";
import { useSheets } from "@/hooks/useSheets";
import { useHaptics } from "@/hooks/useHaptics";
import { wifiQrValue } from "@/lib/format";

export function WifiSheet() {
  const { open, closeSheet } = useSheets();
  const haptics = useHaptics();
  const { wifi } = restaurantConfig.brand;
  const [copied, setCopied] = useState<"ssid" | "pass" | null>(null);

  const copy = async (value: string, key: "ssid" | "pass") => {
    try {
      await navigator.clipboard.writeText(value);
      haptics.success();
      setCopied(key);
      setTimeout(() => setCopied(null), 1400);
    } catch {
      haptics.warning();
    }
  };

  return (
    <Drawer
      open={open === "wifi"}
      onOpenChange={(v) => {
        if (!v) closeSheet();
      }}
    >
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle className="flex items-center gap-2">
            <Wifi size={18} className="text-primary" />
            Guest network
          </DrawerTitle>
          <DrawerDescription>
            Scan the QR or copy the password. No captive portal.
          </DrawerDescription>
        </DrawerHeader>
        <DrawerBody>
          <div className="flex flex-col items-center gap-5 pb-6">
            <div className="rounded-[var(--radius)] bg-white p-4 shadow-lg">
              <QRCodeSVG
                value={wifiQrValue()}
                size={196}
                level="M"
                bgColor="#ffffff"
                fgColor="#0b0f0d"
              />
            </div>
            <p className="flex items-center gap-1.5 text-xs uppercase tracking-widest text-muted">
              <QrCode size={12} /> Camera-ready WIFI payload
            </p>

            <div className="w-full space-y-2">
              <Row
                label="Network"
                value={wifi.ssid}
                copied={copied === "ssid"}
                onCopy={() => copy(wifi.ssid, "ssid")}
              />
              <Row
                label="Password"
                value={wifi.pass}
                copied={copied === "pass"}
                onCopy={() => copy(wifi.pass, "pass")}
              />
            </div>
          </div>
        </DrawerBody>
      </DrawerContent>
    </Drawer>
  );
}

function Row({
  label,
  value,
  copied,
  onCopy,
}: {
  label: string;
  value: string;
  copied: boolean;
  onCopy: () => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-[var(--radius)] border border-border bg-card/60 px-4 py-3">
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-widest text-muted">
          {label}
        </p>
        <p className="truncate font-mono text-sm font-semibold">{value}</p>
      </div>
      <Button variant="surface" size="icon" onClick={onCopy} aria-label="Copy">
        {copied ? <Check size={16} className="text-primary" /> : <Copy size={16} />}
      </Button>
    </div>
  );
}
