import { Award, Ban, Flame, Minus, Plus } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { DynamicIcon } from "@/components/ui/icon";
import { restaurantConfig } from "@/config/restaurant.config";
import { useCart } from "@/hooks/useCart";
import { formatMoney } from "@/lib/format";
import { cn } from "@/utils/cn";
import type { MenuItem } from "@/types/menu.types";

const spring = { type: "spring" as const, stiffness: 400, damping: 25 };

export function DishCard({ item }: { item: MenuItem }) {
  const { addItem, decrement, getQty } = useCart();
  const qty = getQty(item.id);
  const sold = !item.isAvailable;
  const canOrder = restaurantConfig.features.enableDirectOrdering && !sold;

  return (
    <motion.article
      layout
      whileTap={{ scale: 0.985 }}
      transition={spring}
      className={cn(
        "glass-panel relative flex gap-3 rounded-[var(--radius)] p-3",
        sold && "opacity-55",
      )}
    >
      <div
        className={cn(
          "flex h-14 w-14 min-h-14 min-w-14 items-center justify-center rounded-[calc(var(--radius)-4px)]",
          item.isChefsSpecial ? "bg-accent/15 text-accent" : "bg-primary/12 text-primary",
        )}
      >
        <DynamicIcon name={item.icon} size={24} />
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display text-[15px] font-semibold leading-snug text-foreground">
            {item.name}
          </h3>
          <span className="shrink-0 font-semibold tabular-nums text-primary">
            {formatMoney(item.price)}
          </span>
        </div>
        <p className="mt-0.5 line-clamp-2 text-[12px] leading-relaxed text-muted">
          {item.description}
        </p>

        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          {item.isBestSeller && (
            <Badge>
              <Award size={10} /> Best Seller
            </Badge>
          )}
          {item.isChefsSpecial && (
            <Badge variant="gold">
              <Award size={10} /> Chef's
            </Badge>
          )}
          {sold && (
            <Badge variant="sold">
              <Ban size={10} /> Sold Out
            </Badge>
          )}
          {item.spiceLevel > 0 && (
            <span className="inline-flex items-center text-orange-400">
              {Array.from({ length: item.spiceLevel }).map((_, i) => (
                <Flame key={i} size={11} className="fill-orange-400" />
              ))}
            </span>
          )}
        </div>
      </div>

      {canOrder && (
        <div className="flex shrink-0 items-end">
          <AnimatePresence mode="wait" initial={false}>
            {qty === 0 ? (
              <motion.button
                key="add"
                type="button"
                initial={{ scale: 0.6, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.6, opacity: 0 }}
                whileTap={{ scale: 0.9 }}
                transition={spring}
                onClick={() => addItem(item)}
                aria-label={`Add ${item.name}`}
                className="flex h-12 w-12 min-h-12 min-w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_8px_20px_-8px_var(--color-primary)]"
              >
                <Plus size={20} />
              </motion.button>
            ) : (
              <motion.div
                key="stepper"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                transition={spring}
                className="flex h-12 min-h-12 items-center gap-1 rounded-full bg-primary px-1 text-primary-foreground"
              >
                <button
                  type="button"
                  onClick={() => decrement(item.id)}
                  className="flex h-10 w-10 min-h-10 min-w-10 items-center justify-center"
                  aria-label="Decrease"
                >
                  <Minus size={16} />
                </button>
                <span className="min-w-4 text-center text-sm font-bold tabular-nums">
                  {qty}
                </span>
                <button
                  type="button"
                  onClick={() => addItem(item)}
                  className="flex h-10 w-10 min-h-10 min-w-10 items-center justify-center"
                  aria-label="Increase"
                >
                  <Plus size={16} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </motion.article>
  );
}
