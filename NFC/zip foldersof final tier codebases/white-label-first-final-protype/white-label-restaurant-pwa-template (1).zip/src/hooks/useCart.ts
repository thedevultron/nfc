/**
 * Cart store + drawer controls. Totals honour brand.taxPercent
 * and brand.currency from restaurant.config — no hardcoded math in UI.
 */
import {
  createContext,
  createElement,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { restaurantConfig } from "@/config/restaurant.config";
import type { CartLine, MenuItem, OrderPayload, ServiceMode } from "@/types/menu.types";
import { useHaptics } from "@/hooks/useHaptics";

interface CartContextValue {
  lines: CartLine[];
  notes: string;
  isOpen: boolean;
  mode: ServiceMode;
  tableNumber: string | null;
  itemCount: number;
  subtotal: number;
  tax: number;
  total: number;
  addItem: (item: MenuItem) => void;
  decrement: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  remove: (id: string) => void;
  setNotes: (value: string) => void;
  clear: () => void;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  getQty: (id: string) => number;
  setMode: (mode: ServiceMode, table?: string | null) => void;
  toOrderPayload: () => OrderPayload;
}

const CartContext = createContext<CartContextValue | null>(null);

function readInitialTable(): string | null {
  if (typeof window === "undefined") return restaurantConfig.defaultTable;
  const q = new URLSearchParams(window.location.search).get("table");
  return q && q.trim() ? q.trim() : restaurantConfig.defaultTable;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const haptics = useHaptics();
  const [lines, setLines] = useState<CartLine[]>([]);
  const [notes, setNotes] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [tableNumber, setTableNumber] = useState<string | null>(readInitialTable);
  const [mode, setModeState] = useState<ServiceMode>(() =>
    readInitialTable() ? "dine-in" : "takeaway",
  );

  const addItem = useCallback(
    (item: MenuItem) => {
      if (!item.isAvailable) return;
      haptics.add();
      setLines((prev) => {
        const existing = prev.find((l) => l.item.id === item.id);
        if (existing) {
          return prev.map((l) =>
            l.item.id === item.id ? { ...l, quantity: l.quantity + 1 } : l,
          );
        }
        return [...prev, { item, quantity: 1 }];
      });
    },
    [haptics],
  );

  const decrement = useCallback((id: string) => {
    haptics.tap();
    setLines((prev) =>
      prev
        .map((l) =>
          l.item.id === id ? { ...l, quantity: l.quantity - 1 } : l,
        )
        .filter((l) => l.quantity > 0),
    );
  }, [haptics]);

  const setQty = useCallback((id: string, qty: number) => {
    setLines((prev) => {
      if (qty <= 0) return prev.filter((l) => l.item.id !== id);
      return prev.map((l) =>
        l.item.id === id ? { ...l, quantity: qty } : l,
      );
    });
  }, []);

  const remove = useCallback((id: string) => {
    haptics.warning();
    setLines((prev) => prev.filter((l) => l.item.id !== id));
  }, [haptics]);

  const clear = useCallback(() => {
    setLines([]);
    setNotes("");
  }, []);

  const openCart = useCallback(() => {
    haptics.tap();
    setIsOpen(true);
  }, [haptics]);

  const closeCart = useCallback(() => setIsOpen(false), []);
  const toggleCart = useCallback(() => {
    haptics.tap();
    setIsOpen((v) => !v);
  }, [haptics]);

  const getQty = useCallback(
    (id: string) => lines.find((l) => l.item.id === id)?.quantity ?? 0,
    [lines],
  );

  const setMode = useCallback((next: ServiceMode, table: string | null = null) => {
    haptics.select();
    setModeState(next);
    setTableNumber(next === "dine-in" ? table ?? tableNumber ?? "01" : null);
  }, [haptics, tableNumber]);

  const subtotal = useMemo(
    () => lines.reduce((sum, l) => sum + l.item.price * l.quantity, 0),
    [lines],
  );
  const tax = useMemo(
    () => Math.round((subtotal * restaurantConfig.brand.taxPercent) / 100),
    [subtotal],
  );
  const total = subtotal + tax;
  const itemCount = useMemo(
    () => lines.reduce((n, l) => n + l.quantity, 0),
    [lines],
  );

  const toOrderPayload = useCallback(
    (): OrderPayload => ({
      tableNumber,
      mode,
      items: lines.map((l) => ({
        id: l.item.id,
        name: l.item.name,
        quantity: l.quantity,
        price: l.item.price,
      })),
      notes,
      subtotal,
      tax,
      total,
      placedAt: new Date().toISOString(),
    }),
    [tableNumber, mode, lines, notes, subtotal, tax, total],
  );

  const value: CartContextValue = {
    lines,
    notes,
    isOpen,
    mode,
    tableNumber,
    itemCount,
    subtotal,
    tax,
    total,
    addItem,
    decrement,
    setQty,
    remove,
    setNotes,
    clear,
    openCart,
    closeCart,
    toggleCart,
    getQty,
    setMode,
    toOrderPayload,
  };

  return createElement(CartContext.Provider, { value }, children);
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
