/**
 * Coordinates exclusive bottom-sheets (WiFi, Review, Booking, Info).
 * Cart remains in useCart so ordering state stays independent.
 */
import {
  createContext,
  createElement,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";
import { useHaptics } from "@/hooks/useHaptics";

export type SheetName = "wifi" | "review" | "reservation" | "info";

interface SheetsValue {
  open: SheetName | null;
  openSheet: (name: SheetName) => void;
  closeSheet: () => void;
}

const SheetsContext = createContext<SheetsValue | null>(null);

export function SheetsProvider({ children }: { children: ReactNode }) {
  const haptics = useHaptics();
  const [open, setOpen] = useState<SheetName | null>(null);

  const openSheet = useCallback(
    (name: SheetName) => {
      haptics.tap();
      setOpen(name);
    },
    [haptics],
  );

  const closeSheet = useCallback(() => setOpen(null), []);

  return createElement(
    SheetsContext.Provider,
    { value: { open, openSheet, closeSheet } },
    children,
  );
}

export function useSheets() {
  const ctx = useContext(SheetsContext);
  if (!ctx) throw new Error("useSheets must be used within SheetsProvider");
  return ctx;
}
