/**
 * Native haptic pulses. Wired into add-to-cart, filter chips, and drawers.
 * Silently no-ops on desktop browsers that lack navigator.vibrate.
 */
import { useCallback } from "react";

export function useHaptics() {
  const vibrate = useCallback((pattern: number | number[] = 10) => {
    try {
      if (typeof navigator !== "undefined" && "vibrate" in navigator) {
        navigator.vibrate(pattern);
      }
    } catch {
      /* unsupported platform */
    }
  }, []);

  return {
    tap: () => vibrate(10),
    add: () => vibrate(15),
    success: () => vibrate([12, 40, 18]),
    warning: () => vibrate([30, 40, 30]),
    select: () => vibrate(8),
  };
}
