import { restaurantConfig } from "../config/restaurant.config";
import type { ServiceMode } from "../types/config.types";

export function formatPrice(value: number): string {
  const { currency, locale } = restaurantConfig.brand;
  try {
    const formatted = new Intl.NumberFormat(locale, {
      maximumFractionDigits: 0,
    }).format(value);
    return `${currency}${formatted}`;
  } catch {
    return `${currency}${value}`;
  }
}

export function digitsOnly(phone: string): string {
  return phone.replace(/[^\d]/g, "");
}

export function whatsappHref(text: string): string {
  const number = digitsOnly(restaurantConfig.brand.whatsappNumber);
  return `https://wa.me/${number}?text=${encodeURIComponent(text)}`;
}

export interface NfcContext {
  mode: ServiceMode;
  tableId: string;
  label: string;
}

/** NFC tags deep-link with ?table=04 or ?mode=takeaway — no code changes needed. */
export function readNfcContext(): NfcContext {
  const defaults = restaurantConfig.nfc;
  if (typeof window === "undefined") {
    return {
      mode: defaults.defaultMode,
      tableId: defaults.tableId,
      label:
        defaults.defaultMode === "table"
          ? `Table ${defaults.tableId}  ·  Tap Mode Active`
          : "Takeaway Mode",
    };
  }
  const params = new URLSearchParams(window.location.search);
  const table = params.get("table");
  const modeParam = params.get("mode");

  if (modeParam === "takeaway") {
    return { mode: "takeaway", tableId: "", label: "Takeaway Mode" };
  }
  const tableId = table ?? defaults.tableId;
  if (defaults.defaultMode === "takeaway" && !table) {
    return { mode: "takeaway", tableId: "", label: "Takeaway Mode" };
  }
  return {
    mode: "table",
    tableId,
    label: `Table ${tableId}  ·  Tap Mode Active`,
  };
}

export function todayISO(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function addDaysISO(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function formatDateLabel(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(y, (m ?? 1) - 1, d ?? 1);
  return date.toLocaleDateString(restaurantConfig.brand.locale, {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}
