/**
 * DETERMINISTIC QR-STYLE MARK
 * --------------------------------------------------------------------------
 * Renders a finder-patterned matrix from a payload string (Wi-Fi credentials).
 * Icon-driven PWA: no external image assets. Copy-to-clipboard is the primary
 * action; the matrix is a visual scan motif generated entirely in SVG.
 */

import { useMemo } from "react";

function hashChar(n: number): number {
  let x = (n * 2654435761) >>> 0;
  x ^= x << 13;
  x ^= x >>> 17;
  x ^= x << 5;
  return x >>> 0;
}

function buildMatrix(payload: string, size = 25): boolean[][] {
  const cells = Array.from({ length: size }, () => Array<boolean>(size).fill(false));

  const paintFinder = (r0: number, c0: number) => {
    for (let r = 0; r < 7; r++) {
      for (let c = 0; c < 7; c++) {
        const edge = r === 0 || c === 0 || r === 6 || c === 6;
        const inner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        cells[r0 + r][c0 + c] = edge || inner;
      }
    }
  };

  paintFinder(0, 0);
  paintFinder(0, size - 7);
  paintFinder(size - 7, 0);

  // Timing patterns
  for (let i = 8; i < size - 8; i++) {
    cells[6][i] = i % 2 === 0;
    cells[i][6] = i % 2 === 0;
  }

  const inFinder = (r: number, c: number) =>
    (r < 8 && c < 8) || (r < 8 && c >= size - 8) || (r >= size - 8 && c < 8) || r === 6 || c === 6;

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (inFinder(r, c)) continue;
      const idx = r * size + c;
      const ch = payload.charCodeAt(idx % payload.length) || 1;
      cells[r][c] = hashChar(ch * (idx + 3) + payload.length) % 3 !== 0;
    }
  }

  return cells;
}

export function QrMark({
  payload,
  title,
}: {
  payload: string;
  title: string;
}) {
  const size = 25;
  const matrix = useMemo(() => buildMatrix(payload, size), [payload]);
  const cell = 7;
  const dim = size * cell;

  return (
    <svg
      viewBox={`0 0 ${dim} ${dim}`}
      role="img"
      aria-label={title}
      className="h-full w-full"
    >
      <rect width={dim} height={dim} fill="#f4f1ea" rx="8" />
      {matrix.map((row, r) =>
        row.map((on, c) =>
          on ? (
            <rect
              key={`${r}-${c}`}
              x={c * cell}
              y={r * cell}
              width={cell}
              height={cell}
              fill="#0c100e"
            />
          ) : null,
        ),
      )}
    </svg>
  );
}

export function wifiQrPayload(ssid: string, pass: string, security: string): string {
  return `WIFI:S:${ssid};T:${security};P:${pass};;`;
}
