/**
 * CLIENT THEME TOKENS
 * --------------------------------------------------------------------------
 * Change colors, radius, density, or fonts HERE to re-skin the entire PWA.
 * Layout components read CSS variables injected from this object — they never
 * hard-code brand colors.
 *
 * primaryColor  → buttons, active tabs, price, + add controls
 * accentColor   → gold highlights, NFC badge, chef's special
 * radius        → cards, sheets, pills, icon wells
 * defaultMode   → "dark" | "light"
 * density       → "comfortable" | "compact" (padding scale)
 */

import type { ThemeConfig } from "../types/config.types";

export const themeConfig: ThemeConfig = {
  primaryColor: "hsl(142.1 76.2% 36.3%)",
  primaryForeground: "hsl(144 80% 98%)",
  accentColor: "hsl(38 55% 62%)",
  backgroundColor: "hsl(150 14% 5%)",
  surfaceColor: "hsl(150 12% 7.5%)",
  surfaceElevated: "hsl(150 10% 11%)",
  foregroundColor: "hsl(48 22% 95%)",
  mutedForeground: "hsl(150 8% 64%)",
  borderColor: "hsl(150 10% 16%)",
  destructiveColor: "hsl(0 72% 51%)",
  radius: "0.75rem",
  enableGlassmorphism: true,
  defaultMode: "dark",
  density: "comfortable",
  fontFamily: {
    display: "'Playfair Display', Georgia, serif",
    body: "'DM Sans', system-ui, sans-serif",
  },
};

/** Maps themeConfig onto :root so Tailwind arbitrary values stay in sync. */
export function applyTheme(): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const t = themeConfig;

  root.style.setProperty("--primary", t.primaryColor);
  root.style.setProperty("--primary-foreground", t.primaryForeground);
  root.style.setProperty("--accent", t.accentColor);
  root.style.setProperty("--background", t.backgroundColor);
  root.style.setProperty("--surface", t.surfaceColor);
  root.style.setProperty("--surface-elevated", t.surfaceElevated);
  root.style.setProperty("--foreground", t.foregroundColor);
  root.style.setProperty("--muted-foreground", t.mutedForeground);
  root.style.setProperty("--border", t.borderColor);
  root.style.setProperty("--destructive", t.destructiveColor);
  root.style.setProperty("--radius", t.radius);
  root.style.setProperty("--font-display", t.fontFamily.display);
  root.style.setProperty("--font-body", t.fontFamily.body);
  root.style.setProperty(
    "--density-pad",
    t.density === "compact" ? "0.7" : "1",
  );
  root.style.setProperty(
    "--glass-bg",
    t.enableGlassmorphism
      ? "color-mix(in oklab, var(--surface) 72%, transparent)"
      : "var(--surface)",
  );
  root.style.setProperty(
    "--glass-blur",
    t.enableGlassmorphism ? "22px" : "0px",
  );

  root.classList.remove("dark", "light");
  root.classList.add(t.defaultMode);
  root.style.colorScheme = t.defaultMode;
  document.body.style.fontFamily = t.fontFamily.body;
  document.body.style.backgroundColor = t.backgroundColor;
  document.body.style.color = t.foregroundColor;
}
