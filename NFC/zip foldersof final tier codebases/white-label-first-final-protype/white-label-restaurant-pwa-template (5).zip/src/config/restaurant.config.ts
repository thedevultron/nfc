/**
 * CLIENT BUSINESS CONFIG
 * --------------------------------------------------------------------------
 * Swap this file per restaurant. Feature flags hide/show entire modules
 * (booking sheet, review funnel, Wi-Fi modal, WhatsApp CTA, PWA install)
 * without touching component source.
 *
 * n8nWebhooks.*  → live endpoints consumed by /src/services
 * nfc            → default table/takeaway context (overridden by URL params)
 * brand.icon     → Lucide icon name used as the wordmark mark
 */

import type { RestaurantConfig } from "../types/config.types";

export const restaurantConfig: RestaurantConfig = {
  brand: {
    name: "Aura Bistro & Lounge",
    subtitle: "Modern Culinary Experience",
    tagline: "Seasonal plates. Crafted pours. Unhurried evenings.",
    icon: "ChefHat",
    googleReviewUrl: "https://maps.google.com/?q=Aura+Bistro+Lounge",
    whatsappNumber: "+919876543210",
    whatsappPrefill:
      "Hi Aura, I'd like to enquire about a table / an order.",
    wifi: { ssid: "Aura_Guest_5G", pass: "Bistro@2026", security: "WPA" },
    address: "12 Orchid Lane, Indiranagar, Bengaluru 560038",
    hours: "Tue–Sun  ·  12:00 – 23:30",
    phone: "+91 80 4567 8900",
    currency: "₹",
    locale: "en-IN",
  },
  features: {
    enableBookings: true,
    enableReviews: true,
    enableWifi: true,
    enableDirectOrdering: true,
    enableWhatsApp: true,
    enablePWAInstall: true,
    enableHaptics: true,
  },
  n8nWebhooks: {
    reservationUrl: "https://your-n8n-instance.com/webhook/reservation",
    feedbackUrl: "https://your-n8n-instance.com/webhook/feedback",
    orderUrl: "https://your-n8n-instance.com/webhook/order",
  },
  nfc: {
    defaultMode: "table",
    tableId: "04",
  },
  bookingTimeSlots: [
    "12:00",
    "12:30",
    "13:00",
    "13:30",
    "19:00",
    "19:30",
    "20:00",
    "20:30",
    "21:00",
    "21:30",
  ],
  maxPartySize: 12,
};
