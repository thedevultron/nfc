/**
 * MENU / CART / BOOKING / FEEDBACK SCHEMAS
 * --------------------------------------------------------------------------
 * Swap menuData.ts to re-skin the entire catalogue. Components only consume
 * these interfaces — never hard-coded dish names or prices.
 */

export type DietaryTag = "veg" | "nonveg" | "vegan";

export interface MenuCategory {
  id: string;
  label: string;
  /** Lucide icon name — resolved at runtime via getLucideIcon() */
  icon: string;
  description?: string;
}

export interface MenuItem {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  /** Lucide icon used as the dish's visual badge */
  icon: string;
  dietary: DietaryTag;
  /** 0 = none, 1–3 = Flame count */
  spiceLevel: 0 | 1 | 2 | 3;
  isBestSeller: boolean;
  isChefsSpecial: boolean;
  isAvailable: boolean;
}

export interface CartLine {
  item: MenuItem;
  quantity: number;
}

export interface CartSnapshot {
  lines: CartLine[];
  specialInstructions: string;
  subtotal: number;
  itemCount: number;
}

export interface ReservationPayload {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  notes: string;
  restaurant: string;
  source: "pwa";
}

export interface FeedbackPayload {
  rating: number;
  message: string;
  name?: string;
  phone?: string;
  restaurant: string;
  source: "pwa";
  /** true when the guest was redirected to Google instead of private form */
  publicReview: boolean;
}

export interface OrderPayload {
  lines: Array<{
    id: string;
    name: string;
    quantity: number;
    price: number;
  }>;
  specialInstructions: string;
  subtotal: number;
  mode: "table" | "takeaway";
  tableId?: string;
  restaurant: string;
  source: "pwa";
}

export type ApiResult = {
  success: boolean;
  message: string;
  mock?: boolean;
};

export type DietaryFilter = DietaryTag | "special" | "all";

export type AppSheet =
  | "cart"
  | "reservation"
  | "review"
  | "wifi"
  | "info"
  | null;

export type NavTab = "menu" | "cart" | "book" | "more";
