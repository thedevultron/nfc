/**
 * WHITE-LABEL SCHEMA
 * --------------------------------------------------------------------------
 * These interfaces describe EVERYTHING a new client can change.
 * Deploying for a new restaurant should NEVER require edits outside /src/config.
 */

export type ColorMode = "dark" | "light";
export type UiDensity = "comfortable" | "compact";
export type ServiceMode = "table" | "takeaway";

export interface ThemeFontFamily {
  /** Display / brand wordmark (serif recommended) */
  display: string;
  /** UI / body copy */
  body: string;
}

export interface ThemeConfig {
  /** CSS color used for CTAs, active states, and brand accents */
  primaryColor: string;
  primaryForeground: string;
  /** Secondary luxury accent (gold, copper, etc.) */
  accentColor: string;
  backgroundColor: string;
  surfaceColor: string;
  surfaceElevated: string;
  foregroundColor: string;
  mutedForeground: string;
  borderColor: string;
  destructiveColor: string;
  /** Applied as --radius on :root. Cards, pills, sheets inherit this. */
  radius: string;
  enableGlassmorphism: boolean;
  defaultMode: ColorMode;
  density: UiDensity;
  fontFamily: ThemeFontFamily;
}

export interface WifiConfig {
  ssid: string;
  pass: string;
  /** WPA | WEP | nopass — encoded into the Wi-Fi QR payload */
  security: "WPA" | "WEP" | "nopass";
}

export interface BrandConfig {
  name: string;
  subtitle: string;
  tagline: string;
  /**
   * Lucide icon name rendered as the brand mark.
   * Change this instead of shipping a logo file.
   */
  icon: string;
  googleReviewUrl: string;
  whatsappNumber: string;
  whatsappPrefill: string;
  wifi: WifiConfig;
  address: string;
  hours: string;
  phone: string;
  /** Prefix used by formatPrice() — e.g. "₹", "$", "€" */
  currency: string;
  locale: string;
}

export interface FeatureToggles {
  enableBookings: boolean;
  enableReviews: boolean;
  enableWifi: boolean;
  enableDirectOrdering: boolean;
  enableWhatsApp: boolean;
  enablePWAInstall: boolean;
  enableHaptics: boolean;
}

export interface N8nWebhooks {
  reservationUrl: string;
  feedbackUrl: string;
  orderUrl: string;
}

export interface NfcDefaults {
  /** Fallback when the URL has no ?table= or ?mode= param */
  defaultMode: ServiceMode;
  tableId: string;
}

export interface RestaurantConfig {
  brand: BrandConfig;
  features: FeatureToggles;
  n8nWebhooks: N8nWebhooks;
  nfc: NfcDefaults;
  /** Reservation time chips rendered by ReservationSheet */
  bookingTimeSlots: string[];
  maxPartySize: number;
}
