/**
 * APP SHELL
 * --------------------------------------------------------------------------
 * Wires layout + feature modules. Client branding, feature flags, menu data,
 * and webhook URLs all flow in from /src/config — this file should not need
 * edits when white-labelling a new restaurant.
 */

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { CartProvider, useCart } from "./hooks/useCart";
import { Shell } from "./components/layout/Shell";
import { TopBar } from "./components/layout/TopBar";
import { Header } from "./components/layout/Header";
import { BottomNav } from "./components/layout/BottomNav";
import { MenuList } from "./components/features/MenuList";
import { CartSheet } from "./components/features/CartSheet";
import { ReviewModal } from "./components/features/ReviewModal";
import { ReservationSheet } from "./components/features/ReservationSheet";
import { WifiModal } from "./components/features/WifiModal";
import { InfoSheet } from "./components/features/InfoSheet";
import { ToastViewport, type ToastState } from "./components/ui/Toast";
import { applyTheme } from "./config/theme.config";
import { restaurantConfig } from "./config/restaurant.config";
import { readNfcContext } from "./utils/format";
import type { AppSheet, NavTab } from "./types/menu.types";

applyTheme();

function AuraApp() {
  const nfc = useMemo(() => readNfcContext(), []);
  const cart = useCart();
  const [tab, setTab] = useState<NavTab>("menu");
  const [sheet, setSheet] = useState<AppSheet>(null);
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = (next: Omit<ToastState, "id">) => {
    const id = Date.now();
    setToast({ ...next, id });
    window.setTimeout(() => {
      setToast((current) => (current?.id === id ? null : current));
    }, 2800);
  };

  const openSheet = (next: AppSheet) => {
    if (next === "cart") {
      cart.open();
      setTab("cart");
      return;
    }
    setSheet(next);
    if (next === "reservation") setTab("book");
    if (next === "info") setTab("more");
  };

  const onTab = (next: NavTab) => {
    setTab(next);
    if (next === "menu") {
      cart.close();
      setSheet(null);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    if (next === "cart") {
      cart.open();
      return;
    }
    if (next === "book") {
      if (restaurantConfig.features.enableBookings) setSheet("reservation");
      return;
    }
    setSheet("info");
  };

  useEffect(() => {
    document.title = restaurantConfig.brand.name;
  }, []);

  return (
    <Shell
      header={<TopBar />}
      nav={<BottomNav active={tab} onChange={onTab} />}
    >
      <Header nfc={nfc} onOpenSheet={openSheet} />
      <MenuList />

      <AnimatePresence>
        <CartSheet
          open={cart.isOpen}
          onOpenChange={(open) => {
            if (open) cart.open();
            else {
              cart.close();
              if (tab === "cart") setTab("menu");
            }
          }}
          nfc={nfc}
          onToast={showToast}
        />
      </AnimatePresence>

      <ReservationSheet
        open={sheet === "reservation"}
        onOpenChange={(open) => {
          setSheet(open ? "reservation" : null);
          if (!open && tab === "book") setTab("menu");
        }}
        onToast={showToast}
      />

      <ReviewModal
        open={sheet === "review"}
        onOpenChange={(open) => setSheet(open ? "review" : null)}
        onToast={showToast}
      />

      <WifiModal
        open={sheet === "wifi"}
        onOpenChange={(open) => setSheet(open ? "wifi" : null)}
      />

      <InfoSheet
        open={sheet === "info"}
        onOpenChange={(open) => {
          setSheet(open ? "info" : null);
          if (!open && tab === "more") setTab("menu");
        }}
        onOpenSheet={openSheet}
      />

      <ToastViewport toast={toast} />
    </Shell>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AuraApp />
    </CartProvider>
  );
}
