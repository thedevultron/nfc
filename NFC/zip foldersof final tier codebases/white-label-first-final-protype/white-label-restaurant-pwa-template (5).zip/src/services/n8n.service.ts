/**
 * n8n WEBHOOK TRANSPORT
 * --------------------------------------------------------------------------
 * Isolated fetch layer. Swap URLs in restaurant.config.ts — never here.
 * CORS failures and missing backends resolve optimistically so the PWA
 * remains demo-able without a live n8n instance.
 */

import { restaurantConfig } from "../config/restaurant.config";
import type { ApiResult } from "../types/menu.types";

type WebhookKey = keyof typeof restaurantConfig.n8nWebhooks;

async function postWebhook(key: WebhookKey, payload: unknown): Promise<ApiResult> {
  const url = restaurantConfig.n8nWebhooks[key];
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...((payload as object) ?? {}),
        dispatchedAt: new Date().toISOString(),
        webhook: key,
      }),
    });
    if (!response.ok) {
      throw new Error(`n8n responded ${response.status}`);
    }
    const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
    return {
      success: true,
      message: typeof data.message === "string" ? data.message : "Dispatched",
    };
  } catch {
    // Optimistic fallback keeps the white-label demo fully interactive.
    console.info(`[n8n mock] ${key}`, payload);
    return {
      success: true,
      mock: true,
      message: "Captured locally — connect n8n to go live.",
    };
  }
}

export const n8nService = {
  postReservation: (payload: unknown) => postWebhook("reservationUrl", payload),
  postFeedback: (payload: unknown) => postWebhook("feedbackUrl", payload),
  postOrder: (payload: unknown) => postWebhook("orderUrl", payload),
};
