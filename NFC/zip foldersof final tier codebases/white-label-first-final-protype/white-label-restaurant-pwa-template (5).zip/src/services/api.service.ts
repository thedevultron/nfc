/**
 * DOMAIN API
 * --------------------------------------------------------------------------
 * Feature modules call these methods — they never fetch() themselves.
 * Point restaurantConfig.n8nWebhooks at live n8n URLs to go to production.
 */

import { restaurantConfig } from "../config/restaurant.config";
import { n8nService } from "./n8n.service";
import type {
  ApiResult,
  FeedbackPayload,
  OrderPayload,
  ReservationPayload,
} from "../types/menu.types";

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const apiService = {
  async sendReservation(payload: ReservationPayload): Promise<ApiResult> {
    console.log(
      "Sending reservation to n8n:",
      restaurantConfig.n8nWebhooks.reservationUrl,
      payload,
    );
    await delay(420);
    return n8nService.postReservation(payload);
  },

  async sendFeedback(payload: FeedbackPayload): Promise<ApiResult> {
    console.log(
      "Sending feedback to n8n:",
      restaurantConfig.n8nWebhooks.feedbackUrl,
      payload,
    );
    await delay(360);
    return n8nService.postFeedback(payload);
  },

  async sendOrder(payload: OrderPayload): Promise<ApiResult> {
    console.log(
      "Sending order to n8n:",
      restaurantConfig.n8nWebhooks.orderUrl,
      payload,
    );
    await delay(480);
    return n8nService.postOrder(payload);
  },
};
