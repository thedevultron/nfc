import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "../../utils/cn";

export function Card({
  className,
  children,
  ...props
}: HTMLMotionProps<"div">) {
  return (
    <motion.div
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      className={cn(
        "rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)]",
        className,
      )}
      {...props}
    >
      {children}
    </motion.div>
  );
}
