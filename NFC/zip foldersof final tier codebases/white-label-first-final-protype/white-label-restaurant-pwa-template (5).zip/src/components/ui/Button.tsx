import { motion, type HTMLMotionProps } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import { LoaderCircle } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "../../utils/cn";

type Variant = "primary" | "secondary" | "ghost" | "accent" | "destructive" | "outline";
type Size = "md" | "lg" | "icon" | "pill";

interface ButtonProps extends Omit<HTMLMotionProps<"button">, "children"> {
  variant?: Variant;
  size?: Size;
  icon?: LucideIcon;
  iconRight?: LucideIcon;
  loading?: boolean;
  block?: boolean;
  children?: ReactNode;
}

const variants: Record<Variant, string> = {
  primary:
    "bg-[var(--primary)] text-[var(--primary-foreground)] shadow-[0_8px_24px_color-mix(in_oklab,var(--primary)_35%,transparent)]",
  secondary:
    "bg-[var(--surface-elevated)] text-[var(--foreground)] border border-[var(--border)]",
  ghost: "bg-transparent text-[var(--foreground)]",
  accent:
    "bg-[var(--accent)] text-[#1a1408] shadow-[0_8px_24px_color-mix(in_oklab,var(--accent)_30%,transparent)]",
  destructive: "bg-[var(--destructive)] text-white",
  outline:
    "bg-transparent text-[var(--foreground)] border border-[var(--border)]",
};

const sizes: Record<Size, string> = {
  md: "min-h-12 px-4 text-sm gap-2 rounded-[var(--radius)]",
  lg: "min-h-14 px-5 text-[15px] gap-2.5 rounded-[var(--radius)]",
  icon: "h-12 w-12 min-h-12 min-w-12 rounded-full",
  pill: "min-h-12 px-4 text-sm gap-2 rounded-full",
};

export function Button({
  variant = "primary",
  size = "md",
  icon: Icon,
  iconRight: IconRight,
  loading,
  block,
  className,
  disabled,
  children,
  ...props
}: ButtonProps) {
  return (
    <motion.button
      type="button"
      whileTap={disabled || loading ? undefined : { scale: 0.94 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      disabled={disabled || loading}
      className={cn(
        "inline-flex items-center justify-center font-medium tracking-tight select-none",
        "active:brightness-95 disabled:opacity-40 disabled:pointer-events-none",
        variants[variant],
        sizes[size],
        block && "w-full",
        className,
      )}
      {...props}
    >
      {loading ? (
        <LoaderCircle className="h-4 w-4 animate-spin" />
      ) : (
        Icon && <Icon className="h-[18px] w-[18px] shrink-0" strokeWidth={2.1} />
      )}
      {children}
      {IconRight && !loading && (
        <IconRight className="h-[18px] w-[18px] shrink-0" strokeWidth={2.1} />
      )}
    </motion.button>
  );
}
