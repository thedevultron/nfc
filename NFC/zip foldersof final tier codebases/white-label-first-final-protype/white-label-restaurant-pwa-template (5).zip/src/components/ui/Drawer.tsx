import { Drawer as Vaul } from "vaul";
import { X } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "../../utils/cn";

interface AppDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  nested?: boolean;
}

export function AppDrawer({
  open,
  onOpenChange,
  title,
  subtitle,
  icon,
  children,
  footer,
  nested,
}: AppDrawerProps) {
  const Root = nested ? Vaul.NestedRoot : Vaul.Root;
  return (
    <Root open={open} onOpenChange={onOpenChange} shouldScaleBackground={!nested}>
      <Vaul.Portal>
        <Vaul.Overlay className="fixed inset-0 z-50 bg-black/60 backdrop-blur-[2px]" />
        <Vaul.Content
          className={cn(
            "fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[92dvh] w-full max-w-lg flex-col",
            "rounded-t-[calc(var(--radius)+0.6rem)]",
            "border border-[var(--border)] border-b-0",
            "bg-[var(--surface)] text-[var(--foreground)]",
            "shadow-[0_-24px_80px_rgba(0,0,0,0.55)]",
            "pb-[max(env(safe-area-inset-bottom),12px)]",
          )}
        >
          <div className="flex justify-center pt-3">
            <div className="h-1.5 w-12 rounded-full bg-white/18" />
          </div>

          <div className="flex items-start gap-3 px-5 pb-3 pt-4">
            {icon && (
              <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[color-mix(in_oklab,var(--primary)_16%,transparent)] text-[var(--primary)]">
                {icon}
              </div>
            )}
            <div className="min-w-0 flex-1">
              <Vaul.Title className="font-[family-name:var(--font-display)] text-2xl leading-tight tracking-tight">
                {title}
              </Vaul.Title>
              {subtitle && (
                <Vaul.Description className="mt-0.5 text-sm text-[var(--muted-foreground)]">
                  {subtitle}
                </Vaul.Description>
              )}
            </div>
            <button
              type="button"
              onClick={() => onOpenChange(false)}
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-[var(--muted-foreground)] hover:bg-white/5"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-4">
            {children}
          </div>

          {footer && (
            <div className="border-t border-[var(--border)] px-5 pt-3">{footer}</div>
          )}
        </Vaul.Content>
      </Vaul.Portal>
    </Root>
  );
}
