import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "../../utils/cn";

type Tone = "neutral" | "primary" | "accent" | "veg" | "nonveg" | "vegan" | "danger" | "muted";

interface BadgeProps {
  children: ReactNode;
  icon?: LucideIcon;
  tone?: Tone;
  className?: string;
}

const tones: Record<Tone, string> = {
  neutral: "bg-white/8 text-[var(--foreground)] border-white/10",
  primary:
    "bg-[color-mix(in_oklab,var(--primary)_18%,transparent)] text-[var(--primary)] border-[color-mix(in_oklab,var(--primary)_28%,transparent)]",
  accent:
    "bg-[color-mix(in_oklab,var(--accent)_18%,transparent)] text-[var(--accent)] border-[color-mix(in_oklab,var(--accent)_30%,transparent)]",
  veg: "bg-emerald-500/12 text-emerald-400 border-emerald-500/20",
  nonveg: "bg-rose-500/12 text-rose-400 border-rose-500/20",
  vegan: "bg-lime-500/12 text-lime-400 border-lime-500/20",
  danger: "bg-red-500/12 text-red-400 border-red-500/25",
  muted: "bg-white/5 text-[var(--muted-foreground)] border-white/8",
};

export function Badge({ children, icon: Icon, tone = "neutral", className }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em]",
        tones[tone],
        className,
      )}
    >
      {Icon && <Icon className="h-3 w-3" strokeWidth={2.4} />}
      {children}
    </span>
  );
}
