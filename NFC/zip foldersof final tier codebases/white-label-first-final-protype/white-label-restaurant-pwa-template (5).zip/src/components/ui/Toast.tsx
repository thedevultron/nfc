import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, CircleAlert } from "lucide-react";
import { cn } from "../../utils/cn";

export interface ToastState {
  id: number;
  title: string;
  description?: string;
  tone?: "success" | "error";
}

export function ToastViewport({ toast }: { toast: ToastState | null }) {
  return (
    <AnimatePresence>
      {toast && (
        <motion.div
          key={toast.id}
          initial={{ opacity: 0, y: 24, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.96 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          className={cn(
            "pointer-events-none fixed inset-x-0 z-[70] mx-auto w-[min(92%,420px)]",
            "bottom-[calc(5.75rem+env(safe-area-inset-bottom))]",
          )}
        >
          <div className="flex items-start gap-3 rounded-2xl border border-white/10 bg-[var(--surface-elevated)] px-4 py-3 shadow-2xl">
            {toast.tone === "error" ? (
              <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-red-400" />
            ) : (
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[var(--primary)]" />
            )}
            <div className="min-w-0">
              <p className="text-sm font-semibold">{toast.title}</p>
              {toast.description && (
                <p className="mt-0.5 text-xs text-[var(--muted-foreground)]">
                  {toast.description}
                </p>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
