import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { cn } from "../../utils/cn";

interface StarRatingProps {
  value: number;
  onChange?: (value: number) => void;
  size?: number;
  readOnly?: boolean;
}

export function StarRating({ value, onChange, size = 36, readOnly }: StarRatingProps) {
  return (
    <div className="flex items-center justify-center gap-1.5" role="radiogroup" aria-label="Rating">
      {[1, 2, 3, 4, 5].map((n) => {
        const active = n <= value;
        return (
          <motion.button
            key={n}
            type="button"
            role="radio"
            aria-checked={active}
            disabled={readOnly}
            whileTap={readOnly ? undefined : { scale: 0.82 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            onClick={() => onChange?.(n)}
            className={cn(
              "flex h-12 w-12 items-center justify-center rounded-full",
              !readOnly && "hover:bg-white/5",
            )}
          >
            <Star
              width={size}
              height={size}
              strokeWidth={1.6}
              className={cn(
                "transition-colors duration-200",
                active
                  ? "fill-[var(--accent)] text-[var(--accent)]"
                  : "fill-transparent text-white/25",
              )}
            />
          </motion.button>
        );
      })}
    </div>
  );
}
