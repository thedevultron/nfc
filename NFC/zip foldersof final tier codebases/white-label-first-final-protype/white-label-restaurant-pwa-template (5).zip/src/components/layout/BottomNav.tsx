import { motion } from "framer-motion";
import {
  CalendarDays,
  Info,
  ShoppingBag,
  UtensilsCrossed,
} from "lucide-react";
import { restaurantConfig } from "../../config/restaurant.config";
import { useCart } from "../../hooks/useCart";
import { useHaptics } from "../../hooks/useHaptics";
import type { NavTab } from "../../types/menu.types";
import { cn } from "../../utils/cn";

interface BottomNavProps {
  active: NavTab;
  onChange: (tab: NavTab) => void;
}

export function BottomNav({ active, onChange }: BottomNavProps) {
  const { itemCount } = useCart();
  const haptics = useHaptics();
  const f = restaurantConfig.features;

  const tabs: Array<{
    id: NavTab;
    label: string;
    icon: typeof UtensilsCrossed;
    show: boolean;
  }> = [
    { id: "menu", label: "Menu", icon: UtensilsCrossed, show: true },
    { id: "cart", label: "Cart", icon: ShoppingBag, show: true },
    { id: "book", label: "Book", icon: CalendarDays, show: f.enableBookings },
    { id: "more", label: "More", icon: Info, show: true },
  ];

  const visible = tabs.filter((t) => t.show);

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-lg border-t border-[var(--border)]"
      style={{
        background: "var(--glass-bg)",
        backdropFilter: `blur(var(--glass-blur)) saturate(160%)`,
        paddingBottom: "max(env(safe-area-inset-bottom), 10px)",
      }}
    >
      <div className="relative grid auto-cols-fr grid-flow-col px-2 pt-1">
        {visible.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                haptics.selection();
                onChange(tab.id);
              }}
              className="relative flex min-h-14 flex-col items-center justify-center gap-0.5"
            >
              {isActive && (
                <motion.span
                  layoutId="nav-indicator"
                  className="absolute inset-x-3 top-1 h-[calc(100%-6px)] rounded-2xl bg-[color-mix(in_oklab,var(--primary)_16%,transparent)]"
                  transition={{ type: "spring", stiffness: 400, damping: 28 }}
                />
              )}
              <span className="relative">
                <Icon
                  className={cn(
                    "h-5 w-5",
                    isActive ? "text-[var(--primary)]" : "text-[var(--muted-foreground)]",
                  )}
                  strokeWidth={isActive ? 2.3 : 1.8}
                />
                {tab.id === "cart" && itemCount > 0 && (
                  <span className="absolute -right-2.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--primary)] px-1 text-[9px] font-bold text-[var(--primary-foreground)]">
                    {itemCount}
                  </span>
                )}
              </span>
              <span
                className={cn(
                  "relative text-[10px] font-semibold uppercase tracking-[0.14em]",
                  isActive ? "text-[var(--primary)]" : "text-[var(--muted-foreground)]",
                )}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
