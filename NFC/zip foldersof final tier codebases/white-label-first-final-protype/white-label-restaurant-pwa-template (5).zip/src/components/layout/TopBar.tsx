import { Download, ChefHat } from "lucide-react";
import { motion } from "framer-motion";
import { restaurantConfig } from "../../config/restaurant.config";
import { getLucideIcon } from "../../utils/icons";
import { usePWAInstall } from "../../hooks/usePWAInstall";
import { useHaptics } from "../../hooks/useHaptics";

export function TopBar() {
  const { canInstall, install } = usePWAInstall();
  const haptics = useHaptics();
  const BrandIcon = getLucideIcon(restaurantConfig.brand.icon) ?? ChefHat;

  return (
    <div
      className="flex items-center justify-between gap-3 px-5 pb-2"
      style={{ paddingTop: "max(env(safe-area-inset-top), 14px)" }}
    >
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[color-mix(in_oklab,var(--primary)_18%,transparent)] text-[var(--primary)] ring-1 ring-[color-mix(in_oklab,var(--primary)_28%,transparent)]">
          <BrandIcon className="h-5 w-5" strokeWidth={2.1} />
        </div>
        <div className="min-w-0">
          <h1 className="truncate font-[family-name:var(--font-display)] text-[22px] leading-none tracking-tight">
            {restaurantConfig.brand.name}
          </h1>
          <p className="mt-1 truncate text-[11px] uppercase tracking-[0.18em] text-[var(--muted-foreground)]">
            {restaurantConfig.brand.subtitle}
          </p>
        </div>
      </div>

      {canInstall && (
        <motion.button
          type="button"
          whileTap={{ scale: 0.92 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          onClick={() => {
            haptics.medium();
            void install();
          }}
          className="flex h-12 items-center gap-1.5 rounded-full border border-[var(--border)] bg-white/5 px-3 text-xs font-semibold uppercase tracking-[0.12em] text-[var(--accent)]"
        >
          <Download className="h-4 w-4" />
          Install
        </motion.button>
      )}
    </div>
  );
}
