/**
 * DYNAMIC ACTION HEADER
 * --------------------------------------------------------------------------
 * Quick actions are gated by restaurantConfig.features.* so a client can
 * hide Wi-Fi / WhatsApp / Reviews / Bookings from a single config file.
 * NFC badge label is derived from ?table= / ?mode= URL params.
 */

import { motion } from "framer-motion";
import {
  CalendarDays,
  MessageCircle,
  SmartphoneNfc,
  Star,
  Wifi,
} from "lucide-react";
import { restaurantConfig } from "../../config/restaurant.config";
import { useHaptics } from "../../hooks/useHaptics";
import { whatsappHref, type NfcContext } from "../../utils/format";
import type { AppSheet } from "../../types/menu.types";
import { cn } from "../../utils/cn";

interface HeaderProps {
  nfc: NfcContext;
  onOpenSheet: (sheet: AppSheet) => void;
}

interface QuickAction {
  id: string;
  label: string;
  caption: string;
  icon: typeof Wifi;
  enabled: boolean;
  onPress: () => void;
}

const GRID: Record<number, string> = {
  1: "grid-cols-1",
  2: "grid-cols-2",
  3: "grid-cols-3",
  4: "grid-cols-4",
};

export function Header({ nfc, onOpenSheet }: HeaderProps) {
  const haptics = useHaptics();
  const f = restaurantConfig.features;

  const actions: QuickAction[] = [
    {
      id: "wifi",
      label: "Wi-Fi",
      caption: "Instant",
      icon: Wifi,
      enabled: f.enableWifi,
      onPress: () => onOpenSheet("wifi"),
    },
    {
      id: "wa",
      label: "WhatsApp",
      caption: "Concierge",
      icon: MessageCircle,
      enabled: f.enableWhatsApp,
      onPress: () => {
        window.open(
          whatsappHref(restaurantConfig.brand.whatsappPrefill),
          "_blank",
          "noopener,noreferrer",
        );
      },
    },
    {
      id: "review",
      label: "Review",
      caption: "Rate us",
      icon: Star,
      enabled: f.enableReviews,
      onPress: () => onOpenSheet("review"),
    },
    {
      id: "book",
      label: "Book",
      caption: "A table",
      icon: CalendarDays,
      enabled: f.enableBookings,
      onPress: () => onOpenSheet("reservation"),
    },
  ].filter((a) => a.enabled);

  return (
    <div className="px-5 pb-3 pt-1">
      <p className="mb-3 max-w-[22ch] font-[family-name:var(--font-display)] text-[1.85rem] leading-[1.15] tracking-tight">
        {restaurantConfig.brand.tagline}
      </p>

      <div className="mb-3 inline-flex max-w-full items-center gap-2 rounded-full border border-[color-mix(in_oklab,var(--accent)_28%,transparent)] bg-[color-mix(in_oklab,var(--accent)_10%,transparent)] px-3 py-1.5">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[var(--accent)] opacity-60" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--accent)]" />
        </span>
        <SmartphoneNfc className="h-3.5 w-3.5 text-[var(--accent)]" />
        <span className="truncate text-[11px] font-semibold uppercase tracking-[0.16em] text-[var(--accent)]">
          {nfc.label}
        </span>
      </div>

      <div className={cn("grid gap-2", GRID[actions.length] ?? "grid-cols-4")}>
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <motion.button
              key={action.id}
              type="button"
              whileTap={{ scale: 0.92 }}
              transition={{ type: "spring", stiffness: 400, damping: 25 }}
              onClick={() => {
                haptics.selection();
                action.onPress();
              }}
              className="flex min-h-20 flex-col items-center justify-center gap-1.5 rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-1 py-2"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-[var(--foreground)]">
                <Icon className="h-[18px] w-[18px]" strokeWidth={2} />
              </span>
              <span className="text-[11px] font-semibold leading-none">{action.label}</span>
              <span className="text-[9px] uppercase tracking-[0.14em] text-[var(--muted-foreground)]">
                {action.caption}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
