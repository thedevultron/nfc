import type { ReactNode } from "react";
import { cn } from "../../utils/cn";

interface ShellProps {
  header: ReactNode;
  children: ReactNode;
  nav: ReactNode;
}

export function Shell({ header, children, nav }: ShellProps) {
  return (
    <div className="relative mx-auto min-h-dvh w-full max-w-lg overflow-hidden bg-[var(--background)] text-[var(--foreground)]">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-24 -top-24 h-64 w-64 rounded-full bg-[var(--primary)] opacity-[0.09] blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 top-32 h-56 w-56 rounded-full bg-[var(--accent)] opacity-[0.07] blur-3xl"
      />

      <header
        className={cn("sticky top-0 z-30")}
        style={{
          background: "var(--glass-bg)",
          backdropFilter: `blur(var(--glass-blur)) saturate(160%)`,
        }}
      >
        {header}
      </header>

      <main className="relative pb-[calc(6.25rem+env(safe-area-inset-bottom))]">
        {children}
      </main>

      {nav}
    </div>
  );
}
