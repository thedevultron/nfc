import {
  Clock,
  Download,
  MapPin,
  MessageCircle,
  Phone,
  Star,
  Wifi,
} from "lucide-react";
import { AppDrawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { restaurantConfig } from "../../config/restaurant.config";
import { getLucideIcon } from "../../utils/icons";
import { whatsappHref } from "../../utils/format";
import { usePWAInstall } from "../../hooks/usePWAInstall";
import { useHaptics } from "../../hooks/useHaptics";
import type { AppSheet } from "../../types/menu.types";

interface InfoSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onOpenSheet: (sheet: AppSheet) => void;
}

export function InfoSheet({ open, onOpenChange, onOpenSheet }: InfoSheetProps) {
  const BrandIcon = getLucideIcon(restaurantConfig.brand.icon);
  const { canInstall, install, isInstalled } = usePWAInstall();
  const haptics = useHaptics();
  const b = restaurantConfig.brand;
  const f = restaurantConfig.features;

  return (
    <AppDrawer
      open={open}
      onOpenChange={onOpenChange}
      title={b.name}
      subtitle={b.tagline}
      icon={<BrandIcon className="h-5 w-5" />}
    >
      <div className="space-y-3 pb-2">
        <MetaRow icon={MapPin} label="Address" value={b.address} />
        <MetaRow icon={Clock} label="Hours" value={b.hours} />
        <MetaRow icon={Phone} label="Phone" value={b.phone} />

        <div className="grid grid-cols-2 gap-2 pt-2">
          {f.enableWifi && (
            <Button
              variant="secondary"
              icon={Wifi}
              onClick={() => {
                onOpenChange(false);
                onOpenSheet("wifi");
              }}
            >
              Wi-Fi
            </Button>
          )}
          {f.enableReviews && (
            <Button
              variant="secondary"
              icon={Star}
              onClick={() => {
                onOpenChange(false);
                onOpenSheet("review");
              }}
            >
              Review
            </Button>
          )}
          {f.enableWhatsApp && (
            <Button
              variant="secondary"
              icon={MessageCircle}
              onClick={() =>
                window.open(whatsappHref(b.whatsappPrefill), "_blank", "noopener,noreferrer")
              }
            >
              WhatsApp
            </Button>
          )}
          <Button
            variant="secondary"
            icon={Phone}
            onClick={() => {
              window.location.href = `tel:${b.phone}`;
            }}
          >
            Call
          </Button>
        </div>

        {canInstall && (
          <Button
            block
            className="mt-2"
            icon={Download}
            onClick={() => {
              haptics.medium();
              void install();
            }}
          >
            Add to Home Screen
          </Button>
        )}
        {isInstalled && (
          <p className="pt-1 text-center text-xs text-[var(--muted-foreground)]">
            Running as an installed app
          </p>
        )}
      </div>
    </AppDrawer>
  );
}

function MetaRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof MapPin;
  label: string;
  value: string;
}) {
  return (
    <div className="flex gap-3 rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 py-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5 text-[var(--primary)]">
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-[0.16em] text-[var(--muted-foreground)]">
          {label}
        </p>
        <p className="text-sm leading-snug">{value}</p>
      </div>
    </div>
  );
}
