/**
 * SMART REVIEW FILTER
 * --------------------------------------------------------------------------
 * 4–5 stars → public Google review (restaurantConfig.brand.googleReviewUrl)
 * <4 stars  → private manager feedback via n8n feedback webhook
 * This split is the entire point of the module — do not invert it.
 */

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ExternalLink, Heart, Send, Star } from "lucide-react";
import { AppDrawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { StarRating } from "../ui/StarRating";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService } from "../../services/api.service";
import { useHaptics } from "../../hooks/useHaptics";
import type { ToastState } from "../ui/Toast";

interface ReviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onToast: (toast: Omit<ToastState, "id">) => void;
}

export function ReviewModal({ open, onOpenChange, onToast }: ReviewModalProps) {
  const [rating, setRating] = useState(0);
  const [message, setMessage] = useState("");
  const [name, setName] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const haptics = useHaptics();

  const reset = () => {
    setRating(0);
    setMessage("");
    setName("");
    setSending(false);
    setSent(false);
  };

  const submitPrivate = async () => {
    setSending(true);
    haptics.medium();
    const result = await apiService.sendFeedback({
      rating,
      message,
      name: name || undefined,
      restaurant: restaurantConfig.brand.name,
      source: "pwa",
      publicReview: false,
    });
    setSending(false);
    if (result.success) {
      haptics.success();
      setSent(true);
      onToast({
        title: "Thank you — this stays private",
        description: "The manager will read this today.",
      });
    } else {
      haptics.error();
      onToast({ title: "Could not send feedback", tone: "error" });
    }
  };

  const openGoogle = () => {
    haptics.success();
    void apiService.sendFeedback({
      rating,
      message: "",
      restaurant: restaurantConfig.brand.name,
      source: "pwa",
      publicReview: true,
    });
    window.open(restaurantConfig.brand.googleReviewUrl, "_blank", "noopener,noreferrer");
    onToast({ title: "Opening Google Reviews" });
  };

  return (
    <AppDrawer
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) setTimeout(reset, 280);
      }}
      title="How was Aura?"
      subtitle="A quiet tap. Honest stars."
      icon={<Star className="h-5 w-5" />}
    >
      <div className="pb-2 pt-2">
        <StarRating
          value={rating}
          onChange={(n) => {
            haptics.selection();
            setRating(n);
            setSent(false);
          }}
        />
        <p className="mt-1 text-center text-xs uppercase tracking-[0.18em] text-[var(--muted-foreground)]">
          {rating === 0
            ? "Tap to rate"
            : rating >= 4
              ? "We're glowing"
              : "We'll make this right"}
        </p>

        <AnimatePresence mode="wait">
          {rating === 0 ? (
            <motion.p
              key="idle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-8 text-center text-sm text-[var(--muted-foreground)]"
            >
              Your rating decides whether we send you public — or keep it between us.
            </motion.p>
          ) : rating >= 4 ? (
            <motion.div
              key="public"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ type: "spring", stiffness: 400, damping: 28 }}
              className="mt-8 space-y-4"
            >
              <div className="rounded-[var(--radius)] border border-[color-mix(in_oklab,var(--accent)_30%,transparent)] bg-[color-mix(in_oklab,var(--accent)_8%,transparent)] p-4 text-sm leading-relaxed">
                Thank you. A public note on Google helps other guests find the room.
              </div>
              <Button block size="lg" variant="accent" icon={ExternalLink} onClick={openGoogle}>
                Post public review on Google
              </Button>
            </motion.div>
          ) : sent ? (
            <motion.div
              key="thanks"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 rounded-[var(--radius)] border border-[var(--border)] p-6 text-center"
            >
              <Heart className="mx-auto h-7 w-7 text-[var(--primary)]" />
              <p className="mt-3 font-medium">Received. This never goes public.</p>
            </motion.div>
          ) : (
            <motion.form
              key="private"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ type: "spring", stiffness: 400, damping: 28 }}
              className="mt-6 space-y-3"
              onSubmit={(e) => {
                e.preventDefault();
                void submitPrivate();
              }}
            >
              <p className="text-sm text-[var(--muted-foreground)]">
                Tell the manager what we can improve — this stays in-house.
              </p>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name (optional)"
                className="h-12 w-full rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 text-sm outline-none focus:border-[var(--primary)]"
              />
              <textarea
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
                placeholder="What didn't land tonight?"
                className="w-full resize-none rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 py-2.5 text-sm outline-none focus:border-[var(--primary)]"
              />
              <Button block size="lg" type="submit" loading={sending} icon={Send}>
                Send private feedback
              </Button>
            </motion.form>
          )}
        </AnimatePresence>
      </div>
    </AppDrawer>
  );
}
