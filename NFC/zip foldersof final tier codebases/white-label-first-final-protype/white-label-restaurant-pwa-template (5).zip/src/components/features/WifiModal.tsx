import { useState } from "react";
import { Check, Copy, QrCode, Wifi } from "lucide-react";
import { AppDrawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { restaurantConfig } from "../../config/restaurant.config";
import { QrMark, wifiQrPayload } from "../../utils/qr";
import { useHaptics } from "../../hooks/useHaptics";

interface WifiModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WifiModal({ open, onOpenChange }: WifiModalProps) {
  const { ssid, pass, security } = restaurantConfig.brand.wifi;
  const [copied, setCopied] = useState<"ssid" | "pass" | "all" | null>(null);
  const haptics = useHaptics();
  const payload = wifiQrPayload(ssid, pass, security);

  const copy = async (value: string, key: "ssid" | "pass" | "all") => {
    try {
      await navigator.clipboard.writeText(value);
      haptics.success();
      setCopied(key);
      window.setTimeout(() => setCopied(null), 1600);
    } catch {
      haptics.error();
    }
  };

  return (
    <AppDrawer
      open={open}
      onOpenChange={onOpenChange}
      title="Guest Wi-Fi"
      subtitle="Scan or copy. No login page."
      icon={<Wifi className="h-5 w-5" />}
    >
      <div className="flex flex-col items-center pb-2">
        <div className="relative w-[220px] overflow-hidden rounded-2xl border border-[var(--border)] bg-[#f4f1ea] p-3 shadow-inner">
          <QrMark payload={payload} title={`Wi-Fi ${ssid}`} />
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <span className="flex h-9 w-9 items-center justify-center rounded-md bg-[#f4f1ea] text-[#0c100e]">
              <QrCode className="h-5 w-5" />
            </span>
          </div>
        </div>

        <div className="mt-5 w-full space-y-2">
          <CredRow
            label="Network"
            value={ssid}
            copied={copied === "ssid"}
            onCopy={() => void copy(ssid, "ssid")}
          />
          <CredRow
            label="Password"
            value={pass}
            copied={copied === "pass"}
            onCopy={() => void copy(pass, "pass")}
          />
        </div>

        <Button
          block
          className="mt-4"
          variant="secondary"
          icon={copied === "all" ? Check : Copy}
          onClick={() => void copy(`SSID: ${ssid}\nPassword: ${pass}`, "all")}
        >
          {copied === "all" ? "Copied" : "Copy both"}
        </Button>
      </div>
    </AppDrawer>
  );
}

function CredRow({
  label,
  value,
  copied,
  onCopy,
}: {
  label: string;
  value: string;
  copied: boolean;
  onCopy: () => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 py-2.5">
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-[0.16em] text-[var(--muted-foreground)]">
          {label}
        </p>
        <p className="truncate font-mono text-sm">{value}</p>
      </div>
      <button
        type="button"
        onClick={onCopy}
        className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-[var(--primary)]"
        aria-label={`Copy ${label}`}
      >
        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      </button>
    </div>
  );
}
