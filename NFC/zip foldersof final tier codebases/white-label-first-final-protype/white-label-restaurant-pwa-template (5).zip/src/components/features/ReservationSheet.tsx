import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { CalendarDays, CheckCircle2, Minus, Plus, Users } from "lucide-react";
import { AppDrawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService } from "../../services/api.service";
import { useHaptics } from "../../hooks/useHaptics";
import { addDaysISO, formatDateLabel, todayISO } from "../../utils/format";
import { cn } from "../../utils/cn";
import type { ToastState } from "../ui/Toast";

interface ReservationSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onToast: (toast: Omit<ToastState, "id">) => void;
}

export function ReservationSheet({
  open,
  onOpenChange,
  onToast,
}: ReservationSheetProps) {
  const dates = useMemo(
    () => Array.from({ length: 14 }, (_, i) => addDaysISO(i) || todayISO()),
    [],
  );
  const [date, setDate] = useState(dates[0] ?? todayISO());
  const [time, setTime] = useState(restaurantConfig.bookingTimeSlots[4] ?? "19:30");
  const [guests, setGuests] = useState(2);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [sending, setSending] = useState(false);
  const [success, setSuccess] = useState(false);
  const haptics = useHaptics();

  const reset = () => {
    setSuccess(false);
    setSending(false);
  };

  const submit = async () => {
    if (!name.trim() || !phone.trim()) return;
    setSending(true);
    haptics.medium();
    const result = await apiService.sendReservation({
      name: name.trim(),
      phone: phone.trim(),
      date,
      time,
      guests,
      notes,
      restaurant: restaurantConfig.brand.name,
      source: "pwa",
    });
    setSending(false);
    if (result.success) {
      haptics.success();
      setSuccess(true);
      onToast({
        title: "Table requested",
        description: `${formatDateLabel(date)} · ${time} · ${guests} guests`,
      });
    } else {
      haptics.error();
      onToast({ title: "Could not book", tone: "error" });
    }
  };

  return (
    <AppDrawer
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) setTimeout(reset, 280);
      }}
      title="Reserve a table"
      subtitle={restaurantConfig.brand.hours}
      icon={<CalendarDays className="h-5 w-5" />}
      footer={
        success ? (
          <Button block size="lg" variant="secondary" onClick={() => onOpenChange(false)}>
            Done
          </Button>
        ) : (
          <Button
            block
            size="lg"
            loading={sending}
            disabled={!name.trim() || !phone.trim()}
            onClick={() => void submit()}
          >
            Request {guests} {guests === 1 ? "guest" : "guests"} · {time}
          </Button>
        )
      }
    >
      {success ? (
        <div className="py-10 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 400, damping: 20 }}
            className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[color-mix(in_oklab,var(--primary)_18%,transparent)] text-[var(--primary)]"
          >
            <CheckCircle2 className="h-8 w-8" />
          </motion.div>
          <p className="mt-4 font-[family-name:var(--font-display)] text-2xl">
            Request received
          </p>
          <p className="mt-2 text-sm text-[var(--muted-foreground)]">
            {formatDateLabel(date)} at {time} for {guests}. We'll confirm on WhatsApp shortly.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          <div>
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-[var(--muted-foreground)]">
              Date
            </p>
            <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
              {dates.map((d) => {
                const active = d === date;
                return (
                  <button
                    key={d}
                    type="button"
                    onClick={() => {
                      haptics.selection();
                      setDate(d);
                    }}
                    className={cn(
                      "relative flex h-[4.5rem] w-[4.4rem] shrink-0 flex-col items-center justify-center rounded-2xl border text-center",
                      active
                        ? "border-transparent text-[var(--primary-foreground)]"
                        : "border-[var(--border)] text-[var(--muted-foreground)]",
                    )}
                  >
                    {active && (
                      <motion.span
                        layoutId="date-indicator"
                        className="absolute inset-0 rounded-2xl bg-[var(--primary)]"
                        transition={{ type: "spring", stiffness: 400, damping: 28 }}
                      />
                    )}
                    <span className="relative text-[10px] uppercase tracking-[0.14em]">
                      {formatDateLabel(d).split(" ")[0]}
                    </span>
                    <span className="relative mt-0.5 font-[family-name:var(--font-display)] text-xl leading-none">
                      {formatDateLabel(d).split(" ")[1]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-[var(--muted-foreground)]">
              Time
            </p>
            <div className="flex flex-wrap gap-2">
              {restaurantConfig.bookingTimeSlots.map((slot) => {
                const active = slot === time;
                return (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => {
                      haptics.selection();
                      setTime(slot);
                    }}
                    className={cn(
                      "relative flex h-11 min-w-[4.5rem] items-center justify-center rounded-full border px-3 text-sm font-medium",
                      active
                        ? "border-transparent text-[var(--primary-foreground)]"
                        : "border-[var(--border)] text-[var(--muted-foreground)]",
                    )}
                  >
                    {active && (
                      <motion.span
                        layoutId="time-indicator"
                        className="absolute inset-0 rounded-full bg-[var(--primary)]"
                        transition={{ type: "spring", stiffness: 400, damping: 28 }}
                      />
                    )}
                    <span className="relative tabular-nums">{slot}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 py-2">
            <span className="flex items-center gap-2 text-sm">
              <Users className="h-4 w-4 text-[var(--primary)]" />
              Guests
            </span>
            <div className="flex items-center gap-1">
              <motion.button
                type="button"
                whileTap={{ scale: 0.9 }}
                className="flex h-11 w-11 items-center justify-center rounded-full"
                onClick={() => {
                  haptics.selection();
                  setGuests((g) => Math.max(1, g - 1));
                }}
              >
                <Minus className="h-4 w-4" />
              </motion.button>
              <span className="w-6 text-center font-semibold tabular-nums">{guests}</span>
              <motion.button
                type="button"
                whileTap={{ scale: 0.9 }}
                className="flex h-11 w-11 items-center justify-center rounded-full"
                onClick={() => {
                  haptics.selection();
                  setGuests((g) => Math.min(restaurantConfig.maxPartySize, g + 1));
                }}
              >
                <Plus className="h-4 w-4" />
              </motion.button>
            </div>
          </div>

          <div className="space-y-2">
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Name"
              className="h-12 w-full rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 text-sm outline-none focus:border-[var(--primary)]"
            />
            <input
              required
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Phone / WhatsApp"
              className="h-12 w-full rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 text-sm outline-none focus:border-[var(--primary)]"
            />
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Occasion, high-chair, allergies…"
              className="w-full resize-none rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 py-2.5 text-sm outline-none focus:border-[var(--primary)]"
            />
          </div>
        </div>
      )}
    </AppDrawer>
  );
}
