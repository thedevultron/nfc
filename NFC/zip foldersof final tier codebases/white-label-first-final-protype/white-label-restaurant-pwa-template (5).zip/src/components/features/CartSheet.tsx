import { useState } from "react";
import {
  Minus,
  Plus,
  ShoppingBag,
  SquarePen,
  Trash2,
  UtensilsCrossed,
  MessageCircle,
} from "lucide-react";
import { motion } from "framer-motion";
import { AppDrawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { useCart } from "../../hooks/useCart";
import { useHaptics } from "../../hooks/useHaptics";
import { restaurantConfig } from "../../config/restaurant.config";
import { apiService } from "../../services/api.service";
import { formatPrice, whatsappHref, type NfcContext } from "../../utils/format";
import { getLucideIcon } from "../../utils/icons";
import type { ToastState } from "../ui/Toast";

interface CartSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  nfc: NfcContext;
  onToast: (toast: Omit<ToastState, "id">) => void;
}

export function CartSheet({ open, onOpenChange, nfc, onToast }: CartSheetProps) {
  const {
    lines,
    itemCount,
    subtotal,
    increment,
    decrement,
    removeItem,
    clear,
    specialInstructions,
    setSpecialInstructions,
  } = useCart();
  const haptics = useHaptics();
  const [sending, setSending] = useState(false);
  const canOrder = restaurantConfig.features.enableDirectOrdering;

  const composeSummary = () => {
    const header = [
      `*${restaurantConfig.brand.name}*`,
      nfc.mode === "table" ? `Table ${nfc.tableId}` : "Takeaway",
      "",
    ];
    const body = lines.map(
      (l) => `• ${l.quantity}× ${l.item.name} — ${formatPrice(l.item.price * l.quantity)}`,
    );
    const notes = specialInstructions.trim()
      ? ["", `_Notes:_ ${specialInstructions.trim()}`]
      : [];
    return [...header, ...body, ...notes, "", `*Total: ${formatPrice(subtotal)}*`].join("\n");
  };

  const placeOrder = async (via: "kitchen" | "whatsapp") => {
    if (!lines.length) return;
    setSending(true);
    haptics.medium();
    const payload = {
      lines: lines.map((l) => ({
        id: l.item.id,
        name: l.item.name,
        quantity: l.quantity,
        price: l.item.price,
      })),
      specialInstructions,
      subtotal,
      mode: nfc.mode,
      tableId: nfc.tableId || undefined,
      restaurant: restaurantConfig.brand.name,
      source: "pwa" as const,
    };

    const result = await apiService.sendOrder(payload);

    if (via === "whatsapp" && restaurantConfig.features.enableWhatsApp) {
      window.open(whatsappHref(composeSummary()), "_blank", "noopener,noreferrer");
    }

    setSending(false);
    if (result.success) {
      haptics.success();
      onToast({
        title: via === "whatsapp" ? "Order sent to WhatsApp" : "Order sent to kitchen",
        description: result.mock
          ? "Demo mode — connect n8n to go live."
          : "The team has the ticket.",
      });
      clear();
      onOpenChange(false);
    } else {
      haptics.error();
      onToast({ title: "Could not send order", tone: "error" });
    }
  };

  return (
    <AppDrawer
      open={open}
      onOpenChange={onOpenChange}
      title="Your order"
      subtitle={
        itemCount
          ? `${itemCount} ${itemCount === 1 ? "item" : "items"}  ·  ${formatPrice(subtotal)}`
          : "The bag is empty"
      }
      icon={<ShoppingBag className="h-5 w-5" />}
      footer={
        lines.length > 0 && canOrder ? (
          <div className="space-y-2">
            <Button
              block
              size="lg"
              loading={sending}
              icon={UtensilsCrossed}
              onClick={() => void placeOrder("kitchen")}
            >
              Place order · {formatPrice(subtotal)}
            </Button>
            {restaurantConfig.features.enableWhatsApp && (
              <Button
                block
                variant="secondary"
                icon={MessageCircle}
                disabled={sending}
                onClick={() => void placeOrder("whatsapp")}
              >
                Send via WhatsApp
              </Button>
            )}
          </div>
        ) : null
      }
    >
      {lines.length === 0 ? (
        <div className="py-10 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-white/5">
            <ShoppingBag className="h-7 w-7 text-[var(--muted-foreground)]" />
          </div>
          <p className="mt-4 font-medium">Nothing here yet</p>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            Add a plate from the menu to begin.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {lines.map((line) => {
            const Icon = getLucideIcon(line.item.icon);
            return (
              <div
                key={line.item.id}
                className="flex gap-3 rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] p-3"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[color-mix(in_oklab,var(--primary)_12%,transparent)] text-[var(--primary)]">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="truncate font-medium">{line.item.name}</p>
                    <p className="text-sm font-semibold text-[var(--primary)]">
                      {formatPrice(line.item.price * line.quantity)}
                    </p>
                  </div>
                  <p className="text-xs text-[var(--muted-foreground)]">
                    {formatPrice(line.item.price)} each
                  </p>
                  <div className="mt-2 flex items-center justify-between">
                    <div className="flex h-10 items-center rounded-full border border-[var(--border)]">
                      <motion.button
                        type="button"
                        whileTap={{ scale: 0.9 }}
                        className="flex h-10 w-10 items-center justify-center"
                        onClick={() => {
                          haptics.selection();
                          decrement(line.item.id);
                        }}
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </motion.button>
                      <span className="w-5 text-center text-sm font-bold tabular-nums">
                        {line.quantity}
                      </span>
                      <motion.button
                        type="button"
                        whileTap={{ scale: 0.9 }}
                        className="flex h-10 w-10 items-center justify-center"
                        onClick={() => {
                          haptics.light();
                          increment(line.item.id);
                        }}
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </motion.button>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeItem(line.item.id)}
                      className="flex h-10 w-10 items-center justify-center rounded-full text-[var(--muted-foreground)] hover:text-red-400"
                      aria-label="Remove"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          <label className="mt-2 block">
            <span className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-[var(--muted-foreground)]">
              <SquarePen className="h-3.5 w-3.5" />
              Special instructions
            </span>
            <textarea
              value={specialInstructions}
              onChange={(e) => setSpecialInstructions(e.target.value)}
              rows={3}
              placeholder="Allergies, spice, no onion, extra cutlery…"
              className="w-full resize-none rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] px-3 py-2.5 text-sm outline-none placeholder:text-[var(--muted-foreground)] focus:border-[var(--primary)]"
            />
          </label>
        </div>
      )}
    </AppDrawer>
  );
}
