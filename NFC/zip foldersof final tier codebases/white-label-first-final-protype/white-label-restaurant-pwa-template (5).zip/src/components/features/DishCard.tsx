import { motion, AnimatePresence } from "framer-motion";
import {
  Award,
  Ban,
  Beef,
  CircleDot,
  Flame,
  Leaf,
  Minus,
  Plus,
} from "lucide-react";
import type { MenuItem } from "../../types/menu.types";
import { Badge } from "../ui/Badge";
import { getLucideIcon } from "../../utils/icons";
import { formatPrice } from "../../utils/format";
import { useCart } from "../../hooks/useCart";
import { useHaptics } from "../../hooks/useHaptics";
import { cn } from "../../utils/cn";

interface DishCardProps {
  item: MenuItem;
  index: number;
}

const dietaryMeta = {
  veg: { icon: CircleDot, tone: "veg" as const, label: "Veg" },
  nonveg: { icon: Beef, tone: "nonveg" as const, label: "Non-veg" },
  vegan: { icon: Leaf, tone: "vegan" as const, label: "Vegan" },
};

export function DishCard({ item, index }: DishCardProps) {
  const { addItem, increment, decrement, quantityOf } = useCart();
  const haptics = useHaptics();
  const qty = quantityOf(item.id);
  const Icon = getLucideIcon(item.icon);
  const diet = dietaryMeta[item.dietary];
  const soldOut = !item.isAvailable;

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        type: "spring",
        stiffness: 400,
        damping: 28,
        delay: Math.min(index, 8) * 0.03,
      }}
      className={cn(
        "relative overflow-hidden rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-elevated)] p-3.5",
        soldOut && "opacity-55",
      )}
    >
      <div className="flex gap-3">
        <div
          className={cn(
            "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl",
            "bg-[color-mix(in_oklab,var(--primary)_12%,transparent)] text-[var(--primary)]",
          )}
        >
          <Icon className="h-6 w-6" strokeWidth={1.8} />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold leading-snug tracking-tight">{item.name}</h3>
            <p className="shrink-0 font-[family-name:var(--font-display)] text-base text-[var(--primary)]">
              {formatPrice(item.price)}
            </p>
          </div>
          <p className="mt-1 line-clamp-2 text-[13px] leading-relaxed text-[var(--muted-foreground)]">
            {item.description}
          </p>

          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
            <Badge icon={diet.icon} tone={diet.tone}>
              {diet.label}
            </Badge>
            {item.isBestSeller && (
              <Badge icon={Flame} tone="accent">
                Best Seller
              </Badge>
            )}
            {item.isChefsSpecial && (
              <Badge icon={Award} tone="primary">
                Chef's
              </Badge>
            )}
            {item.spiceLevel > 0 && (
              <span className="inline-flex items-center pl-0.5">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Flame
                    key={i}
                    className={cn(
                      "h-3 w-3",
                      i < item.spiceLevel ? "fill-orange-500 text-orange-500" : "text-white/15",
                    )}
                  />
                ))}
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-end">
        {soldOut ? (
          <Badge icon={Ban} tone="danger">
            Sold Out
          </Badge>
        ) : (
          <div className="flex h-12 items-center">
            <AnimatePresence initial={false} mode="popLayout">
              {qty === 0 ? (
                <motion.button
                  key="add"
                  type="button"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  whileTap={{ scale: 0.9 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  onClick={() => {
                    haptics.light();
                    addItem(item);
                  }}
                  className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--primary)] text-[var(--primary-foreground)] shadow-[0_8px_20px_color-mix(in_oklab,var(--primary)_35%,transparent)]"
                  aria-label={`Add ${item.name}`}
                >
                  <Plus className="h-5 w-5" strokeWidth={2.4} />
                </motion.button>
              ) : (
                <motion.div
                  key="stepper"
                  layout
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex h-12 items-center gap-1 rounded-full bg-[var(--primary)] px-1 text-[var(--primary-foreground)]"
                >
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.88 }}
                    transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    onClick={() => {
                      haptics.selection();
                      decrement(item.id);
                    }}
                    className="flex h-10 w-10 items-center justify-center"
                    aria-label="Decrease"
                  >
                    <Minus className="h-4 w-4" strokeWidth={2.4} />
                  </motion.button>
                  <motion.span
                    key={qty}
                    initial={{ y: 8, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="w-5 text-center text-sm font-bold tabular-nums"
                  >
                    {qty}
                  </motion.span>
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.88 }}
                    transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    onClick={() => {
                      haptics.light();
                      increment(item.id);
                    }}
                    className="flex h-10 w-10 items-center justify-center"
                    aria-label="Increase"
                  >
                    <Plus className="h-4 w-4" strokeWidth={2.4} />
                  </motion.button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </motion.article>
  );
}
