/**
 * DIGITAL MENU
 * --------------------------------------------------------------------------
 * Categories, search, and dietary pills are driven by menuData.ts.
 * layoutId="cat-indicator" slides the shared selection highlight.
 */

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Award, Beef, CircleDot, Leaf, Search, UtensilsCrossed, X } from "lucide-react";
import { menuCategories, menuItems } from "../../config/menuData";
import { getLucideIcon } from "../../utils/icons";
import { useHaptics } from "../../hooks/useHaptics";
import type { DietaryFilter, MenuCategory } from "../../types/menu.types";
import { DishCard } from "./DishCard";
import { cn } from "../../utils/cn";

const filters: Array<{ id: DietaryFilter; label: string; icon: typeof Leaf }> = [
  { id: "all", label: "All", icon: UtensilsCrossed },
  { id: "veg", label: "Veg", icon: CircleDot },
  { id: "nonveg", label: "Non-veg", icon: Beef },
  { id: "vegan", label: "Vegan", icon: Leaf },
  { id: "special", label: "Chef's", icon: Award },
];

const ALL_CATEGORY: MenuCategory = {
  id: "all",
  label: "All",
  icon: "UtensilsCrossed",
  description: "The full room",
};

export function MenuList() {
  const [categoryId, setCategoryId] = useState("all");
  const cats = [ALL_CATEGORY, ...menuCategories];
  const [diet, setDiet] = useState<DietaryFilter>("all");
  const [query, setQuery] = useState("");
  const haptics = useHaptics();

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menuItems.filter((item) => {
      if (categoryId !== "all" && item.categoryId !== categoryId) return false;
      if (diet === "special" && !item.isChefsSpecial) return false;
      if (diet !== "all" && diet !== "special" && item.dietary !== diet) return false;
      if (q && !`${item.name} ${item.description}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [categoryId, diet, query]);

  const grouped = useMemo(() => {
    return menuCategories
      .map((cat) => ({
        cat,
        items: visible.filter((i) => i.categoryId === cat.id),
      }))
      .filter((g) => g.items.length > 0);
  }, [visible]);

  return (
    <div>
      <div
        className="sticky z-20 border-b border-[var(--border)] bg-[var(--glass-bg)] pt-1 backdrop-blur-[var(--glass-blur)]"
        style={{ top: "calc(env(safe-area-inset-top) + 3.65rem)" }}
      >
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-5 pb-3">
          {cats.map((cat) => {
            const Icon = getLucideIcon(cat.icon);
            const active = categoryId === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  haptics.selection();
                  setCategoryId(cat.id);
                }}
                className={cn(
                  "relative flex h-12 shrink-0 items-center gap-2 rounded-full px-3.5 text-sm font-medium",
                  active ? "text-[var(--primary-foreground)]" : "text-[var(--muted-foreground)]",
                )}
              >
                {active && (
                  <motion.span
                    layoutId="cat-indicator"
                    className="absolute inset-0 rounded-full bg-[var(--primary)]"
                    transition={{ type: "spring", stiffness: 400, damping: 28 }}
                  />
                )}
                <Icon className="relative h-4 w-4" strokeWidth={2.1} />
                <span className="relative">{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-5 pt-4">
        <label className="relative block">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--muted-foreground)]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search plates, pours, spices…"
            className="h-12 w-full rounded-full border border-[var(--border)] bg-[var(--surface-elevated)] pl-10 pr-10 text-sm outline-none placeholder:text-[var(--muted-foreground)] focus:border-[var(--primary)]"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-[var(--muted-foreground)]"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </label>

        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1">
          {filters.map((f) => {
            const Icon = f.icon;
            const active = diet === f.id;
            return (
              <motion.button
                key={f.id}
                type="button"
                whileTap={{ scale: 0.94 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                onClick={() => {
                  haptics.selection();
                  setDiet(f.id);
                }}
                className={cn(
                  "flex h-11 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-xs font-semibold uppercase tracking-[0.12em]",
                  active
                    ? "border-[var(--primary)] bg-[color-mix(in_oklab,var(--primary)_16%,transparent)] text-[var(--primary)]"
                    : "border-[var(--border)] text-[var(--muted-foreground)]",
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {f.label}
              </motion.button>
            );
          })}
        </div>
      </div>

      <div className="mt-4 space-y-6 px-5">
        <AnimatePresence mode="wait">
          {grouped.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-[var(--radius)] border border-dashed border-[var(--border)] px-6 py-14 text-center"
            >
              <Search className="mx-auto h-8 w-8 text-[var(--muted-foreground)]" />
              <p className="mt-3 font-medium">No matching dishes</p>
              <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                Try another category or clear filters.
              </p>
            </motion.div>
          ) : (
            grouped.map((group) => (
              <section key={group.cat.id}>
                <div className="mb-3 flex items-end justify-between">
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.2em] text-[var(--accent)]">
                      {group.cat.description}
                    </p>
                    <h2 className="font-[family-name:var(--font-display)] text-2xl leading-tight">
                      {group.cat.label}
                    </h2>
                  </div>
                  <span className="text-xs text-[var(--muted-foreground)]">
                    {group.items.length} {group.items.length === 1 ? "plate" : "plates"}
                  </span>
                </div>
                <div className="space-y-3">
                  {group.items.map((item, i) => (
                    <DishCard key={item.id} item={item} index={i} />
                  ))}
                </div>
              </section>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
