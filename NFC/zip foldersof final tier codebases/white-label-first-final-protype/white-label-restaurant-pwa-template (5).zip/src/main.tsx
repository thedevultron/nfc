import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { applyTheme } from "./config/theme.config";
import { restaurantConfig } from "./config/restaurant.config";
import { themeConfig } from "./config/theme.config";

applyTheme();

const manifest = {
  name: restaurantConfig.brand.name,
  short_name: restaurantConfig.brand.name.split(" ")[0],
  description: restaurantConfig.brand.subtitle,
  start_url: ".",
  display: "standalone",
  background_color: themeConfig.backgroundColor,
  theme_color: themeConfig.backgroundColor,
};

const blob = new Blob([JSON.stringify(manifest)], { type: "application/json" });
const manifestUrl = URL.createObjectURL(blob);
let link = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
if (!link) {
  link = document.createElement("link");
  link.rel = "manifest";
  document.head.appendChild(link);
}
link.href = manifestUrl;

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
