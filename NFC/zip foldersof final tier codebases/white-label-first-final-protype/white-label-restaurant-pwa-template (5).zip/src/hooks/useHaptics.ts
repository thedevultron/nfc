/**
 * NATIVE HAPTICS
 * --------------------------------------------------------------------------
 * Thin wrapper around navigator.vibrate. Honours features.enableHaptics
 * so a client can disable vibration globally from restaurant.config.ts.
 */

import { restaurantConfig } from "../config/restaurant.config";

type HapticKind = "light" | "medium" | "success" | "error" | "selection";

const PATTERNS: Record<HapticKind, number | number[]> = {
  light: 10,
  medium: 18,
  success: [12, 40, 18],
  error: [30, 40, 30],
  selection: 8,
};

export function useHaptics() {
  const enabled = restaurantConfig.features.enableHaptics;

  const trigger = (kind: HapticKind = "light") => {
    if (!enabled) return;
    if (typeof navigator === "undefined" || typeof navigator.vibrate !== "function") {
      return;
    }
    try {
      navigator.vibrate(PATTERNS[kind]);
    } catch {
      /* Safari desktop / unsupported */
    }
  };

  return {
    trigger,
    light: () => trigger("light"),
    medium: () => trigger("medium"),
    success: () => trigger("success"),
    error: () => trigger("error"),
    selection: () => trigger("selection"),
  };
}
