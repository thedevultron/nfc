/**
 * ============================================================================
 *  restaurant.config.ts   ──  ⚙️  CLIENT EDIT ZONE (100% DATA DRIVEN)
 * ----------------------------------------------------------------------------
 *  All business logic, feature toggles, contact details, NFC/table context,
 *  quick actions and backend webhook endpoints live here. The UI reads from
 *  these values, so changing content / enabling features requires ZERO edits
 *  to any component or layout file.
 *
 *  👉 Flip a flag in `features`       → capability instantly appears/vanishes.
 *  👉 Edit `brand`                    → re-names the whole app & contact info.
 *  👉 Paste real URLs in `n8nWebhooks` → live data flows to your automation.
 *  👉 Edit `quickActions`             → re-orders / re-labels header actions.
 * ============================================================================
 */
import type { RestaurantConfig } from "@/types/config.types";

export const restaurantConfig: RestaurantConfig = {
  /* ────────────────────────────  BRAND IDENTITY  ──────────────────────────── */
  brand: {
    name: "Aura Bistro & Lounge",
    subtitle: "Modern Culinary Experience",
    tagline: "Farm-fresh plates, craft cocktails & an atmosphere to savour.",
    // Abstract Lucide mark — no logo image asset required.
    markIcon: "UtensilsCrossed",
    googleReviewUrl: "https://maps.google.com/?cid=00000000000000000000",
    whatsappNumber: "+919876543210",
    phone: "+919876543210",
    address: "14 Lumière Avenue, Bandra West, Mumbai 400050",
    openingHours: "Mon–Sun · 11:00 AM – 1:00 AM",
    wifi: {
      ssid: "Aura_Guest_5G",
      pass: "Bistro@2026",
      security: "WPA",
      hidden: false,
    },
  },

  /* ────────────────────────────  FEATURE TOGGLES  ─────────────────────────── */
  // Toggle any of these to instantly show/hide the related feature everywhere.
  features: {
    enableBookings: true,
    enableReviews: true,
    enableWifi: true,
    enableDirectOrdering: true,
    enableWhatsapp: true,
  },

  /* ────────────────────────────  NFC / TABLE CONTEXT  ─────────────────────── */
  // Drives the dynamic "interaction mode" badge in the header. In production
  // this tableNumber is injected by the physical NFC tag at scan-time.
  context: {
    tableNumber: "04",
    modes: [
      { id: "dinein", label: "Dine-In", icon: "Utensils" },
      { id: "takeaway", label: "Takeaway", icon: "ShoppingBag" },
    ],
  },

  /* ────────────────────────────  HEADER QUICK ACTIONS  ────────────────────── */
  // Each action is purely icon-driven (Lucide) and routed to an overlay.
  // Remove an entry here and its tile vanishes from the action grid.
  quickActions: [
    { id: "wifi", label: "WiFi", icon: "Wifi", target: "wifi", featureFlag: "enableWifi" },
    { id: "whatsapp", label: "Concierge", icon: "MessageCircle", target: "whatsapp", featureFlag: "enableWhatsapp" },
    { id: "review", label: "Review", icon: "Star", target: "review", featureFlag: "enableReviews" },
    { id: "reservation", label: "Book", icon: "Calendar", target: "reservation", featureFlag: "enableBookings" },
  ],

  /* ────────────────────────────  n8n WEBHOOK ENDPOINTS  ───────────────────── */
  // Drop your live n8n webhook URLs here to wire the app to your automation.
  // Until then, api.service.ts falls back to an optimistic mock response.
  n8nWebhooks: {
    reservationUrl: "https://your-n8n-instance.com/webhook/reservation",
    feedbackUrl: "https://your-n8n-instance.com/webhook/feedback",
    orderUrl: "https://your-n8n-instance.com/webhook/order",
    reviewUrl: "https://your-n8n-instance.com/webhook/review",
  },

  /* ────────────────────────────  LOCALISATION  ────────────────────────────── */
  currency: { code: "INR", symbol: "₹", locale: "en-IN" },
  guestOptions: [1, 2, 3, 4, 5, 6, 7, 8],
  timeSlots: [
    "12:30 PM", "01:00 PM", "01:30 PM", "07:00 PM",
    "07:30 PM", "08:00 PM", "08:30 PM", "09:00 PM", "09:30 PM",
  ],
};
