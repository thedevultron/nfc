/**
 * ============================================================================
 *  menuData.ts   ──  ⚙️  CLIENT EDIT ZONE (100% DATA DRIVEN)
 * ----------------------------------------------------------------------------
 *  The entire digital menu. Edit, add or remove categories & items here and
 *  the MenuList component, search, dietary filters and cart update instantly.
 *  No component edits required.
 *
 *  Each item references a Lucide `icon` (rendered as its badge) instead of a
 *  food photograph, keeping the template 100% asset-free & brand-neutral.
 * ============================================================================
 */
import type { MenuCategory, MenuItem } from "@/types/menu.types";

export const menuCategories: MenuCategory[] = [
  { id: "signature", name: "Chef's Specials", icon: "Sparkles" },
  { id: "starters", name: "Starters", icon: "Flame" },
  { id: "mains", name: "Main Course", icon: "Beef" },
  { id: "pizza", name: "Wood-Fired", icon: "Pizza" },
  { id: "drinks", name: "Cocktails", icon: "Wine" },
  { id: "coffee", name: "Coffee & Tea", icon: "Coffee" },
  { id: "desserts", name: "Desserts", icon: "IceCream" },
];

export const menuItems: MenuItem[] = [
  // ────────────────────────────  CHEF'S SPECIALS  ────────────────────────────
  {
    id: "sig-1", name: "Truffle Mushroom Risotto", categoryId: "signature",
    description: "Arborio rice slow-cooked with wild mushrooms, black truffle & aged parmesan.",
    price: 680, icon: "Soup", spiceLevel: 0, dietary: ["veg", "chef"],
    isBestSeller: true, isAvailable: true, prepTime: 22,
  },
  {
    id: "sig-2", name: "Saffron Seafood Linguine", categoryId: "signature",
    description: "Hand-rolled linguine, tiger prawns, clams & a saffron-tomato broth.",
    price: 820, icon: "Fish", spiceLevel: 1, dietary: ["chef"],
    isAvailable: true, prepTime: 26,
  },
  {
    id: "sig-3", name: "Smoked BBQ Platter", categoryId: "signature",
    description: "Slow-smoked ribs, pulled chicken & jackfruit with house bourbon glaze.",
    price: 1190, icon: "Drumstick", spiceLevel: 2, dietary: ["nonveg", "chef"],
    isBestSeller: true, isAvailable: true, prepTime: 30,
  },

  // ────────────────────────────  STARTERS  ───────────────────────────────────
  {
    id: "st-1", name: "Crispy Cauliflower Bites", categoryId: "starters",
    description: "Tempura cauliflower, gochujang honey & toasted sesame.",
    price: 320, icon: "Salad", spiceLevel: 2, dietary: ["veg", "vegan"],
    isAvailable: true, prepTime: 14,
  },
  {
    id: "st-2", name: "Loaded Nacho Stack", categoryId: "starters",
    description: "Stone-ground corn, three-cheese melt, jalapeño & pico de gallo.",
    price: 360, icon: "Cookie", spiceLevel: 1, dietary: ["veg"],
    isBestSeller: true, isAvailable: true, prepTime: 12,
  },
  {
    id: "st-3", name: "Spiced Chicken Skewers", categoryId: "starters",
    description: "Char-grilled peri-peri chicken with smoked aioli.",
    price: 420, icon: "Drumstick", spiceLevel: 3, dietary: ["nonveg"],
    isAvailable: true, prepTime: 16,
  },
  {
    id: "st-4", name: "Burrata & Heirloom Tomato", categoryId: "starters",
    description: "Creamy burrata, basil oil & balsamic pearls.",
    price: 480, icon: "Salad", spiceLevel: 0, dietary: ["veg"],
    isAvailable: false, prepTime: 8,
  },

  // ────────────────────────────  MAIN COURSE  ────────────────────────────────
  {
    id: "mn-1", name: "Herb-Crusted Lamb Chops", categoryId: "mains",
    description: "Rosemary-rubbed lamb, buttery mash & red wine jus.",
    price: 980, icon: "Beef", spiceLevel: 1, dietary: ["nonveg", "chef"],
    isBestSeller: true, isAvailable: true, prepTime: 28,
  },
  {
    id: "mn-2", name: "Pan-Seared Atlantic Salmon", categoryId: "mains",
    description: "Crisp-skin salmon, citrus beurre blanc & asparagus.",
    price: 760, icon: "Fish", spiceLevel: 0, dietary: ["nonveg"],
    isAvailable: true, prepTime: 24,
  },
  {
    id: "mn-3", name: "Wild Mushroom Wellington", categoryId: "mains",
    description: "Flaky pastry, duxelles & truffle gravy.",
    price: 720, icon: "Soup", spiceLevel: 0, dietary: ["veg", "vegan"],
    isAvailable: true, prepTime: 32,
  },
  {
    id: "mn-4", name: "Butter Chicken Masala", categoryId: "mains",
    description: "Tandoor chicken in a rich tomato-cashew gravy.",
    price: 540, icon: "Drumstick", spiceLevel: 2, dietary: ["nonveg"],
    isBestSeller: true, isAvailable: true, prepTime: 20,
  },

  // ────────────────────────────  WOOD-FIRED  ─────────────────────────────────
  {
    id: "pz-1", name: "Margherita D.O.P", categoryId: "pizza",
    description: "San Marzano, fior di latte & fresh basil.",
    price: 460, icon: "Pizza", spiceLevel: 0, dietary: ["veg"],
    isAvailable: true, prepTime: 15,
  },
  {
    id: "pz-2", name: "Spicy Pepperoni", categoryId: "pizza",
    description: "Double pepperoni, chilli honey drizzle & mozzarella.",
    price: 540, icon: "Pizza", spiceLevel: 2, dietary: ["nonveg"],
    isBestSeller: true, isAvailable: true, prepTime: 16,
  },
  {
    id: "pz-3", name: "Garden Vegan", categoryId: "pizza",
    description: "Roasted peppers, artichoke, olives & vegan cheese.",
    price: 500, icon: "Pizza", spiceLevel: 1, dietary: ["veg", "vegan"],
    isAvailable: true, prepTime: 16,
  },

  // ────────────────────────────  COCKTAILS  ──────────────────────────────────
  {
    id: "dr-1", name: "Aura Signature Margarita", categoryId: "drinks",
    description: "Reposado tequila, blood orange & smoked salt rim.",
    price: 380, icon: "Martini", spiceLevel: 0, dietary: ["veg", "chef"],
    isBestSeller: true, isAvailable: true, prepTime: 6,
  },
  {
    id: "dr-2", name: "Cucumber Gin Fizz", categoryId: "drinks",
    description: "Botanical gin, muddled cucumber & elderflower tonic.",
    price: 360, icon: "Wine", spiceLevel: 0, dietary: ["veg"],
    isAvailable: true, prepTime: 5,
  },
  {
    id: "dr-3", name: "Tropical Sunset Mocktail", categoryId: "drinks",
    description: "Passion fruit, mango, lime & soda — zero proof.",
    price: 260, icon: "CupSoda", spiceLevel: 0, dietary: ["veg", "vegan"],
    isAvailable: true, prepTime: 4,
  },

  // ────────────────────────────  COFFEE & TEA  ───────────────────────────────
  {
    id: "cf-1", name: "Spanish Latte", categoryId: "coffee",
    description: "Double espresso, condensed milk & a velvety pour.",
    price: 220, icon: "Coffee", spiceLevel: 0, dietary: ["veg"],
    isBestSeller: true, isAvailable: true, prepTime: 4,
  },
  {
    id: "cf-2", name: "Iced Matcha Cloud", categoryId: "coffee",
    description: "Ceremonial matcha, oat milk & vanilla cold foam.",
    price: 260, icon: "CupSoda", spiceLevel: 0, dietary: ["veg", "vegan"],
    isAvailable: true, prepTime: 5,
  },
  {
    id: "cf-3", name: "Masala Cutting Chai", categoryId: "coffee",
    description: "Slow-brewed spiced milk tea with cardamom & ginger.",
    price: 120, icon: "Coffee", spiceLevel: 1, dietary: ["veg"],
    isAvailable: true, prepTime: 6,
  },

  // ────────────────────────────  DESSERTS  ───────────────────────────────────
  {
    id: "ds-1", name: "Molten Dark Chocolate", categoryId: "desserts",
    description: "Warm fondant, salted caramel & vanilla bean gelato.",
    price: 300, icon: "CakeSlice", spiceLevel: 0, dietary: ["veg", "chef"],
    isBestSeller: true, isAvailable: true, prepTime: 12,
  },
  {
    id: "ds-2", name: "Pistachio Kunafa", categoryId: "desserts",
    description: "Crisp kataifi, rose cream & crushed pistachio.",
    price: 340, icon: "Donut", spiceLevel: 0, dietary: ["veg"],
    isAvailable: true, prepTime: 10,
  },
  {
    id: "ds-3", name: "Coconut Berry Sorbet", categoryId: "desserts",
    description: "Dairy-free coconut sorbet with macerated berries.",
    price: 240, icon: "IceCream", spiceLevel: 0, dietary: ["veg", "vegan"],
    isAvailable: true, prepTime: 4,
  },
];
