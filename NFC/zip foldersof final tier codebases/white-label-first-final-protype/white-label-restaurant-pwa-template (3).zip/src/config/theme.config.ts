/**
 * ============================================================================
 *  theme.config.ts   ──  ⚙️  CLIENT EDIT ZONE (100% DATA DRIVEN)
 * ----------------------------------------------------------------------------
 *  This is the ONLY file you touch to re-brand the entire PWA's appearance.
 *  Everything below is read at runtime by `applyTheme()` (see
 *  /src/utils/applyTheme.ts) which translates these values into CSS variables
 *  consumed by every component. No component, layout or animation file needs
 *  editing to change the look.
 *
 *  👉 Change `primaryColor`  → recolours every button, badge, ring & glow.
 *  👉 Change `accentColor`   → recolours highlights, ratings & CTA accents.
 *  👉 Change `radius`        → softens or sharpens every corner app-wide.
 *  👉 Toggle `enableGlassmorphism` → solid ↔ frosted-glass surfaces.
 *  👉 Change `defaultMode`   → flips the whole app to light/dark.
 *  👉 Change fonts → set here AND add the matching <link> in index.html.
 * ============================================================================
 */
import type { ThemeConfig } from "@/types/config.types";

export const themeConfig: ThemeConfig = {
  /** Emerald — calm, premium, appetite-friendly. Try "hsl(0 84% 60%)" for red. */
  primaryColor: "hsl(142.1 76.2% 36.3%)",
  /** Warm gold used for ratings, best-sellers & chef specials. */
  accentColor: "hsl(38 92% 50%)",

  /** Global corner radius. "1rem" = soft & modern, "0.25rem" = sharp/techy. */
  radius: "0.9rem",

  /** Spacing scale. "compact" shrinks gaps for dense menus. */
  density: "comfortable",

  /** Frosted translucent surfaces (header, bottom nav, cards, sheets). */
  enableGlassmorphism: true,

  /** Default appearance. Users still get the toggle. */
  defaultMode: "dark",

  /** Body / UI font — must be loaded in index.html <head>. */
  fontFamily:
    "'Plus Jakarta Sans', ui-sans-serif, system-ui, -apple-system, sans-serif",
  /** Display font for the brand wordmark & large headings. */
  displayFontFamily: "'Playfair Display', Georgia, serif",
};
