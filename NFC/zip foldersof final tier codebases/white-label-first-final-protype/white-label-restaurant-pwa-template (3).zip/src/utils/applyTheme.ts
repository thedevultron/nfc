/**
 * ============================================================================
 *  applyTheme.ts   ──  🎨  CONFIG → CSS VARIABLE BRIDGE
 * ----------------------------------------------------------------------------
 *  The single function that turns `themeConfig` into live CSS variables on
 *  <html>. Because every component styles itself from these variables, THIS
 *  is the magic that lets editing /src/config/theme.config.ts recolour,
 *  re-radius and re-font the whole PWA with zero component edits.
 *
 *  Run once on mount (see App.tsx) and again whenever the config changes.
 * ============================================================================
 */
import { themeConfig } from "@/config/theme.config";
import type { ColorToken } from "@/types/config.types";

/* ─────────────────────────  COLOR HELPERS  ──────────────────────────
 * Minimal, dependency-free parsers so we can derive foreground/ring tokens
 * from whatever CSS color the integrator drops into the config.
 */

function parseColor(color: ColorToken): { r: number; g: number; b: number } | null {
  const c = color.trim();

  // hsl(142.1 76.2% 36.3%) or hsl(142, 76%, 36%)
  const hsl = c.match(
    /hsla?\(\s*([\d.]+)[,\s]+([\d.]+)%[,\s]+([\d.]+)%/,
  );
  if (hsl) {
    const [r, g, b] = hslToRgb(+hsl[1], +hsl[2], +hsl[3]);
    return { r, g, b };
  }

  // rgb(12 34 56) / rgb(12, 34, 56)
  const rgb = c.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/);
  if (rgb) return { r: +rgb[1], g: +rgb[2], b: +rgb[3] };

  // #rrggbb / #rgb
  const hex = c.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (hex) {
    let h = hex[1];
    if (h.length === 3) h = h.split("").map((x) => x + x).join("");
    return {
      r: parseInt(h.slice(0, 2), 16),
      g: parseInt(h.slice(2, 4), 16),
      b: parseInt(h.slice(4, 6), 16),
    };
  }
  return null;
}

function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  s /= 100;
  l /= 100;
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) =>
    l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [
    Math.round(f(0) * 255),
    Math.round(f(8) * 255),
    Math.round(f(4) * 255),
  ];
}

/** Relative luminance → black/white foreground for best contrast. */
function bestForeground(color: ColorToken): string {
  const rgb = parseColor(color);
  if (!rgb) return "#ffffff";
  const lum =
    (0.2126 * rgb.r + 0.7152 * rgb.g + 0.0722 * rgb.b) / 255;
  return lum > 0.6 ? "hsl(0 0% 8%)" : "#ffffff";
}

/** Slightly desaturated, lighter tint of a color — great for rings/glows. */
function tint(color: ColorToken, amount: number): string {
  const rgb = parseColor(color);
  if (!rgb) return color;
  const [h, s, l] = rgbToHsl(rgb.r, rgb.g, rgb.b);
  return `hsl(${h.toFixed(1)} ${Math.max(0, s - 20).toFixed(1)}% ${Math.min(
    92,
    l + amount,
  ).toFixed(1)}%)`;
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  const l = (max + min) / 2;
  const d = max - min;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  if (d !== 0) {
    switch (max) {
      case r:
        h = ((g - b) / d) % 6;
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      default:
        h = (r - g) / d + 4;
    }
    h *= 60;
    if (h < 0) h += 360;
  }
  return [h, s * 100, l * 100];
}

/* ───────────────────────────  APPLIER  ──────────────────────────── */

export function applyTheme(mode: "dark" | "light" = themeConfig.defaultMode) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;

  // Brand colors + auto-derived foreground / ring / glow.
  root.style.setProperty("--primary", themeConfig.primaryColor);
  root.style.setProperty("--primary-foreground", bestForeground(themeConfig.primaryColor));
  root.style.setProperty("--ring", tint(themeConfig.primaryColor, 8));
  root.style.setProperty("--accent", themeConfig.accentColor);
  root.style.setProperty("--accent-foreground", bestForeground(themeConfig.accentColor));
  root.style.setProperty("--glow", themeConfig.primaryColor);

  // Radii (a single value cascades to every component via calc() in CSS).
  root.style.setProperty("--radius", themeConfig.radius);

  // Density → spacing scale token consumed by layout components.
  root.style.setProperty(
    "--density",
    themeConfig.density === "compact" ? "0.5rem" : "0.75rem",
  );

  // Glassmorphism: when off, surfaces become solid + blur disabled.
  if (themeConfig.enableGlassmorphism) {
    root.style.setProperty("--glass-blur", "16px");
    root.style.setProperty(
      "--glass-bg",
      mode === "dark" ? "hsl(20 15% 9% / 0.72)" : "hsl(40 30% 100% / 0.72)",
    );
    root.style.setProperty(
      "--glass-border",
      mode === "dark"
        ? "1px solid hsl(0 0% 100% / 0.08)"
        : "1px solid hsl(0 0% 0% / 0.06)",
    );
  } else {
    root.style.setProperty("--glass-blur", "0px");
    root.style.setProperty(
      "--glass-bg",
      mode === "dark" ? "hsl(20 15% 9%)" : "hsl(40 30% 100%)",
    );
    root.style.setProperty("--glass-border", "1px solid var(--border)");
  }

  // Typography.
  root.style.setProperty("--font-sans", themeConfig.fontFamily);
  root.style.setProperty("--font-display", themeConfig.displayFontFamily);

  // Light / dark mode.
  root.classList.toggle("dark", mode === "dark");
  root.style.colorScheme = mode;
}

export type { ColorToken };
