/**
 * ============================================================================
 *  format.ts   ──  🔠  PURE PRESENTATION HELPERS
 * ----------------------------------------------------------------------------
 *  Currency rendering, deep-link builders and order summarisation. Pulls
 *  locale + currency from restaurantConfig so re-skinning for a new market is
 *  a config-only change.
 * ============================================================================
 */
import { restaurantConfig } from "@/config/restaurant.config";
import type { CartItem, OrderPayload } from "@/types/menu.types";

/** Format a number as the restaurant's currency. */
export function formatPrice(value: number): string {
  const { locale, code } = restaurantConfig.currency;
  try {
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency: code,
      maximumFractionDigits: 0,
    }).format(value);
  } catch {
    return `${restaurantConfig.currency.symbol}${value}`;
  }
}

/** Build a wa.me deep link with an optional pre-filled message. */
export function whatsappLink(message?: string): string {
  const number = restaurantConfig.brand.whatsappNumber.replace(/[^\d]/g, "");
  const base = `https://wa.me/${number}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

/** Turn the cart into a human-readable, URL-encoded order message. */
export function buildOrderMessage(
  items: CartItem[],
  subtotal: number,
  mode: string,
  note?: string,
): string {
  const lines = items.map(
    (i) =>
      `• ${i.quantity}× ${i.item.name} — ${formatPrice(i.item.price * i.quantity)}${
        i.note ? ` (_${i.note}_)` : ""
      }`,
  );
  return [
    `*New ${mode} Order*`,
    `${restaurantConfig.brand.name}`,
    "",
    ...lines,
    "",
    `*Total: ${formatPrice(subtotal)}*`,
    note ? `Note: ${note}` : "",
  ]
    .filter(Boolean)
    .join("\n");
}

/** Shape the cart into the typed order payload for api.service.ts. */
export function toOrderPayload(
  items: CartItem[],
  subtotal: number,
  mode: string,
  note: string,
): OrderPayload {
  return {
    items: items.map((i) => ({
      name: i.item.name,
      quantity: i.quantity,
      price: i.item.price,
      note: i.note,
    })),
    subtotal,
    total: subtotal,
    note,
    mode,
    source: "aura-pwa",
  };
}
