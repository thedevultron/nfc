/**
 * ============================================================================
 *  menu.types.ts
 * ----------------------------------------------------------------------------
 *  Schema for the digital menu, cart, reservations and feedback payloads.
 *  Menu data lives in `/src/config/menuData.ts` — edit there to change the
 *  entire menu without ever opening a component file.
 * ============================================================================
 */
import type { IconName } from "./config.types";

/** Dietary identifiers that drive the filter pills & badges. */
export type DietaryTag = "veg" | "nonveg" | "vegan" | "chef";

/** A single category in the menu (Starters, Drinks, Specials…). */
export interface MenuCategory {
  id: string;
  name: string;
  /** Lucide icon rendered on the sticky category bar. */
  icon: IconName;
}

/** Spice level, rendered as a repeating Flame indicator. */
export type SpiceLevel = 0 | 1 | 2 | 3;

/** A sellable dish / menu item. */
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  categoryId: string;
  /** Lucide icon used as the dish's icon badge (no food photos). */
  icon: IconName;
  spiceLevel: SpiceLevel;
  dietary: DietaryTag[];
  isBestSeller?: boolean;
  isAvailable: boolean;
  /** Prep time in minutes, shown as a subtle hint. */
  prepTime?: number;
}

/** Line item in the cart. */
export interface CartItem {
  item: MenuItem;
  quantity: number;
  note?: string;
}

/** A submitted reservation. */
export interface ReservationPayload {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  occasion?: string;
  /** Dine-in vs takeaway mode captured from the header context. */
  mode: string;
  source: string;
}

/** Submitted feedback / review. */
export interface FeedbackPayload {
  rating: number;
  name?: string;
  contact?: string;
  message: string;
  isPublicReview: boolean;
  mode: string;
  source: string;
}

/** Submitted order. */
export interface OrderPayload {
  items: Array<{
    name: string;
    quantity: number;
    price: number;
    note?: string;
  }>;
  subtotal: number;
  total: number;
  note: string;
  mode: string;
  source: string;
}
