/**
 * ============================================================================
 *  config.types.ts
 * ----------------------------------------------------------------------------
 *  The single source of truth for the SCHEMA of every editable config file.
 *
 *  NOTE FOR INTEGRATORS:
 *  These interfaces describe the *shape* of the data inside `/src/config/*`.
 *  Editing the config values never requires touching this file — it only
 *  changes if you want to fundamentally change what is configurable.
 * ============================================================================
 */

/** Lucide icon names are referenced as plain strings in config (e.g. "Flame"). */
export type IconName = string;

/** Color tokens are stored as full, valid CSS color strings (hsl/rgb/hex). */
export type ColorToken = string;

/**
 * THEME CONFIG SCHEMA
 * Controls the entire visual identity: colors, typography, corner radius,
 * density (spacing scale) and ambient effects (glassmorphism).
 */
export interface ThemeConfig {
  /** Headline brand color used for primary buttons, highlights & rings. */
  primaryColor: ColorToken;
  /** Secondary highlight color used for accents, badges & CTAs. */
  accentColor: ColorToken;
  /** Base corner radius for cards, buttons & sheets. */
  radius: string;
  /** Tighter UI for dense information layouts. */
  density: "comfortable" | "compact";
  /** Enables translucent backdrop-blur surfaces (premium feel). */
  enableGlassmorphism: boolean;
  /** Default light/dark appearance. */
  defaultMode: "dark" | "light";
  /** Google Font family stack. Loaded from the <head> in index.html. */
  fontFamily: string;
  /** Display font used for the brand wordmark & headings. */
  displayFontFamily: string;
}

/** A single quick-action shown in the header action grid. */
export interface QuickAction {
  id: string;
  label: string;
  icon: IconName;
  /** Which overlay / behaviour this action triggers. */
  target: "wifi" | "whatsapp" | "review" | "reservation" | "info";
  /** Hidden when the matching feature flag is disabled. */
  featureFlag?: keyof RestaurantFeatures;
}

/** WiFi network credentials for the guest QR modal. */
export interface WifiConfig {
  ssid: string;
  pass: string;
  /** WPA / WEP / nopass — used to build the `WIFI:` QR string. */
  security: string;
  hidden: boolean;
}

/** Feature toggles — flip these to instantly add/remove capabilities. */
export interface RestaurantFeatures {
  enableBookings: boolean;
  enableReviews: boolean;
  enableWifi: boolean;
  enableDirectOrdering: boolean;
  enableWhatsapp: boolean;
}

/** Pre-configured n8n webhook endpoints (no code edits to swap backend). */
export interface N8nWebhooks {
  reservationUrl: string;
  feedbackUrl: string;
  orderUrl: string;
  reviewUrl: string;
}

/** Brand identity block. */
export interface BrandConfig {
  name: string;
  subtitle: string;
  /** Short tagline shown in the hero. */
  tagline: string;
  /** Lucide icon used as the abstract brand mark (no logo images). */
  markIcon: IconName;
  googleReviewUrl: string;
  whatsappNumber: string;
  phone: string;
  address: string;
  openingHours: string;
  wifi: WifiConfig;
}

/** Table/NFC context that powers the dynamic interaction-mode badge. */
export interface ContextConfig {
  tableNumber: string;
  /** Switchable interaction modes surfaced in the header. */
  modes: Array<{
    id: "dinein" | "takeaway";
    label: string;
    icon: IconName;
  }>;
}

/** Currency & number formatting. */
export interface CurrencyConfig {
  code: string;
  symbol: string;
  locale: string;
}

/**
 * RESTAURANT CONFIG SCHEMA
 * Business details, feature toggles, NFC context, quick actions & links.
 */
export interface RestaurantConfig {
  brand: BrandConfig;
  features: RestaurantFeatures;
  context: ContextConfig;
  quickActions: QuickAction[];
  n8nWebhooks: N8nWebhooks;
  currency: CurrencyConfig;
  /** Guest count options for the reservation sheet. */
  guestOptions: number[];
  /** Available reservation time slots. */
  timeSlots: string[];
}
