/**
 * ============================================================================
 *  Pressable   ──  SPRING-PHYSICS TAP TARGET + HAPTICS
 * ----------------------------------------------------------------------------
 *  Replaces a plain <button> whenever you want the spec'd micro-interaction:
 *  `type:"spring", stiffness:400, damping:25` with a subtle scale-down on tap,
 *  plus a native vibration. Minimum 48×48 touch target by default.
 * ============================================================================
 */
import * as React from "react";
import { motion, type HTMLMotionProps } from "framer-motion";
import { useHaptics, type HapticPattern } from "@/hooks/useHaptics";
import { cn } from "@/utils/cn";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 25 };

export interface PressableProps
  extends Omit<HTMLMotionProps<"button">, "ref"> {
  /** Haptic fired on tap. Pass null/undefined to disable. */
  haptic?: HapticPattern | null;
  /** Ensure the 48×48 minimum touch target even for small icons. */
  ensureTarget?: boolean;
}

export const Pressable = React.forwardRef<HTMLButtonElement, PressableProps>(
  (
    { className, children, haptic = "tap", ensureTarget = true, onTap, ...props },
    ref,
  ) => {
    const { trigger } = useHaptics();

    return (
      <motion.button
        ref={ref}
        whileTap={{ scale: 0.94 }}
        whileHover={{ scale: 1.02 }}
        transition={SPRING}
        onTap={(e, info) => {
          if (haptic) trigger(haptic);
          onTap?.(e, info);
        }}
        className={cn(
          "inline-flex select-none items-center justify-center outline-none focus-visible:ring-2 focus-visible:ring-ring",
          ensureTarget && "min-h-12 min-w-12",
          className,
        )}
        {...props}
      >
        {children}
      </motion.button>
    );
  },
);
Pressable.displayName = "Pressable";
