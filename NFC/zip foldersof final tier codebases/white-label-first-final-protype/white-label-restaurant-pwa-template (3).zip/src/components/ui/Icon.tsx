/**
 * ============================================================================
 *  Icon   ──  🧩  LUCIDE ICON REGISTRY (CONFIG-DRIVEN)
 * ----------------------------------------------------------------------------
 *  Config files reference icons by string name (e.g. icon: "Flame"). This maps
 *  those names to real Lucide components. To make more icons available to the
 *  config layer, just add them to the registry below — keeping the bundle lean
 *  (we never import the entire icon library).
 * ============================================================================
 */
import {
  Apple, ArrowRight, Award, Ban, Beef, Calendar, CalendarDays, CakeSlice,
  Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, CircleDot,
  Clock, Coffee, Copy, Cookie, CupSoda, Donut, Download, Drumstick,
  ExternalLink, Fish, Flame, Heart, Info, IceCream, Leaf, Loader2, MapPin,
  Martini, MessageCircle, Minus, Phone, Pizza, Plus, QrCode, Quote, Salad,
  Search, Send, Share, ShoppingBag, Soup, Sparkles, SquarePen, Star,
  Trash2, Utensils, UtensilsCrossed, Users, Wine, X,
  type LucideProps,
} from "lucide-react";
import type { ComponentType } from "react";

const REGISTRY = {
  Apple, ArrowRight, Award, Ban, Beef, Calendar, CalendarDays, CakeSlice,
  Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, CircleDot,
  Clock, Coffee, Copy, Cookie, CupSoda, Donut, Download, Drumstick,
  ExternalLink, Fish, Flame, Heart, Info, IceCream, Leaf, Loader2, MapPin,
  Martini, MessageCircle, Minus, Phone, Pizza, Plus, QrCode, Quote, Salad,
  Search, Send, Share, ShoppingBag, Soup, Sparkles, SquarePen, Star,
  Trash2, Utensils, UtensilsCrossed, Users, Wine, X,
} satisfies Record<string, ComponentType<LucideProps>>;

export type RegisteredIcon = keyof typeof REGISTRY;

export interface IconProps extends LucideProps {
  name: string;
}

export function Icon({ name, ...props }: IconProps) {
  const Cmp = (REGISTRY as Record<string, ComponentType<LucideProps>>)[name];
  if (!Cmp) return null;
  return <Cmp {...props} />;
}

export default Icon;
