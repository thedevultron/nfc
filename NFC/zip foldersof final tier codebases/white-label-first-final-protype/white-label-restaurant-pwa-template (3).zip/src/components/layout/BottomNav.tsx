/**
 * BottomNav — fixed glass tab bar. The active tab is marked with a shared-
 * element indicator (layoutId="tab-pill") that springs across options. The
 * centre slot holds an elevated cart button with a live quantity badge.
 */
import { motion } from "framer-motion";
import { Calendar, Info, ShoppingBag, Star, Utensils } from "lucide-react";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { Pressable } from "@/components/ui/Pressable";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 30 };

interface NavTabDef {
  id: string;
  label: string;
  icon: typeof Utensils;
}

const TABS: NavTabDef[] = [
  { id: "menu", label: "Menu", icon: Utensils },
  { id: "reserve", label: "Book", icon: Calendar },
  { id: "review", label: "Review", icon: Star },
  { id: "info", label: "Info", icon: Info },
];

export function BottomNav({
  activeView,
  onMenu,
  onReserve,
  onReview,
  onInfo,
}: {
  activeView: string;
  onMenu: () => void;
  onReserve: () => void;
  onReview: () => void;
  onInfo: () => void;
}) {
  const { count, openDrawer } = useCart();
  const { trigger } = useHaptics();

  const handlers: Record<string, () => void> = {
    menu: () => {
      trigger("tap");
      onMenu();
    },
    reserve: () => {
      trigger("tap");
      onReserve();
    },
    review: () => {
      trigger("tap");
      onReview();
    },
    info: () => {
      trigger("tap");
      onInfo();
    },
  };

  return (
    <nav className="fixed bottom-0 left-1/2 z-40 w-full max-w-[480px] -translate-x-1/2">
      <div className="glass pb-safe">
        <div className="relative grid grid-cols-5 items-center px-2 pt-1.5">
          {/* left two tabs */}
          <NavTab tab={TABS[0]} active={activeView === "menu"} onClick={handlers.menu} />
          <NavTab tab={TABS[1]} active={activeView === "reserve"} onClick={handlers.reserve} />

          {/* centre elevated cart */}
          <div className="flex justify-center">
            <Pressable
              haptic="select"
              ensureTarget={false}
              onClick={() => {
                trigger("open");
                openDrawer();
              }}
              className="-mt-7 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-xl shadow-primary/40 ring-4 ring-background"
              aria-label={`Open cart, ${count} items`}
            >
              <motion.span
                key={count}
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 500, damping: 18 }}
                className="relative"
              >
                <ShoppingBag className="h-6 w-6" />
                {count > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={SPRING}
                    className="absolute -right-3 -top-3 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[11px] font-bold text-accent-foreground ring-2 ring-background"
                  >
                    {count}
                  </motion.span>
                )}
              </motion.span>
            </Pressable>
          </div>

          {/* right two tabs */}
          <NavTab tab={TABS[2]} active={activeView === "review"} onClick={handlers.review} />
          <NavTab tab={TABS[3]} active={activeView === "info"} onClick={handlers.info} />
        </div>
      </div>
    </nav>
  );
}

function NavTab({
  tab,
  active,
  onClick,
}: {
  tab: NavTabDef;
  active: boolean;
  onClick: () => void;
}) {
  const Icon = tab.icon;
  return (
    <Pressable
      ensureTarget={false}
      onClick={onClick}
      className="relative flex flex-col items-center gap-1 py-2"
    >
      {active && (
        <motion.div
          layoutId="tab-pill"
          transition={SPRING}
          className="absolute top-0 h-1 w-8 rounded-full bg-primary"
        />
      )}
      <span className="relative flex h-9 w-9 items-center justify-center">
        <motion.span
          animate={{ scale: active ? 1.08 : 1, y: active ? -1 : 0 }}
          transition={SPRING}
          className={active ? "text-primary" : "text-muted-foreground"}
        >
          <Icon className="h-[22px] w-[22px]" strokeWidth={active ? 2.5 : 2} />
        </motion.span>
      </span>
      <span
        className={`text-[10px] font-semibold ${
          active ? "text-primary" : "text-muted-foreground"
        }`}
      >
        {tab.label}
      </span>
    </Pressable>
  );
}
