/**
 * ============================================================================
 *  Header   ──  MODULE A · DYNAMIC ACTION HEADER
 * ----------------------------------------------------------------------------
 *  1) NFC Touchpoint Context — a live badge reflecting the current interaction
 *     mode (Dine-In @ Table 04 vs Takeaway), with a shared-element (layoutId)
 *     toggle. In production `tableNumber` is injected by the physical NFC tag.
 *  2) Quick Action Grid — purely Lucide-icon tiles (WiFi, Concierge, Review,
 *     Book) rendered straight from restaurant.config → quickActions. Adding or
 *     removing an entry there instantly changes this grid. No code edits.
 * ============================================================================
 */
import { AnimatePresence, motion } from "framer-motion";
import { restaurantConfig } from "@/config/restaurant.config";
import { useHaptics } from "@/hooks/useHaptics";
import { Icon } from "@/components/ui/Icon";
import { Pressable } from "@/components/ui/Pressable";
import type { QuickAction } from "@/types/config.types";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 30 };

export function Header({
  mode,
  onModeChange,
  onAction,
}: {
  mode: string;
  onModeChange: (modeId: string) => void;
  onAction: (target: QuickAction["target"]) => void;
}) {
  const { trigger } = useHaptics();
  const { context, features, quickActions } = restaurantConfig;

  // Only render actions whose feature flag is enabled (config-driven).
  const visibleActions = quickActions.filter(
    (a) => !a.featureFlag || features[a.featureFlag],
  );

  const activeMode =
    context.modes.find((m) => m.id === mode) ?? context.modes[0];

  return (
    <section className="px-4">
      {/* ─────────────  NFC TOUCHPOINT CONTEXT BADGE  ───────────── */}
      <div className="relative overflow-hidden rounded-3xl border border-primary/25 bg-gradient-to-br from-primary/15 via-card to-card p-4 shadow-lg shadow-primary/5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" />
            </span>
            <div className="leading-tight">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-primary">
                Tap Mode Active
              </p>
              <p className="text-sm font-medium text-foreground/90">
                {activeMode.id === "dinein"
                  ? `Table ${context.tableNumber} · ${activeMode.label}`
                  : activeMode.label}
              </p>
            </div>
          </div>
        </div>

        {/* Mode switcher — shared-element highlight (layoutId) */}
        <div className="mt-3 grid grid-cols-2 gap-1 rounded-full bg-background/60 p-1">
          {context.modes.map((m) => {
            const selected = m.id === activeMode.id;
            return (
              <Pressable
                key={m.id}
                haptic="tap"
                ensureTarget={false}
                onClick={() => onModeChange(m.id)}
                className="relative flex items-center justify-center gap-1.5 rounded-full px-3 py-2 text-sm font-semibold"
              >
                {selected && (
                  <motion.div
                    layoutId="mode-pill"
                    transition={SPRING}
                    className="absolute inset-0 rounded-full bg-primary text-primary-foreground shadow-md shadow-primary/30"
                  />
                )}
                <span
                  className={`relative z-10 flex items-center gap-1.5 ${
                    selected ? "text-primary-foreground" : "text-muted-foreground"
                  }`}
                >
                  <Icon name={m.icon} className="h-4 w-4" />
                  {m.label}
                </span>
              </Pressable>
            );
          })}
        </div>
      </div>

      {/* ─────────────  QUICK ACTION GRID  ───────────── */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        {visibleActions.map((action, i) => (
          <motion.div
            key={action.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i, type: "spring", stiffness: 300, damping: 24 }}
          >
            <Pressable
              haptic="select"
              ensureTarget={false}
              onClick={() => {
                trigger("tap");
                onAction(action.target);
              }}
              className="glass flex w-full items-center gap-3 rounded-2xl p-3.5 text-left"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
                <Icon name={action.icon} className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-semibold leading-tight">
                  {action.label === "Concierge" ? "WhatsApp" : action.label}
                </span>
                <span className="block truncate text-[11px] text-muted-foreground">
                  {action.label === "WiFi"
                    ? "Connect instantly"
                    : action.label === "Concierge"
                      ? "Chat & order"
                      : action.label === "Review"
                        ? "Rate your visit"
                        : "Reserve a table"}
                </span>
              </span>
            </Pressable>
          </motion.div>
        ))}
      </div>

      {/* tagline strip */}
      <AnimatePresence>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-4 px-1 text-center text-[13px] leading-relaxed text-muted-foreground text-balance"
        >
          {restaurantConfig.brand.tagline}
        </motion.p>
      </AnimatePresence>
    </section>
  );
}
