/**
 * AppShell — the device-like container. Width-caps the app to a phone column,
 * renders the ambient brand-glow background, and provides the scroll surface
 * with safe-area padding so fixed bars (TopBar / BottomNav) never overlap
 * content. Pure layout — reads nothing from config directly.
 */
import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

export function AppShell({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className="app-ambient relative flex min-h-screen w-full justify-center bg-background">
      <div
        className={cn(
          "relative flex min-h-screen w-full max-w-[480px] flex-col",
          className,
        )}
      >
        {children}
      </div>
    </div>
  );
}
