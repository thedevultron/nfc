/**
 * TopBar — sticky glass status strip. Brand mark + name on the left; theme
 * toggle and the native PWA "Add to Home Screen" affordance on the right.
 */
import { motion } from "framer-motion";
import { Download, Moon, Share, Sun } from "lucide-react";
import { restaurantConfig } from "@/config/restaurant.config";
import { usePWAInstall } from "@/hooks/usePWAInstall";
import { useHaptics } from "@/hooks/useHaptics";
import { Icon } from "@/components/ui/Icon";
import { Pressable } from "@/components/ui/Pressable";

export function TopBar({
  isDark,
  onToggleTheme,
}: {
  isDark: boolean;
  onToggleTheme: () => void;
}) {
  const { canInstall, isiOS, promptInstall } = usePWAInstall();
  const { trigger } = useHaptics();
  const { brand } = restaurantConfig;

  return (
    <header className="fixed left-1/2 top-0 z-40 w-full max-w-[480px] -translate-x-1/2">
      <div className="glass pt-safe">
        <div className="flex items-center justify-between gap-2 px-4 py-2.5">
          {/* Brand mark — abstract Lucide glyph, never a logo image */}
          <div className="flex min-w-0 items-center gap-2.5">
            <motion.div
              initial={{ rotate: -8, scale: 0.8, opacity: 0 }}
              animate={{ rotate: 0, scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 300, damping: 18 }}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground shadow-lg shadow-primary/30"
            >
              <Icon name={brand.markIcon} className="h-5 w-5" />
            </motion.div>
            <div className="min-w-0 leading-tight">
              <p className="truncate font-display text-[15px] font-bold tracking-tight">
                {brand.name}
              </p>
              <p className="truncate text-[11px] text-muted-foreground">
                {brand.subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {canInstall && (
              <Pressable
                haptic="tap"
                ensureTarget={false}
                onClick={() => {
                  trigger("select");
                  if (isiOS) navigator.share?.({ title: brand.name }) ?? void 0;
                  else void promptInstall();
                }}
                className="gap-1.5 rounded-full bg-secondary/70 px-3 py-2 text-xs font-semibold text-secondary-foreground"
                aria-label="Install app"
              >
                {isiOS ? <Share className="h-4 w-4" /> : <Download className="h-4 w-4" />}
                <span>Install</span>
              </Pressable>
            )}

            <Pressable
              haptic="tap"
              ensureTarget={false}
              onClick={onToggleTheme}
              aria-label="Toggle theme"
              className="rounded-full bg-secondary/70 p-2 text-secondary-foreground"
            >
              <motion.span
                key={isDark ? "moon" : "sun"}
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="block"
              >
                {isDark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </motion.span>
            </Pressable>
          </div>
        </div>
      </div>
    </header>
  );
}
