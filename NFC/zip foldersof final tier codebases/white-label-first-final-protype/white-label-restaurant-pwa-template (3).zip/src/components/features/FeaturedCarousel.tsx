/**
 * FeaturedCarousel — horizontally-scrolling hero of "Chef's Special" items.
 * Purely icon-driven gradient cards with a one-tap add. Pulls chef-tagged
 * dishes from menuData.ts; no assets required.
 */
import { motion } from "framer-motion";
import { Plus, Star } from "lucide-react";
import { menuItems } from "@/config/menuData";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { Icon } from "@/components/ui/Icon";
import { Pressable } from "@/components/ui/Pressable";
import { formatPrice } from "@/utils/format";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 25 };

export function FeaturedCarousel() {
  const { addItem } = useCart();
  const { trigger } = useHaptics();
  const featured = menuItems.filter(
    (i) => i.dietary.includes("chef") && i.isAvailable,
  );

  if (featured.length === 0) return null;

  return (
    <section className="pl-4">
      <div className="mb-2.5 flex items-center gap-2 px-1">
        <Icon name="Sparkles" className="h-4 w-4 text-accent" />
        <h2 className="font-display text-lg font-bold tracking-tight">Featured Today</h2>
      </div>

      <div className="no-scrollbar flex snap-x snap-mandatory gap-3 overflow-x-auto pr-4 pb-1">
        {featured.map((item, i) => (
          <motion.article
            key={item.id}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.06, type: "spring", stiffness: 260, damping: 24 }}
            className="relative flex w-[230px] shrink-0 snap-start flex-col overflow-hidden rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/20 via-card to-card p-4"
          >
            <span className="absolute right-3 top-3 flex items-center gap-0.5 rounded-full bg-accent/90 px-2 py-0.5 text-[10px] font-bold text-accent-foreground">
              <Star className="h-2.5 w-2.5 fill-accent-foreground" />
              Chef's
            </span>

            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/15 text-primary">
              <Icon name={item.icon} className="h-8 w-8" />
            </div>

            <h3 className="font-display text-base font-bold leading-tight">{item.name}</h3>
            <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
              {item.description}
            </p>

            <div className="mt-3 flex items-center justify-between">
              <span className="font-display text-lg font-bold text-primary">
                {formatPrice(item.price)}
              </span>
              <Pressable
                haptic="select"
                ensureTarget={false}
                onClick={() => {
                  trigger("select");
                  addItem(item);
                }}
                className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30"
                aria-label={`Add ${item.name}`}
              >
                <motion.span whileTap={{ scale: 0.85 }} transition={SPRING}>
                  <Plus className="h-5 w-5" strokeWidth={2.5} />
                </motion.span>
              </Pressable>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
