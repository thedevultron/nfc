/**
 * ============================================================================
 *  ReservationSheet   ──  MODULE E · TABLE RESERVATION
 * ----------------------------------------------------------------------------
 *  Vaul bottom-sheet with a horizontal date picker, time-slot chips, guest
 *  stepper (Users icon) and contact fields. Submit dispatches the payload via
 *  api.service.ts → n8n and shows an optimistic success state with a booking
 *  reference. All slots / guest options come from restaurant.config.ts.
 * ============================================================================
 */
import { useMemo, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CalendarDays, CheckCircle2, Loader2, Minus, Plus, Users } from "lucide-react";
import { toast } from "sonner";
import { restaurantConfig } from "@/config/restaurant.config";
import { useHaptics } from "@/hooks/useHaptics";
import { apiService } from "@/services/api.service";
import {
  DrawerRoot,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerFooter,
} from "@/components/ui/drawer";
import { Input } from "@/components/ui/input";
import { Pressable } from "@/components/ui/Pressable";
import type { ReservationPayload } from "@/types/menu.types";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 25 };

function buildDays(count: number) {
  const fmt = new Intl.DateTimeFormat("en-US", {
    weekday: "short",
    day: "numeric",
  });
  const today = new Date();
  return Array.from({ length: count }).map((_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    return {
      key: d.toISOString().slice(0, 10),
      weekday: d.toLocaleDateString("en-US", { weekday: "short" }),
      day: d.getDate(),
      label: i === 0 ? "Today" : i === 1 ? "Tomorrow" : fmt.format(d),
    };
  });
}

export function ReservationSheet({
  open,
  onOpenChange,
  mode,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: string;
}) {
  const { trigger } = useHaptics();
  const days = useMemo(() => buildDays(10), []);
  const { guestOptions, timeSlots } = restaurantConfig;

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState(days[0].key);
  const [time, setTime] = useState(timeSlots[5]);
  const [guests, setGuests] = useState(2);
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");
  const [reference, setReference] = useState("");

  const valid = name.trim() && phone.trim() && date && time;

  function reset() {
    setName("");
    setPhone("");
    setDate(days[0].key);
    setTime(timeSlots[5]);
    setGuests(2);
    setStatus("idle");
  }

  async function submit() {
    if (!valid || status === "loading") return;
    trigger("success");
    setStatus("loading");
    const payload: ReservationPayload = {
      name,
      phone,
      date,
      time,
      guests,
      mode,
      source: "aura-pwa",
    };
    const res = await apiService.sendReservation(payload);
    setReference(res.data?.reference ?? "");
    setStatus("done");
    toast.success(res.message);
  }

  function handleClose(o: boolean) {
    onOpenChange(o);
    if (!o && status === "done") {
      // reset after the closing animation
      setTimeout(reset, 250);
    }
  }

  return (
    <DrawerRoot open={open} onOpenChange={handleClose}>
      <DrawerContent className="max-h-[92vh]">
        <DrawerHeader>
          <div className="flex items-center gap-2 text-primary">
            <CalendarDays className="h-5 w-5" />
            <DrawerTitle>Reserve a Table</DrawerTitle>
          </div>
        </DrawerHeader>

        <AnimatePresence mode="wait">
          {status === "done" ? (
            <SuccessView key="success" reference={reference} onClose={() => handleClose(false)} />
          ) : (
            <motion.div
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="no-scrollbar flex-1 space-y-5 overflow-y-auto px-5 pb-2"
            >
              {/* contact */}
              <div className="grid gap-3">
                <Input placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
                <Input
                  placeholder="Phone number"
                  inputMode="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>

              {/* date picker */}
              <Field label="Date">
                <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1">
                  {days.map((d) => {
                    const selected = d.key === date;
                    return (
                      <button
                        key={d.key}
                        onClick={() => {
                          trigger("tap");
                          setDate(d.key);
                        }}
                        className={`flex w-16 shrink-0 flex-col items-center gap-0.5 rounded-2xl border py-2.5 transition-colors ${
                          selected
                            ? "border-primary bg-primary text-primary-foreground shadow-md shadow-primary/25"
                            : "border-border bg-card text-muted-foreground"
                        }`}
                      >
                        <span className="text-[10px] font-semibold uppercase">
                          {d.weekday}
                        </span>
                        <span className="font-display text-lg font-bold leading-none">
                          {d.day}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </Field>

              {/* time slots */}
              <Field label="Time">
                <div className="flex flex-wrap gap-2">
                  {timeSlots.map((t) => {
                    const selected = t === time;
                    return (
                      <button
                        key={t}
                        onClick={() => {
                          trigger("tap");
                          setTime(t);
                        }}
                        className={`rounded-full border px-3.5 py-2 text-sm font-semibold transition-colors ${
                          selected
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border bg-card text-muted-foreground"
                        }`}
                      >
                        {t}
                      </button>
                    );
                  })}
                </div>
              </Field>

              {/* guests */}
              <Field label="Guests">
                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-muted-foreground" />
                  <div className="flex items-center gap-1 rounded-full bg-secondary/70 p-1">
                    <Pressable
                      haptic="tap"
                      ensureTarget={false}
                      onClick={() => setGuests((g) => Math.max(1, g - 1))}
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-background"
                    >
                      <Minus className="h-4 w-4" strokeWidth={2.5} />
                    </Pressable>
                    <span className="min-w-8 text-center font-bold tabular-nums">{guests}</span>
                    <Pressable
                      haptic="tap"
                      ensureTarget={false}
                      onClick={() =>
                        setGuests((g) => Math.min(guestOptions[guestOptions.length - 1] ?? 12, g + 1))
                      }
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground"
                    >
                      <Plus className="h-4 w-4" strokeWidth={2.5} />
                    </Pressable>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {guests > 1 ? "people" : "person"}
                  </span>
                </div>
              </Field>
            </motion.div>
          )}
        </AnimatePresence>

        {status !== "done" && (
          <DrawerFooter className="border-t border-border bg-card/60">
            <Pressable
              haptic="select"
              onClick={submit}
              disabled={!valid || status === "loading"}
              className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary text-base font-bold text-primary-foreground shadow-lg shadow-primary/30 disabled:opacity-50"
            >
              {status === "loading" ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Confirming…
                </>
              ) : (
                <>
                  <CalendarDays className="h-5 w-5" />
                  Confirm Reservation
                </>
              )}
            </Pressable>
          </DrawerFooter>
        )}
      </DrawerContent>
    </DrawerRoot>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-2">
      <p className="px-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      {children}
    </div>
  );
}

function SuccessView({ reference, onClose }: { reference: string; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={SPRING}
      className="flex flex-col items-center gap-3 px-6 py-10 text-center"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 14 }}
        className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/15 text-primary"
      >
        <CheckCircle2 className="h-11 w-11" />
      </motion.div>
      <div>
        <p className="font-display text-xl font-bold">Reservation Confirmed!</p>
        <p className="text-sm text-muted-foreground">
          We can't wait to host you. A confirmation has been sent.
        </p>
      </div>
      {reference && (
        <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-muted-foreground">
          Ref: {reference}
        </span>
      )}
      <Pressable
        haptic="tap"
        onClick={onClose}
        className="mt-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground"
      >
        Done
      </Pressable>
    </motion.div>
  );
}
