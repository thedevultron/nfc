/**
 * ============================================================================
 *  CartSheet   ──  MODULE C · DYNAMIC CART SHEET
 * ----------------------------------------------------------------------------
 *  Vaul bottom-sheet (drag-to-dismiss). Line items with steppers, special
 *  instructions, live totals, and an order CTA that builds an order payload,
 *  dispatches it via api.service.ts (n8n) and — for takeaway — opens a
 *  pre-filled WhatsApp deep link. Empty + success states included.
 * ============================================================================
 */
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Minus, Plus, ShoppingBag, SquarePen, Trash2, Utensils } from "lucide-react";
import { toast } from "sonner";
import { restaurantConfig } from "@/config/restaurant.config";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { apiService } from "@/services/api.service";
import {
  DrawerRoot,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerFooter,
} from "@/components/ui/drawer";
import { Icon } from "@/components/ui/Icon";
import { Textarea } from "@/components/ui/textarea";
import { Pressable } from "@/components/ui/Pressable";
import { formatPrice, buildOrderMessage, toOrderPayload, whatsappLink } from "@/utils/format";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 25 };

export function CartSheet({ mode }: { mode: string }) {
  const { items, subtotal, count, increment, decrement, clear, isEmpty, isDrawerOpen, openDrawer, closeDrawer } =
    useCart();
  const { trigger } = useHaptics();
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const isTakeaway = mode === "takeaway";

  async function placeOrder() {
    if (isEmpty || submitting) return;
    trigger("success");
    setSubmitting(true);
    const payload = toOrderPayload(items, subtotal, mode, note);

    if (isTakeaway && restaurantConfig.features.enableWhatsapp) {
      window.open(whatsappLink(buildOrderMessage(items, subtotal, mode, note)), "_blank");
    }
    const result = await apiService.sendOrder(payload);
    toast.success(result.message, { description: result.mocked ? "Demo mode" : undefined });
    setSubmitting(false);
    setNote("");
    clear();
    closeDrawer();
  }

  return (
    <DrawerRoot
      open={isDrawerOpen}
      onOpenChange={(o) => (o ? openDrawer() : closeDrawer())}
    >
      <DrawerContent className="max-h-[90vh]">
        <DrawerHeader>
          <div className="flex items-center gap-2 text-primary">
            <ShoppingBag className="h-5 w-5" />
            <DrawerTitle>Your Order</DrawerTitle>
          </div>
          {!isEmpty && (
            <Pressable
              haptic="warn"
              ensureTarget={false}
              onClick={() => {
                trigger("warn");
                clear();
              }}
              className="flex items-center gap-1 rounded-full bg-destructive/10 px-3 py-1.5 text-xs font-semibold text-destructive"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Clear
            </Pressable>
          )}
        </DrawerHeader>

        {isEmpty ? (
          <EmptyCart onClose={closeDrawer} />
        ) : (
          <>
            {/* scrollable item list */}
            <div className="no-scrollbar flex-1 space-y-2 overflow-y-auto px-5 py-3">
              <AnimatePresence initial={false}>
                {items.map((line) => (
                  <motion.div
                    key={line.item.id}
                    layout
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, x: -40 }}
                    transition={SPRING}
                    className="flex items-center gap-3 rounded-2xl border border-border bg-background/50 p-2.5"
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-secondary text-foreground/70">
                      <Icon name={line.item.icon} className="h-6 w-6" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{line.item.name}</p>
                      <p className="text-xs text-primary">{formatPrice(line.item.price)}</p>
                    </div>
                    <div className="flex items-center gap-1 rounded-full bg-secondary/70 p-1">
                      <Pressable
                        haptic="tap"
                        ensureTarget={false}
                        onClick={() => decrement(line.item.id)}
                        className="flex h-8 w-8 items-center justify-center rounded-full bg-background text-foreground"
                      >
                        <Minus className="h-4 w-4" strokeWidth={2.5} />
                      </Pressable>
                      <motion.span
                        key={line.quantity}
                        initial={{ scale: 0.6 }}
                        animate={{ scale: 1 }}
                        transition={SPRING}
                        className="min-w-5 text-center text-sm font-bold tabular-nums"
                      >
                        {line.quantity}
                      </motion.span>
                      <Pressable
                        haptic="tap"
                        ensureTarget={false}
                        onClick={() => increment(line.item.id)}
                        className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground"
                      >
                        <Plus className="h-4 w-4" strokeWidth={2.5} />
                      </Pressable>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* special instructions */}
              <div className="relative pt-2">
                <SquarePen className="pointer-events-none absolute left-3 top-[22px] h-4 w-4 text-muted-foreground" />
                <Textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Special instructions (no onion, extra spicy…)"
                  className="min-h-[72px] pl-10"
                />
              </div>
            </div>

            {/* footer: totals + CTA */}
            <DrawerFooter className="border-t border-border bg-card/60">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {count} item{count > 1 ? "s" : ""}
                </span>
                <div className="text-right">
                  <span className="block text-xs text-muted-foreground">Total</span>
                  <span className="font-display text-2xl font-bold text-primary">
                    {formatPrice(subtotal)}
                  </span>
                </div>
              </div>
              <Pressable
                haptic="select"
                onClick={placeOrder}
                disabled={submitting}
                className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary text-base font-bold text-primary-foreground shadow-lg shadow-primary/30 disabled:opacity-70"
              >
                <Utensils className="h-5 w-5" />
                {submitting
                  ? "Sending…"
                  : isTakeaway
                    ? "Place Order via WhatsApp"
                    : "Send Order to Kitchen"}
              </Pressable>
            </DrawerFooter>
          </>
        )}
      </DrawerContent>
    </DrawerRoot>
  );
}

function EmptyCart({ onClose }: { onClose: () => void }) {
  return (
    <div className="flex flex-col items-center gap-4 px-6 py-12 text-center">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 18 }}
        className="flex h-20 w-20 items-center justify-center rounded-full bg-secondary text-muted-foreground"
      >
        <ShoppingBag className="h-9 w-9" />
      </motion.div>
      <div>
        <p className="font-display text-lg font-bold">Your cart is empty</p>
        <p className="text-sm text-muted-foreground">
          Add a few delicious dishes to get started.
        </p>
      </div>
      <Pressable
        haptic="tap"
        onClick={onClose}
        className="rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground"
      >
        Browse Menu
      </Pressable>
    </div>
  );
}
