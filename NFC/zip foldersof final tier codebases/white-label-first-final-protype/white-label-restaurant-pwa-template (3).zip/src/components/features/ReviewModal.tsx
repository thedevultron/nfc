/**
 * ============================================================================
 *  ReviewModal   ──  MODULE D · SMART REVIEW & FEEDBACK FILTER
 * ----------------------------------------------------------------------------
 *  Interactive 5-star rating (Lucide Star). Logic split:
 *    • 4–5 ★ → unlocks a high-visibility "Post Public Review on Google"
 *      button (ExternalLink) → configured Google Maps URL.
 *    • < 4 ★ → pivots to a PRIVATE feedback form routed straight to
 *      management via api.service.ts, preventing public negative reviews.
 * ============================================================================
 */
import { useState } from "react";
import { motion } from "framer-motion";
import { ExternalLink, Heart, Send, Star } from "lucide-react";
import { toast } from "sonner";
import { restaurantConfig } from "@/config/restaurant.config";
import { useHaptics } from "@/hooks/useHaptics";
import { apiService } from "@/services/api.service";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Pressable } from "@/components/ui/Pressable";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 25 };

type Step = "rate" | "low" | "thanks";

export function ReviewModal({
  open,
  onOpenChange,
  mode,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: string;
}) {
  const { trigger } = useHaptics();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [step, setStep] = useState<Step>("rate");
  const [message, setMessage] = useState("");
  const [contact, setContact] = useState("");
  const [sending, setSending] = useState(false);

  function reset() {
    setRating(0);
    setHover(0);
    setStep("rate");
    setMessage("");
    setContact("");
  }

  function handleRate(value: number) {
    trigger("select");
    setRating(value);
    // Route high vs low ratings to the correct flow.
    setTimeout(() => setStep(value >= 4 ? "rate" : "low"), 150);
  }

  async function sendPrivate() {
    if (sending) return;
    setSending(true);
    const res = await apiService.sendFeedback({
      rating,
      message,
      contact,
      isPublicReview: false,
      mode,
      source: "aura-pwa",
    });
    setSending(false);
    toast.success(res.message);
    setStep("thanks");
  }

  async function goToGoogle() {
    trigger("success");
    // Log the high-rating intent (optional analytics) before redirecting.
    apiService.sendReview({
      rating,
      message: "High-rating public review intent",
      isPublicReview: true,
      mode,
      source: "aura-pwa",
    });
    window.open(restaurantConfig.brand.googleReviewUrl, "_blank");
    toast.success("Thanks for the love! 💚");
    onOpenChange(false);
    setTimeout(reset, 250);
  }

  const highRated = rating >= 4;

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        onOpenChange(o);
        if (!o) setTimeout(reset, 250);
      }}
    >
      <DialogContent className="gap-5">
        <DialogTitle className="sr-only">Rate your experience</DialogTitle>

        {/* heading */}
        <div className="text-center">
          <motion.div
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 14 }}
            className="mx-auto mb-2 flex h-14 w-14 items-center justify-center rounded-2xl bg-accent/15 text-accent"
          >
            <Star className="h-7 w-7 fill-accent" />
          </motion.div>
          <h2 className="font-display text-xl font-bold">Enjoyed your visit?</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {step === "thanks"
              ? "Thank you for your feedback."
              : "Tap to rate your experience at the restaurant."}
          </p>
        </div>

        {step === "thanks" ? (
          <Thanks onClose={() => onOpenChange(false)} />
        ) : (
          <>
            {/* star rating */}
            <div className="flex justify-center gap-1.5">
              {[1, 2, 3, 4, 5].map((n) => {
                const active = (hover || rating) >= n;
                return (
                  <Pressable
                    key={n}
                    haptic="tap"
                    ensureTarget={false}
                    onClick={() => handleRate(n)}
                    onHoverStart={() => setHover(n)}
                    onHoverEnd={() => setHover(0)}
                    className="p-1"
                    aria-label={`${n} star${n > 1 ? "s" : ""}`}
                  >
                    <motion.span
                      animate={{ scale: active ? 1.1 : 1 }}
                      transition={SPRING}
                      className="block"
                    >
                      <Star
                        className={`h-9 w-9 transition-colors ${
                          active ? "fill-accent text-accent" : "text-muted-foreground/40"
                        }`}
                      />
                    </motion.span>
                  </Pressable>
                );
              })}
            </div>

            {/* smart logic split */}
            {rating > 0 && highRated && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={SPRING}
                className="space-y-2 text-center"
              >
                <p className="text-sm font-medium text-foreground">
                  We're thrilled! Would you mind sharing it publicly?
                </p>
                <Pressable
                  haptic="success"
                  onClick={goToGoogle}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-accent py-3.5 font-bold text-accent-foreground shadow-lg shadow-accent/30"
                >
                  <Star className="h-5 w-5 fill-accent-foreground" />
                  Post Public Review on Google
                  <ExternalLink className="h-4 w-4" />
                </Pressable>
              </motion.div>
            )}

            {step === "low" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={SPRING}
                className="space-y-3 text-center"
              >
                <p className="text-sm font-medium text-foreground">
                  We're sorry we fell short. Tell the manager what we can improve:
                </p>
                <Input
                  placeholder="Phone or email (optional)"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                />
                <Textarea
                  placeholder="What could we do better?"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="min-h-[96px]"
                />
                <Pressable
                  haptic="select"
                  onClick={sendPrivate}
                  disabled={!message.trim() || sending}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 font-bold text-primary-foreground shadow-lg shadow-primary/30 disabled:opacity-50"
                >
                  <Send className="h-4 w-4" />
                  Send Private Feedback
                </Pressable>
              </motion.div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Thanks({ onClose }: { onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={SPRING}
      className="flex flex-col items-center gap-3 py-2 text-center"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 14 }}
        className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/15 text-primary"
      >
        <Heart className="h-8 w-8 fill-primary" />
      </motion.div>
      <p className="text-sm text-muted-foreground">
        Your message has been sent privately to management.
      </p>
      <Pressable
        haptic="tap"
        onClick={onClose}
        className="mt-1 rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground"
      >
        Close
      </Pressable>
    </motion.div>
  );
}
