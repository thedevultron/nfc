/**
 * ============================================================================
 *  MenuList   ──  MODULE B · HIGH-CONVERTING DIGITAL MENU
 * ----------------------------------------------------------------------------
 *  • Sticky category navigation — horizontal Lucide-icon pills with a shared
 *    element (layoutId) indicator that springs between categories.
 *  • Instant search + toggle dietary filter pills (Veg / Non-Veg / Vegan /
 *    Chef's Special).
 *  • Animated dish cards (DishCard) with layout transitions on filter change.
 *  All data flows from /src/config/menuData.ts — edit there, never here.
 * ============================================================================
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, Utensils, X } from "lucide-react";
import { menuCategories, menuItems } from "@/config/menuData";
import { useHaptics } from "@/hooks/useHaptics";
import { Icon } from "@/components/ui/Icon";
import { DishCard } from "./DishCard";
import type { DietaryTag } from "@/types/menu.types";

const SPRING = { type: "spring" as const, stiffness: 400, damping: 30 };

const DIETARY_FILTERS: Array<{
  id: DietaryTag;
  label: string;
  icon: string;
}> = [
  { id: "veg", label: "Veg", icon: "CircleDot" },
  { id: "nonveg", label: "Non-Veg", icon: "Beef" },
  { id: "vegan", label: "Vegan", icon: "Leaf" },
  { id: "chef", label: "Chef's Special", icon: "Award" },
];

export function MenuList() {
  const { trigger } = useHaptics();
  const [activeCat, setActiveCat] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [dietary, setDietary] = useState<Set<DietaryTag>>(new Set());
  const stripRef = useRef<HTMLDivElement>(null);

  // keep the active category pill centred in the horizontal scroller
  useEffect(() => {
    const el = stripRef.current?.querySelector<HTMLButtonElement>(
      `[data-cat="${activeCat}"]`,
    );
    el?.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [activeCat]);

  const toggleDietary = (id: DietaryTag) => {
    trigger("tap");
    setDietary((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  // base filtering pipeline (config-driven data, pure functions)
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menuItems.filter((item) => {
      const catOk = activeCat === "all" || item.categoryId === activeCat;
      const dietOk =
        dietary.size === 0 || item.dietary.some((d) => dietary.has(d));
      const queryOk =
        !q ||
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q);
      return catOk && dietOk && queryOk;
    });
  }, [activeCat, dietary, query]);

  // group results by category for a structured menu (flat while searching)
  const groups = useMemo(() => {
    if (query.trim()) {
      return [{ category: { id: "results", name: "Search Results", icon: "Search" }, items: filtered }];
    }
    return menuCategories
      .filter((c) => activeCat === "all" || c.id === activeCat)
      .map((category) => ({
        category,
        items: filtered.filter((i) => i.categoryId === category.id),
      }))
      .filter((g) => g.items.length > 0);
  }, [filtered, activeCat, query]);

  const categories = [
    { id: "all", name: "All", icon: "Utensils" },
    ...menuCategories,
  ];

  return (
    <section className="relative">
      {/* ─────────── search + dietary filters (scroll with page) ─────────── */}
      <div className="space-y-3 px-4 pb-2 pt-1">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search dishes, drinks…"
            className="h-12 w-full rounded-full border border-input bg-background/60 pl-10 pr-10 text-sm text-foreground shadow-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-ring/40"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {DIETARY_FILTERS.map((f) => {
            const active = dietary.has(f.id);
            return (
              <button
                key={f.id}
                onClick={() => toggleDietary(f.id)}
                className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                  active
                    ? "border-primary bg-primary text-primary-foreground shadow-md shadow-primary/25"
                    : "border-border bg-card text-muted-foreground"
                }`}
              >
                <Icon name={f.icon} className="h-3.5 w-3.5" />
                {f.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ─────────── sticky category navigation (layoutId indicator) ─────────── */}
      <div className="sticky top-[calc(env(safe-area-inset-top)+58px)] z-30 bg-background/85 px-4 py-2 backdrop-blur-xl">
        <div
          ref={stripRef}
          className="no-scrollbar flex gap-2 overflow-x-auto scroll-smooth"
        >
          {categories.map((c) => {
            const selected = activeCat === c.id;
            return (
              <button
                key={c.id}
                data-cat={c.id}
                onClick={() => {
                  trigger("tap");
                  setActiveCat(c.id);
                }}
                className="relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-semibold"
              >
                {selected && (
                  <motion.span
                    layoutId="cat-pill"
                    transition={SPRING}
                    className="absolute inset-0 rounded-full bg-primary shadow-md shadow-primary/30"
                  />
                )}
                <span
                  className={`relative z-10 flex items-center gap-1.5 ${
                    selected ? "text-primary-foreground" : "text-muted-foreground"
                  }`}
                >
                  <Icon name={c.icon} className="h-4 w-4" />
                  {c.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ─────────── dish cards ─────────── */}
      <div className="space-y-6 px-4 pb-4 pt-1">
        <AnimatePresence mode="popLayout">
          {groups.map((group) => (
            <motion.div
              key={group.category.id}
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-3"
            >
              <div className="flex items-center gap-2 px-1">
                <Icon
                  name={group.category.icon}
                  className="h-4 w-4 text-accent"
                />
                <h2 className="font-display text-lg font-bold tracking-tight">
                  {group.category.name}
                </h2>
                <span className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
                  {group.items.length}
                </span>
              </div>
              <div className="space-y-2.5">
                <AnimatePresence mode="popLayout">
                  {group.items.map((item) => (
                    <DishCard key={item.id} item={item} />
                  ))}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center gap-3 py-16 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-secondary text-muted-foreground">
              <Utensils className="h-7 w-7" />
            </div>
            <div>
              <p className="font-semibold">No dishes found</p>
              <p className="text-sm text-muted-foreground">
                Try a different search or clear filters.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
