/**
 * DishCard — a single menu item. 100% icon-driven (no food photography).
 * Shows dietary badges, spice-level flames, best-seller tag, prep time and a
 * sold-out state. The (+) button fires haptics and animates into a stepper.
 */
import { motion } from "framer-motion";
import { Ban, Clock, Flame, Minus, Plus } from "lucide-react";
import type { MenuItem, DietaryTag } from "@/types/menu.types";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { Icon } from "@/components/ui/Icon";
import { Badge } from "@/components/ui/badge";
import { Pressable } from "@/components/ui/Pressable";
import { formatPrice } from "@/utils/format";

const DIETARY: Record<
  DietaryTag,
  { icon: string; label: string; variant: "veg" | "vegan" | "nonveg" | "chef" }
> = {
  veg: { icon: "CircleDot", label: "Veg", variant: "veg" },
  vegan: { icon: "Leaf", label: "Vegan", variant: "vegan" },
  nonveg: { icon: "Beef", label: "Non-Veg", variant: "nonveg" },
  chef: { icon: "Award", label: "Chef's", variant: "chef" },
};

const SPRING = { type: "spring" as const, stiffness: 400, damping: 25 };

export function DishCard({ item }: { item: MenuItem }) {
  const { addItem, quantityOf, increment, decrement } = useCart();
  const { trigger } = useHaptics();
  const qty = quantityOf(item.id);

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={SPRING}
      className={`relative flex gap-3 rounded-2xl border border-border bg-card p-3 shadow-sm ${
        !item.isAvailable ? "opacity-60" : ""
      }`}
    >
      {/* Icon badge stands in for a dish photo */}
      <div className="relative flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-secondary to-secondary/40">
        <Icon name={item.icon} className="h-7 w-7 text-foreground/70" />
        {item.isBestSeller && (
          <span className="absolute left-0 top-0 rounded-br-lg bg-accent px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-accent-foreground">
            ★ Best
          </span>
        )}
      </div>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold leading-tight">{item.name}</h3>
          <span className="shrink-0 font-display text-base font-bold text-primary">
            {formatPrice(item.price)}
          </span>
        </div>

        <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
          {item.description}
        </p>

        {/* meta row: dietary + spice + prep time */}
        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
          {item.dietary.map((d) => (
            <Badge key={d} variant={DIETARY[d].variant} className="gap-0.5">
              <Icon name={DIETARY[d].icon} className="h-3 w-3" />
              {DIETARY[d].label}
            </Badge>
          ))}

          {item.spiceLevel > 0 && (
            <span className="flex items-center gap-0.5" title={`Spice ${item.spiceLevel}/3`}>
              {Array.from({ length: item.spiceLevel }).map((_, i) => (
                <Flame key={i} className="h-3.5 w-3.5 fill-accent/30 text-accent" />
              ))}
            </span>
          )}

          {item.prepTime && (
            <span className="flex items-center gap-0.5 text-[11px] text-muted-foreground">
              <Clock className="h-3 w-3" />
              {item.prepTime}m
            </span>
          )}
        </div>

        {/* action */}
        <div className="mt-auto flex items-center justify-end pt-2">
          {!item.isAvailable ? (
            <div className="flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1.5 text-xs font-bold text-destructive">
              <Ban className="h-3.5 w-3.5" />
              Sold Out
            </div>
          ) : qty === 0 ? (
            <Pressable
              haptic="select"
              ensureTarget={false}
              onClick={() => {
                trigger("select");
                addItem(item);
              }}
              className="flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground shadow-md shadow-primary/25"
            >
              <Plus className="h-4 w-4" strokeWidth={2.5} />
              Add
            </Pressable>
          ) : (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={SPRING}
              className="flex items-center gap-1 rounded-full bg-primary/10 p-1 text-primary"
            >
              <Pressable
                haptic="tap"
                ensureTarget={false}
                onClick={() => {
                  trigger("tap");
                  decrement(item.id);
                }}
                className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-primary/15"
              >
                <Minus className="h-4 w-4" strokeWidth={2.5} />
              </Pressable>
              <motion.span
                key={qty}
                initial={{ scale: 0.6, y: -4 }}
                animate={{ scale: 1, y: 0 }}
                transition={SPRING}
                className="min-w-5 text-center text-sm font-bold tabular-nums"
              >
                {qty}
              </motion.span>
              <Pressable
                haptic="tap"
                ensureTarget={false}
                onClick={() => {
                  trigger("select");
                  increment(item.id);
                }}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground"
              >
                <Plus className="h-4 w-4" strokeWidth={2.5} />
              </Pressable>
            </motion.div>
          )}
        </div>
      </div>
    </motion.article>
  );
}
