/**
 * InfoSheet — restaurant details (address, hours, phone) surfaced from
 * restaurant.config.ts. Used by the "Info" bottom-nav tab.
 */
import { motion } from "framer-motion";
import { MessageCircle, Phone, Navigation } from "lucide-react";
import { restaurantConfig } from "@/config/restaurant.config";
import { useHaptics } from "@/hooks/useHaptics";
import {
  DrawerRoot,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { Icon } from "@/components/ui/Icon";
import { Pressable } from "@/components/ui/Pressable";
import { whatsappLink } from "@/utils/format";

const SPRING = { type: "spring" as const, stiffness: 300, damping: 24 };

export function InfoSheet({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { trigger } = useHaptics();
  const { brand } = restaurantConfig;

  const rows = [
    { icon: "MapPin", label: "Address", value: brand.address },
    { icon: "Clock", label: "Opening Hours", value: brand.openingHours },
    { icon: "Phone", label: "Phone", value: brand.phone },
  ];

  const mapsUrl = `https://maps.google.com/?q=${encodeURIComponent(brand.address)}`;

  return (
    <DrawerRoot open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[88vh]">
        <DrawerHeader>
          <DrawerTitle>Visit Us</DrawerTitle>
        </DrawerHeader>

        <div className="no-scrollbar flex-1 space-y-5 overflow-y-auto px-5 pb-4">
          {/* brand header */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={SPRING}
            className="flex items-center gap-3 rounded-2xl border border-border bg-gradient-to-br from-primary/10 to-card p-4"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground">
              <Icon name={brand.markIcon} className="h-6 w-6" />
            </div>
            <div>
              <p className="font-display text-lg font-bold leading-tight">{brand.name}</p>
              <p className="text-sm text-muted-foreground">{brand.subtitle}</p>
            </div>
          </motion.div>

          {/* detail rows */}
          <div className="space-y-2">
            {rows.map((r) => (
              <div
                key={r.label}
                className="flex items-start gap-3 rounded-2xl border border-border bg-card p-3.5"
              >
                <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-secondary text-foreground/70">
                  <Icon name={r.icon} className="h-5 w-5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    {r.label}
                  </p>
                  <p className="text-sm font-medium">{r.value}</p>
                </div>
              </div>
            ))}
          </div>

          {/* quick contact actions */}
          <div className="grid grid-cols-3 gap-2">
            <Pressable
              haptic="select"
              ensureTarget={false}
              onClick={() => {
                trigger("select");
                window.location.href = `tel:${brand.phone}`;
              }}
              className="flex flex-col items-center gap-1.5 rounded-2xl border border-border bg-card py-3.5 text-xs font-semibold"
            >
              <Phone className="h-5 w-5 text-primary" />
              Call
            </Pressable>
            <Pressable
              haptic="select"
              ensureTarget={false}
              onClick={() => {
                trigger("select");
                window.open(whatsappLink(`Hi ${brand.name}!`), "_blank");
              }}
              className="flex flex-col items-center gap-1.5 rounded-2xl border border-border bg-card py-3.5 text-xs font-semibold"
            >
              <MessageCircle className="h-5 w-5 text-primary" />
              WhatsApp
            </Pressable>
            <Pressable
              haptic="select"
              ensureTarget={false}
              onClick={() => {
                trigger("select");
                window.open(mapsUrl, "_blank");
              }}
              className="flex flex-col items-center gap-1.5 rounded-2xl border border-border bg-card py-3.5 text-xs font-semibold"
            >
              <Navigation className="h-5 w-5 text-primary" />
              Directions
            </Pressable>
          </div>
        </div>
      </DrawerContent>
    </DrawerRoot>
  );
}
