/**
 * WifiModal — instant-connect modal. Shows SSID, a copyable password and a
 * dynamic QR (the standard WIFI: scheme) so guests scan-to-connect. All
 * credentials come from restaurant.config.ts → brand.wifi.
 */
import { motion } from "framer-motion";
import { QRCodeSVG } from "qrcode.react";
import { Check, Copy, Eye, EyeOff, Wifi } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { restaurantConfig } from "@/config/restaurant.config";
import { useHaptics } from "@/hooks/useHaptics";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";
import { Pressable } from "@/components/ui/Pressable";

export function WifiModal({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { trigger } = useHaptics();
  const { wifi } = restaurantConfig.brand;
  const [reveal, setReveal] = useState(false);
  const [copied, setCopied] = useState<null | "ssid" | "pass">(null);

  // WIFI: network config string understood natively by phone cameras.
  const qrValue = `WIFI:T:${wifi.security};S:${wifi.ssid};P:${wifi.pass};H:${wifi.hidden};`;

  async function copy(value: string, which: "ssid" | "pass") {
    trigger("select");
    try {
      await navigator.clipboard.writeText(value);
      setCopied(which);
      toast.success(which === "ssid" ? "Network name copied" : "Password copied");
      setTimeout(() => setCopied(null), 1600);
    } catch {
      toast.error("Couldn't copy — long-press to copy manually.");
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="gap-4">
        <DialogTitle className="sr-only">Connect to WiFi</DialogTitle>

        <div className="flex flex-col items-center gap-1 text-center">
          <motion.div
            initial={{ scale: 0, rotate: -10 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 14 }}
            className="mb-1 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/30"
          >
            <Wifi className="h-7 w-7" />
          </motion.div>
          <h2 className="font-display text-xl font-bold">Free Guest WiFi</h2>
          <p className="text-sm text-muted-foreground">Point your camera at the code to connect</p>
        </div>

        {/* QR — sits on a white tile for guaranteed scan contrast */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 260, damping: 16 }}
          className="mx-auto rounded-3xl bg-white p-4 shadow-xl"
        >
          <QRCodeSVG value={qrValue} size={188} level="M" includeMargin={false} />
        </motion.div>

        {/* credentials */}
        <div className="space-y-2">
          <CredentialRow label="Network" value={wifi.ssid} onCopy={() => copy(wifi.ssid, "ssid")} copied={copied === "ssid"} />
          <CredentialRow
            label="Password"
            value={reveal ? wifi.pass : "•".repeat(Math.min(wifi.pass.length, 10))}
            onCopy={() => copy(wifi.pass, "pass")}
            copied={copied === "pass"}
            trailing={
              <Pressable
                haptic="tap"
                ensureTarget={false}
                onClick={() => {
                  trigger("tap");
                  setReveal((r) => !r);
                }}
                className="text-muted-foreground"
                aria-label={reveal ? "Hide password" : "Show password"}
              >
                {reveal ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Pressable>
            }
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CredentialRow({
  label,
  value,
  onCopy,
  copied,
  trailing,
}: {
  label: string;
  value: string;
  onCopy: () => void;
  copied: boolean;
  trailing?: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-2 rounded-2xl border border-border bg-background/50 p-3">
      <div className="min-w-0 flex-1">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="truncate font-mono text-sm font-semibold">{value}</p>
      </div>
      {trailing}
      <Pressable
        haptic="tap"
        ensureTarget={false}
        onClick={onCopy}
        className={`flex h-9 w-9 items-center justify-center rounded-full ${
          copied ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"
        }`}
        aria-label={`Copy ${label}`}
      >
        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      </Pressable>
    </div>
  );
}
