/**
 * ============================================================================
 *  App.tsx   ──  MAIN LAYOUT INTEGRATION
 * ----------------------------------------------------------------------------
 *  Orchestrates the decoupled modules: applies the live theme from config,
 *  holds top-level UI state (interaction mode, overlays, dark/light) and
 *  mounts the fixed bars + feature overlays. AnimatePresence-ready.
 *
 *  ── TO RE-SKIN FOR A NEW CLIENT, EDIT ONLY /src/config/* ──
 *    • theme.config.ts      → colours, radius, glass, fonts, density
 *    • restaurant.config.ts → brand, features, webhooks, quick actions
 *    • menuData.ts          → the entire menu
 *  No file in /components, /hooks or /services needs touching.
 * ============================================================================
 */
import { useEffect, useRef, useState } from "react";
import { Toaster } from "sonner";
import { themeConfig } from "@/config/theme.config";
import { restaurantConfig } from "@/config/restaurant.config";
import { applyTheme } from "@/utils/applyTheme";
import { useHaptics } from "@/hooks/useHaptics";
import { whatsappLink } from "@/utils/format";
import { CartProvider } from "@/hooks/useCart";
import { AppShell } from "@/components/layout/AppShell";
import { TopBar } from "@/components/layout/TopBar";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { MenuList } from "@/components/features/MenuList";
import { FeaturedCarousel } from "@/components/features/FeaturedCarousel";
import { CartSheet } from "@/components/features/CartSheet";
import { ReservationSheet } from "@/components/features/ReservationSheet";
import { ReviewModal } from "@/components/features/ReviewModal";
import { WifiModal } from "@/components/features/WifiModal";
import { InfoSheet } from "@/components/features/InfoSheet";
import type { QuickAction } from "@/types/config.types";

function AuraApp() {
  const { trigger } = useHaptics();

  // ── theming (driven by theme.config.ts) ──
  const [isDark, setIsDark] = useState(themeConfig.defaultMode === "dark");
  useEffect(() => applyTheme(isDark ? "dark" : "light"), [isDark]);

  // ── NFC interaction mode (Dine-In / Takeaway) ──
  const [mode, setMode] = useState<string>(restaurantConfig.context.modes[0].id);

  // ── bottom-nav active indicator ──
  const [activeView, setActiveView] = useState("menu");

  // ── overlay visibility (cart handled by useCart context) ──
  const [reservationOpen, setReservationOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [wifiOpen, setWifiOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);

  const menuTopRef = useRef<HTMLDivElement>(null);

  // Route quick-action targets to overlays / deep links.
  function handleAction(target: QuickAction["target"]) {
    trigger("open");
    switch (target) {
      case "wifi":
        setWifiOpen(true);
        break;
      case "whatsapp":
        window.open(
          whatsappLink(`Hi ${restaurantConfig.brand.name}! I'd like to inquire.`),
          "_blank",
        );
        break;
      case "review":
        setReviewOpen(true);
        setActiveView("review");
        break;
      case "reservation":
        setReservationOpen(true);
        setActiveView("reserve");
        break;
      case "info":
        setInfoOpen(true);
        setActiveView("info");
        break;
    }
  }

  function goMenu() {
    setActiveView("menu");
    menuTopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <AppShell>
      <TopBar isDark={isDark} onToggleTheme={() => setIsDark((d) => !d)} />

      <main className="relative z-[1] flex flex-1 flex-col gap-5 px-0 pt-[calc(env(safe-area-inset-top)+58px)] pb-[calc(env(safe-area-inset-bottom)+96px)]">
        <Header
          mode={mode}
          onModeChange={(m) => {
            trigger("select");
            setMode(m);
          }}
          onAction={handleAction}
        />

        <div ref={menuTopRef} className="scroll-mt-[70px]">
          <FeaturedCarousel />
        </div>

        <MenuList />
      </main>

      <BottomNav
        activeView={activeView}
        onMenu={goMenu}
        onReserve={() => setReservationOpen(true)}
        onReview={() => setReviewOpen(true)}
        onInfo={() => setInfoOpen(true)}
      />

      {/* ── FEATURE OVERLAYS ── */}
      <CartSheet mode={mode} />
      <ReservationSheet
        open={reservationOpen}
        onOpenChange={setReservationOpen}
        mode={mode}
      />
      <ReviewModal open={reviewOpen} onOpenChange={setReviewOpen} mode={mode} />
      <WifiModal open={wifiOpen} onOpenChange={setWifiOpen} />
      <InfoSheet open={infoOpen} onOpenChange={setInfoOpen} />

      <Toaster
        position="top-center"
        theme={isDark ? "dark" : "light"}
        toastOptions={{ style: { borderRadius: "14px" } }}
      />
    </AppShell>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AuraApp />
    </CartProvider>
  );
}
