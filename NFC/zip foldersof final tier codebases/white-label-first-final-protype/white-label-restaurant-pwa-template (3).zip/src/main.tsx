import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { applyTheme } from "@/utils/applyTheme";

// Apply the configured theme BEFORE first paint to avoid a flash of the
// unstyled / wrong-mode state. Re-applied reactively from App.tsx afterwards.
applyTheme();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
