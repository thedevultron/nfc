/**
 * ============================================================================
 *  api.service.ts   ──  🧠  APPLICATION API LAYER (FACADE)
 * ----------------------------------------------------------------------------
 *  The single place feature components call to talk to the backend. It wraps
 *  `n8n.service.ts` and adds the resilience layer: structured payloads,
 *  source-tagging and an OPTIMISTIC MOCK FALLBACK so the template works
 *  end-to-end with no live backend configured.
 *
 *  Integration path:
 *    1. Paste your real n8n URLs into restaurant.config.ts → live data flows.
 *    2. Keep placeholders → every call still resolves { success: true }.
 *
 *  Components never import n8n.service directly — only this facade — keeping
 *  the backend contract in exactly one place.
 * ============================================================================
 */
import { restaurantConfig } from "@/config/restaurant.config";
import { n8nService } from "./n8n.service";
import type {
  FeedbackPayload,
  OrderPayload,
  ReservationPayload,
} from "@/types/menu.types";

/** Normalised success shape every caller can rely on. */
export interface ApiResult<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  /** True when the result came from the mock fallback (useful for demo badges). */
  mocked: boolean;
}

/** Builds a mock result when a live webhook is unreachable/unconfigured. */
function mockResult<T>(message: string, data?: T): ApiResult<T> {
  return { success: true, message, data, mocked: true };
}

/** True when the configured URL is still a placeholder / clearly offline. */
function looksLikePlaceholder(url: string): boolean {
  return url.includes("your-n8n-instance.com") || url.trim() === "";
}

export const apiService = {
  /** MODULE E — Table reservation submission. */
  async sendReservation(
    payload: ReservationPayload,
  ): Promise<ApiResult<{ reference: string }>> {
    const body = { ...payload, source: "aura-pwa" };
    if (looksLikePlaceholder(restaurantConfig.n8nWebhooks.reservationUrl)) {
      return mockResult("Mock reservation dispatched", {
        reference: `RES-${Date.now().toString(36).toUpperCase()}`,
      });
    }
    try {
      await n8nService.sendReservation(body);
      return {
        success: true,
        message: "Reservation confirmed",
        mocked: false,
        data: { reference: `RES-${Date.now().toString(36).toUpperCase()}` },
      };
    } catch (e) {
      // Optimistic fallback so the UI flow never breaks for the guest.
      console.warn("[apiService] reservation webhook failed, using mock.", e);
      return mockResult("Reservation saved locally — we'll confirm shortly.", {
        reference: `RES-${Date.now().toString(36).toUpperCase()}`,
      });
    }
  },

  /** MODULE D — Private feedback (low ratings) submission. */
  async sendFeedback(payload: FeedbackPayload): Promise<ApiResult> {
    const body = { ...payload, source: "aura-pwa" };
    if (looksLikePlaceholder(restaurantConfig.n8nWebhooks.feedbackUrl)) {
      return mockResult("Thank you — feedback sent privately to management.");
    }
    try {
      await n8nService.sendFeedback(body);
      return { success: true, message: "Feedback received", mocked: false };
    } catch (e) {
      console.warn("[apiService] feedback webhook failed, using mock.", e);
      return mockResult("Thank you — feedback sent privately to management.");
    }
  },

  /** MODULE C — Kitchen / WhatsApp order submission. */
  async sendOrder(payload: OrderPayload): Promise<ApiResult> {
    const body = { ...payload, source: "aura-pwa" };
    if (looksLikePlaceholder(restaurantConfig.n8nWebhooks.orderUrl)) {
      return mockResult("Order sent to the kitchen.");
    }
    try {
      await n8nService.sendOrder(body);
      return { success: true, message: "Order received by kitchen", mocked: false };
    } catch (e) {
      console.warn("[apiService] order webhook failed, using mock.", e);
      return mockResult("Order sent to the kitchen.");
    }
  },

  /** MODULE D — High-rating public review intent log (optional). */
  async sendReview(payload: FeedbackPayload): Promise<ApiResult> {
    const body = { ...payload, source: "aura-pwa" };
    if (looksLikePlaceholder(restaurantConfig.n8nWebhooks.reviewUrl)) {
      return mockResult("Review intent logged.");
    }
    try {
      await n8nService.sendReview(body);
      return { success: true, message: "Review intent logged", mocked: false };
    } catch (e) {
      console.warn("[apiService] review webhook failed, using mock.", e);
      return mockResult("Review intent logged.");
    }
  },
};
