/**
 * ============================================================================
 *  n8n.service.ts   ──  🔌  ISOLATED WEBHOOK TRANSPORT
 * ----------------------------------------------------------------------------
 *  Low-level, reusable `fetch` wrappers pre-configured for n8n webhook URLs.
 *  Every URL is pulled from `restaurantConfig.n8nWebhooks`, so swapping your
 *  automation backend is a config-only change — no code edits anywhere.
 *
 *  These handlers are intentionally dumb: they POST JSON and resolve a typed
 *  result. Resilience (timeouts, retries, offline fallbacks) is layered on by
 *  the higher-level `api.service.ts`.
 * ============================================================================
 */
import { restaurantConfig } from "@/config/restaurant.config";

const JSON_HEADERS: HeadersInit = { "Content-Type": "application/json" };

/** Default options for each webhook call. */
export interface WebhookOptions {
  /** Abort after N milliseconds (n8n long polls can be slow). */
  timeoutMs?: number;
  signal?: AbortSignal;
}

/**
 * Generic JSON POST to an n8n webhook.
 * Throws on network/HTTP failure so callers can decide how to recover.
 */
export async function postToWebhook<TPayload, TResponse = unknown>(
  url: string,
  payload: TPayload,
  options: WebhookOptions = {},
): Promise<TResponse> {
  const { timeoutMs = 12000, signal } = options;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  // Respect an externally supplied abort signal too.
  signal?.addEventListener("abort", () => controller.abort());

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: JSON_HEADERS,
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(`Webhook responded with ${response.status}`);
    }

    const text = await response.text();
    return (text ? JSON.parse(text) : {}) as TResponse;
  } finally {
    clearTimeout(timeout);
  }
}

/* ────────────────────────────  CONCRETE HANDLERS  ───────────────────────────
 * Each maps to one configured webhook endpoint. Add new ones here as your
 * automation grows — UI components import them via api.service.ts.
 */
export const n8nService = {
  sendReservation: (payload: unknown, options?: WebhookOptions) =>
    postToWebhook(restaurantConfig.n8nWebhooks.reservationUrl, payload, options),

  sendFeedback: (payload: unknown, options?: WebhookOptions) =>
    postToWebhook(restaurantConfig.n8nWebhooks.feedbackUrl, payload, options),

  sendOrder: (payload: unknown, options?: WebhookOptions) =>
    postToWebhook(restaurantConfig.n8nWebhooks.orderUrl, payload, options),

  sendReview: (payload: unknown, options?: WebhookOptions) =>
    postToWebhook(restaurantConfig.n8nWebhooks.reviewUrl, payload, options),
};
