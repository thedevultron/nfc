/**
 * ============================================================================
 *  useCart   ──  🛒  CART STATE + DRAWER CONTROLS
 * ----------------------------------------------------------------------------
 *  Exposed via a React Context so the floating cart button, the cart sheet
 *  and the menu "add" buttons all stay in sync without prop-drilling.
 *  State is persisted to localStorage for a native-feeling PWA session.
 * ============================================================================
 */
import {
  createContext,
  createElement,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { CartItem, MenuItem } from "@/types/menu.types";

const STORAGE_KEY = "aura-cart-v1";

interface CartContextValue {
  items: CartItem[];
  count: number; // total quantity across items
  subtotal: number;
  isEmpty: boolean;
  // item mutations
  addItem: (item: MenuItem, qty?: number) => void;
  removeItem: (itemId: string) => void;
  increment: (itemId: string) => void;
  decrement: (itemId: string) => void;
  setQuantity: (itemId: string, qty: number) => void;
  clear: () => void;
  quantityOf: (itemId: string) => number;
  // drawer controls
  isDrawerOpen: boolean;
  openDrawer: () => void;
  closeDrawer: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);

function loadInitial(): CartItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as CartItem[]) : [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(loadInitial);
  const [isDrawerOpen, setDrawerOpen] = useState(false);

  // Persist on change.
  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* storage may be unavailable in private mode */
    }
  }, [items]);

  const addItem = useCallback((item: MenuItem, qty = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.item.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.item.id === item.id
            ? { ...i, quantity: i.quantity + qty }
            : i,
        );
      }
      return [...prev, { item, quantity: qty }];
    });
  }, []);

  const removeItem = useCallback((itemId: string) => {
    setItems((prev) => prev.filter((i) => i.item.id !== itemId));
  }, []);

  const setQuantity = useCallback((itemId: string, qty: number) => {
    setItems((prev) =>
      qty <= 0
        ? prev.filter((i) => i.item.id !== itemId)
        : prev.map((i) => (i.item.id === itemId ? { ...i, quantity: qty } : i)),
    );
  }, []);

  const increment = useCallback(
    (itemId: string) => {
      setItems((prev) =>
        prev.map((i) =>
          i.item.id === itemId ? { ...i, quantity: i.quantity + 1 } : i,
        ),
      );
    },
    [],
  );

  const decrement = useCallback((itemId: string) => {
    setItems((prev) =>
      prev
        .map((i) =>
          i.item.id === itemId ? { ...i, quantity: i.quantity - 1 } : i,
        )
        .filter((i) => i.quantity > 0),
    );
  }, []);

  const clear = useCallback(() => setItems([]), []);
  const openDrawer = useCallback(() => setDrawerOpen(true), []);
  const closeDrawer = useCallback(() => setDrawerOpen(false), []);

  const quantityOf = useCallback(
    (itemId: string) =>
      items.find((i) => i.item.id === itemId)?.quantity ?? 0,
    [items],
  );

  const count = useMemo(
    () => items.reduce((sum, i) => sum + i.quantity, 0),
    [items],
  );
  const subtotal = useMemo(
    () => items.reduce((sum, i) => sum + i.quantity * i.item.price, 0),
    [items],
  );

  const value: CartContextValue = {
    items,
    count,
    subtotal,
    isEmpty: items.length === 0,
    addItem,
    removeItem,
    increment,
    decrement,
    setQuantity,
    clear,
    quantityOf,
    isDrawerOpen,
    openDrawer,
    closeDrawer,
  };

  return createElement(CartContext.Provider, { value }, children);
}

/** Access the cart. Must be used inside <CartProvider>. */
export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a <CartProvider>");
  return ctx;
}
