/**
 * ============================================================================
 *  useHaptics   ──  📳  NATIVE HAPTIC FEEDBACK
 * ----------------------------------------------------------------------------
 *  Wraps `navigator.vibrate` behind a typed, SSR-safe API with named patterns.
 *  Wired into item adds, filter taps and drawer triggers so every interaction
 *  feels native. Degrades silently on unsupported devices.
 * ============================================================================
 */
import { useCallback, useMemo } from "react";

export type HapticPattern =
  | "tap" // micro-tick — filters, chips
  | "select" // soft double-tick — adding items
  | "success" // rising pulse — order placed / reservation confirmed
  | "warn" // heavier buzz — sold-out / error
  | "open"; // gentle open — drawer revealed

const PATTERNS: Record<HapticPattern, number | number[]> = {
  tap: 10,
  select: [12, 30, 12],
  success: [18, 40, 30, 40, 60],
  warn: [60, 50, 60],
  open: 20,
};

export function useHaptics(enabled = true) {
  const supported =
    typeof navigator !== "undefined" && typeof navigator.vibrate === "function";

  /** Fire a single named haptic pattern. */
  const trigger = useCallback(
    (pattern: HapticPattern = "tap") => {
      if (!enabled || !supported) return;
      try {
        navigator.vibrate(PATTERNS[pattern]);
      } catch {
        /* no-op — vibration can be blocked by permissions/visibility */
      }
    },
    [enabled, supported],
  );

  return useMemo(
    () => ({ trigger, supported }),
    [trigger, supported],
  );
}
