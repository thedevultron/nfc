/**
 * ============================================================================
 *  usePWAInstall   ──  📲  NATIVE "ADD TO HOME SCREEN"
 * ----------------------------------------------------------------------------
 *  Captures Chrome/Android/Edge's `beforeinstallprompt` event and exposes a
 *  `promptInstall()` trigger. On iOS (which offers no prompt API) it exposes
 *  `isiOS` so the UI can surface the manual "Share → Add to Home Screen" hint.
 * ============================================================================
 */
import { useCallback, useEffect, useState } from "react";

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: "accepted" | "dismissed";
    platform: string;
  }>;
  prompt: () => Promise<void>;
}

const isStandalone = () =>
  (typeof window !== "undefined" &&
    (window.matchMedia?.("(display-mode: standalone)").matches ||
      // iOS Safari standalone flag
      (window.navigator as Navigator & { standalone?: boolean }).standalone ===
        true)) ??
  false;

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] =
    useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState<boolean>(isStandalone());
  const [isiOS, setIsiOS] = useState(false);

  useEffect(() => {
    const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
    setIsiOS(/iphone|ipad|ipod/i.test(ua) && !/crios|fxios/i.test(ua));

    const onBeforeInstall = (e: Event) => {
      e.preventDefault(); // stop the default mini-infobar
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!deferredPrompt) return "unavailable" as const;
    await deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    return choice.outcome;
  }, [deferredPrompt]);

  /** True when it makes sense to show an "Install App" affordance. */
  const canInstall = !!deferredPrompt || (!installed && isiOS);

  return { canInstall, installed, isiOS, promptInstall };
}
