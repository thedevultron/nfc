/**
 * ============================================================================
 *  HOOK ▸ usePWAInstall
 * ============================================================================
 *  Captures the `beforeinstallprompt` event and exposes a native
 *  "Add to Home Screen" trigger. Also injects a runtime Web App Manifest that
 *  is generated *entirely* from /src/config (name, colours) — meaning a new
 *  client deployment gets correct PWA metadata with zero code edits.
 * ============================================================================
 */

import { useCallback, useEffect, useState } from 'react';
import { restaurantConfig } from '../config/restaurant.config';
import { themeConfig } from '../config/theme.config';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

function injectRuntimeManifest() {
  if (typeof document === 'undefined') return;
  if (document.querySelector('link[rel="manifest"][data-runtime]')) return;

  const manifest = {
    name: restaurantConfig.brand.name,
    short_name: restaurantConfig.brand.name.split(' ')[0],
    description: restaurantConfig.brand.subtitle,
    start_url: '.',
    display: 'standalone',
    background_color: themeConfig.defaultMode === 'dark' ? '#080a09' : '#ffffff',
    theme_color: themeConfig.defaultMode === 'dark' ? '#080a09' : '#ffffff',
    icons: [],
  };

  const blob = new Blob([JSON.stringify(manifest)], { type: 'application/manifest+json' });
  const link = document.createElement('link');
  link.rel = 'manifest';
  link.setAttribute('data-runtime', 'true');
  link.href = URL.createObjectURL(blob);
  document.head.appendChild(link);
}

export function usePWAInstall() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (!restaurantConfig.features.enablePWAInstall) return;
    injectRuntimeManifest();

    const standalone =
      window.matchMedia?.('(display-mode: standalone)').matches ||
      // iOS Safari
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setInstalled(!!standalone);

    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
    };

    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!deferred) return { outcome: 'unavailable' as const };
    await deferred.prompt();
    const choice = await deferred.userChoice;
    setDeferred(null);
    return choice;
  }, [deferred]);

  return {
    canInstall: !!deferred && !installed && !dismissed,
    installed,
    promptInstall,
    dismiss: () => setDismissed(true),
  };
}
