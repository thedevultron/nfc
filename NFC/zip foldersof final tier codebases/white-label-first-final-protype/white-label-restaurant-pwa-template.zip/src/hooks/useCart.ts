/**
 * ============================================================================
 *  HOOK ▸ useCart (context-backed global cart state)
 * ============================================================================
 *  Pure state logic — zero UI. Totals derive their tax / service percentages
 *  from restaurantConfig.order, so changing a client's tax rate is a config
 *  edit, never a code edit.
 *
 *  Written with React.createElement so the file can stay a `.ts` module while
 *  still exporting a provider, matching the prescribed architecture.
 * ============================================================================
 */

import { createContext, createElement, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { restaurantConfig } from '../config/restaurant.config';
import type { CartLine, CartState, MenuItem } from '../types/menu.types';

interface CartApi extends CartState {
  add: (item: MenuItem) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  qtyOf: (id: string) => number;
  clear: () => void;
  setNote: (note: string) => void;
  /** Drawer controls live with the cart so any component can open it. */
  isOpen: boolean;
  open: () => void;
  close: () => void;
  setOpen: (v: boolean) => void;
}

const CartContext = createContext<CartApi | null>(null);

const round = (n: number) => Math.round(n * 100) / 100;

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [note, setNote] = useState('');
  const [isOpen, setOpen] = useState(false);

  const add = useCallback((item: MenuItem) => {
    if (!item.isAvailable) return;
    setLines((prev) => {
      const hit = prev.find((l) => l.item.id === item.id);
      return hit
        ? prev.map((l) => (l.item.id === item.id ? { ...l, qty: l.qty + 1 } : l))
        : [...prev, { item, qty: 1 }];
    });
  }, []);

  const setQty = useCallback((id: string, qty: number) => {
    setLines((prev) =>
      qty <= 0 ? prev.filter((l) => l.item.id !== id) : prev.map((l) => (l.item.id === id ? { ...l, qty } : l)),
    );
  }, []);

  const remove = useCallback((id: string) => setLines((prev) => prev.filter((l) => l.item.id !== id)), []);
  const clear = useCallback(() => {
    setLines([]);
    setNote('');
  }, []);

  const totals = useMemo(() => {
    const subtotal = lines.reduce((s, l) => s + l.item.price * l.qty, 0);
    const tax = round((subtotal * restaurantConfig.order.taxRatePercent) / 100);
    const service = round((subtotal * restaurantConfig.order.serviceChargePercent) / 100);
    return {
      subtotal: round(subtotal),
      tax,
      service,
      total: round(subtotal + tax + service),
      count: lines.reduce((s, l) => s + l.qty, 0),
    };
  }, [lines]);

  const value: CartApi = {
    lines,
    note,
    ...totals,
    add,
    remove,
    setQty,
    qtyOf: (id: string) => lines.find((l) => l.item.id === id)?.qty ?? 0,
    clear,
    setNote,
    isOpen,
    open: () => setOpen(true),
    close: () => setOpen(false),
    setOpen,
  };

  return createElement(CartContext.Provider, { value }, children);
}

export function useCart(): CartApi {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside <CartProvider />');
  return ctx;
}
