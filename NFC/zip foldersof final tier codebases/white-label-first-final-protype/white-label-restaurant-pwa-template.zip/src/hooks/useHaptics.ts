/**
 * ============================================================================
 *  HOOK ▸ useHaptics
 * ============================================================================
 *  Native vibration feedback. Globally gated by
 *  restaurantConfig.features.enableHaptics — flip that flag to disable every
 *  vibration in the app without editing a component.
 * ============================================================================
 */

import { useCallback } from 'react';
import { restaurantConfig } from '../config/restaurant.config';

type HapticPattern = 'tap' | 'select' | 'success' | 'warning' | 'error';

const PATTERNS: Record<HapticPattern, number | number[]> = {
  tap: 10,
  select: 15,
  success: [12, 40, 22],
  warning: [20, 60, 20],
  error: [40, 30, 40, 30, 60],
};

export function useHaptics() {
  const enabled = restaurantConfig.features.enableHaptics;

  const vibrate = useCallback(
    (pattern: HapticPattern = 'tap') => {
      if (!enabled) return;
      if (typeof navigator === 'undefined' || !('vibrate' in navigator)) return;
      try {
        navigator.vibrate(PATTERNS[pattern]);
      } catch {
        /* silently ignore unsupported platforms (iOS Safari) */
      }
    },
    [enabled],
  );

  return {
    vibrate,
    tap: () => vibrate('tap'),
    select: () => vibrate('select'),
    success: () => vibrate('success'),
    error: () => vibrate('error'),
    supported: typeof navigator !== 'undefined' && 'vibrate' in navigator,
  };
}
