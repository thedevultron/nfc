/**
 * HOOK ▸ useTouchpoint
 * Resolves the NFC / QR entry context from the URL (?table=12&mode=takeaway),
 * falling back to restaurantConfig.touchpoint defaults. Every physical NFC tag
 * can therefore encode a different table with zero rebuilds.
 */
import { useMemo } from 'react';
import { restaurantConfig } from '../config/restaurant.config';

export function useTouchpoint() {
  return useMemo(() => {
    const params = new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '');
    const { defaultTable, defaultMode, labels } = restaurantConfig.touchpoint;
    const table = params.get('table') ?? defaultTable;
    const mode = (params.get('mode') as 'dinein' | 'takeaway') ?? defaultMode;
    return {
      table,
      mode,
      label: mode === 'dinein' ? `Table ${table} · ${labels.dinein}` : labels.takeaway,
      isNfc: params.get('src') === 'nfc' || params.has('table'),
    };
  }, []);
}
