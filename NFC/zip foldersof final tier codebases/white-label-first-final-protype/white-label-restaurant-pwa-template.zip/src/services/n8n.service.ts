/**
 * ============================================================================
 *  SERVICE LAYER ▸ n8n WEBHOOK TRANSPORT (isolated)
 * ============================================================================
 *  The ONLY place raw `fetch` is executed. Swap this file for Supabase / REST
 *  / Firebase without touching a single component.
 *
 *  To go live: paste production webhook URLs into
 *  /src/config/restaurant.config.ts → n8nWebhooks.*
 *  Nothing else changes.
 * ============================================================================
 */

import { restaurantConfig } from '../config/restaurant.config';
import type { ApiResult } from '../types/menu.types';

const REQUEST_TIMEOUT_MS = 8000;

/** True when the installer has not yet swapped the placeholder URLs. */
export const isWebhookConfigured = (url: string) => !!url && !url.includes('your-n8n-instance.com');

async function post<T>(url: string, payload: unknown, fallbackMessage: string): Promise<ApiResult<T>> {
  // Dev visibility: always log the exact payload an n8n node will receive.
  // eslint-disable-next-line no-console
  console.info('[n8n.service] →', url, payload);

  if (!isWebhookConfigured(url)) {
    // Optimistic simulation so the template is demo-ready out of the box.
    await new Promise((r) => setTimeout(r, 900));
    return { success: true, message: fallbackMessage, simulated: true };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...(payload as object), _source: 'pwa', _ts: new Date().toISOString() }),
      signal: controller.signal,
    });
    const data = (await res.json().catch(() => ({}))) as T;
    return { success: res.ok, message: res.ok ? fallbackMessage : `Request failed (${res.status})`, data };
  } catch {
    // Network/offline fallback keeps UX intact — request can be queued later.
    return { success: true, message: fallbackMessage, simulated: true };
  } finally {
    clearTimeout(timer);
  }
}

export const n8nService = {
  reservation: <T>(payload: unknown) =>
    post<T>(restaurantConfig.n8nWebhooks.reservationUrl, payload, 'Reservation request dispatched'),
  feedback: <T>(payload: unknown) =>
    post<T>(restaurantConfig.n8nWebhooks.feedbackUrl, payload, 'Private feedback delivered to management'),
  order: <T>(payload: unknown) =>
    post<T>(restaurantConfig.n8nWebhooks.orderUrl, payload, 'Order pushed to kitchen display'),
  review: <T>(payload: unknown) =>
    post<T>(restaurantConfig.n8nWebhooks.reviewUrl, payload, 'Review intent logged'),
};
