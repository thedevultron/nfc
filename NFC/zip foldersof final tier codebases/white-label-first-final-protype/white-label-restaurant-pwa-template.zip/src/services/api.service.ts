/**
 * ============================================================================
 *  SERVICE LAYER ▸ APPLICATION API (business-facing façade)
 * ============================================================================
 *  Components import ONLY this file. It normalises payloads and delegates the
 *  transport to n8n.service.ts. Deep-link builders (WhatsApp / WiFi QR) also
 *  live here so no component ever hard-codes a URL.
 * ============================================================================
 */

import { restaurantConfig } from '../config/restaurant.config';
import { n8nService } from './n8n.service';
import type {
  ApiResult,
  FeedbackPayload,
  OrderPayload,
  ReservationPayload,
} from '../types/menu.types';

const { brand, order: orderCfg } = restaurantConfig;

export const apiService = {
  /** Module E — Table Reservation Drawer */
  async sendReservation(payload: ReservationPayload): Promise<ApiResult> {
    return n8nService.reservation({ type: 'reservation', venue: brand.name, ...payload });
  },

  /** Module D — private (<4★) feedback branch */
  async sendFeedback(payload: FeedbackPayload): Promise<ApiResult> {
    return n8nService.feedback({ type: 'private_feedback', venue: brand.name, ...payload });
  },

  /** Module D — public (4★+) review intent tracking */
  async trackReviewIntent(rating: number): Promise<ApiResult> {
    return n8nService.review({ type: 'public_review_intent', venue: brand.name, rating });
  },

  /** Module C — order dispatch (kitchen webhook + optional WhatsApp handoff) */
  async placeOrder(payload: OrderPayload): Promise<ApiResult<{ whatsappUrl?: string }>> {
    const result =
      orderCfg.channel === 'whatsapp'
        ? { success: true, message: 'Order handed to WhatsApp', simulated: true }
        : await n8nService.order(payload);

    const whatsappUrl =
      orderCfg.channel === 'webhook' ? undefined : buildWhatsAppUrl(formatOrderMessage(payload));

    return { ...result, data: { whatsappUrl } };
  },
};

/* ── Deep-link builders ───────────────────────────────────────────────────── */

export const buildWhatsAppUrl = (message: string) =>
  `https://wa.me/${brand.whatsappNumber.replace(/[^\d]/g, '')}?text=${encodeURIComponent(message)}`;

export const formatOrderMessage = (p: OrderPayload) => {
  const lines = p.lines.map((l) => `• ${l.qty} × ${l.name} — ${brand.currency}${l.qty * l.price}`).join('\n');
  return [
    `*New Order — ${brand.name}*`,
    `Table: ${p.table}  |  Mode: ${p.mode}`,
    '',
    lines,
    '',
    `Subtotal: ${brand.currency}${p.totals.subtotal}`,
    p.totals.tax ? `Tax: ${brand.currency}${p.totals.tax}` : '',
    p.totals.service ? `Service: ${brand.currency}${p.totals.service}` : '',
    `*Total: ${brand.currency}${p.totals.total}*`,
    p.note ? `\nNote: ${p.note}` : '',
  ]
    .filter(Boolean)
    .join('\n');
};

/** WiFi QR payload — rendered as a pure-SVG QR (no image assets). */
export const buildWifiQrPayload = () =>
  `WIFI:T:${brand.wifi.encryption};S:${brand.wifi.ssid};P:${brand.wifi.pass};;`;
