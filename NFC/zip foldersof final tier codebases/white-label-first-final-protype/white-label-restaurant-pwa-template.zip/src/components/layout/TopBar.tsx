/**
 * LAYOUT ▸ TopBar — brand identity row.
 * Brand "logo" is a Lucide icon (config.brand.logoIcon) — no image assets.
 */
import { motion } from 'framer-motion';
import { Download, Share2 } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useHaptics } from '../../hooks/useHaptics';
import { Icon } from '../ui/Icon';
import { SPRING } from '../ui/Button';

export function TopBar() {
  const { brand } = restaurantConfig;
  const { canInstall, promptInstall } = usePWAInstall();
  const haptics = useHaptics();

  const share = async () => {
    haptics.tap();
    const data = { title: brand.name, text: brand.subtitle, url: window.location.href };
    if (navigator.share) await navigator.share(data).catch(() => {});
    else await navigator.clipboard?.writeText(window.location.href).catch(() => {});
  };

  return (
    <div className="flex items-center gap-3">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={SPRING}
        className="grid h-12 w-12 shrink-0 place-items-center rounded-[calc(var(--radius)*0.85)] bg-gradient-to-br from-[var(--brand)] to-[var(--accent)] text-black shadow-lg"
      >
        <Icon name={brand.logoIcon} className="h-6 w-6" strokeWidth={2.1} />
      </motion.div>

      <div className="min-w-0 flex-1">
        <h1
          className="truncate text-[19px] leading-tight font-extrabold tracking-tight text-white"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          {brand.name}
        </h1>
        <p className="truncate text-[12px] text-white/45">{brand.subtitle}</p>
      </div>

      {canInstall && (
        <motion.button
          whileTap={{ scale: 0.92 }}
          transition={SPRING}
          onClick={() => {
            haptics.select();
            void promptInstall();
          }}
          className="touch-target grid place-items-center rounded-full bg-[var(--brand)]/15 text-[var(--brand)] ring-1 ring-[var(--brand)]/30 ring-inset"
          aria-label="Install app"
        >
          <Download className="h-5 w-5" />
        </motion.button>
      )}

      <motion.button
        whileTap={{ scale: 0.92 }}
        transition={SPRING}
        onClick={share}
        className="touch-target grid place-items-center rounded-full bg-white/6 text-white/60 ring-1 ring-white/10 ring-inset"
        aria-label="Share"
      >
        <Share2 className="h-5 w-5" />
      </motion.button>
    </div>
  );
}
