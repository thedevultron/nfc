/**
 * LAYOUT ▸ Shell
 * The single integration point: Header (Module A) + animated tab viewport +
 * BottomNav + all drawers. Tab content is switched through AnimatePresence
 * with directional spring transitions.
 *
 * NOTE FOR INTEGRATORS: nothing in this file is client-specific. Feature
 * availability, labels, icons and colours all resolve from /src/config.
 */
import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CalendarDays, Sparkles } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { buildWhatsAppUrl } from '../../services/api.service';
import { useHaptics } from '../../hooks/useHaptics';
import { Header, type QuickActionId } from './Header';
import { BottomNav } from './BottomNav';
import { MenuList } from '../features/MenuList';
import { CartSheet } from '../features/CartSheet';
import { ReviewModal } from '../features/ReviewModal';
import { ReservationSheet } from '../features/ReservationSheet';
import { WifiModal } from '../features/WifiModal';
import { InfoPanel } from '../features/InfoPanel';
import { Button, SPRING } from '../ui/Button';

export function Shell() {
  const [tab, setTab] = useState(restaurantConfig.navigation[0]?.id ?? 'menu');
  const [wifiOpen, setWifiOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const haptics = useHaptics();

  const handleAction = (id: QuickActionId | 'wifi' | 'review' | 'booking') => {
    switch (id) {
      case 'wifi':
        return setWifiOpen(true);
      case 'review':
        return setReviewOpen(true);
      case 'booking':
        return setBookingOpen(true);
      case 'whatsapp':
        haptics.select();
        return window.open(
          buildWhatsAppUrl(`Hi ${restaurantConfig.brand.name}! I'd like some help with my order.`),
          '_blank',
          'noopener',
        );
    }
  };

  return (
    <div className="min-h-screen bg-[rgb(var(--surface))]">
      {/* Ambient brand glow — pure CSS, no images */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-x-0 top-0 h-72 opacity-40"
        style={{
          background:
            'radial-gradient(120% 80% at 20% 0%, color-mix(in srgb, var(--brand) 34%, transparent), transparent 60%), radial-gradient(90% 70% at 90% 5%, color-mix(in srgb, var(--accent) 22%, transparent), transparent 60%)',
        }}
      />

      <div className="relative">
        <Header onAction={handleAction} />

        <main className="min-h-[70vh] pb-[calc(7.5rem+env(safe-area-inset-bottom))]">
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ ...SPRING, stiffness: 320, damping: 30 }}
            >
              {tab === 'menu' && <MenuList />}
              {tab === 'specials' && <MenuList onlySpecials />}
              {tab === 'book' && <BookingPanel onOpen={() => setBookingOpen(true)} />}
              {tab === 'info' && <InfoPanel onAction={handleAction} />}
            </motion.div>
          </AnimatePresence>
        </main>

        <BottomNav active={tab} onChange={setTab} />
      </div>

      {/* Drawers / dialogs — each gated by its config feature flag */}
      {restaurantConfig.features.enableDirectOrdering && <CartSheet />}
      {restaurantConfig.features.enableWifi && <WifiModal open={wifiOpen} onOpenChange={setWifiOpen} />}
      {restaurantConfig.features.enableReviews && <ReviewModal open={reviewOpen} onOpenChange={setReviewOpen} />}
      {restaurantConfig.features.enableBookings && (
        <ReservationSheet open={bookingOpen} onOpenChange={setBookingOpen} />
      )}
    </div>
  );
}

function BookingPanel({ onOpen }: { onOpen: () => void }) {
  const { brand, reservation } = restaurantConfig;
  return (
    <div className="mx-auto max-w-lg space-y-4 px-4 py-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={SPRING}
        className="rounded-[var(--radius)] bg-gradient-to-br from-[var(--brand)]/20 via-white/5 to-transparent p-6 text-center ring-1 ring-white/10 ring-inset"
      >
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[var(--brand)]/18 text-[var(--brand)]">
          <CalendarDays className="h-7 w-7" />
        </div>
        <h2
          className="mt-4 text-[20px] font-extrabold tracking-tight text-white"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          Reserve your table
        </h2>
        <p className="mx-auto mt-1.5 max-w-[18rem] text-[13px] leading-relaxed text-white/50">
          {brand.hours} · parties up to {reservation.maxGuests}. Instant confirmation via WhatsApp.
        </p>
        <Button size="lg" className="mt-5" onClick={onOpen}>
          <CalendarDays className="h-4.5 w-4.5" /> Open booking sheet
        </Button>
      </motion.div>

      <div className="grid grid-cols-3 gap-2.5">
        {[
          { icon: 'Timer', label: 'Avg wait', value: '12 min' },
          { icon: 'Users', label: 'Max party', value: `${reservation.maxGuests}` },
          { icon: 'Sparkles', label: 'Slots today', value: `${reservation.timeSlots.length}` },
        ].map((s) => (
          <div
            key={s.label}
            className="rounded-[calc(var(--radius)*0.8)] bg-white/5 p-3 text-center ring-1 ring-white/8 ring-inset"
          >
            <Sparkles className="mx-auto h-4 w-4 text-[var(--brand)]" />
            <p className="mt-1.5 text-[15px] font-extrabold text-white">{s.value}</p>
            <p className="text-[10.5px] text-white/40">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
