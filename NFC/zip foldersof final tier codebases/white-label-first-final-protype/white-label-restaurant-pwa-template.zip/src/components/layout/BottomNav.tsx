/**
 * LAYOUT ▸ Fixed Bottom Navigation
 * Tabs are rendered from restaurantConfig.navigation (labels + Lucide names).
 * The active pill uses a shared `layoutId` so it physically slides between tabs.
 * Includes the floating cart FAB with an animated live counter.
 */
import { AnimatePresence, motion } from 'framer-motion';
import { ShoppingBag } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { useCart } from '../../hooks/useCart';
import { useHaptics } from '../../hooks/useHaptics';
import { Icon } from '../ui/Icon';
import { SPRING } from '../ui/Button';

export function BottomNav({ active, onChange }: { active: string; onChange: (id: string) => void }) {
  const cart = useCart();
  const haptics = useHaptics();
  const { navigation, features } = restaurantConfig;

  // Tabs whose feature flag is off are removed from the shell entirely.
  const tabs = navigation.filter((t) => (t.id === 'book' ? features.enableBookings : true));

  return (
    <>
      {features.enableDirectOrdering && (
        <AnimatePresence>
          {cart.count > 0 && !cart.isOpen && (
            <motion.button
              initial={{ y: 80, opacity: 0, scale: 0.8 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 80, opacity: 0, scale: 0.8 }}
              whileTap={{ scale: 0.94 }}
              transition={SPRING}
              onClick={() => {
                haptics.select();
                cart.open();
              }}
              className="brand-glow fixed right-4 bottom-[calc(5.5rem+env(safe-area-inset-bottom))] z-40 flex h-14 items-center gap-3 rounded-full bg-[var(--brand)] pr-5 pl-4 font-bold text-black"
            >
              <span className="relative grid h-9 w-9 place-items-center rounded-full bg-black/15">
                <ShoppingBag className="h-4.5 w-4.5" />
              </span>
              <span className="flex flex-col items-start leading-none">
                <span className="text-[10px] font-bold tracking-wider opacity-70 uppercase">
                  {cart.count} item{cart.count > 1 ? 's' : ''}
                </span>
                <span className="mt-0.5 text-sm">
                  {restaurantConfig.brand.currency}
                  {cart.total}
                </span>
              </span>
            </motion.button>
          )}
        </AnimatePresence>
      )}

      <nav className="fixed inset-x-0 bottom-0 z-40">
        <div className="glass mx-auto flex max-w-lg items-stretch gap-1 border-t border-white/10 px-2 pt-2 pb-[max(env(safe-area-inset-bottom),0.6rem)]">
          {tabs.map((tab) => {
            const isActive = active === tab.id;
            return (
              <motion.button
                key={tab.id}
                whileTap={{ scale: 0.9 }}
                transition={SPRING}
                onClick={() => {
                  haptics.tap();
                  onChange(tab.id);
                }}
                className="touch-target relative flex flex-1 flex-col items-center justify-center gap-1 rounded-[calc(var(--radius)*0.7)] py-1.5"
                aria-current={isActive ? 'page' : undefined}
              >
                {isActive && (
                  <motion.span
                    layoutId="nav-pill"
                    transition={SPRING}
                    className="absolute inset-0 rounded-[calc(var(--radius)*0.7)] bg-[var(--brand)]/14 ring-1 ring-[var(--brand)]/25 ring-inset"
                  />
                )}
                <Icon
                  name={tab.icon}
                  className={`relative z-10 h-5 w-5 transition-colors ${isActive ? 'text-[var(--brand)]' : 'text-white/45'}`}
                />
                <span
                  className={`relative z-10 text-[10.5px] font-semibold transition-colors ${isActive ? 'text-[var(--brand)]' : 'text-white/45'}`}
                >
                  {tab.label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
