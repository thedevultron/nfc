/**
 * MODULE A ▸ Dynamic Action Header
 * ─────────────────────────────────────────────────────────────────────────
 *  • NFC touchpoint badge (Table 04 | Tap Mode Active / Takeaway Mode)
 *  • Quick action grid rendered from restaurantConfig.quickActions[]
 *    Each tile is gated by its `flag` — disabling a feature in config removes
 *    the tile automatically, no JSX edits required.
 */
import { motion } from 'framer-motion';
import { Nfc, ChevronRight } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { useTouchpoint } from '../../hooks/useTouchpoint';
import { useHaptics } from '../../hooks/useHaptics';
import { Icon } from '../ui/Icon';
import { SPRING } from '../ui/Button';
import { TopBar } from './TopBar';

export type QuickActionId = 'wifi' | 'whatsapp' | 'review' | 'booking';

export function Header({ onAction }: { onAction: (id: QuickActionId) => void }) {
  const { quickActions, features, brand } = restaurantConfig;
  const touchpoint = useTouchpoint();
  const haptics = useHaptics();

  const actions = quickActions.filter((a) => features[a.flag]);

  return (
    <header className="relative z-30 border-b border-white/8">
      <div className="mx-auto max-w-lg px-4 pt-safe pb-3">
        <TopBar />

        {/* NFC / QR context strip */}
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...SPRING, delay: 0.05 }}
          className="mt-3 flex items-center gap-2 rounded-full bg-[var(--brand)]/10 py-2 pr-3 pl-3 ring-1 ring-[var(--brand)]/25 ring-inset"
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[var(--brand)] opacity-70" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--brand)]" />
          </span>
          <Nfc className="h-4 w-4 text-[var(--brand)]" />
          <span className="flex-1 truncate text-[12.5px] font-semibold text-[var(--brand)]">
            {touchpoint.label}
          </span>
          <span className="text-[11px] font-medium text-white/40">{brand.hours.split('·')[0]}</span>
        </motion.div>

        {/* Quick action grid — 100% Lucide icon driven */}
        {actions.length > 0 && (
          <div className="mt-3 grid grid-cols-4 gap-2">
            {actions.map((action, i) => (
              <motion.button
                key={action.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...SPRING, delay: 0.04 * i }}
                whileTap={{ scale: 0.93 }}
                onClick={() => {
                  haptics.select();
                  onAction(action.id as QuickActionId);
                }}
                className="touch-target group relative flex flex-col items-center justify-center gap-1.5 overflow-hidden rounded-[calc(var(--radius)*0.8)] bg-white/6 py-3 ring-1 ring-white/10 ring-inset active:bg-white/12"
              >
                <Icon name={action.icon} className="h-5 w-5 text-[var(--brand)]" />
                <span className="text-[10.5px] leading-tight font-semibold text-white/70">{action.label}</span>
                <ChevronRight className="absolute top-1.5 right-1.5 h-3 w-3 text-white/15" />
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
