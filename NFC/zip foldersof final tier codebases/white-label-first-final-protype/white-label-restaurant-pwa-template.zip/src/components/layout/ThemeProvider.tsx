/**
 * LAYOUT ▸ ThemeProvider
 * Bridges /src/config/theme.config.ts → CSS custom properties.
 * This is the ONLY place theme tokens are applied; every component consumes
 * `var(--brand)`, `var(--radius)` etc. Re-skinning a client = editing config.
 */
import { useEffect, type ReactNode } from 'react';
import { themeConfig } from '../../config/theme.config';

export function ThemeProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    const r = document.documentElement.style;
    r.setProperty('--brand', themeConfig.primaryColor);
    r.setProperty('--accent', themeConfig.accentColor);
    r.setProperty('--radius', themeConfig.radius);
    r.setProperty('--pad', themeConfig.density === 'compact' ? '0.75rem' : '1.1rem');
    r.setProperty('--glass', themeConfig.enableGlassmorphism ? '0.55' : '1');
    r.setProperty('--font-body', themeConfig.fonts.body);
    r.setProperty('--font-display', themeConfig.fonts.display);

    if (themeConfig.defaultMode === 'light') {
      r.setProperty('--surface', '248 250 249');
      r.setProperty('--surface-2', '255 255 255');
      r.setProperty('--text', '17 24 20');
      r.setProperty('--muted', '100 112 106');
    }
  }, []);

  return <>{children}</>;
}
