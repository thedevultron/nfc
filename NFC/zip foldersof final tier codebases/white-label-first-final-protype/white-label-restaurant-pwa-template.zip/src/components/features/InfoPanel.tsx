/**
 * FEATURE ▸ Venue Info tab
 * Every row is rendered from restaurantConfig.brand — the engineering layer
 * has zero hard-coded business strings.
 */
import { motion } from 'framer-motion';
import { restaurantConfig } from '../../config/restaurant.config';
import { buildWhatsAppUrl } from '../../services/api.service';
import { useHaptics } from '../../hooks/useHaptics';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { Icon } from '../ui/Icon';
import { Button, SPRING } from '../ui/Button';

export function InfoPanel({ onAction }: { onAction: (id: 'wifi' | 'review' | 'booking') => void }) {
  const { brand, features } = restaurantConfig;
  const haptics = useHaptics();
  const { canInstall, installed, promptInstall } = usePWAInstall();

  const rows = [
    { icon: 'MapPin', label: 'Address', value: brand.address },
    { icon: 'Clock', label: 'Hours', value: brand.hours },
    { icon: 'Phone', label: 'Phone', value: brand.phone },
    { icon: 'Wifi', label: 'Guest WiFi', value: brand.wifi.ssid },
  ];

  return (
    <div className="mx-auto max-w-lg space-y-4 px-4 py-5">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={SPRING}
        className="overflow-hidden rounded-[var(--radius)] bg-gradient-to-br from-[var(--brand)]/18 via-white/5 to-[var(--accent)]/12 p-5 ring-1 ring-white/10 ring-inset"
      >
        <Icon name={brand.logoIcon} className="h-8 w-8 text-[var(--brand)]" />
        <h2
          className="mt-3 text-[20px] font-extrabold tracking-tight text-white"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          {brand.name}
        </h2>
        <p className="mt-1 text-[13px] text-white/55">{brand.tagline}</p>
      </motion.div>

      <div className="divide-y divide-white/6 overflow-hidden rounded-[var(--radius)] bg-white/[0.045] ring-1 ring-white/8 ring-inset">
        {rows.map((r, i) => (
          <motion.div
            key={r.label}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ ...SPRING, delay: i * 0.04 }}
            className="flex items-start gap-3 p-3.5"
          >
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/6 text-[var(--brand)]">
              <Icon name={r.icon} className="h-4 w-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[10.5px] font-bold tracking-wider text-white/35 uppercase">{r.label}</p>
              <p className="mt-0.5 text-[13.5px] leading-snug text-white/80">{r.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {features.enableWhatsApp && (
          <Button
            variant="secondary"
            size="lg"
            onClick={() => {
              haptics.select();
              window.open(
                buildWhatsAppUrl(`Hi ${brand.name}, I have a question about my visit.`),
                '_blank',
                'noopener',
              );
            }}
          >
            <Icon name="MessageCircle" className="h-4.5 w-4.5" /> WhatsApp
          </Button>
        )}
        <Button variant="secondary" size="lg" onClick={() => window.open(`tel:${brand.phone}`)}>
          <Icon name="Phone" className="h-4.5 w-4.5" /> Call
        </Button>
        {features.enableWifi && (
          <Button variant="secondary" size="lg" onClick={() => onAction('wifi')}>
            <Icon name="Wifi" className="h-4.5 w-4.5" /> WiFi
          </Button>
        )}
        {features.enableReviews && (
          <Button variant="secondary" size="lg" onClick={() => onAction('review')}>
            <Icon name="Star" className="h-4.5 w-4.5" /> Rate Us
          </Button>
        )}
      </div>

      {features.enablePWAInstall && !installed && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={SPRING}
          className="flex items-center gap-3 rounded-[var(--radius)] bg-white/5 p-4 ring-1 ring-white/10 ring-inset"
        >
          <Icon name="Smartphone" className="h-6 w-6 shrink-0 text-[var(--brand)]" />
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] font-bold text-white">Install the app</p>
            <p className="text-[12px] text-white/45">
              {canInstall ? 'One tap — no app store needed.' : 'Use “Add to Home Screen” in your browser menu.'}
            </p>
          </div>
          {canInstall && (
            <Button size="sm" onClick={() => void promptInstall()}>
              Install
            </Button>
          )}
        </motion.div>
      )}

      <p className="pt-2 text-center text-[11px] leading-relaxed text-white/25">
        White-label PWA template · all content driven by <span className="font-mono">/src/config</span>
      </p>
    </div>
  );
}
