/**
 * MODULE E ▸ Table Reservation Drawer
 * Calendar strip · time-slot chips (config-driven) · guest stepper ·
 * occasion chips → apiService.sendReservation() → n8n webhook,
 * with optimistic success UI.
 */
import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CalendarDays, CheckCircle2, Clock, Minus, Plus, Users } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { apiService } from '../../services/api.service';
import { useHaptics } from '../../hooks/useHaptics';
import { useTouchpoint } from '../../hooks/useTouchpoint';
import { Button, SPRING } from '../ui/Button';
import { Sheet } from '../ui/Sheet';
import { Input, Label } from '../ui/Field';
import { cn } from '../../utils/cn';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function ReservationSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const haptics = useHaptics();
  const touchpoint = useTouchpoint();
  const cfg = restaurantConfig.reservation;

  const dates = useMemo(
    () =>
      Array.from({ length: 14 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() + i);
        return d;
      }),
    [],
  );

  const [dateIdx, setDateIdx] = useState(0);
  const [time, setTime] = useState(cfg.timeSlots[Math.min(3, cfg.timeSlots.length - 1)]);
  const [guests, setGuests] = useState(2);
  const [occasion, setOccasion] = useState(cfg.occasions[0]);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [state, setState] = useState<'idle' | 'sending' | 'done'>('idle');

  const valid = name.trim().length > 1 && phone.trim().length >= 8;

  const submit = async () => {
    if (!valid) return;
    setState('sending');
    haptics.select();
    await apiService.sendReservation({
      name,
      phone,
      date: dates[dateIdx].toISOString().slice(0, 10),
      time,
      guests,
      occasion,
      table: touchpoint.table,
    });
    setState('done');
    haptics.success();
    setTimeout(() => {
      onOpenChange(false);
      setTimeout(() => setState('idle'), 400);
    }, 2400);
  };

  const stepGuests = (delta: number) => {
    haptics.tap();
    setGuests((g) => Math.min(cfg.maxGuests, Math.max(cfg.minGuests, g + delta)));
  };

  return (
    <Sheet
      open={open}
      onOpenChange={onOpenChange}
      title="Reserve a Table"
      subtitle={`${restaurantConfig.brand.name} · ${restaurantConfig.brand.hours}`}
      icon={<CalendarDays className="h-5 w-5" />}
      footer={
        state !== 'done' && (
          <Button full size="lg" disabled={!valid || state === 'sending'} onClick={submit}>
            {state === 'sending' ? 'Confirming…' : `Request ${guests} seat${guests > 1 ? 's' : ''} · ${time}`}
          </Button>
        )
      }
    >
      <AnimatePresence mode="wait">
        {state === 'done' ? (
          <motion.div
            key="done"
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={SPRING}
            className="py-12 text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ ...SPRING, delay: 0.08 }}
              className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[var(--brand)]/15"
            >
              <CheckCircle2 className="h-8 w-8 text-[var(--brand)]" />
            </motion.div>
            <p className="mt-4 text-[15px] font-bold text-white">Table request sent</p>
            <p className="mt-1 px-6 text-[12.5px] leading-relaxed text-white/45">
              {dates[dateIdx].toDateString()} at {time} for {guests}. You'll get a WhatsApp confirmation shortly.
            </p>
          </motion.div>
        ) : (
          <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5 pt-1">
            {/* Date strip */}
            <div>
              <Label icon="CalendarDays">Select date</Label>
              <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
                {dates.map((d, i) => {
                  const active = i === dateIdx;
                  return (
                    <motion.button
                      key={i}
                      whileTap={{ scale: 0.92 }}
                      transition={SPRING}
                      onClick={() => {
                        haptics.tap();
                        setDateIdx(i);
                      }}
                      className="relative flex h-16 w-14 shrink-0 flex-col items-center justify-center rounded-[calc(var(--radius)*0.7)]"
                    >
                      {active && (
                        <motion.span
                          layoutId="date-pill"
                          transition={SPRING}
                          className="absolute inset-0 rounded-[calc(var(--radius)*0.7)] bg-[var(--brand)]"
                        />
                      )}
                      {!active && (
                        <span className="absolute inset-0 rounded-[calc(var(--radius)*0.7)] bg-white/6 ring-1 ring-white/10 ring-inset" />
                      )}
                      <span
                        className={cn(
                          'relative z-10 text-[10.5px] font-bold uppercase',
                          active ? 'text-black/60' : 'text-white/40',
                        )}
                      >
                        {i === 0 ? 'Today' : DAYS[d.getDay()]}
                      </span>
                      <span
                        className={cn(
                          'relative z-10 text-[17px] font-extrabold',
                          active ? 'text-black' : 'text-white/80',
                        )}
                      >
                        {d.getDate()}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Time slots */}
            <div>
              <Label icon="Clock">Time slot</Label>
              <div className="grid grid-cols-4 gap-2">
                {cfg.timeSlots.map((slot) => {
                  const active = slot === time;
                  return (
                    <motion.button
                      key={slot}
                      whileTap={{ scale: 0.92 }}
                      transition={SPRING}
                      onClick={() => {
                        haptics.tap();
                        setTime(slot);
                      }}
                      className={cn(
                        'relative flex h-11 items-center justify-center gap-1 rounded-full text-[12.5px] font-bold ring-1 ring-inset transition-colors',
                        active
                          ? 'bg-[var(--brand)] text-black ring-transparent'
                          : 'bg-white/6 text-white/65 ring-white/10',
                      )}
                    >
                      <Clock className="h-3.5 w-3.5" />
                      {slot}
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Guests */}
            <div>
              <Label icon="Users">Guests</Label>
              <div className="flex items-center justify-between rounded-[calc(var(--radius)*0.8)] bg-white/6 p-2 ring-1 ring-white/10 ring-inset">
                <motion.button
                  whileTap={{ scale: 0.88 }}
                  transition={SPRING}
                  onClick={() => stepGuests(-1)}
                  className="touch-target grid place-items-center rounded-full bg-white/8 text-white/70"
                  aria-label="Fewer guests"
                >
                  <Minus className="h-4.5 w-4.5" />
                </motion.button>
                <div className="flex items-center gap-2">
                  <Users className="h-4.5 w-4.5 text-[var(--brand)]" />
                  <AnimatePresence mode="popLayout" initial={false}>
                    <motion.span
                      key={guests}
                      initial={{ y: -12, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      exit={{ y: 12, opacity: 0 }}
                      transition={SPRING}
                      className="text-xl font-extrabold text-white"
                    >
                      {guests}
                    </motion.span>
                  </AnimatePresence>
                  <span className="text-[12.5px] text-white/40">guests</span>
                </div>
                <motion.button
                  whileTap={{ scale: 0.88 }}
                  transition={SPRING}
                  onClick={() => stepGuests(1)}
                  className="touch-target grid place-items-center rounded-full bg-[var(--brand)] text-black"
                  aria-label="More guests"
                >
                  <Plus className="h-4.5 w-4.5" />
                </motion.button>
              </div>
            </div>

            {/* Occasion */}
            <div>
              <Label icon="PartyPopper">Occasion</Label>
              <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1">
                {cfg.occasions.map((o) => {
                  const active = o === occasion;
                  return (
                    <motion.button
                      key={o}
                      whileTap={{ scale: 0.93 }}
                      transition={SPRING}
                      onClick={() => {
                        haptics.tap();
                        setOccasion(o);
                      }}
                      className={cn(
                        'h-10 shrink-0 rounded-full px-3.5 text-[12.5px] font-semibold ring-1 ring-inset transition-colors',
                        active
                          ? 'bg-[var(--brand)] text-black ring-transparent'
                          : 'bg-white/6 text-white/60 ring-white/10',
                      )}
                    >
                      {o}
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Contact */}
            <div className="grid gap-3">
              <div>
                <Label icon="User">Full name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Aditi Sharma" />
              </div>
              <div>
                <Label icon="Phone">Mobile number</Label>
                <Input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  inputMode="tel"
                  placeholder="+91 ..."
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Sheet>
  );
}
