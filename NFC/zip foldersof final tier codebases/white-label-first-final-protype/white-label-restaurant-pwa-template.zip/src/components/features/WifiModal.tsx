/**
 * FEATURE ▸ Instant WiFi
 * SSID + password + a live SVG QR (WIFI: payload built in api.service.ts).
 * Pure vector — no image assets anywhere in this template.
 */
import { useState } from 'react';
import { motion } from 'framer-motion';
import { QRCodeSVG } from 'qrcode.react';
import { Check, Copy, QrCode, Wifi } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { buildWifiQrPayload } from '../../services/api.service';
import { useHaptics } from '../../hooks/useHaptics';
import { Sheet } from '../ui/Sheet';
import { SPRING } from '../ui/Button';

export function WifiModal({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { wifi } = restaurantConfig.brand;
  const haptics = useHaptics();
  const [copied, setCopied] = useState<string | null>(null);

  const copy = async (label: string, value: string) => {
    haptics.tap();
    await navigator.clipboard?.writeText(value).catch(() => {});
    setCopied(label);
    setTimeout(() => setCopied(null), 1600);
  };

  return (
    <Sheet
      open={open}
      onOpenChange={onOpenChange}
      variant="dialog"
      title="Guest WiFi"
      subtitle="Scan or tap to copy"
      icon={<Wifi className="h-5 w-5" />}
    >
      <div className="space-y-4 pb-2">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={SPRING}
          className="mx-auto w-fit rounded-[var(--radius)] bg-white p-3.5"
        >
          <QRCodeSVG value={buildWifiQrPayload()} size={168} level="M" marginSize={0} />
        </motion.div>

        <p className="flex items-center justify-center gap-1.5 text-[11.5px] text-white/40">
          <QrCode className="h-3.5 w-3.5" /> Point your camera to auto-join
        </p>

        {[
          { label: 'Network', value: wifi.ssid, icon: Wifi },
          { label: 'Password', value: wifi.pass, icon: Copy },
        ].map((row) => (
          <motion.button
            key={row.label}
            whileTap={{ scale: 0.97 }}
            transition={SPRING}
            onClick={() => copy(row.label, row.value)}
            className="flex w-full items-center gap-3 rounded-[calc(var(--radius)*0.8)] bg-white/6 p-3 text-left ring-1 ring-white/10 ring-inset"
          >
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[var(--brand)]/15 text-[var(--brand)]">
              <row.icon className="h-4.5 w-4.5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[10.5px] font-bold tracking-wider text-white/40 uppercase">{row.label}</p>
              <p className="truncate font-mono text-[14px] font-semibold text-white">{row.value}</p>
            </div>
            {copied === row.label ? (
              <Check className="h-4.5 w-4.5 text-[var(--brand)]" />
            ) : (
              <Copy className="h-4.5 w-4.5 text-white/30" />
            )}
          </motion.button>
        ))}
      </div>
    </Sheet>
  );
}
