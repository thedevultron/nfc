/**
 * MODULE D ▸ Smart Review & Feedback Filter
 * ─────────────────────────────────────────────────────────────────────────
 *  rating >= 4 → high-visibility "Post Public Review on Google" CTA
 *                (URL from restaurantConfig.brand.googleReviewUrl)
 *  rating <  4 → private manager feedback form → apiService.sendFeedback()
 *                so negative sentiment is captured before it goes public.
 */
import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, ExternalLink, MessageSquareHeart, ShieldCheck, Star } from 'lucide-react';
import { feedbackTopics } from '../../config/menuData';
import { restaurantConfig } from '../../config/restaurant.config';
import { apiService } from '../../services/api.service';
import { useHaptics } from '../../hooks/useHaptics';
import { useTouchpoint } from '../../hooks/useTouchpoint';
import { Button, SPRING } from '../ui/Button';
import { Sheet } from '../ui/Sheet';
import { Input, Label, Textarea } from '../ui/Field';
import { cn } from '../../utils/cn';

const RATING_COPY: Record<number, string> = {
  1: 'We let you down. Tell us everything.',
  2: 'Not good enough — what went wrong?',
  3: 'Almost there. How do we improve?',
  4: 'Great! Mind sharing that publicly?',
  5: 'Outstanding! Help others find us ⭐',
};

export function ReviewModal({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const haptics = useHaptics();
  const touchpoint = useTouchpoint();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [topics, setTopics] = useState<string[]>([]);
  const [message, setMessage] = useState('');
  const [contact, setContact] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  const reset = () => {
    setRating(0);
    setTopics([]);
    setMessage('');
    setContact('');
    setSent(false);
  };

  const submitPrivate = async () => {
    setBusy(true);
    haptics.select();
    await apiService.sendFeedback({ rating, categories: topics, message, contact, table: touchpoint.table });
    setBusy(false);
    setSent(true);
    haptics.success();
    setTimeout(() => {
      onOpenChange(false);
      setTimeout(reset, 400);
    }, 2200);
  };

  const goPublic = async () => {
    haptics.success();
    await apiService.trackReviewIntent(rating);
    window.open(restaurantConfig.brand.googleReviewUrl, '_blank', 'noopener');
    onOpenChange(false);
    setTimeout(reset, 400);
  };

  return (
    <Sheet
      open={open}
      onOpenChange={onOpenChange}
      title="How was your experience?"
      subtitle="Takes 15 seconds · helps us get better"
      icon={<MessageSquareHeart className="h-5 w-5" />}
    >
      {sent ? (
        <SuccessState />
      ) : (
        <div className="pb-2">
          {/* Star selector */}
          <div className="flex justify-center gap-1.5 py-4">
            {[1, 2, 3, 4, 5].map((n) => {
              const filled = n <= (hover || rating);
              return (
                <motion.button
                  key={n}
                  whileTap={{ scale: 0.82 }}
                  whileHover={{ scale: 1.12 }}
                  transition={SPRING}
                  onMouseEnter={() => setHover(n)}
                  onMouseLeave={() => setHover(0)}
                  onClick={() => {
                    haptics.tap();
                    setRating(n);
                  }}
                  className="touch-target grid place-items-center"
                  aria-label={`${n} star`}
                >
                  <Star
                    className={cn(
                      'h-9 w-9 transition-colors',
                      filled ? 'fill-[var(--accent)] text-[var(--accent)]' : 'text-white/20',
                    )}
                  />
                </motion.button>
              );
            })}
          </div>

          <AnimatePresence mode="wait">
            {rating > 0 && (
              <motion.p
                key={rating}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="text-center text-[13.5px] font-semibold text-white/70"
              >
                {RATING_COPY[rating]}
              </motion.p>
            )}
          </AnimatePresence>

          {/* Branch */}
          <AnimatePresence mode="wait">
            {rating >= 4 && (
              <motion.div
                key="public"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                transition={SPRING}
                className="mt-5 space-y-3"
              >
                <div className="rounded-[var(--radius)] bg-gradient-to-br from-[var(--brand)]/18 to-[var(--accent)]/10 p-4 ring-1 ring-[var(--brand)]/25 ring-inset">
                  <p className="text-[13px] leading-relaxed text-white/75">
                    You just made our day. A public review takes 20 seconds and directly helps our team.
                  </p>
                </div>
                <Button full size="lg" onClick={goPublic}>
                  <ExternalLink className="h-4.5 w-4.5" /> Post Public Review on Google
                </Button>
                <Button full size="md" variant="ghost" onClick={() => onOpenChange(false)}>
                  Maybe later
                </Button>
              </motion.div>
            )}

            {rating > 0 && rating < 4 && (
              <motion.div
                key="private"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                transition={SPRING}
                className="mt-5 space-y-4"
              >
                <div className="flex items-start gap-2.5 rounded-[var(--radius)] bg-white/5 p-3.5 ring-1 ring-white/10 ring-inset">
                  <ShieldCheck className="mt-0.5 h-4.5 w-4.5 shrink-0 text-[var(--brand)]" />
                  <p className="text-[12.5px] leading-relaxed text-white/60">
                    <span className="font-semibold text-white/85">Private channel.</span> This goes straight to the
                    manager on duty — not to a public listing.
                  </p>
                </div>

                <div>
                  <Label icon="Tags">What can we improve?</Label>
                  <div className="flex flex-wrap gap-2">
                    {feedbackTopics.map((t) => {
                      const active = topics.includes(t);
                      return (
                        <motion.button
                          key={t}
                          whileTap={{ scale: 0.93 }}
                          transition={SPRING}
                          onClick={() => {
                            haptics.tap();
                            setTopics((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]));
                          }}
                          className={cn(
                            'h-10 rounded-full px-3.5 text-[12.5px] font-semibold ring-1 ring-inset transition-colors',
                            active
                              ? 'bg-[var(--brand)] text-black ring-transparent'
                              : 'bg-white/6 text-white/60 ring-white/10',
                          )}
                        >
                          {t}
                        </motion.button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <Label icon="SquarePen">Tell the Manager What We Can Improve</Label>
                  <Textarea
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Be blunt — it's the fastest way we fix things."
                  />
                </div>

                <div>
                  <Label icon="Phone">Contact (optional)</Label>
                  <Input
                    value={contact}
                    onChange={(e) => setContact(e.target.value)}
                    placeholder="Phone or email for a personal follow-up"
                  />
                </div>

                <Button full size="lg" disabled={busy} onClick={submitPrivate}>
                  {busy ? 'Sending privately…' : 'Send to Manager'}
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </Sheet>
  );
}

function SuccessState() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.94 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={SPRING}
      className="py-12 text-center"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ ...SPRING, delay: 0.08 }}
        className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[var(--brand)]/15"
      >
        <CheckCircle2 className="h-8 w-8 text-[var(--brand)]" />
      </motion.div>
      <p className="mt-4 text-[15px] font-bold text-white">Thank you — received</p>
      <p className="mt-1 px-6 text-[12.5px] leading-relaxed text-white/45">
        The duty manager has been notified instantly via our automation workflow.
      </p>
    </motion.div>
  );
}
