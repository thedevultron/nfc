/**
 * MODULE C ▸ Dynamic Cart Sheet
 * Bottom drawer · qty steppers with live pricing · special instructions ·
 * "Place Order via Kitchen / WhatsApp" → apiService.placeOrder() → n8n webhook
 * + URL-encoded WhatsApp handoff. Channel is chosen in restaurant.config.ts.
 */
import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Minus, Plus, ShoppingBag, SquarePen, Trash2 } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { apiService } from '../../services/api.service';
import { useCart } from '../../hooks/useCart';
import { useHaptics } from '../../hooks/useHaptics';
import { useTouchpoint } from '../../hooks/useTouchpoint';
import { Button, SPRING } from '../ui/Button';
import { Icon } from '../ui/Icon';
import { Sheet } from '../ui/Sheet';
import { Label, Textarea } from '../ui/Field';

export function CartSheet() {
  const cart = useCart();
  const haptics = useHaptics();
  const touchpoint = useTouchpoint();
  const [status, setStatus] = useState<'idle' | 'sending' | 'done'>('idle');
  const { currency } = restaurantConfig.brand;

  const submit = async () => {
    if (!cart.lines.length) return;
    setStatus('sending');
    haptics.select();

    const res = await apiService.placeOrder({
      table: touchpoint.table,
      mode: touchpoint.mode,
      lines: cart.lines.map((l) => ({ name: l.item.name, qty: l.qty, price: l.item.price })),
      note: cart.note,
      totals: { subtotal: cart.subtotal, tax: cart.tax, service: cart.service, total: cart.total },
    });

    setStatus('done');
    haptics.success();
    if (res.data?.whatsappUrl) window.open(res.data.whatsappUrl, '_blank', 'noopener');

    setTimeout(() => {
      cart.clear();
      cart.close();
      setStatus('idle');
    }, 1800);
  };

  return (
    <Sheet
      open={cart.isOpen}
      onOpenChange={cart.setOpen}
      title="Your Order"
      subtitle={`${touchpoint.label} · ${cart.count} item${cart.count === 1 ? '' : 's'}`}
      icon={<ShoppingBag className="h-5 w-5" />}
      footer={
        cart.lines.length > 0 && (
          <div className="space-y-3">
            <Row label="Subtotal" value={`${currency}${cart.subtotal}`} />
            {cart.tax > 0 && (
              <Row label={`Tax (${restaurantConfig.order.taxRatePercent}%)`} value={`${currency}${cart.tax}`} />
            )}
            {cart.service > 0 && (
              <Row
                label={`Service (${restaurantConfig.order.serviceChargePercent}%)`}
                value={`${currency}${cart.service}`}
              />
            )}
            <div className="flex items-center justify-between border-t border-white/8 pt-3">
              <span className="text-sm font-bold text-white">Total</span>
              <motion.span
                key={cart.total}
                initial={{ y: -8, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={SPRING}
                className="text-xl font-extrabold text-[var(--brand)]"
              >
                {currency}
                {cart.total}
              </motion.span>
            </div>
            <Button full size="lg" disabled={status !== 'idle'} onClick={submit}>
              {status === 'idle' && (
                <>
                  <Icon name="Send" className="h-4.5 w-4.5" /> Place Order via Kitchen / WhatsApp
                </>
              )}
              {status === 'sending' && (
                <>
                  <Icon name="LoaderCircle" className="h-4.5 w-4.5 animate-spin" /> Sending to kitchen…
                </>
              )}
              {status === 'done' && (
                <>
                  <CheckCircle2 className="h-4.5 w-4.5" /> Order Confirmed
                </>
              )}
            </Button>
            <p className="text-center text-[11px] text-white/30">
              Dispatched to n8n · channel: {restaurantConfig.order.channel}
            </p>
          </div>
        )
      }
    >
      {cart.lines.length === 0 ? (
        <div className="py-14 text-center">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-white/5">
            <ShoppingBag className="h-7 w-7 text-white/25" />
          </div>
          <p className="mt-4 text-sm font-semibold text-white/60">Your tray is empty</p>
          <p className="mt-1 text-[12.5px] text-white/35">Add something delicious from the menu.</p>
        </div>
      ) : (
        <div className="space-y-2.5 pt-1">
          <AnimatePresence initial={false}>
            {cart.lines.map((line) => (
              <motion.div
                key={line.item.id}
                layout
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 60, height: 0, marginBottom: 0 }}
                transition={SPRING}
                className="flex items-center gap-3 rounded-[calc(var(--radius)*0.85)] bg-white/5 p-2.5 ring-1 ring-white/8 ring-inset"
              >
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-[calc(var(--radius)*0.6)] bg-white/8 text-[var(--brand)]">
                  <Icon name={line.item.icon} className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-bold text-white">{line.item.name}</p>
                  <p className="text-[12px] font-semibold text-[var(--brand)]">
                    {currency}
                    {line.item.price * line.qty}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <motion.button
                    whileTap={{ scale: 0.85 }}
                    transition={SPRING}
                    onClick={() => {
                      haptics.tap();
                      cart.setQty(line.item.id, line.qty - 1);
                    }}
                    className="grid h-9 w-9 place-items-center rounded-full bg-white/8 text-white/70"
                    aria-label="Decrease"
                  >
                    {line.qty === 1 ? <Trash2 className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
                  </motion.button>
                  <span className="w-6 text-center text-sm font-extrabold text-white">{line.qty}</span>
                  <motion.button
                    whileTap={{ scale: 0.85 }}
                    transition={SPRING}
                    onClick={() => {
                      haptics.tap();
                      cart.add(line.item);
                    }}
                    className="grid h-9 w-9 place-items-center rounded-full bg-[var(--brand)] text-black"
                    aria-label="Increase"
                  >
                    <Plus className="h-4 w-4" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          <div className="pt-2">
            <Label icon="SquarePen">Special Instructions</Label>
            <Textarea
              rows={3}
              value={cart.note}
              onChange={(e) => cart.setNote(e.target.value)}
              placeholder="Allergies, spice level, no onion, birthday candle…"
            />
            <p className="mt-1.5 flex items-center gap-1 text-[11px] text-white/30">
              <SquarePen className="h-3 w-3" /> Sent verbatim to the kitchen display.
            </p>
          </div>
        </div>
      )}
    </Sheet>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-[13px]">
      <span className="text-white/45">{label}</span>
      <span className="font-semibold text-white/80">{value}</span>
    </div>
  );
}
