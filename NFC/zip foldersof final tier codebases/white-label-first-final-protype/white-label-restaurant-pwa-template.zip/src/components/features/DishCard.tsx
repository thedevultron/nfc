/**
 * MODULE B ▸ Interactive Dish Card
 * Icon badge · dietary tags · spice flames · best-seller · sold-out state ·
 * haptic (+) add button with animated quantity stepper.
 */
import { AnimatePresence, motion } from 'framer-motion';
import { Ban, Clock, Flame, Minus, Plus, Star } from 'lucide-react';
import { restaurantConfig } from '../../config/restaurant.config';
import { useCart } from '../../hooks/useCart';
import { useHaptics } from '../../hooks/useHaptics';
import type { DietaryTag, MenuItem } from '../../types/menu.types';
import { Badge } from '../ui/Badge';
import { Icon } from '../ui/Icon';
import { SPRING } from '../ui/Button';
import { cn } from '../../utils/cn';

const DIET_META: Record<DietaryTag, { label: string; icon: string; tone: 'veg' | 'nonveg' | 'vegan' | 'accent' }> = {
  veg: { label: 'Veg', icon: 'CircleDot', tone: 'veg' },
  nonveg: { label: 'Non-Veg', icon: 'Beef', tone: 'nonveg' },
  vegan: { label: 'Vegan', icon: 'Leaf', tone: 'vegan' },
  special: { label: "Chef's Special", icon: 'Award', tone: 'accent' },
};

export function DishCard({ item, index }: { item: MenuItem; index: number }) {
  const cart = useCart();
  const haptics = useHaptics();
  const qty = cart.qtyOf(item.id);
  const { currency } = restaurantConfig.brand;
  const orderingOn = restaurantConfig.features.enableDirectOrdering;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ ...SPRING, delay: Math.min(index * 0.03, 0.25) }}
      whileTap={item.isAvailable ? { scale: 0.985 } : undefined}
      className={cn(
        'relative overflow-hidden rounded-[var(--radius)] bg-white/[0.045] p-3.5 ring-1 ring-white/8 ring-inset',
        !item.isAvailable && 'opacity-55 grayscale',
      )}
    >
      <div className="flex gap-3.5">
        {/* Lucide icon tile replaces any product photo */}
        <div
          className={cn(
            'relative grid h-16 w-16 shrink-0 place-items-center rounded-[calc(var(--radius)*0.75)] bg-gradient-to-br from-white/12 to-white/4 ring-1 ring-white/10 ring-inset',
            item.isAvailable && 'text-[var(--brand)]',
          )}
        >
          <Icon name={item.icon} className="h-7 w-7" />
          {item.isBestSeller && item.isAvailable && (
            <span className="absolute -top-1.5 -right-1.5 grid h-6 w-6 place-items-center rounded-full bg-[var(--accent)] text-black ring-2 ring-[rgb(var(--surface))]">
              <Star className="h-3.5 w-3.5 fill-black" />
            </span>
          )}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start gap-2">
            <h3 className="min-w-0 flex-1 text-[15px] leading-snug font-bold tracking-tight text-white">
              {item.name}
            </h3>
            <div className="text-right">
              <div className="text-[15px] font-extrabold text-[var(--brand)]">
                {currency}
                {item.price}
              </div>
              {item.compareAtPrice && (
                <div className="text-[11px] text-white/30 line-through">
                  {currency}
                  {item.compareAtPrice}
                </div>
              )}
            </div>
          </div>

          <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-white/45">{item.description}</p>

          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {item.dietary.map((d) => (
              <Badge key={d} tone={DIET_META[d].tone} icon={DIET_META[d].icon}>
                {DIET_META[d].label}
              </Badge>
            ))}
            {item.spiceLevel > 0 && (
              <span className="inline-flex items-center gap-0.5 rounded-full bg-orange-500/12 px-2 py-1 ring-1 ring-orange-400/25 ring-inset">
                {Array.from({ length: item.spiceLevel }).map((_, i) => (
                  <Flame key={i} className="h-3 w-3 fill-orange-400/40 text-orange-400" />
                ))}
              </span>
            )}
            {item.isBestSeller && <Badge tone="accent" icon="TrendingUp">Best Seller</Badge>}
            {item.prepTimeMins && (
              <span className="inline-flex items-center gap-1 text-[10.5px] font-medium text-white/30">
                <Clock className="h-3 w-3" />
                {item.prepTimeMins}m
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Add / stepper control */}
      <div className="mt-3 flex items-center justify-between gap-3">
        <span className="text-[11px] font-medium text-white/25">
          {item.calories ? `${item.calories} kcal` : item.tags?.[0] ?? ''}
        </span>

        {!item.isAvailable ? (
          <Badge tone="danger" icon="Ban" size="sm">
            Sold Out
          </Badge>
        ) : orderingOn ? (
          <AnimatePresence mode="popLayout" initial={false}>
            {qty === 0 ? (
              <motion.button
                key="add"
                layout
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85 }}
                whileTap={{ scale: 0.9 }}
                transition={SPRING}
                onClick={() => {
                  haptics.tap();
                  cart.add(item);
                }}
                className="flex h-10 items-center gap-1.5 rounded-full bg-[var(--brand)] px-4 text-[13px] font-bold text-black"
              >
                <Plus className="h-4 w-4" strokeWidth={2.6} /> Add
              </motion.button>
            ) : (
              <motion.div
                key="stepper"
                layout
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85 }}
                transition={SPRING}
                className="flex h-10 items-center gap-1 rounded-full bg-[var(--brand)]/15 p-1 ring-1 ring-[var(--brand)]/30 ring-inset"
              >
                <motion.button
                  whileTap={{ scale: 0.85 }}
                  transition={SPRING}
                  onClick={() => {
                    haptics.tap();
                    cart.setQty(item.id, qty - 1);
                  }}
                  className="grid h-8 w-8 place-items-center rounded-full bg-white/8 text-[var(--brand)]"
                  aria-label="Decrease"
                >
                  <Minus className="h-4 w-4" strokeWidth={2.6} />
                </motion.button>
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span
                    key={qty}
                    initial={{ y: -10, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 10, opacity: 0 }}
                    transition={SPRING}
                    className="w-6 text-center text-sm font-extrabold text-[var(--brand)]"
                  >
                    {qty}
                  </motion.span>
                </AnimatePresence>
                <motion.button
                  whileTap={{ scale: 0.85 }}
                  transition={SPRING}
                  onClick={() => {
                    haptics.tap();
                    cart.add(item);
                  }}
                  className="grid h-8 w-8 place-items-center rounded-full bg-[var(--brand)] text-black"
                  aria-label="Increase"
                >
                  <Plus className="h-4 w-4" strokeWidth={2.6} />
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        ) : null}
      </div>

      {!item.isAvailable && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center bg-black/25">
          <span className="flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1.5 text-[11px] font-bold tracking-wide text-white/80 uppercase">
            <Ban className="h-3.5 w-3.5" /> Sold Out
          </span>
        </div>
      )}
    </motion.article>
  );
}
