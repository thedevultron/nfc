/**
 * MODULE B ▸ High-Converting Digital Menu
 * ─────────────────────────────────────────────────────────────────────────
 *  • Sticky horizontal category rail (icons from menuData.ts) with a shared
 *    `layoutId` indicator that slides between categories.
 *  • Instant search + dietary filter pills.
 *  • Results are pure derivations of /src/config/menuData.ts.
 */
import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { dietaryFilters, menuCategories, menuItems } from '../../config/menuData';
import { useHaptics } from '../../hooks/useHaptics';
import type { DietaryTag } from '../../types/menu.types';
import { Icon } from '../ui/Icon';
import { SPRING } from '../ui/Button';
import { DishCard } from './DishCard';
import { cn } from '../../utils/cn';

export function MenuList({ onlySpecials = false }: { onlySpecials?: boolean }) {
  const haptics = useHaptics();
  const categories = onlySpecials ? menuCategories.filter((c) => c.id === 'specials') : menuCategories;
  const [category, setCategory] = useState(categories[0]?.id ?? 'all');
  const [query, setQuery] = useState('');
  const [diets, setDiets] = useState<DietaryTag[]>(onlySpecials ? ['special'] : []);
  const [showFilters, setShowFilters] = useState(!onlySpecials);

  const toggleDiet = (d: DietaryTag) => {
    haptics.tap();
    setDiets((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]));
  };

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menuItems.filter((i) => {
      if (onlySpecials && !i.dietary.includes('special') && i.categoryId !== 'specials') return false;
      if (!q && i.categoryId !== category) return false;
      if (q && !(`${i.name} ${i.description}`.toLowerCase().includes(q))) return false;
      if (diets.length && !diets.some((d) => i.dietary.includes(d))) return false;
      return true;
    });
  }, [query, category, diets, onlySpecials]);

  const activeCat = categories.find((c) => c.id === category);

  return (
    <div className="pb-4">
      {/* Search + filter toggle */}
      <div className="mx-auto flex max-w-lg gap-2 px-4 pt-4">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4.5 w-4.5 -translate-y-1/2 text-white/30" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search dishes, drinks, desserts…"
            className="h-12 w-full rounded-[calc(var(--radius)*0.8)] bg-white/6 pr-10 pl-11 text-[14px] text-white placeholder-white/30 ring-1 ring-white/10 ring-inset outline-none focus:ring-2 focus:ring-[var(--brand)]/70"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute top-1/2 right-2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full bg-white/8 text-white/50"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <motion.button
          whileTap={{ scale: 0.92 }}
          transition={SPRING}
          onClick={() => {
            haptics.tap();
            setShowFilters((v) => !v);
          }}
          className={cn(
            'touch-target grid shrink-0 place-items-center rounded-[calc(var(--radius)*0.8)] ring-1 ring-inset transition-colors',
            showFilters || diets.length
              ? 'bg-[var(--brand)]/15 text-[var(--brand)] ring-[var(--brand)]/30'
              : 'bg-white/6 text-white/50 ring-white/10',
          )}
          aria-label="Toggle filters"
        >
          <SlidersHorizontal className="h-5 w-5" />
        </motion.button>
      </div>

      {/* Dietary pills */}
      <AnimatePresence initial={false}>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="overflow-hidden"
          >
            <div className="no-scrollbar mx-auto flex max-w-lg gap-2 overflow-x-auto px-4 pt-3">
              {dietaryFilters.map((f) => {
                const active = diets.includes(f.id as DietaryTag);
                return (
                  <motion.button
                    key={f.id}
                    whileTap={{ scale: 0.93 }}
                    transition={SPRING}
                    onClick={() => toggleDiet(f.id as DietaryTag)}
                    className={cn(
                      'flex h-10 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-[12.5px] font-semibold ring-1 ring-inset transition-colors',
                      active
                        ? 'bg-[var(--brand)] text-black ring-transparent'
                        : 'bg-white/6 text-white/60 ring-white/10',
                    )}
                  >
                    <Icon name={f.icon} className="h-4 w-4" />
                    {f.label}
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sticky category rail with sliding shared-element indicator */}
      {!query && categories.length > 1 && (
        <div className="glass sticky top-0 z-20 mt-3 border-y border-white/6 py-2.5 pt-[max(env(safe-area-inset-top),0.625rem)]">
          <div className="no-scrollbar mx-auto flex max-w-lg gap-2 overflow-x-auto px-4">
            {categories.map((c) => {
              const active = c.id === category;
              return (
                <motion.button
                  key={c.id}
                  whileTap={{ scale: 0.93 }}
                  transition={SPRING}
                  onClick={() => {
                    haptics.select();
                    setCategory(c.id);
                  }}
                  className="relative flex h-11 shrink-0 items-center gap-1.5 rounded-full px-4 text-[13px] font-semibold whitespace-nowrap"
                >
                  {active && (
                    <motion.span
                      layoutId="category-indicator"
                      transition={SPRING}
                      className="absolute inset-0 rounded-full bg-[var(--brand)]"
                    />
                  )}
                  <Icon
                    name={c.icon}
                    className={cn('relative z-10 h-4 w-4', active ? 'text-black' : 'text-[var(--brand)]')}
                  />
                  <span className={cn('relative z-10', active ? 'text-black' : 'text-white/60')}>{c.label}</span>
                </motion.button>
              );
            })}
          </div>
        </div>
      )}

      {/* Section heading */}
      <div className="mx-auto max-w-lg px-4 pt-4">
        <div className="flex items-baseline justify-between">
          <h2
            className="text-[17px] font-extrabold tracking-tight text-white"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            {query ? `Results for "${query}"` : (activeCat?.label ?? 'Menu')}
          </h2>
          <span className="text-[11.5px] font-semibold text-white/35">{results.length} items</span>
        </div>
        {!query && activeCat?.description && (
          <p className="mt-0.5 text-[12.5px] text-white/40">{activeCat.description}</p>
        )}
      </div>

      {/* Dish grid */}
      <motion.div layout className="mx-auto mt-3 grid max-w-lg gap-3 px-4">
        <AnimatePresence mode="popLayout">
          {results.map((item, i) => (
            <DishCard key={item.id} item={item} index={i} />
          ))}
        </AnimatePresence>
        {results.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-[var(--radius)] bg-white/4 py-12 text-center ring-1 ring-white/8 ring-inset"
          >
            <Icon name="SearchX" className="mx-auto h-8 w-8 text-white/25" />
            <p className="mt-3 text-sm font-semibold text-white/60">Nothing matches those filters</p>
            <p className="mt-1 text-[12.5px] text-white/35">Try clearing search or dietary pills.</p>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
