/** UI ▸ Field primitives — inputs, textarea, labels, chip selectors. */
import { cn } from '../../utils/cn';
import { motion } from 'framer-motion';
import { Icon } from './Icon';
import { SPRING } from './Button';

export function Label({ children, icon }: { children: React.ReactNode; icon?: string }) {
  return (
    <span className="mb-2 flex items-center gap-1.5 text-[11px] font-bold tracking-[0.08em] text-white/45 uppercase">
      {icon && <Icon name={icon} className="h-3.5 w-3.5" />}
      {children}
    </span>
  );
}

const base =
  'w-full rounded-[calc(var(--radius)*0.75)] bg-white/6 px-4 text-[15px] text-white placeholder-white/30 ring-1 ring-inset ring-white/10 outline-none transition focus:ring-2 focus:ring-[var(--brand)]/70';

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn(base, 'h-12', props.className)} />;
}

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn(base, 'resize-none py-3 leading-relaxed', props.className)} />;
}

export function Chip({
  active,
  children,
  icon,
  layoutId,
  ...props
}: {
  active?: boolean;
  icon?: string;
  layoutId?: string;
  children?: React.ReactNode;
} & Omit<React.ComponentProps<typeof motion.button>, 'children'>) {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.94 }}
      transition={SPRING}
      {...props}
      className={cn(
        'relative flex h-11 items-center justify-center gap-1.5 rounded-full px-4 text-[13px] font-semibold whitespace-nowrap transition-colors',
        active ? 'text-black' : 'bg-white/6 text-white/65 ring-1 ring-inset ring-white/10',
        props.className,
      )}
    >
      {active && (
        <motion.span
          layoutId={layoutId}
          transition={SPRING}
          className="absolute inset-0 rounded-full bg-[var(--brand)]"
        />
      )}
      {icon && <Icon name={icon} className="relative z-10 h-4 w-4" />}
      <span className="relative z-10">{children}</span>
    </motion.button>
  );
}
