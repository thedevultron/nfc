/** UI ▸ Badge — small icon+label pill used for dietary tags, status, NFC mode. */
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../../utils/cn';
import { Icon } from './Icon';

const badge = cva(
  'inline-flex items-center gap-1 rounded-full font-semibold leading-none whitespace-nowrap',
  {
    variants: {
      tone: {
        neutral: 'bg-white/8 text-white/70 ring-1 ring-inset ring-white/10',
        brand: 'bg-[var(--brand)]/15 text-[var(--brand)] ring-1 ring-inset ring-[var(--brand)]/30',
        accent: 'bg-[var(--accent)]/15 text-[var(--accent)] ring-1 ring-inset ring-[var(--accent)]/30',
        veg: 'bg-emerald-500/12 text-emerald-300 ring-1 ring-inset ring-emerald-400/25',
        nonveg: 'bg-rose-500/12 text-rose-300 ring-1 ring-inset ring-rose-400/25',
        vegan: 'bg-lime-500/12 text-lime-300 ring-1 ring-inset ring-lime-400/25',
        danger: 'bg-zinc-700/70 text-zinc-200 ring-1 ring-inset ring-white/10',
      },
      size: { xs: 'px-2 py-1 text-[10px]', sm: 'px-2.5 py-1.5 text-[11px]' },
    },
    defaultVariants: { tone: 'neutral', size: 'xs' },
  },
);

export function Badge({
  icon,
  children,
  className,
  tone,
  size,
}: { icon?: string; children?: React.ReactNode; className?: string } & VariantProps<typeof badge>) {
  return (
    <span className={cn(badge({ tone, size }), className)}>
      {icon && <Icon name={icon} className="h-3 w-3 shrink-0" />}
      {children}
    </span>
  );
}
