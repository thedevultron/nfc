/**
 * UI ▸ Button — spring-physics press micro-interaction (400/25) baked in.
 * Never edited per client; colours come from CSS vars set by ThemeProvider.
 */
import { motion, type HTMLMotionProps } from 'framer-motion';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../../utils/cn';

export const SPRING = { type: 'spring' as const, stiffness: 400, damping: 25 };

const button = cva(
  'relative inline-flex select-none items-center justify-center gap-2 font-semibold tracking-tight transition-colors disabled:pointer-events-none disabled:opacity-45',
  {
    variants: {
      variant: {
        primary: 'bg-[var(--brand)] text-black brand-glow',
        accent: 'bg-[var(--accent)] text-black',
        secondary: 'bg-white/10 text-white ring-1 ring-inset ring-white/12',
        outline: 'bg-transparent text-white ring-1 ring-inset ring-white/18',
        ghost: 'bg-transparent text-white/70 hover:text-white',
        danger: 'bg-rose-500/15 text-rose-300 ring-1 ring-inset ring-rose-400/25',
      },
      size: {
        sm: 'h-10 px-3.5 text-[13px] rounded-[calc(var(--radius)*0.6)]',
        md: 'h-12 px-5 text-sm rounded-[calc(var(--radius)*0.8)]',
        lg: 'h-14 px-6 text-[15px] rounded-[var(--radius)]',
        icon: 'h-12 w-12 rounded-[calc(var(--radius)*0.75)]',
      },
      full: { true: 'w-full' },
    },
    defaultVariants: { variant: 'primary', size: 'md' },
  },
);

export type ButtonProps = HTMLMotionProps<'button'> & VariantProps<typeof button>;

export function Button({ className, variant, size, full, ...props }: ButtonProps) {
  return (
    <motion.button
      whileTap={{ scale: 0.955 }}
      whileHover={{ scale: 1.015 }}
      transition={SPRING}
      className={cn(button({ variant, size, full }), className)}
      {...props}
    />
  );
}
