/**
 * UI ▸ Icon
 * Resolves a *string* icon name coming from /src/config into a real
 * lucide-react component. This is what allows clients to change every icon in
 * the PWA by editing config only. Falls back to `Circle` for typos.
 */
import * as Lucide from 'lucide-react';
import type { LucideProps } from 'lucide-react';

type IconRegistry = Record<string, React.ComponentType<LucideProps>>;

export function Icon({ name, ...props }: { name: string } & LucideProps) {
  const registry = Lucide as unknown as IconRegistry;
  const Cmp = registry[name] ?? Lucide.Circle;
  return <Cmp strokeWidth={1.9} {...props} />;
}
