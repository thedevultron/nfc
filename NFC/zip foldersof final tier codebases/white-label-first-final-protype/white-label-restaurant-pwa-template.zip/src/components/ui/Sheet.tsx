/**
 * UI ▸ Sheet — Vaul/Shadcn-style bottom drawer.
 * Spring drag-to-dismiss, scrim fade, focus lock on scroll, safe-area aware.
 * Used by Cart, Reservation, Review and WiFi modules.
 */
import { AnimatePresence, motion, type PanInfo } from 'framer-motion';
import { useEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { cn } from '../../utils/cn';
import { useHaptics } from '../../hooks/useHaptics';

interface SheetProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title?: string;
  subtitle?: string;
  icon?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  /** 'sheet' = bottom drawer, 'dialog' = centred modal (WiFi QR). */
  variant?: 'sheet' | 'dialog';
  className?: string;
}

export function Sheet({
  open,
  onOpenChange,
  title,
  subtitle,
  icon,
  children,
  footer,
  variant = 'sheet',
  className,
}: SheetProps) {
  const haptics = useHaptics();

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onEsc = (e: KeyboardEvent) => e.key === 'Escape' && onOpenChange(false);
    window.addEventListener('keydown', onEsc);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onEsc);
    };
  }, [open, onOpenChange]);

  const handleDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.y > 120 || info.velocity.y > 700) {
      haptics.tap();
      onOpenChange(false);
    }
  };

  const isSheet = variant === 'sheet';

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            onClick={() => onOpenChange(false)}
            className="absolute inset-0 bg-black/70 backdrop-blur-[3px]"
          />

          <motion.div
            role="dialog"
            aria-modal="true"
            initial={isSheet ? { y: '100%' } : { opacity: 0, scale: 0.94, y: 20 }}
            animate={isSheet ? { y: 0 } : { opacity: 1, scale: 1, y: 0 }}
            exit={isSheet ? { y: '100%' } : { opacity: 0, scale: 0.95, y: 12 }}
            transition={{ type: 'spring', stiffness: 320, damping: 34 }}
            drag={isSheet ? 'y' : false}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.5 }}
            onDragEnd={handleDragEnd}
            className={cn(
              'glass relative z-10 flex w-full max-h-[92vh] flex-col overflow-hidden border border-white/10 shadow-2xl',
              isSheet
                ? 'rounded-t-[calc(var(--radius)*1.6)] sm:max-w-lg sm:rounded-[calc(var(--radius)*1.4)]'
                : 'mx-4 max-w-sm rounded-[calc(var(--radius)*1.4)]',
              className,
            )}
          >
            {isSheet && (
              <div className="flex justify-center pt-3 pb-1">
                <div className="h-1.5 w-11 rounded-full bg-white/25" />
              </div>
            )}

            {(title || icon) && (
              <div className="flex items-start gap-3 px-5 pt-3 pb-4">
                {icon && (
                  <div className="mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-[calc(var(--radius)*0.7)] bg-[var(--brand)]/15 text-[var(--brand)]">
                    {icon}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <h2 className="truncate text-[17px] font-bold tracking-tight text-white">{title}</h2>
                  {subtitle && <p className="mt-0.5 text-[12.5px] text-white/50">{subtitle}</p>}
                </div>
                <button
                  onClick={() => onOpenChange(false)}
                  aria-label="Close"
                  className="touch-target -mr-2 -mt-2 grid place-items-center rounded-full text-white/50 active:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            )}

            <div className="no-scrollbar flex-1 overflow-y-auto overscroll-contain px-5 pb-4">{children}</div>

            {footer && (
              <div className="border-t border-white/8 bg-black/25 px-5 pt-4 pb-[max(env(safe-area-inset-bottom),1rem)]">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
