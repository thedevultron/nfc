/**
 * ============================================================================
 *  CLIENT-EDITABLE ▸ THEME
 * ============================================================================
 *  Change ONLY the values below to re-skin the entire PWA.
 *  These tokens are injected as CSS custom properties at runtime by
 *  <ThemeProvider /> (src/components/layout/ThemeProvider.tsx), so every
 *  component reads them through Tailwind arbitrary values such as
 *  `bg-[var(--brand)]`. No component file needs to be touched.
 *
 *  • primaryColor  -> --brand           (buttons, active states, prices)
 *  • accentColor   -> --accent          (gradients, badges, glow)
 *  • radius        -> --radius          (cards, chips, sheets)
 *  • density       -> --pad             (global vertical rhythm)
 * ============================================================================
 */

import type { ThemeConfig } from '../types/config.types';

export const themeConfig: ThemeConfig = {
  primaryColor: 'hsl(142.1 76.2% 42%)', // Emerald — swap for any client hue
  accentColor: 'hsl(38 96% 56%)', // Amber highlight
  radius: '1rem',
  enableGlassmorphism: true,
  defaultMode: 'dark',
  density: 'comfortable',
  fonts: {
    display: '"Plus Jakarta Sans", ui-sans-serif, system-ui, sans-serif',
    body: 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
  },
};
