/**
 * ============================================================================
 *  CLIENT-EDITABLE ▸ BUSINESS / FEATURES / INTEGRATIONS
 * ============================================================================
 *  This is the single source of truth for a deployment.
 *
 *  • brand.*          -> Header, WiFi modal, WhatsApp deep-links, footer
 *  • features.*       -> Feature flags. Setting a flag to `false` removes the
 *                        quick-action tile, the bottom-nav entry AND the
 *                        related drawer from the bundle-level UI tree.
 *  • quickActions[]   -> Order + labels + Lucide icon names of header grid
 *  • navigation[]     -> Bottom tab bar (icons resolved from lucide-react)
 *  • n8nWebhooks.*    -> Paste live n8n Production Webhook URLs here.
 *                        services/n8n.service.ts consumes these directly.
 * ============================================================================
 */

import type { RestaurantConfig } from '../types/config.types';

export const restaurantConfig: RestaurantConfig = {
  brand: {
    name: 'Aura Bistro & Lounge',
    subtitle: 'Modern Culinary Experience',
    logoIcon: 'ChefHat', // any lucide-react icon name
    tagline: 'Tap. Browse. Order. Enjoy.',
    currency: '₹',
    googleReviewUrl: 'https://maps.google.com/?cid=000000000000000000',
    whatsappNumber: '+919876543210',
    phone: '+91 98765 43210',
    address: '14 Lantern Lane, Bandra West, Mumbai 400050',
    hours: 'Mon–Sun · 11:00 — 23:30',
    wifi: { ssid: 'Aura_Guest_5G', pass: 'Bistro@2026', encryption: 'WPA' },
  },

  features: {
    enableBookings: true,
    enableReviews: true,
    enableWifi: true,
    enableDirectOrdering: true,
    enableWhatsApp: true,
    enableHaptics: true,
    enablePWAInstall: true,
  },

  touchpoint: {
    defaultTable: '04',
    defaultMode: 'dinein',
    labels: {
      dinein: 'Tap Mode Active',
      takeaway: 'Takeaway Mode',
    },
  },

  quickActions: [
    { id: 'wifi', label: 'Instant WiFi', icon: 'Wifi', flag: 'enableWifi' },
    { id: 'whatsapp', label: 'Concierge', icon: 'MessageCircle', flag: 'enableWhatsApp' },
    { id: 'review', label: 'Rate Us', icon: 'Star', flag: 'enableReviews' },
    { id: 'booking', label: 'Book Table', icon: 'CalendarDays', flag: 'enableBookings' },
  ],

  navigation: [
    { id: 'menu', label: 'Menu', icon: 'UtensilsCrossed' },
    { id: 'specials', label: 'Specials', icon: 'Sparkles' },
    { id: 'book', label: 'Book', icon: 'CalendarDays' },
    { id: 'info', label: 'Info', icon: 'Info' },
  ],

  reservation: {
    timeSlots: ['12:00', '13:00', '14:00', '18:30', '19:30', '20:30', '21:30', '22:30'],
    minGuests: 1,
    maxGuests: 16,
    occasions: ['Casual Dining', 'Birthday', 'Anniversary', 'Business', 'Date Night'],
  },

  order: {
    taxRatePercent: 5,
    serviceChargePercent: 0,
    channel: 'both', // 'whatsapp' | 'webhook' | 'both'
  },

  n8nWebhooks: {
    reservationUrl: 'https://your-n8n-instance.com/webhook/reservation',
    feedbackUrl: 'https://your-n8n-instance.com/webhook/feedback',
    orderUrl: 'https://your-n8n-instance.com/webhook/order',
    reviewUrl: 'https://your-n8n-instance.com/webhook/review',
  },
};
