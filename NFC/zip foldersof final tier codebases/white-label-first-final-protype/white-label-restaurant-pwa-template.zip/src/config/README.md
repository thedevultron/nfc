# /src/config — the only folder a white-label deployment edits

This PWA is strictly decoupled. Layout, animation, hooks and services never
contain client-specific values.

| File | Controls | Reaches the UI via |
| --- | --- | --- |
| `theme.config.ts` | brand colour, accent, radius, glassmorphism, density, mode, fonts | `layout/ThemeProvider.tsx` → CSS custom properties (`--brand`, `--accent`, `--radius`, `--pad`, `--glass`) consumed by every component |
| `restaurant.config.ts` | business details, feature flags, quick-action grid, bottom-nav tabs, reservation slots, tax/service %, n8n webhook URLs | `layout/Header.tsx`, `layout/BottomNav.tsx`, `hooks/useCart.ts`, `services/*` |
| `menuData.ts` | categories, dishes, prices, dietary badges, spice levels, availability, filter pills, feedback topics | `features/MenuList.tsx` → `features/DishCard.tsx` |

## Common tasks

**Re-skin the app** → change `primaryColor` / `accentColor` / `radius` in `theme.config.ts`.

**Remove a feature** → set its flag to `false` in `restaurantConfig.features`.
The quick-action tile, bottom-nav tab and the corresponding drawer are all removed
from the render tree automatically (`Shell.tsx` / `Header.tsx` / `BottomNav.tsx` read the flags).

**Go live with a backend** → paste production URLs into `restaurantConfig.n8nWebhooks`.
`services/n8n.service.ts` detects the placeholder host and switches from
optimistic mock resolution to real `fetch` POSTs. No component changes.

**Change any icon** → every icon is a *string* name of a `lucide-react` export
(`components/ui/Icon.tsx` resolves it at runtime). No image assets exist in this project.

**Per-table NFC tags** → encode `?table=12&mode=dinein&src=nfc` in the tag URL.
`hooks/useTouchpoint.ts` resolves it and the header badge + order payload update automatically.
