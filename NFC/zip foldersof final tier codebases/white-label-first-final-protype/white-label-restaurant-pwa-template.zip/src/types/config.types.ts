/**
 * ============================================================================
 *  TYPE LAYER — CONFIG SCHEMA
 * ============================================================================
 *  These interfaces are the *contract* between /src/config/* (client-owned)
 *  and everything else (engineering-owned). A white-label deployment should
 *  only ever change values inside /src/config — never these shapes.
 * ============================================================================
 */

/** Any valid icon name exported by `lucide-react` (e.g. "Flame", "Wine"). */
export type LucideIconName = string;

export interface ThemeConfig {
  /** Primary brand colour. Accepts any CSS colour string (hsl/oklch/hex). */
  primaryColor: string;
  /** Secondary accent used for gradients + highlights. */
  accentColor: string;
  /** Global border radius token, e.g. "0.75rem". */
  radius: string;
  /** Enables frosted-glass surfaces across headers, nav and sheets. */
  enableGlassmorphism: boolean;
  /** Initial colour mode for the shell. */
  defaultMode: 'dark' | 'light';
  /** Controls vertical rhythm / padding scale of every surface. */
  density: 'compact' | 'comfortable';
  /** Display + body font stacks (loaded by the host page). */
  fonts: { display: string; body: string };
}

export interface FeatureFlags {
  enableBookings: boolean;
  enableReviews: boolean;
  enableWifi: boolean;
  enableDirectOrdering: boolean;
  enableWhatsApp: boolean;
  enableHaptics: boolean;
  enablePWAInstall: boolean;
}

export interface BrandConfig {
  name: string;
  subtitle: string;
  /** Lucide icon used as the "logo" — no image assets are ever used. */
  logoIcon: LucideIconName;
  tagline: string;
  currency: string;
  googleReviewUrl: string;
  whatsappNumber: string;
  phone: string;
  address: string;
  hours: string;
  wifi: { ssid: string; pass: string; encryption: 'WPA' | 'WEP' | 'nopass' };
}

export interface QuickAction {
  id: 'wifi' | 'whatsapp' | 'review' | 'booking' | string;
  label: string;
  icon: LucideIconName;
  /** Feature flag key which gates visibility of this tile. */
  flag: keyof FeatureFlags;
}

export interface NavItem {
  id: string;
  label: string;
  icon: LucideIconName;
}

export interface RestaurantConfig {
  brand: BrandConfig;
  features: FeatureFlags;
  /** NFC / QR touchpoint context resolved at runtime (?table=04&mode=dinein). */
  touchpoint: {
    defaultTable: string;
    defaultMode: 'dinein' | 'takeaway';
    labels: Record<string, string>;
  };
  quickActions: QuickAction[];
  navigation: NavItem[];
  reservation: {
    timeSlots: string[];
    maxGuests: number;
    minGuests: number;
    occasions: string[];
  };
  order: {
    taxRatePercent: number;
    serviceChargePercent: number;
    /** Where the formatted order string is dispatched. */
    channel: 'whatsapp' | 'webhook' | 'both';
  };
  n8nWebhooks: {
    reservationUrl: string;
    feedbackUrl: string;
    orderUrl: string;
    reviewUrl: string;
  };
}
