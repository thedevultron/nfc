/**
 * ============================================================================
 *  TYPE LAYER — MENU / CART / RESERVATION / FEEDBACK SCHEMA
 * ============================================================================
 */

import type { LucideIconName } from './config.types';

export type DietaryTag = 'veg' | 'nonveg' | 'vegan' | 'special';

export interface MenuCategory {
  id: string;
  label: string;
  /** Lucide icon rendered in the sticky category rail. */
  icon: LucideIconName;
  description?: string;
}

export interface MenuItem {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  /** Optional strike-through original price for offers. */
  compareAtPrice?: number;
  icon: LucideIconName;
  dietary: DietaryTag[];
  /** 0–3 flame indicators. */
  spiceLevel: number;
  isBestSeller?: boolean;
  isAvailable: boolean;
  prepTimeMins?: number;
  calories?: number;
  tags?: string[];
}

export interface CartLine {
  item: MenuItem;
  qty: number;
}

export interface CartState {
  lines: CartLine[];
  note: string;
  subtotal: number;
  tax: number;
  service: number;
  total: number;
  count: number;
}

export interface ReservationPayload {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  occasion?: string;
  notes?: string;
  table?: string;
}

export interface FeedbackPayload {
  rating: number;
  categories: string[];
  message: string;
  contact?: string;
  table?: string;
}

export interface OrderPayload {
  table: string;
  mode: string;
  lines: { name: string; qty: number; price: number }[];
  note: string;
  totals: { subtotal: number; tax: number; service: number; total: number };
}

export interface ApiResult<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  /** True when the mock/offline fallback resolved the request. */
  simulated?: boolean;
}
