/**
 * ============================================================================
 *  APP ENTRY — integration only.
 * ============================================================================
 *  Deploying for a new client?  Touch ONLY these three files:
 *    1. /src/config/theme.config.ts       → colours, radius, density, mode
 *    2. /src/config/restaurant.config.ts  → brand, feature flags, n8n webhooks
 *    3. /src/config/menuData.ts           → categories, dishes, filters
 *
 *  Everything below (layout, animation, state, services) stays untouched.
 * ============================================================================
 */
import { CartProvider } from './hooks/useCart';
import { ThemeProvider } from './components/layout/ThemeProvider';
import { Shell } from './components/layout/Shell';

export default function App() {
  return (
    <ThemeProvider>
      <CartProvider>
        <Shell />
      </CartProvider>
    </ThemeProvider>
  );
}
