/* ============================================================================
 * CONFIG SCHEMAS
 * ----------------------------------------------------------------------------
 * These interfaces define the contract for everything a client can change.
 * Editing /src/config/*.ts re-skins and re-brands the entire PWA — the UI in
 * /src/components never needs to be touched for a new deployment.
 * ==========================================================================*/

/** Full color system. Values are complete CSS colors (hsl strings recommended). */
export interface ThemeColors {
  /** App canvas / page background */
  background: string;
  /** Card & sheet surfaces */
  surface: string;
  /** Elevated tiles, chips, inputs */
  raised: string;
  /** Hairline borders & dividers */
  line: string;
  /** Primary text */
  ink: string;
  /** Secondary / de-emphasized text */
  muted: string;
  /** Brand action color (buttons, highlights, prices) */
  primary: string;
  /** Text rendered on top of `primary` */
  primaryInk: string;
  /** Secondary brand hue (success states, vegan marks) */
  accent: string;
  /** Text rendered on top of `accent` */
  accentInk: string;
  /** Heat / destructive color (spice levels, sold-out, errors) */
  chili: string;
}

export interface ThemeFonts {
  /** Display face — headings, dish names, brand. Any Google Font family name. */
  display: string;
  /** Body face — UI copy, descriptions. Any Google Font family name. */
  body: string;
}

export type UiDensity = "comfortable" | "compact";
export type UiMode = "dark" | "light";

export interface ThemeConfig {
  colors: ThemeColors;
  fonts: ThemeFonts;
  /** Base corner radius, e.g. "0.75rem". Cards & tiles derive multiples of it. */
  radius: string;
  /** "comfortable" = airy cards, "compact" = tighter packing, same layout. */
  density: UiDensity;
  /** When true, nav / sheets / sticky bars get translucent blur surfaces. */
  enableGlassmorphism: boolean;
  /** Default color mode applied on boot. */
  defaultMode: UiMode;
}

/* -------------------------------------------------------------------------- */

export interface WifiConfig {
  ssid: string;
  pass: string;
  /** WPA | WEP | nopass — used to build the scannable QR payload */
  security: "WPA" | "WEP" | "nopass";
}

export interface OpeningHours {
  /** Full weekday name, ordered Monday → Sunday */
  day: string;
  /** Human label, e.g. "12:00 – 23:00" */
  hours: string;
  /** 24h "HH:MM" — used to compute the live Open/Closed pill */
  opens: string;
  closes: string;
  closed?: boolean;
}

export interface BrandConfig {
  name: string;
  subtitle: string;
  tagline: string;
  address: string;
  phone: string;
  /** Deep link used by the Smart Review Filter for 4–5 star ratings */
  googleReviewUrl: string;
  /** E.164 format, digits only — used for wa.me concierge links */
  whatsappNumber: string;
  wifi: WifiConfig;
  hours: OpeningHours[];
  socials: { instagram?: string; facebook?: string };
}

export type OrderMode = "dine-in" | "takeaway";

export interface InteractionConfig {
  /** NFC table identifier read from the tap point (e.g. "04") */
  tableId: string;
  defaultMode: OrderMode;
  /** Label shown on the NFC context badge */
  tapLabel: string;
}

export interface FeatureFlags {
  enableBookings: boolean;
  enableReviews: boolean;
  enableWifi: boolean;
  /** Kitchen webhook + WhatsApp order pipeline */
  enableDirectOrdering: boolean;
  /** Allow dine-in ↔ takeaway switching on the context badge */
  enableTakeaway: boolean;
  /** Show the "Add to Home Screen" prompts */
  enableInstallPrompt: boolean;
  /** Native vibration on taps (Android). No-op elsewhere. */
  enableHaptics: boolean;
}

export interface LocaleConfig {
  /** e.g. "en-IN", "en-US", "ar-AE" */
  locale: string;
  /** ISO currency code used by Intl.NumberFormat, e.g. "INR" */
  currencyCode: string;
  /** Displayed on the cart totals line */
  taxLabel: string;
  /** 0.05 = 5% */
  taxRate: number;
}

export interface BookingConfig {
  lunchSlots: string[];
  dinnerSlots: string[];
  maxGuests: number;
}

export interface N8nWebhooks {
  reservationUrl: string;
  feedbackUrl: string;
  orderUrl: string;
}

export interface RestaurantConfig {
  brand: BrandConfig;
  interaction: InteractionConfig;
  features: FeatureFlags;
  locale: LocaleConfig;
  booking: BookingConfig;
  /** Rotating marquee lines shown above the menu */
  promotions: string[];
  n8nWebhooks: N8nWebhooks;
}
