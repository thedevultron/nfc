/* ============================================================================
 * MENU / COMMERCE SCHEMAS
 * Shape of menu catalogs, cart state, and every payload dispatched to n8n.
 * ==========================================================================*/

export type DietaryTag = "veg" | "nonveg" | "vegan";

/** 0 = mild/none … 3 = fiery. Rendered as a row of Flame icons. */
export type SpiceLevel = 0 | 1 | 2 | 3;

export interface MenuCategory {
  id: string;
  label: string;
  /** Lucide icon name — resolved at runtime by <DynamicIcon /> */
  icon: string;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  categoryId: string;
  /** Lucide icon name shown on the dish tile */
  icon: string;
  /** Empty array = no dietary mark (e.g. alcoholic drinks) */
  diet: DietaryTag[];
  spice: SpiceLevel;
  bestSeller?: boolean;
  /** false → greyed card, "Sold Out" badge, add-to-cart disabled */
  isAvailable: boolean;
  prepMinutes: number;
}

export interface CartLine {
  item: MenuItem;
  qty: number;
}

export interface OrderLinePayload {
  name: string;
  qty: number;
  unitPrice: number;
  lineTotal: number;
}

export interface OrderPayload {
  source: "kitchen-webhook" | "whatsapp";
  tableId: string;
  mode: "dine-in" | "takeaway";
  lines: OrderLinePayload[];
  subtotal: number;
  tax: number;
  total: number;
  currencyCode: string;
  instructions: string;
  placedAt: string;
}

export interface ReservationPayload {
  name: string;
  phone: string;
  /** "Sat, 14 Mar 2026" */
  date: string;
  /** "19:30" */
  time: string;
  guests: number;
  notes: string;
  createdAt: string;
}

export interface FeedbackPayload {
  /** 1–5 star internal rating */
  rating: number;
  message: string;
  name?: string;
  contact?: string;
  channel: "smart-review-filter";
  createdAt: string;
}

export interface WebhookResult {
  success: boolean;
  mock?: boolean;
  message?: string;
}
