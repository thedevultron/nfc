import type { ThemeConfig } from "@/types/config.types";

/* ============================================================================
 * THEME — CLIENT EDIT ZONE ①
 * ----------------------------------------------------------------------------
 * EVERY color, font, corner radius and spacing density in the app is derived
 * from this single object at boot (see App.tsx → applyTheme). Re-skin the PWA
 * for a new client by changing values here — no component edits required.
 *
 * Tip: colors accept any CSS color, but keep hsl() strings so opacity
 * modifiers (bg-primary/15 etc.) keep working.
 * ==========================================================================*/
export const themeConfig: ThemeConfig = {
  colors: {
    // -- Canvas & surfaces -------------------------------------------------
    background: "hsl(22 16% 7%)",   // deep espresso — the app canvas
    surface:    "hsl(22 14% 10%)",  // cards, sheets, bottom nav
    raised:     "hsl(24 13% 14%)",  // chips, icon tiles, inputs
    line:       "hsl(26 12% 20%)",  // hairline borders
    // -- Typography --------------------------------------------------------
    ink:   "hsl(38 30% 93%)",       // warm parchment white
    muted: "hsl(32 11% 60%)",
    // -- Brand -------------------------------------------------------------
    primary:     "hsl(38 90% 58%)", // saffron gold — actions, prices, highlights
    primaryInk:  "hsl(24 45% 10%)", // text on gold
    accent:      "hsl(146 24% 50%)",// sage — success states, veg marks
    accentInk:   "hsl(150 35% 8%)",
    chili:       "hsl(8 74% 56%)",  // heat — spice meters, sold-out, errors
  },
  fonts: {
    display: "Fraunces", // characterful editorial serif (brand, dish names)
    body:    "Manrope",  // geometric humanist sans (UI copy)
  },
  radius: "0.7rem",      // base radius — cards use 1.5×, hero tiles 2.2×
  density: "comfortable",// "compact" tightens card padding for dense catalogs
  enableGlassmorphism: true,
  defaultMode: "dark" as const,
};
