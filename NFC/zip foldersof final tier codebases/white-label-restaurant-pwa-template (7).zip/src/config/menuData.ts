import type { MenuCategory, MenuItem } from "@/types/menu.types";

/* ============================================================================
 * MENU CATALOG — CLIENT EDIT ZONE ③
 * ----------------------------------------------------------------------------
 * Swap this file per client. Categories & dishes drive the sticky chip bar,
 * filters, search, cart and WhatsApp order formatter automatically.
 *   • `icon` is a Lucide icon NAME (string) rendered by <DynamicIcon />
 *   • `diet`: ["veg"] | ["nonveg"] | ["vegan"] | [] (no mark, e.g. alcohol)
 *   • `isAvailable: false` → sold-out card (Ban badge, add disabled)
 * ==========================================================================*/

export const menuCategories: MenuCategory[] = [
  { id: "signatures", label: "Signatures", icon: "Award" },
  { id: "starters",   label: "Starters",   icon: "Flame" },
  { id: "mains",      label: "Mains & Grill", icon: "ChefHat" },
  { id: "pizza",      label: "Wood-Fired", icon: "Pizza" },
  { id: "desserts",   label: "Desserts",   icon: "CakeSlice" },
  { id: "bar",        label: "Drinks & Bar", icon: "Wine" },
  { id: "cafe",       label: "Café & Brews", icon: "Coffee" },
];

export const menuItems: MenuItem[] = [
  /* ------------------------------ Signatures ----------------------------- */
  {
    id: "lamb-shank",
    name: "Slow-Braised Lamb Shank",
    description: "48-hour marinade, saffron jus, charred spring onions, smoked mash.",
    price: 749, categoryId: "signatures", icon: "Drumstick",
    diet: ["nonveg"], spice: 1, bestSeller: true, isAvailable: true, prepMinutes: 25,
  },
  {
    id: "smoked-butter-chicken",
    name: "Smoked Butter Chicken",
    description: "Tandoor-smoked thigh, cashew makhani, burnt garlic, charred naan.",
    price: 549, categoryId: "signatures", icon: "ChefHat",
    diet: ["nonveg"], spice: 2, bestSeller: true, isAvailable: true, prepMinutes: 20,
  },
  {
    id: "truffle-risotto",
    name: "Wild Mushroom Risotto",
    description: "Porcini & king oyster, 24-month parmesan, white truffle oil.",
    price: 469, categoryId: "signatures", icon: "Soup",
    diet: ["veg"], spice: 0, bestSeller: true, isAvailable: true, prepMinutes: 18,
  },
  {
    id: "miso-salmon",
    name: "Miso-Glazed Salmon",
    description: "Sesame crust, charred bok choy, yuzu beurre blanc, crispy shallots.",
    price: 689, categoryId: "signatures", icon: "Fish",
    diet: ["nonveg"], spice: 0, isAvailable: false, prepMinutes: 22,
  },

  /* ------------------------------- Starters ------------------------------ */
  {
    id: "corn-ribs",
    name: "Charred Corn Ribs",
    description: "Chipotle-lime butter, cotija snow, coriander, smoked salt.",
    price: 289, categoryId: "starters", icon: "Flame",
    diet: ["veg"], spice: 2, isAvailable: true, prepMinutes: 12,
  },
  {
    id: "gochujang-wings",
    name: "Crispy Gochujang Wings",
    description: "Double-fried, gochujang glaze, toasted sesame, pickled daikon.",
    price: 349, categoryId: "starters", icon: "Drumstick",
    diet: ["nonveg"], spice: 3, bestSeller: true, isAvailable: true, prepMinutes: 14,
  },
  {
    id: "burrata-heirloom",
    name: "Burrata & Heirloom Tomato",
    description: "Basil oil, sourdough crisps, aged balsamic, cracked pepper.",
    price: 419, categoryId: "starters", icon: "Salad",
    diet: ["veg"], spice: 0, isAvailable: true, prepMinutes: 8,
  },
  {
    id: "broccoli-tikka",
    name: "Tandoori Broccoli Tikka",
    description: "Hung-curd marinade, ajwain tempering, mint chutney.",
    price: 269, categoryId: "starters", icon: "Leaf",
    diet: ["vegan"], spice: 2, isAvailable: true, prepMinutes: 12,
  },
  {
    id: "chilli-prawns",
    name: "Chilli Garlic Prawns",
    description: "Wok-tossed tiger prawns, burnt garlic, spring onion, lime.",
    price: 459, categoryId: "starters", icon: "Shrimp",
    diet: ["nonveg"], spice: 3, isAvailable: true, prepMinutes: 10,
  },

  /* ---------------------------- Mains & Grill ---------------------------- */
  {
    id: "ribeye",
    name: "Dry-Aged Ribeye 300g",
    description: "21-day aged, smoked rosemary butter, hand-cut fries, watercress.",
    price: 949, categoryId: "mains", icon: "Beef",
    diet: ["nonveg"], spice: 0, bestSeller: true, isAvailable: true, prepMinutes: 25,
  },
  {
    id: "chicken-supreme",
    name: "Herb-Crusted Chicken Supreme",
    description: "Ratatouille, pomme purée, thyme jus, confit garlic.",
    price: 529, categoryId: "mains", icon: "Drumstick",
    diet: ["nonveg"], spice: 1, isAvailable: true, prepMinutes: 22,
  },
  {
    id: "paneer-lasagna",
    name: "Paneer Tikka Lasagna",
    description: "Layered tikka paneer, smoked cheddar béchamel, charred peppers.",
    price: 449, categoryId: "mains", icon: "UtensilsCrossed",
    diet: ["veg"], spice: 2, isAvailable: true, prepMinutes: 20,
  },
  {
    id: "bibimbap",
    name: "Korean Bibimbap Bowl",
    description: "Short-grain rice, seasonal veg, gochujang, crispy-edged egg.",
    price: 399, categoryId: "mains", icon: "Salad",
    diet: ["nonveg"], spice: 2, isAvailable: true, prepMinutes: 16,
  },

  /* ---------------------------- Wood-Fired Pizza ------------------------- */
  {
    id: "margherita",
    name: "San Marzano Margherita",
    description: "Fior di latte, torn basil, cold-pressed olive oil, 90-second bake.",
    price: 449, categoryId: "pizza", icon: "Pizza",
    diet: ["veg"], spice: 0, bestSeller: true, isAvailable: true, prepMinutes: 15,
  },
  {
    id: "diavola",
    name: "Diavola",
    description: "Spicy salami, chilli honey, smoked scamorza, oregano.",
    price: 549, categoryId: "pizza", icon: "Pizza",
    diet: ["nonveg"], spice: 3, isAvailable: true, prepMinutes: 15,
  },
  {
    id: "truffle-funghi",
    name: "Truffle Funghi",
    description: "Wild mushrooms, truffle cream, taleggio, rocket, hazelnut.",
    price: 519, categoryId: "pizza", icon: "Pizza",
    diet: ["veg"], spice: 0, isAvailable: true, prepMinutes: 15,
  },
  {
    id: "bbq-chicken-pizza",
    name: "BBQ Chicken & Onion",
    description: "Smoky BBQ base, pickled red onion, coriander, mozzarella.",
    price: 499, categoryId: "pizza", icon: "Pizza",
    diet: ["nonveg"], spice: 1, isAvailable: true, prepMinutes: 15,
  },

  /* ------------------------------- Desserts ------------------------------ */
  {
    id: "basque-cheesecake",
    name: "Basque Burnt Cheesecake",
    description: "Caramelised crown, macerated berries, crème fraîche.",
    price: 329, categoryId: "desserts", icon: "CakeSlice",
    diet: ["veg"], spice: 0, bestSeller: true, isAvailable: true, prepMinutes: 6,
  },
  {
    id: "chocolate-fondant",
    name: "Dark Chocolate Fondant",
    description: "70% Valrhona core, sea salt, vanilla bean gelato.",
    price: 349, categoryId: "desserts", icon: "Cookie",
    diet: ["veg"], spice: 0, isAvailable: true, prepMinutes: 12,
  },
  {
    id: "tiramisu",
    name: "Tiramisu Classico",
    description: "Espresso-soaked savoiardi, whipped mascarpone, cocoa.",
    price: 299, categoryId: "desserts", icon: "IceCream",
    diet: ["veg"], spice: 0, isAvailable: true, prepMinutes: 5,
  },

  /* ----------------------------- Drinks & Bar ---------------------------- */
  {
    id: "old-fashioned",
    name: "Smoked Old Fashioned",
    description: "Small-batch bourbon, demerara, applewood smoke, orange coin.",
    price: 599, categoryId: "bar", icon: "Martini",
    diet: [], spice: 0, bestSeller: true, isAvailable: true, prepMinutes: 5,
  },
  {
    id: "watermelon-cooler",
    name: "Fresh Watermelon Cooler",
    description: "Pressed watermelon, mint, lime, black salt rim.",
    price: 199, categoryId: "bar", icon: "CupSoda",
    diet: ["vegan"], spice: 0, isAvailable: true, prepMinutes: 4,
  },
  {
    id: "craft-lager",
    name: "Craft Draft Lager 500ml",
    description: "Local microbrew — crisp, dry, gently bitter finish.",
    price: 349, categoryId: "bar", icon: "Wine",
    diet: [], spice: 0, isAvailable: false, prepMinutes: 2,
  },
  {
    id: "virgin-colada",
    name: "Virgin Colada",
    description: "Charred pineapple, coconut cream, lime leaf.",
    price: 249, categoryId: "bar", icon: "CupSoda",
    diet: ["vegan"], spice: 0, isAvailable: true, prepMinutes: 5,
  },

  /* ----------------------------- Café & Brews ---------------------------- */
  {
    id: "flat-white",
    name: "Flat White",
    description: "Single-estate Chikmagalur arabica, velvet-steamed milk.",
    price: 189, categoryId: "cafe", icon: "Coffee",
    diet: ["veg"], spice: 0, bestSeller: true, isAvailable: true, prepMinutes: 4,
  },
  {
    id: "vietnamese-coffee",
    name: "Vietnamese Iced Coffee",
    description: "Robusta phin drip, condensed milk, over cracked ice.",
    price: 219, categoryId: "cafe", icon: "Coffee",
    diet: ["veg"], spice: 0, isAvailable: true, prepMinutes: 6,
  },
  {
    id: "matcha-cloud",
    name: "Matcha Cloud Latte",
    description: "Ceremonial Uji matcha, oat milk, torched foam.",
    price: 259, categoryId: "cafe", icon: "Coffee",
    diet: ["vegan"], spice: 0, isAvailable: true, prepMinutes: 5,
  },
  {
    id: "sourdough-jam",
    name: "Sourdough Toast & Jam",
    description: "Cultured butter, seasonal preserves, flaked salt.",
    price: 179, categoryId: "cafe", icon: "Sandwich",
    diet: ["veg"], spice: 0, isAvailable: true, prepMinutes: 7,
  },
];
