import type { RestaurantConfig } from "@/types/config.types";

/* ============================================================================
 * RESTAURANT — CLIENT EDIT ZONE ②
 * ----------------------------------------------------------------------------
 * Business identity, feature switches, locale, booking slots, promotions and
 * n8n webhook endpoints. The UI reads this file exclusively:
 *   • flip a feature flag → the matching tile / view disappears everywhere
 *   • swap the webhook URLs → orders, bookings & feedback route to a new n8n
 *   • change locale → currency, tax line & date formats update globally
 * ==========================================================================*/
export const restaurantConfig: RestaurantConfig = {
  brand: {
    name: "Aura Bistro & Lounge",
    subtitle: "Modern Culinary Experience",
    tagline: "Fire, smoke & seasonal plates",
    address: "12 Indigo Lane, Fort District, Mumbai 400001",
    phone: "+91 98765 43210",
    googleReviewUrl:
      "https://maps.google.com/?cid=15764320918404129803",
    whatsappNumber: "+919876543210", // digits only, E.164
    wifi: {
      ssid: "Aura_Guest_5G",
      pass: "Bistro@2026",
      security: "WPA",
    },
    hours: [
      { day: "Monday",    hours: "12:00 – 23:00", opens: "12:00", closes: "23:00" },
      { day: "Tuesday",   hours: "12:00 – 23:00", opens: "12:00", closes: "23:00" },
      { day: "Wednesday", hours: "12:00 – 23:00", opens: "12:00", closes: "23:00" },
      { day: "Thursday",  hours: "12:00 – 23:30", opens: "12:00", closes: "23:30" },
      { day: "Friday",    hours: "12:00 – 01:00", opens: "12:00", closes: "01:00" },
      { day: "Saturday",  hours: "12:00 – 01:00", opens: "12:00", closes: "01:00" },
      { day: "Sunday",    hours: "11:00 – 23:00", opens: "11:00", closes: "23:00" },
    ],
    socials: {
      instagram: "https://instagram.com/aura.bistro",
    },
  },

  /* NFC tap-point context rendered on the dynamic action header badge.
     In production the tableId is injected by the NFC tag payload. */
  interaction: {
    tableId: "04",
    defaultMode: "dine-in",
    tapLabel: "Tap Mode Active",
  },

  /* Feature toggles — hide entire capabilities per client without code edits. */
  features: {
    enableBookings: true,
    enableReviews: true,
    enableWifi: true,
    enableDirectOrdering: true,
    enableTakeaway: true,
    enableInstallPrompt: true,
    enableHaptics: true,
  },

  locale: {
    locale: "en-IN",
    currencyCode: "INR",
    taxLabel: "GST (5%)",
    taxRate: 0.05,
  },

  booking: {
    lunchSlots: ["12:00", "12:30", "13:00", "13:30", "14:00", "14:30"],
    dinnerSlots: ["18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00"],
    maxGuests: 12,
  },

  /* Rotating marquee above the menu — seasonal promos, happy hours, events. */
  promotions: [
    "Thursday Truffle Night — 20% off all risottos",
    "Happy Hours 4–7 PM · craft drafts 1+1",
    "Chef's 7-course tasting · ₹1,499 per guest",
    "Free Basque cheesecake on your first app order",
  ],

  /* n8n integration — point these at your instance's webhook endpoints.
     When unreachable the app resolves optimistically so demos never break. */
  n8nWebhooks: {
    reservationUrl: "https://your-n8n-instance.com/webhook/reservation",
    feedbackUrl: "https://your-n8n-instance.com/webhook/feedback",
    orderUrl: "https://your-n8n-instance.com/webhook/order",
  },
};
