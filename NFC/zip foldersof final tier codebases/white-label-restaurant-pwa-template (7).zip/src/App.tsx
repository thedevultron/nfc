import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft } from "lucide-react";
import { themeConfig } from "@/config/theme.config";
import { restaurantConfig } from "@/config/restaurant.config";
import { CartProvider, useCart } from "@/hooks/useCart";
import { ToastProvider } from "@/components/ui/toast";
import { Header } from "@/components/layout/Header";
import { BottomNav, type AppView } from "@/components/layout/BottomNav";
import { WifiModal } from "@/components/layout/WifiModal";
import { MenuList } from "@/components/features/MenuList";
import { CartSheet } from "@/components/features/CartSheet";
import { ReviewModal } from "@/components/features/ReviewModal";
import { ReservationSheet, ReservationForm } from "@/components/features/ReservationSheet";
import { AboutView } from "@/components/features/AboutView";
import { cn } from "@/utils/cn";

/* ============================================================================
 * APP SHELL — integration only.
 * No client-specific values live here: theme tokens are written to CSS
 * variables from /src/config/theme.config.ts at boot, and every feature is
 * composed from /config + /components modules. Deploying for a new client =
 * editing the three files in /src/config. Nothing else changes.
 * ==========================================================================*/

/** Writes theme.config into CSS custom properties — the whole re-skin pipeline. */
function useApplyTheme() {
  useEffect(() => {
    const root = document.documentElement;
    const { colors, fonts, radius, density, defaultMode } = themeConfig;
    const tokens: Record<string, string> = {
      "--background": colors.background,
      "--surface": colors.surface,
      "--raised": colors.raised,
      "--line": colors.line,
      "--ink": colors.ink,
      "--muted": colors.muted,
      "--primary": colors.primary,
      "--primary-ink": colors.primaryInk,
      "--accent": colors.accent,
      "--accent-ink": colors.accentInk,
      "--chili": colors.chili,
      "--brand-font-display": `"${fonts.display}", Georgia, serif`,
      "--brand-font-body": `"${fonts.body}", "Avenir Next", sans-serif`,
      "--radius": radius,
      "--pad-card": density === "compact" ? "0.7rem" : "1rem",
    };
    Object.entries(tokens).forEach(([key, value]) => root.style.setProperty(key, value));
    root.dataset.mode = defaultMode;
    root.style.colorScheme = defaultMode;
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", colors.background);
    document.title = `${restaurantConfig.brand.name} · Order at the Table`;
  }, []);
}

/** Layered ambient background — warm key light, sage bounce, grain, vignette. */
function AmbientBackground() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div
        className="absolute -top-36 left-1/2 h-[430px] w-[560px] -translate-x-1/2 rounded-full opacity-[0.14] blur-[110px]"
        style={{ background: "var(--primary)" }}
      />
      <div
        className="absolute top-1/3 -right-28 h-72 w-72 rounded-full opacity-[0.07] blur-[90px]"
        style={{ background: "var(--accent)" }}
      />
      <div className="bg-noise absolute inset-0 opacity-[0.05]" />
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to bottom, transparent 55%, color-mix(in oklab, var(--background) 88%, black))",
        }}
      />
    </div>
  );
}

function PageHeader({ title, subtitle, onBack }: { title: string; subtitle: string; onBack: () => void }) {
  return (
    <div>
      <button
        onClick={onBack}
        aria-label="Back to menu"
        className="-ml-2 flex h-11 w-11 cursor-pointer items-center justify-center rounded-full text-muted transition-colors hover:bg-raised hover:text-ink"
      >
        <ChevronLeft className="h-5 w-5" strokeWidth={2.4} />
      </button>
      <h1 className="font-display mt-1 text-[27px] leading-[1.05] font-semibold tracking-tight">{title}</h1>
      <p className="mt-1.5 text-[12.5px] font-semibold text-muted">{subtitle}</p>
    </div>
  );
}

function AppInner() {
  useApplyTheme();
  const { features } = restaurantConfig;
  const { isOpen: cartOpen, closeCart } = useCart();

  const [view, setView] = useState<AppView>("menu");
  const [wifiOpen, setWifiOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reservationOpen, setReservationOpen] = useState(false);

  /* Guard: a view can be nav-gated by feature flags */
  const activeView: AppView =
    view === "booking" && !features.enableBookings ? "menu" : view;

  return (
    <div className={cn("relative min-h-dvh", themeConfig.enableGlassmorphism && "is-glass")}>
      <AmbientBackground />

      <main className="relative z-10 mx-auto max-w-lg px-4 pt-[calc(env(safe-area-inset-top)+18px)] pb-40">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeView}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ type: "spring", stiffness: 320, damping: 30 }}
          >
            {activeView === "menu" && (
              <>
                <Header
                  onOpenWifi={() => setWifiOpen(true)}
                  onOpenReview={() => setReviewOpen(true)}
                  onOpenBooking={() => setReservationOpen(true)}
                />
                <MenuList />
              </>
            )}

            {activeView === "booking" && (
              <>
                <PageHeader
                  title="Reserve a Table"
                  subtitle="Pick a slot — we'll confirm on WhatsApp"
                  onBack={() => setView("menu")}
                />
                <div className="mt-5">
                  <ReservationForm />
                </div>
              </>
            )}

            {activeView === "about" && (
              <>
                <PageHeader
                  title={restaurantConfig.brand.name}
                  subtitle={restaurantConfig.brand.tagline}
                  onBack={() => setView("menu")}
                />
                <AboutView onOpenWifi={() => setWifiOpen(true)} />
              </>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      <BottomNav
        view={activeView}
        onNavigate={setView}
        onOpenReview={() => setReviewOpen(true)}
      />

      {/* Global overlays — triggered from header, nav and views alike */}
      <CartSheet open={cartOpen} onOpenChange={(o) => !o && closeCart()} />
      <WifiModal open={wifiOpen} onOpenChange={setWifiOpen} />
      <ReviewModal open={reviewOpen} onOpenChange={setReviewOpen} />
      <ReservationSheet open={reservationOpen} onOpenChange={setReservationOpen} />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <CartProvider>
        <AppInner />
      </CartProvider>
    </ToastProvider>
  );
}
