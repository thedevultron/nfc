import { useCallback, useMemo } from "react";
import { restaurantConfig } from "@/config/restaurant.config";

/* ============================================================================
 * HAPTICS — native vibration feedback (Android / supported hardware).
 * Every trigger respects restaurant.config.ts → features.enableHaptics, so a
 * client can silence the whole app with one flag. Silently no-ops on iOS/web.
 * ==========================================================================*/

export function useHaptics() {
  const enabled = restaurantConfig.features.enableHaptics;

  const vibrate = useCallback(
    (pattern: number | number[]) => {
      if (!enabled) return;
      if (typeof navigator !== "undefined" && "vibrate" in navigator) {
        try {
          navigator.vibrate(pattern);
        } catch {
          /* vibration permission unavailable */
        }
      }
    },
    [enabled]
  );

  return useMemo(
    () => ({
      /** Light tick — filter chips, steppers, drawer triggers */
      tap: () => vibrate(10),
      /** Confident blip — adding to cart, selecting a slot */
      select: () => vibrate(18),
      /** Double pulse — order placed, booking confirmed */
      success: () => vibrate([12, 40, 20]),
      /** Heavy buzz — validation errors */
      error: () => vibrate([30, 40, 30]),
    }),
    [vibrate]
  );
}
