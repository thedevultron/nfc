import {
  createContext,
  createElement,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { CartLine, MenuItem } from "@/types/menu.types";
import type { OrderMode } from "@/types/config.types";
import { restaurantConfig } from "@/config/restaurant.config";

/* ============================================================================
 * CART STATE — context + hook
 * Owns line items, quantities, totals (tax rate read from config.locale),
 * the order-mode switch (dine-in ↔ takeaway) and drawer visibility.
 * Persisted to localStorage so a page refresh never loses an in-flight order.
 * ==========================================================================*/

const STORAGE_KEY = "aura.cart.v1";

interface CartContextValue {
  lines: CartLine[];
  count: number;
  subtotal: number;
  tax: number;
  total: number;
  instructions: string;
  setInstructions: (value: string) => void;
  orderMode: OrderMode;
  toggleOrderMode: () => void;
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addItem: (item: MenuItem) => void;
  increment: (itemId: string) => void;
  decrement: (itemId: string) => void;
  removeLine: (itemId: string) => void;
  clear: () => void;
  qtyOf: (itemId: string) => number;
}

const CartContext = createContext<CartContextValue | null>(null);

function loadPersisted(): CartLine[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as CartLine[];
    return Array.isArray(parsed) ? parsed.filter((l) => l?.item && l.qty > 0) : [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(loadPersisted);
  const [instructions, setInstructions] = useState("");
  const [orderMode, setOrderMode] = useState<OrderMode>(
    restaurantConfig.interaction.defaultMode
  );
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      /* storage unavailable — cart lives in memory only */
    }
  }, [lines]);

  const addItem = useCallback((item: MenuItem) => {
    if (!item.isAvailable) return;
    setLines((prev) => {
      const existing = prev.find((l) => l.item.id === item.id);
      if (existing) {
        return prev.map((l) => (l.item.id === item.id ? { ...l, qty: l.qty + 1 } : l));
      }
      return [...prev, { item, qty: 1 }];
    });
  }, []);

  const increment = useCallback((itemId: string) => {
    setLines((prev) => prev.map((l) => (l.item.id === itemId ? { ...l, qty: l.qty + 1 } : l)));
  }, []);

  const decrement = useCallback((itemId: string) => {
    setLines((prev) =>
      prev
        .map((l) => (l.item.id === itemId ? { ...l, qty: l.qty - 1 } : l))
        .filter((l) => l.qty > 0)
    );
  }, []);

  const removeLine = useCallback((itemId: string) => {
    setLines((prev) => prev.filter((l) => l.item.id !== itemId));
  }, []);

  const clear = useCallback(() => {
    setLines([]);
    setInstructions("");
  }, []);

  const qtyOf = useCallback(
    (itemId: string) => lines.find((l) => l.item.id === itemId)?.qty ?? 0,
    [lines]
  );

  const toggleOrderMode = useCallback(() => {
    if (!restaurantConfig.features.enableTakeaway) return;
    setOrderMode((m) => (m === "dine-in" ? "takeaway" : "dine-in"));
  }, []);

  const totals = useMemo(() => {
    const subtotal = lines.reduce((sum, l) => sum + l.item.price * l.qty, 0);
    const tax = Math.round(subtotal * restaurantConfig.locale.taxRate * 100) / 100;
    return { subtotal, tax, total: subtotal + tax };
  }, [lines]);

  const value: CartContextValue = useMemo(
    () => ({
      lines,
      count: lines.reduce((sum, l) => sum + l.qty, 0),
      ...totals,
      instructions,
      setInstructions,
      orderMode,
      toggleOrderMode,
      isOpen,
      openCart: () => setIsOpen(true),
      closeCart: () => setIsOpen(false),
      addItem,
      increment,
      decrement,
      removeLine,
      clear,
      qtyOf,
    }),
    [lines, totals, instructions, orderMode, isOpen, addItem, increment, decrement, removeLine, clear, qtyOf, toggleOrderMode]
  );

  // createElement keeps this module JSX-free so it can ship as `useCart.ts`
  return createElement(CartContext.Provider, { value }, children);
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
