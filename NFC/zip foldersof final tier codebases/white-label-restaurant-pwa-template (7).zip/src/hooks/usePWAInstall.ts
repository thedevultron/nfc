import { useCallback, useEffect, useMemo, useState } from "react";

/* ============================================================================
 * PWA INSTALL — "Add to Home Screen" lifecycle.
 * Captures Chromium's beforeinstallprompt, exposes a programmatic install()
 * and detects iOS (which needs the Share-sheet path) + already-installed.
 * ==========================================================================*/

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function usePWAInstall() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState<boolean>(() =>
    typeof window !== "undefined"
      ? window.matchMedia("(display-mode: standalone)").matches
      : false
  );

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault(); // we surface our own branded install moments
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const install = useCallback(async (): Promise<boolean> => {
    if (!deferred) return false;
    await deferred.prompt();
    const choice = await deferred.userChoice;
    setDeferred(null);
    return choice.outcome === "accepted";
  }, [deferred]);

  const isIOS = useMemo(
    () =>
      typeof navigator !== "undefined" &&
      /iphone|ipad|ipod/i.test(navigator.userAgent),
    []
  );

  return {
    /** Native prompt available (Chromium) and not yet installed */
    canInstall: deferred !== null && !installed,
    installed,
    isIOS,
    install,
  };
}
