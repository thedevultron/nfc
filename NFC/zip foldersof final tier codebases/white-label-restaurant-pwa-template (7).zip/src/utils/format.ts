import { restaurantConfig } from "@/config/restaurant.config";

/* Currency formatting driven by config.locale — one place, whole app. */
const formatter = new Intl.NumberFormat(restaurantConfig.locale.locale, {
  style: "currency",
  currency: restaurantConfig.locale.currencyCode,
  maximumFractionDigits: 0,
});

export function formatPrice(value: number): string {
  return formatter.format(value);
}
