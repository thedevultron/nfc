import { BadgeCheck, Clock, Download, ExternalLink, MapPin, MessageCircle, Phone, Wifi } from "lucide-react";
import { restaurantConfig } from "@/config/restaurant.config";
import { usePWAInstall } from "@/hooks/usePWAInstall";
import { useToast } from "@/components/ui/toast";
import { useHaptics } from "@/hooks/useHaptics";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { buildWhatsAppLink } from "@/services/n8n.service";
import { cn } from "@/utils/cn";

/* ============================================================================
 * ABOUT / INFO VIEW — venue facts, hours, WiFi, install prompt.
 * Every row is derived from restaurant.config.ts; nothing is per-client code.
 * ==========================================================================*/

interface AboutViewProps {
  onOpenWifi: () => void;
}

export function AboutView({ onOpenWifi }: AboutViewProps) {
  const { brand, features } = restaurantConfig;
  const { canInstall, installed, isIOS, install } = usePWAInstall();
  const { toast } = useToast();
  const { tap } = useHaptics();

  const todayIdx = (new Date().getDay() + 6) % 7;
  const today = brand.hours[todayIdx];
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const toMin = (v: string) => {
    const [h, m] = v.split(":").map(Number);
    return h * 60 + m;
  };
  const opens = today && !today.closed ? toMin(today.opens) : 0;
  const closes = today && !today.closed ? toMin(today.closes) : 0;
  const openNow =
    !!today && !today.closed && (closes > opens ? nowMin >= opens && nowMin < closes : nowMin >= opens || nowMin < closes);

  const handleInstall = async () => {
    tap();
    if (canInstall) {
      const ok = await install();
      toast(
        ok
          ? { title: "Installing Aura…", description: "Find it on your home screen", tone: "success" }
          : { title: "Install dismissed", tone: "info" }
      );
    } else if (isIOS) {
      toast({ title: "Add to Home Screen", description: "Safari → Share → Add to Home Screen", tone: "info" });
    }
  };

  return (
    <div className="mt-5 space-y-3">
      {/* ---------- Find us ---------- */}
      <Card>
        <p className="flex items-center gap-2 text-[11px] font-bold tracking-[0.16em] text-muted uppercase">
          <MapPin className="h-4 w-4 text-primary" strokeWidth={2.3} />
          Find us
        </p>
        <p className="mt-2.5 text-[14.5px] leading-snug font-bold">{brand.address}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(brand.address)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-11 items-center gap-2 rounded-full bg-primary px-4 text-[13px] font-bold text-primary-ink"
          >
            <ExternalLink className="h-4 w-4" strokeWidth={2.4} />
            Directions
          </a>
          <a
            href={`tel:${brand.phone.replace(/\s/g, "")}`}
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-raised/60 px-4 text-[13px] font-bold"
          >
            <Phone className="h-4 w-4 text-primary" strokeWidth={2.3} />
            Call
          </a>
          <a
            href={buildWhatsAppLink(brand.whatsappNumber, `Hi ${brand.name}!`)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-raised/60 px-4 text-[13px] font-bold"
          >
            <MessageCircle className="h-4 w-4 text-primary" strokeWidth={2.3} />
            WhatsApp
          </a>
        </div>
        {brand.socials.instagram && (
          <a
            href={brand.socials.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-1.5 text-[12.5px] font-bold text-muted hover:text-primary"
          >
            @aura.bistro
            <ExternalLink className="h-3.5 w-3.5" strokeWidth={2.4} />
          </a>
        )}
      </Card>

      {/* ---------- Hours ---------- */}
      <Card>
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-2 text-[11px] font-bold tracking-[0.16em] text-muted uppercase">
            <Clock className="h-4 w-4 text-primary" strokeWidth={2.3} />
            Opening hours
          </p>
          <Badge tone={openNow ? "accent" : "chili"}>{openNow ? "Open now" : "Closed"}</Badge>
        </div>
        <div className="mt-3 space-y-1.5">
          {brand.hours.map((row, i) => (
            <div
              key={row.day}
              className={cn(
                "flex items-center justify-between rounded-full px-3 py-1.5 text-[13px] font-semibold",
                i === todayIdx ? "bg-primary/10 font-extrabold text-primary" : "text-muted"
              )}
            >
              <span className="flex items-center gap-2">
                {row.day}
                {i === todayIdx && (
                  <Badge tone="primary" className="px-1.5 py-[1px] text-[9.5px]">Today</Badge>
                )}
              </span>
              <span className="font-mono text-[12px]">{row.closed ? "Closed" : row.hours}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* ---------- WiFi ---------- */}
      {features.enableWifi && (
        <Card className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-full bg-primary/15 text-primary">
              <Wifi className="h-5 w-5" strokeWidth={2.1} />
            </span>
            <div>
              <p className="text-[14px] font-extrabold">Guest WiFi</p>
              <p className="text-[12px] font-semibold text-muted">{brand.wifi.ssid}</p>
            </div>
          </div>
          <Button variant="soft" size="sm" onClick={onOpenWifi}>
            Show QR
          </Button>
        </Card>
      )}

      {/* ---------- Install ---------- */}
      {features.enableInstallPrompt && !installed && (canInstall || isIOS) && (
        <Card className="flex items-center justify-between gap-3 border-primary/30 bg-primary/6">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-full bg-primary text-primary-ink">
              <Download className="h-5 w-5" strokeWidth={2.3} />
            </span>
            <div>
              <p className="text-[14px] font-extrabold">Take Aura home</p>
              <p className="text-[12px] font-semibold text-muted">One tap — order faster next visit</p>
            </div>
          </div>
          <Button size="sm" onClick={() => void handleInstall()}>
            Install
          </Button>
        </Card>
      )}

      {installed && (
        <Card className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-full bg-accent/15 text-accent">
            <BadgeCheck className="h-5 w-5" strokeWidth={2.1} />
          </span>
          <div>
            <p className="text-[14px] font-extrabold">App installed</p>
            <p className="text-[12px] font-semibold text-muted">
              Launch Aura from your home screen for the full experience.
            </p>
          </div>
        </Card>
      )}

      {/* ---------- White-label footer ---------- */}
      <p className="pt-2 pb-4 text-center text-[11px] font-semibold text-muted/80">
        White-label PWA shell · re-skin entirely from <span className="font-mono text-primary">/src/config</span>
        <span className="mx-1.5">·</span>© 2026 {brand.name}
      </p>
    </div>
  );
}
