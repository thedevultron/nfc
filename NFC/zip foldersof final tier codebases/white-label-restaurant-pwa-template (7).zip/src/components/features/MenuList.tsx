import { useMemo, useState } from "react";
import { motion, type Variants } from "framer-motion";
import {
  Award, Ban, Beef, CircleDot, Flame, Leaf, Minus, Plus, Search, Sparkles,
  Timer, Utensils, X,
} from "lucide-react";
import { menuCategories, menuItems } from "@/config/menuData";
import { restaurantConfig } from "@/config/restaurant.config";
import type { DietaryTag, MenuItem } from "@/types/menu.types";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { Badge } from "@/components/ui/badge";
import { Button, PRESS_SPRING } from "@/components/ui/button";
import { DynamicIcon } from "@/components/ui/dynamic-icon";
import { formatPrice } from "@/utils/format";
import { cn } from "@/utils/cn";

/* ============================================================================
 * MODULE B — HIGH-CONVERTING DIGITAL MENU
 * Catalog data lives entirely in /src/config/menuData.ts; category chips,
 * dietary filters, sold-out states and the add-to-cart pipeline all derive
 * from it. Nothing here is hard-coded per client.
 * ==========================================================================*/

type DietFilter = "all" | "veg" | "nonveg" | "vegan" | "special";

const DIET_FILTERS: { id: DietFilter; label: string; icon?: typeof Leaf }[] = [
  { id: "all", label: "Everything", icon: Utensils },
  { id: "veg", label: "Veg", icon: CircleDot },
  { id: "nonveg", label: "Non-Veg", icon: Beef },
  { id: "vegan", label: "Vegan", icon: Leaf },
  { id: "special", label: "Chef's Picks", icon: Award },
];

const listVariants: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.045, delayChildren: 0.05 } },
};
const cardVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: PRESS_SPRING },
};

/** FSSAI-style dietary mark: green square = veg/vegan, red square = non-veg. */
function DietMark({ diet }: { diet: DietaryTag[] }) {
  if (diet.length === 0) return null;
  const isNonVeg = diet.includes("nonveg");
  return (
    <span
      title={isNonVeg ? "Non-vegetarian" : diet.includes("vegan") ? "Vegan" : "Vegetarian"}
      className={cn(
        "grid h-[13px] w-[13px] shrink-0 place-items-center rounded-[3px] border-[1.5px]",
        isNonVeg ? "border-chili text-chili" : "border-accent text-accent"
      )}
    >
      <span className="h-[5px] w-[5px] rounded-full bg-current" />
    </span>
  );
}

function DishCard({ item }: { item: MenuItem }) {
  const { addItem, increment, decrement, qtyOf } = useCart();
  const { tap, select } = useHaptics();
  const qty = qtyOf(item.id);
  const soldOut = !item.isAvailable;

  return (
    <motion.div
      variants={cardVariants}
      className={cn(
        "app-surface relative flex gap-3 rounded-card border border-line p-3",
        soldOut && "opacity-75"
      )}
    >
      {/* Icon tile — every dish is icon-driven, no photography required */}
      <div
        className={cn(
          "grid h-16 w-16 shrink-0 place-items-center rounded-card border border-line bg-raised/70 text-primary",
          soldOut && "grayscale"
        )}
      >
        <DynamicIcon name={item.icon} className="h-7 w-7" strokeWidth={1.9} />
      </div>

      <div className="min-w-0 flex-1">
        <h3 className="flex items-center gap-1.5 text-[15px] leading-snug font-extrabold text-ink">
          <DietMark diet={item.diet} />
          <span className="truncate">{item.name}</span>
        </h3>
        <p className="mt-0.5 line-clamp-2 text-[12px] leading-snug font-medium text-muted">
          {item.description}
        </p>
        <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-1">
          <span className="font-display text-[16px] font-semibold text-primary">
            {formatPrice(item.price)}
          </span>
          {item.spice > 0 && (
            <span className="flex items-center gap-[2px]" title={`Spice level ${item.spice}/3`}>
              {Array.from({ length: item.spice }).map((_, i) => (
                <Flame key={i} className="h-3 w-3 text-chili" fill="currentColor" strokeWidth={1} />
              ))}
            </span>
          )}
          <span className="flex items-center gap-1 text-[11px] font-bold text-muted">
            <Timer className="h-3 w-3" strokeWidth={2.4} />
            {item.prepMinutes} min
          </span>
          {item.bestSeller && (
            <Badge tone="primary" className="px-1.5 py-[2px]">
              <Award className="h-3 w-3" />
              Best Seller
            </Badge>
          )}
        </div>
      </div>

      {/* Add / stepper / sold-out */}
      <div className="flex shrink-0 flex-col items-end justify-center">
        {soldOut ? (
          <Badge tone="chili">
            <Ban className="h-3 w-3" />
            Sold Out
          </Badge>
        ) : qty === 0 ? (
          <motion.button
            whileTap={{ scale: 0.85 }}
            transition={PRESS_SPRING}
            onClick={() => {
              select();
              addItem(item);
            }}
            aria-label={`Add ${item.name} to cart`}
            className="grid h-12 w-12 cursor-pointer place-items-center rounded-full bg-primary text-primary-ink shadow-[0_10px_24px_-8px] shadow-primary/60"
          >
            <Plus className="h-5 w-5" strokeWidth={2.75} />
          </motion.button>
        ) : (
          <div className="flex h-12 items-center rounded-full bg-primary text-primary-ink shadow-[0_10px_24px_-8px] shadow-primary/50">
            <button
              onClick={() => {
                tap();
                decrement(item.id);
              }}
              aria-label={`Remove one ${item.name}`}
              className="grid h-full w-10 cursor-pointer place-items-center"
            >
              <Minus className="h-4 w-4" strokeWidth={2.75} />
            </button>
            <motion.span
              key={qty}
              initial={{ scale: 0.4, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={PRESS_SPRING}
              className="w-5 text-center text-[14px] font-extrabold"
            >
              {qty}
            </motion.span>
            <button
              onClick={() => {
                select();
                increment(item.id);
              }}
              aria-label={`Add one ${item.name}`}
              className="grid h-full w-10 cursor-pointer place-items-center"
            >
              <Plus className="h-4 w-4" strokeWidth={2.75} />
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}

export function MenuList() {
  const [query, setQuery] = useState("");
  const [diet, setDiet] = useState<DietFilter>("all");
  const [category, setCategory] = useState("all");
  const { tap } = useHaptics();
  const { promotions } = restaurantConfig;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menuItems.filter((item) => {
      if (category !== "all" && item.categoryId !== category) return false;
      if (diet === "veg" && !item.diet.includes("veg") && !item.diet.includes("vegan")) return false;
      if (diet === "nonveg" && !item.diet.includes("nonveg")) return false;
      if (diet === "vegan" && !item.diet.includes("vegan")) return false;
      if (diet === "special" && !item.bestSeller) return false;
      if (q && !`${item.name} ${item.description}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [category, diet, query]);

  const reset = () => {
    setQuery("");
    setDiet("all");
    setCategory("all");
  };

  return (
    <section className="mt-5">
      {/* ---------- Promotions ticker ---------- */}
      <div className="overflow-hidden rounded-full border border-line bg-raised/40 py-2">
        <div className="animate-marquee flex w-max items-center gap-8 hover:[animation-play-state:paused]">
          {[...promotions, ...promotions].map((line, i) => (
            <span
              key={i}
              className="flex items-center gap-2 text-[12px] font-bold whitespace-nowrap text-muted"
            >
              <Sparkles className="h-3.5 w-3.5 shrink-0 text-primary" strokeWidth={2.4} />
              {line}
            </span>
          ))}
        </div>
      </div>

      {/* ---------- Search ---------- */}
      <div className="mt-3 flex h-12 items-center gap-2.5 rounded-full border border-line bg-raised/50 px-4 transition-colors focus-within:border-primary/60">
        <Search className="h-[17px] w-[17px] shrink-0 text-muted" strokeWidth={2.4} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search dishes, cravings, ingredients…"
          className="w-full bg-transparent text-sm font-semibold outline-none placeholder:text-muted/70"
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            aria-label="Clear search"
            className="grid h-8 w-8 shrink-0 cursor-pointer place-items-center rounded-full text-muted hover:bg-raised hover:text-ink"
          >
            <X className="h-4 w-4" strokeWidth={2.4} />
          </button>
        )}
      </div>

      {/* ---------- Dietary filter pills (layoutId slide) ---------- */}
      <div className="no-scrollbar -mx-4 mt-2.5 flex gap-1.5 overflow-x-auto px-4">
        {DIET_FILTERS.map((f) => {
          const active = diet === f.id;
          const Icon = f.icon;
          return (
            <motion.button
              key={f.id}
              whileTap={{ scale: 0.93 }}
              transition={PRESS_SPRING}
              onClick={() => {
                tap();
                setDiet(f.id);
              }}
              className={cn(
                "relative flex h-9 shrink-0 cursor-pointer items-center gap-1.5 rounded-full px-3.5 text-[12px] font-bold whitespace-nowrap",
                active ? "text-primary-ink" : "border border-line bg-raised/40 text-muted hover:text-ink"
              )}
            >
              {active && (
                <motion.span
                  layoutId="diet-pill"
                  transition={PRESS_SPRING}
                  className="absolute inset-0 rounded-full bg-primary"
                />
              )}
              {Icon && <Icon className="relative z-10 h-3.5 w-3.5" strokeWidth={2.5} />}
              <span className="relative z-10">{f.label}</span>
            </motion.button>
          );
        })}
      </div>

      {/* ---------- Sticky category rail ---------- */}
      <div className="app-surface sticky top-0 z-30 -mx-4 mt-3 border-b border-line/70 px-4 pt-[calc(env(safe-area-inset-top)+8px)] pb-2.5">
        <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
          {[{ id: "all", label: "All", icon: "Sparkles" }, ...menuCategories].map((cat) => {
            const active = category === cat.id;
            return (
              <motion.button
                key={cat.id}
                whileTap={{ scale: 0.93 }}
                transition={PRESS_SPRING}
                onClick={() => {
                  tap();
                  setCategory(cat.id);
                }}
                className={cn(
                  "relative flex h-10 shrink-0 cursor-pointer items-center gap-1.5 rounded-full px-3.5 text-[12.5px] font-bold whitespace-nowrap",
                  active ? "text-primary-ink" : "border border-line text-muted hover:text-ink"
                )}
              >
                {active && (
                  <motion.span
                    layoutId="cat-pill"
                    transition={PRESS_SPRING}
                    className="absolute inset-0 rounded-full bg-primary"
                  />
                )}
                <DynamicIcon
                  name={cat.icon}
                  className="relative z-10 h-4 w-4"
                  strokeWidth={2.3}
                />
                <span className="relative z-10">{cat.label}</span>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* ---------- Result meta ---------- */}
      <div className="mt-3.5 flex items-center justify-between">
        <p className="text-[12px] font-bold tracking-wide text-muted uppercase">
          {filtered.length} {filtered.length === 1 ? "dish" : "dishes"}
        </p>
        {(diet !== "all" || category !== "all" || query) && (
          <button
            onClick={() => {
              tap();
              reset();
            }}
            className="cursor-pointer text-[12px] font-bold text-primary hover:underline"
          >
            Clear filters
          </button>
        )}
      </div>

      {/* ---------- Dish list ---------- */}
      {filtered.length > 0 ? (
        <motion.div variants={listVariants} initial="hidden" animate="show" className="mt-2.5 space-y-2.5">
          {filtered.map((item) => (
            <DishCard key={item.id} item={item} />
          ))}
        </motion.div>
      ) : (
        <div className="mt-14 flex flex-col items-center text-center">
          <span className="grid h-16 w-16 place-items-center rounded-full border border-line bg-raised/60 text-muted">
            <Search className="h-6 w-6" strokeWidth={2} />
          </span>
          <p className="font-display mt-4 text-lg font-semibold">Nothing on the pass</p>
          <p className="mt-1 max-w-[240px] text-[13px] font-medium text-muted">
            No dishes match your current search and filters.
          </p>
          <Button variant="soft" className="mt-5" onClick={reset}>
            <X className="h-4 w-4" strokeWidth={2.5} />
            Clear filters
          </Button>
        </div>
      )}
    </section>
  );
}
