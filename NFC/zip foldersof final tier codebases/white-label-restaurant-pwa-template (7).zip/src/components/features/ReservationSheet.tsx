import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  CalendarDays, Check, ChevronLeft, ChevronRight, Clock, Minus, Plus, Send, Users,
} from "lucide-react";
import { BottomSheet } from "@/components/ui/drawer";
import { Button, PRESS_SPRING } from "@/components/ui/button";
import { useHaptics } from "@/hooks/useHaptics";
import { useToast } from "@/components/ui/toast";
import { apiService } from "@/services/api.service";
import { restaurantConfig } from "@/config/restaurant.config";
import type { ReservationPayload } from "@/types/menu.types";
import { cn } from "@/utils/cn";

/* ============================================================================
 * MODULE E — TABLE RESERVATION
 * Calendar + slot chips + guest stepper. Submission is OPTIMISTIC: the guest
 * sees confirmation instantly while api.service dispatches the payload to the
 * n8n reservation webhook in the background. The same <ReservationForm />
 * powers both the bottom sheet and the full "Book" tab.
 * ==========================================================================*/

const WEEKDAYS = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

function SectionLabel({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <p className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.14em] text-muted uppercase">
      {icon}
      {children}
    </p>
  );
}

export function ReservationForm() {
  const { booking } = restaurantConfig;
  const { tap, select, success, error } = useHaptics();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [guests, setGuests] = useState(2);
  const [date, setDate] = useState<Date | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [monthOffset, setMonthOffset] = useState(0);
  const [formError, setFormError] = useState<string | null>(null);
  const [status, setStatus] = useState<"idle" | "success">("idle");
  const [confirmed, setConfirmed] = useState<ReservationPayload | null>(null);

  const calendar = useMemo(() => {
    const now = new Date();
    const monthDate = new Date(now.getFullYear(), now.getMonth() + monthOffset, 1);
    const year = monthDate.getFullYear();
    const month = monthDate.getMonth();
    const leadingBlanks = (new Date(year, month, 1).getDay() + 6) % 7; // Monday-first
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
      label: monthDate.toLocaleDateString("en-IN", { month: "long", year: "numeric" }),
      leadingBlanks,
      days: Array.from({ length: daysInMonth }, (_, i) => {
        const d = new Date(year, month, i + 1);
        return { value: d, day: i + 1, past: d < today };
      }),
      today,
    };
  }, [monthOffset]);

  const reset = () => {
    setStatus("idle");
    setConfirmed(null);
    setDate(null);
    setTime(null);
    setName("");
    setPhone("");
    setNotes("");
    setGuests(2);
    setFormError(null);
  };

  const submit = () => {
    if (!name.trim()) return fail("Tell us who the table is for.");
    if (phone.replace(/\D/g, "").length < 8) return fail("Add a phone number we can confirm on.");
    if (!date) return fail("Pick a date on the calendar.");
    if (!time) return fail("Choose a time slot.");

    const payload: ReservationPayload = {
      name: name.trim(),
      phone: phone.trim(),
      date: date.toLocaleDateString("en-IN", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      time,
      guests,
      notes: notes.trim(),
      createdAt: new Date().toISOString(),
    };

    /* Optimistic UI: confirm instantly; the webhook fires in the background
       and resolves mock-style when the n8n instance isn't wired yet. */
    void apiService.sendReservation(payload).then((res) =>
      console.info("[reservation] dispatch result:", res)
    );
    setConfirmed(payload);
    setStatus("success");
    success();
    toast({
      title: "Table reserved",
      description: `${payload.date} · ${time} · ${guests} guests`,
      tone: "success",
    });
  };

  const fail = (msg: string) => {
    setFormError(msg);
    error();
  };

  const chip = (value: string) => {
    const active = time === value;
    return (
      <motion.button
        key={value}
        whileTap={{ scale: 0.92 }}
        transition={PRESS_SPRING}
        onClick={() => {
          select();
          setTime(value);
          setFormError(null);
        }}
        className={cn(
          "h-10 cursor-pointer rounded-full border px-3.5 text-[13px] font-bold transition-colors",
          active
            ? "border-transparent bg-primary text-primary-ink"
            : "border-line bg-raised/40 text-muted hover:text-ink"
        )}
      >
        {value}
      </motion.button>
    );
  };

  return (
    <AnimatePresence mode="wait">
      {status === "success" && confirmed ? (
        /* ---------------- Optimistic success ---------------- */
        <motion.div
          key="success"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={PRESS_SPRING}
          className="pt-2 text-center"
        >
          <motion.span
            initial={{ scale: 0.3 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 380, damping: 18 }}
            className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-accent text-accent-ink"
          >
            <Check className="h-7 w-7" strokeWidth={3} />
          </motion.span>
          <p className="font-display mt-4 text-[22px] font-semibold">You're on the list!</p>
          <p className="mt-1 text-[13px] font-medium text-muted">
            We'll confirm on WhatsApp shortly.
          </p>
          <div className="mx-auto mt-5 max-w-xs space-y-2 rounded-card border border-line bg-raised/40 p-4 text-left">
            {[
              { icon: CalendarDays, label: confirmed.date },
              { icon: Clock, label: `${confirmed.time} · ${confirmed.guests} guests` },
              { icon: Users, label: confirmed.name },
            ].map((row, i) => (
              <p key={i} className="flex items-center gap-2.5 text-[13.5px] font-bold">
                <row.icon className="h-4 w-4 text-primary" strokeWidth={2.3} />
                {row.label}
              </p>
            ))}
          </div>
          <div className="mt-5 flex justify-center gap-2">
            <Button variant="soft" onClick={reset}>Book another</Button>
          </div>
        </motion.div>
      ) : (
        /* ---------------- Form ---------------- */
        <motion.div
          key="form"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 0.97 }}
          className="space-y-5 pt-1"
        >
          {/* Calendar */}
          <div>
            <SectionLabel icon={<CalendarDays className="h-3.5 w-3.5 text-primary" strokeWidth={2.4} />}>
              Pick a date
            </SectionLabel>
            <div className="mt-2 rounded-card border border-line bg-raised/40 p-3">
              <div className="flex items-center justify-between px-1">
                <button
                  onClick={() => {
                    tap();
                    setMonthOffset((m) => Math.max(0, m - 1));
                  }}
                  disabled={monthOffset === 0}
                  aria-label="Previous month"
                  className="grid h-9 w-9 cursor-pointer place-items-center rounded-full text-muted hover:bg-raised hover:text-ink disabled:pointer-events-none disabled:opacity-30"
                >
                  <ChevronLeft className="h-4 w-4" strokeWidth={2.5} />
                </button>
                <p className="font-display text-[15px] font-semibold">{calendar.label}</p>
                <button
                  onClick={() => {
                    tap();
                    setMonthOffset((m) => Math.min(2, m + 1));
                  }}
                  disabled={monthOffset === 2}
                  aria-label="Next month"
                  className="grid h-9 w-9 cursor-pointer place-items-center rounded-full text-muted hover:bg-raised hover:text-ink disabled:pointer-events-none disabled:opacity-30"
                >
                  <ChevronRight className="h-4 w-4" strokeWidth={2.5} />
                </button>
              </div>
              <div className="mt-2 grid grid-cols-7 gap-1 text-center">
                {WEEKDAYS.map((d) => (
                  <span key={d} className="py-1 text-[10.5px] font-extrabold tracking-wide text-muted uppercase">
                    {d}
                  </span>
                ))}
                {Array.from({ length: calendar.leadingBlanks }).map((_, i) => (
                  <span key={`b${i}`} />
                ))}
                {calendar.days.map(({ value, day, past }) => {
                  const selected = date?.toDateString() === value.toDateString();
                  const isToday = calendar.today.toDateString() === value.toDateString();
                  return (
                    <motion.button
                      key={day}
                      whileTap={past ? undefined : { scale: 0.85 }}
                      transition={PRESS_SPRING}
                      disabled={past}
                      onClick={() => {
                        select();
                        setDate(value);
                        setFormError(null);
                      }}
                      className={cn(
                        "aspect-square cursor-pointer rounded-full text-[13px] font-bold transition-colors",
                        past && "cursor-default text-muted/35",
                        !past && !selected && "text-ink hover:bg-raised",
                        isToday && !selected && "border border-primary/50 text-primary",
                        selected && "bg-primary text-primary-ink"
                      )}
                    >
                      {day}
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Time slots */}
          <div>
            <SectionLabel icon={<Clock className="h-3.5 w-3.5 text-primary" strokeWidth={2.4} />}>
              Lunch service
            </SectionLabel>
            <div className="mt-2 flex flex-wrap gap-1.5">{booking.lunchSlots.map(chip)}</div>
            <SectionLabel icon={<Clock className="h-3.5 w-3.5 text-primary mt-3" strokeWidth={2.4} />}>
              Dinner service
            </SectionLabel>
            <div className="mt-2 flex flex-wrap gap-1.5">{booking.dinnerSlots.map(chip)}</div>
          </div>

          {/* Guests */}
          <div className="flex items-center justify-between rounded-card border border-line bg-raised/40 px-3.5 py-2.5">
            <span className="flex items-center gap-2 text-[13.5px] font-extrabold">
              <Users className="h-4 w-4 text-primary" strokeWidth={2.3} />
              Guests
            </span>
            <div className="flex items-center gap-1">
              <Button
                variant="soft"
                size="iconSm"
                disabled={guests <= 1}
                onClick={() => setGuests((g) => Math.max(1, g - 1))}
                aria-label="Fewer guests"
              >
                <Minus className="h-4 w-4" strokeWidth={2.5} />
              </Button>
              <motion.span
                key={guests}
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={PRESS_SPRING}
                className="w-9 text-center text-[16px] font-extrabold"
              >
                {guests}
              </motion.span>
              <Button
                variant="soft"
                size="iconSm"
                disabled={guests >= booking.maxGuests}
                onClick={() => setGuests((g) => Math.min(booking.maxGuests, g + 1))}
                aria-label="More guests"
              >
                <Plus className="h-4 w-4" strokeWidth={2.5} />
              </Button>
            </div>
          </div>

          {/* Details */}
          <div className="space-y-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Name on the booking"
              className="h-12 w-full rounded-card border border-line bg-raised/50 px-4 text-sm font-semibold outline-none placeholder:text-muted/60 focus:border-primary/60"
            />
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              type="tel"
              placeholder="WhatsApp / phone number"
              className="h-12 w-full rounded-card border border-line bg-raised/50 px-4 text-sm font-semibold outline-none placeholder:text-muted/60 focus:border-primary/60"
            />
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Occasion, seating preference… (optional)"
              className="w-full resize-none rounded-card border border-line bg-raised/50 px-4 py-3 text-sm font-semibold outline-none placeholder:text-muted/60 focus:border-primary/60"
            />
          </div>

          {formError && (
            <motion.p
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-[12.5px] font-bold text-chili"
            >
              {formError}
            </motion.p>
          )}

          <Button size="lg" className="w-full" onClick={submit}>
            <Send className="h-4 w-4" strokeWidth={2.4} />
            Confirm Reservation
          </Button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface ReservationSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/** Bottom-sheet wrapper — same form, sheet presentation (header quick action). */
export function ReservationSheet({ open, onOpenChange }: ReservationSheetProps) {
  return (
    <BottomSheet open={open} onOpenChange={onOpenChange} label="Reserve a table">
      <div className="no-scrollbar max-h-[85dvh] overflow-y-auto px-5 pt-1 pb-8">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-full bg-primary/15 text-primary">
            <CalendarDays className="h-5 w-5" strokeWidth={2.1} />
          </span>
          <div>
            <h2 className="font-display text-[22px] leading-tight font-semibold">Reserve a Table</h2>
            <p className="text-[12px] font-semibold text-muted">
              We hold bookings for 15 minutes past the slot
            </p>
          </div>
        </div>
        <div className="mt-4">
          <ReservationForm />
        </div>
      </div>
    </BottomSheet>
  );
}
