import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Bike, Check, MessageCircle, Minus, Plus, Send, ShoppingBag, SquarePen,
  Trash2, UtensilsCrossed,
} from "lucide-react";
import { BottomSheet } from "@/components/ui/drawer";
import { Button, PRESS_SPRING } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { useToast } from "@/components/ui/toast";
import { apiService } from "@/services/api.service";
import { buildWhatsAppLink } from "@/services/n8n.service";
import { restaurantConfig } from "@/config/restaurant.config";
import { formatPrice } from "@/utils/format";
import type { OrderPayload } from "@/types/menu.types";

/* ============================================================================
 * MODULE C — DYNAMIC CART SHEET
 * Quantity math, tax line and currency all derive from config. "Place order"
 * dispatches the typed payload to the n8n order webhook; the WhatsApp path
 * URL-encodes the same summary into a wa.me deep link.
 * ==========================================================================*/

type Phase = "idle" | "sending" | "sent";

interface CartSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CartSheet({ open, onOpenChange }: CartSheetProps) {
  const cart = useCart();
  const { tap, select, success } = useHaptics();
  const { toast } = useToast();
  const [phase, setPhase] = useState<Phase>("idle");
  const { brand, features, interaction, locale } = restaurantConfig;

  const buildPayload = (source: OrderPayload["source"]): OrderPayload => ({
    source,
    tableId: interaction.tableId,
    mode: cart.orderMode,
    lines: cart.lines.map((l) => ({
      name: l.item.name,
      qty: l.qty,
      unitPrice: l.item.price,
      lineTotal: l.item.price * l.qty,
    })),
    subtotal: cart.subtotal,
    tax: cart.tax,
    total: cart.total,
    currencyCode: locale.currencyCode,
    instructions: cart.instructions,
    placedAt: new Date().toISOString(),
  });

  const finish = () => {
    window.setTimeout(() => {
      cart.clear();
      setPhase("idle");
      onOpenChange(false);
    }, 1500);
  };

  const placeOrder = async () => {
    setPhase("sending");
    await apiService.sendOrder(buildPayload("kitchen-webhook"));
    success();
    setPhase("sent");
    toast({
      title: "Order sent to kitchen",
      description: `Table ${interaction.tableId} · ${formatPrice(cart.total)}`,
      tone: "success",
    });
    finish();
  };

  const orderViaWhatsApp = () => {
    const lines = cart.lines
      .map((l) => `• ${l.qty} × ${l.item.name} — ${formatPrice(l.item.price * l.qty)}`)
      .join("\n");
    const message = [
      `*${brand.name}* — new order`,
      cart.orderMode === "dine-in"
        ? `Table ${interaction.tableId} (Dine-In)`
        : "Takeaway order",
      "",
      lines,
      "",
      `Subtotal: ${formatPrice(cart.subtotal)}`,
      `${locale.taxLabel}: ${formatPrice(cart.tax)}`,
      `*Total: ${formatPrice(cart.total)}*`,
      cart.instructions ? `Notes: ${cart.instructions}` : "",
    ]
      .filter(Boolean)
      .join("\n");
    window.open(buildWhatsAppLink(brand.whatsappNumber, message), "_blank", "noopener");
    void apiService.sendOrder(buildPayload("whatsapp"));
    select();
    toast({
      title: "Opening WhatsApp…",
      description: "Order summary is pre-filled for you",
      tone: "info",
    });
    finish();
  };

  const empty = cart.lines.length === 0 && phase !== "sent";

  return (
    <BottomSheet open={open} onOpenChange={onOpenChange} label="Your order">
      <div className="no-scrollbar max-h-[85dvh] overflow-y-auto px-5 pt-1 pb-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <h2 className="font-display text-[22px] leading-tight font-semibold">Your Order</h2>
            {cart.count > 0 && phase !== "sent" && (
              <Badge tone="primary">{cart.count} items</Badge>
            )}
          </div>
          <span className="flex items-center gap-1.5 rounded-full border border-line bg-raised/60 px-3 py-1.5 text-[11.5px] font-bold">
            {cart.orderMode === "dine-in" ? (
              <UtensilsCrossed className="h-3.5 w-3.5 text-primary" strokeWidth={2.4} />
            ) : (
              <Bike className="h-3.5 w-3.5 text-primary" strokeWidth={2.4} />
            )}
            {cart.orderMode === "dine-in" ? `Table ${interaction.tableId}` : "Takeaway"}
          </span>
        </div>

        <AnimatePresence mode="wait">
          {/* ---------------- Success state ---------------- */}
          {phase === "sent" ? (
            <motion.div
              key="sent"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={PRESS_SPRING}
              className="flex flex-col items-center py-12 text-center"
            >
              <motion.span
                initial={{ scale: 0.3 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 380, damping: 18 }}
                className="grid h-16 w-16 place-items-center rounded-full bg-accent text-accent-ink"
              >
                <Check className="h-7 w-7" strokeWidth={3} />
              </motion.span>
              <p className="font-display mt-4 text-xl font-semibold">Order dispatched</p>
              <p className="mt-1 max-w-[250px] text-[13px] font-medium text-muted">
                The kitchen has your ticket. Sit back — it's on its way to table{" "}
                {interaction.tableId}.
              </p>
            </motion.div>
          ) : empty ? (
            /* ---------------- Empty state ---------------- */
            <motion.div
              key="empty"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center py-12 text-center"
            >
              <span className="grid h-16 w-16 place-items-center rounded-full border border-line bg-raised/60 text-muted">
                <ShoppingBag className="h-6 w-6" strokeWidth={2} />
              </span>
              <p className="font-display mt-4 text-xl font-semibold">Nothing here yet</p>
              <p className="mt-1 text-[13px] font-medium text-muted">
                Dishes you add will appear in this tray.
              </p>
              <Button variant="soft" className="mt-5" onClick={() => onOpenChange(false)}>
                Browse the menu
              </Button>
            </motion.div>
          ) : (
            /* ---------------- Line items ---------------- */
            <motion.div key="lines" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="mt-3 divide-y divide-line/70">
                {cart.lines.map((line) => (
                  <div key={line.item.id} className="flex items-center gap-3 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-extrabold">{line.item.name}</p>
                      <p className="text-[11.5px] font-semibold text-muted">
                        {formatPrice(line.item.price)} each
                      </p>
                    </div>
                    <div className="flex h-10 items-center rounded-full border border-line">
                      <button
                        onClick={() => {
                          tap();
                          cart.decrement(line.item.id);
                        }}
                        aria-label={`One less ${line.item.name}`}
                        className="grid h-full w-9 cursor-pointer place-items-center text-muted hover:text-chili"
                      >
                        <Minus className="h-3.5 w-3.5" strokeWidth={2.75} />
                      </button>
                      <motion.span
                        key={line.qty}
                        initial={{ scale: 0.5, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={PRESS_SPRING}
                        className="w-5 text-center text-[13px] font-extrabold"
                      >
                        {line.qty}
                      </motion.span>
                      <button
                        onClick={() => {
                          tap();
                          cart.increment(line.item.id);
                        }}
                        aria-label={`One more ${line.item.name}`}
                        className="grid h-full w-9 cursor-pointer place-items-center text-muted hover:text-accent"
                      >
                        <Plus className="h-3.5 w-3.5" strokeWidth={2.75} />
                      </button>
                    </div>
                    <span className="w-[68px] text-right text-[14px] font-extrabold text-primary">
                      {formatPrice(line.item.price * line.qty)}
                    </span>
                    <button
                      onClick={() => {
                        tap();
                        cart.removeLine(line.item.id);
                      }}
                      aria-label={`Remove ${line.item.name}`}
                      className="grid h-9 w-7 cursor-pointer place-items-center rounded-full text-muted hover:text-chili"
                    >
                      <Trash2 className="h-4 w-4" strokeWidth={2.2} />
                    </button>
                  </div>
                ))}
              </div>

              {/* Kitchen notes */}
              <label className="mt-2 block">
                <span className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.14em] text-muted uppercase">
                  <SquarePen className="h-3.5 w-3.5" strokeWidth={2.2} />
                  Special instructions
                </span>
                <textarea
                  value={cart.instructions}
                  onChange={(e) => cart.setInstructions(e.target.value)}
                  rows={2}
                  placeholder="No onions, extra spicy, allergies…"
                  className="mt-1.5 w-full resize-none rounded-card border border-line bg-raised/50 px-3.5 py-2.5 text-sm font-semibold outline-none placeholder:text-muted/60 focus:border-primary/60"
                />
              </label>

              {/* Totals */}
              <div className="mt-3 space-y-1.5 rounded-card border border-line bg-raised/40 p-3.5 text-[13px] font-semibold">
                <div className="flex justify-between text-muted">
                  <span>Subtotal</span>
                  <span>{formatPrice(cart.subtotal)}</span>
                </div>
                <div className="flex justify-between text-muted">
                  <span>{locale.taxLabel}</span>
                  <span>{formatPrice(cart.tax)}</span>
                </div>
                <div className="flex items-center justify-between border-t border-dashed border-line pt-2">
                  <span className="text-[14px] font-extrabold text-ink">Total</span>
                  <span className="font-display text-[19px] font-semibold text-primary">
                    {formatPrice(cart.total)}
                  </span>
                </div>
              </div>

              {/* Actions */}
              {features.enableDirectOrdering && (
                <div className="mt-4 space-y-2">
                  <Button
                    size="lg"
                    className="w-full"
                    disabled={phase === "sending"}
                    onClick={() => void placeOrder()}
                  >
                    {phase === "sending" ? (
                      <>
                        <motion.span
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}
                          className="h-4 w-4 rounded-full border-2 border-primary-ink/30 border-t-primary-ink"
                        />
                        Sending to kitchen…
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" strokeWidth={2.4} />
                        Place Order via Kitchen
                      </>
                    )}
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full"
                    disabled={phase === "sending"}
                    onClick={orderViaWhatsApp}
                  >
                    <MessageCircle className="h-4 w-4" strokeWidth={2.3} />
                    Order on WhatsApp
                  </Button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </BottomSheet>
  );
}
