import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ExternalLink, NotebookPen, Send, Star } from "lucide-react";
import { BottomSheet } from "@/components/ui/drawer";
import { Button, PRESS_SPRING } from "@/components/ui/button";
import { useHaptics } from "@/hooks/useHaptics";
import { useToast } from "@/components/ui/toast";
import { apiService } from "@/services/api.service";
import { restaurantConfig } from "@/config/restaurant.config";
import type { FeedbackPayload } from "@/types/menu.types";
import { cn } from "@/utils/cn";

/* ============================================================================
 * MODULE D — SMART REVIEW & FEEDBACK FILTER
 * The rating quietly routes the guest:
 *   ★★★★★ 4–5 → high-visibility "Post Public Review on Google" button
 *   ★ 1–3   → private manager feedback form (webhook), never public
 * Protects the public rating while every complaint still reaches the team.
 * ==========================================================================*/

type Stage = "rate" | "public" | "private" | "sent";

const RATING_WORDS = ["", "Ouch — tell us more", "Not your day", "Almost there", "Lovely!", "Exceptional!"];

interface ReviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ReviewModal({ open, onOpenChange }: ReviewModalProps) {
  const { select, success, error } = useHaptics();
  const { toast } = useToast();
  const { brand } = restaurantConfig;

  const [stage, setStage] = useState<Stage>("rate");
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [message, setMessage] = useState("");
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [sending, setSending] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const reset = () => {
    setStage("rate");
    setRating(0);
    setHover(0);
    setMessage("");
    setName("");
    setContact("");
    setSending(false);
    setFormError(null);
  };

  const close = () => {
    onOpenChange(false);
    window.setTimeout(reset, 350);
  };

  const pick = (value: number) => {
    setRating(value);
    select();
    /* Let the stars land, then route by sentiment */
    window.setTimeout(() => setStage(value >= 4 ? "public" : "private"), 480);
  };

  const sendPrivateFeedback = async () => {
    if (message.trim().length < 5) {
      setFormError("Give the manager at least a sentence to work with.");
      error();
      return;
    }
    setFormError(null);
    setSending(true);
    const payload: FeedbackPayload = {
      rating,
      message: message.trim(),
      name: name.trim() || undefined,
      contact: contact.trim() || undefined,
      channel: "smart-review-filter",
      createdAt: new Date().toISOString(),
    };
    await apiService.sendFeedback(payload);
    success();
    setSending(false);
    setStage("sent");
    toast({ title: "Sent to the manager", description: "Privately — nothing was posted", tone: "success" });
  };

  const shown = hover || rating;

  return (
    <BottomSheet open={open} onOpenChange={(o) => (o ? onOpenChange(true) : close())} label="Rate your visit">
      <div className="px-5 pt-1 pb-9">
        <AnimatePresence mode="wait">
          {/* ---------------- Stage: rate ---------------- */}
          {stage === "rate" && (
            <motion.div
              key="rate"
              initial={{ opacity: 0, x: 28 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -28 }}
              transition={PRESS_SPRING}
              className="text-center"
            >
              <h2 className="font-display text-[24px] font-semibold">How was everything?</h2>
              <p className="mx-auto mt-1.5 max-w-[290px] text-[13px] font-medium text-muted">
                Praise goes public, problems go straight to the manager — privately.
              </p>
              <div className="mt-5 flex justify-center gap-1.5" onMouseLeave={() => setHover(0)}>
                {[1, 2, 3, 4, 5].map((value) => (
                  <motion.button
                    key={value}
                    whileTap={{ scale: 0.78 }}
                    transition={PRESS_SPRING}
                    onMouseEnter={() => setHover(value)}
                    onClick={() => pick(value)}
                    aria-label={`${value} star${value > 1 ? "s" : ""}`}
                    className="grid h-12 w-12 cursor-pointer place-items-center"
                  >
                    <Star
                      className={cn(
                        "h-8 w-8 transition-all duration-200",
                        value <= shown ? "text-primary" : "text-line"
                      )}
                      fill={value <= shown ? "currentColor" : "none"}
                      strokeWidth={1.6}
                    />
                  </motion.button>
                ))}
              </div>
              <p className="mt-2 h-5 text-[13px] font-bold text-primary">
                {RATING_WORDS[shown]}
              </p>
            </motion.div>
          )}

          {/* ---------------- Stage: public (4–5★) ---------------- */}
          {stage === "public" && (
            <motion.div
              key="public"
              initial={{ opacity: 0, x: 28 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -28 }}
              transition={PRESS_SPRING}
              className="text-center"
            >
              <div className="flex justify-center gap-1">
                {[1, 2, 3, 4, 5].map((v) => (
                  <Star
                    key={v}
                    className={cn("h-5 w-5", v <= rating ? "text-primary" : "text-line")}
                    fill={v <= rating ? "currentColor" : "none"}
                    strokeWidth={1.6}
                  />
                ))}
              </div>
              <h2 className="font-display mt-3 text-[24px] font-semibold">
                {rating === 5 ? "You made our day!" : "Wonderful — thank you!"}
              </h2>
              <p className="mx-auto mt-1.5 max-w-[290px] text-[13px] font-medium text-muted">
                Would you share it publicly? Twenty seconds of yours keeps the whole team cooking.
              </p>
              <Button
                size="lg"
                className="mt-6 w-full"
                onClick={() => window.open(brand.googleReviewUrl, "_blank", "noopener")}
              >
                <ExternalLink className="h-4 w-4" strokeWidth={2.5} />
                Post Public Review on Google
              </Button>
              <Button size="lg" variant="ghost" className="mt-2 w-full" onClick={close}>
                Maybe later
              </Button>
            </motion.div>
          )}

          {/* ---------------- Stage: private (<4★) ---------------- */}
          {stage === "private" && (
            <motion.div
              key="private"
              initial={{ opacity: 0, x: 28 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -28 }}
              transition={PRESS_SPRING}
            >
              <div className="flex items-center gap-3">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary/15 text-primary">
                  <NotebookPen className="h-5 w-5" strokeWidth={2} />
                </span>
                <div>
                  <h2 className="font-display text-[21px] leading-tight font-semibold">
                    Tell the manager what we can improve
                  </h2>
                  <p className="text-[12px] font-semibold text-muted">
                    Private — never posted anywhere.
                  </p>
                </div>
              </div>

              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={3}
                autoFocus
                placeholder="What went wrong? The dish, the wait, the table…"
                className="mt-4 w-full resize-none rounded-card border border-line bg-raised/50 px-3.5 py-3 text-sm font-semibold outline-none placeholder:text-muted/60 focus:border-primary/60"
              />
              {formError && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-1.5 text-[12px] font-bold text-chili"
                >
                  {formError}
                </motion.p>
              )}
              <div className="mt-2 grid grid-cols-2 gap-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Name (optional)"
                  className="h-12 w-full rounded-card border border-line bg-raised/50 px-3.5 text-sm font-semibold outline-none placeholder:text-muted/60 focus:border-primary/60"
                />
                <input
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="Phone / email"
                  className="h-12 w-full rounded-card border border-line bg-raised/50 px-3.5 text-sm font-semibold outline-none placeholder:text-muted/60 focus:border-primary/60"
                />
              </div>
              <Button size="lg" className="mt-3 w-full" disabled={sending} onClick={() => void sendPrivateFeedback()}>
                {sending ? (
                  <>
                    <motion.span
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}
                      className="h-4 w-4 rounded-full border-2 border-primary-ink/30 border-t-primary-ink"
                    />
                    Sending…
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" strokeWidth={2.4} />
                    Send to the Manager
                  </>
                )}
              </Button>
              <button
                onClick={() => setStage("rate")}
                className="mx-auto mt-2.5 block cursor-pointer text-[12.5px] font-bold text-muted hover:text-ink"
              >
                Change my rating
              </button>
            </motion.div>
          )}

          {/* ---------------- Stage: sent ---------------- */}
          {stage === "sent" && (
            <motion.div
              key="sent"
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={PRESS_SPRING}
              className="flex flex-col items-center py-6 text-center"
            >
              <motion.span
                initial={{ scale: 0.3 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 380, damping: 18 }}
                className="grid h-16 w-16 place-items-center rounded-full bg-accent text-accent-ink"
              >
                <Check className="h-7 w-7" strokeWidth={3} />
              </motion.span>
              <p className="font-display mt-4 text-xl font-semibold">Delivered to the manager</p>
              <p className="mt-1 max-w-[260px] text-[13px] font-medium text-muted">
                Thank you for the honest note — the team will make it right.
              </p>
              <Button variant="soft" className="mt-5" onClick={close}>
                Done
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </BottomSheet>
  );
}
