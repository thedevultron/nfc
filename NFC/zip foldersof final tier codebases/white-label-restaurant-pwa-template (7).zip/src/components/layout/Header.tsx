import { motion } from "framer-motion";
import { Download, Nfc } from "lucide-react";
import { restaurantConfig } from "@/config/restaurant.config";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { usePWAInstall } from "@/hooks/usePWAInstall";
import { useToast } from "@/components/ui/toast";
import { DynamicIcon } from "@/components/ui/dynamic-icon";
import { PRESS_SPRING } from "@/components/ui/button";
import { buildWhatsAppLink } from "@/services/n8n.service";
import { cn } from "@/utils/cn";

/* ============================================================================
 * MODULE A — DYNAMIC ACTION HEADER
 * Reads brand + feature flags from /src/config/restaurant.config.ts:
 *   • NFC badge reflects interaction.tableId & live order mode
 *   • quick-action tiles appear/disappear purely via features.* flags
 * ==========================================================================*/

interface HeaderProps {
  onOpenWifi: () => void;
  onOpenReview: () => void;
  onOpenBooking: () => void;
}

function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

/** Live Open/Closed pill derived from brand.hours — no hardcoded copy. */
function useOpenStatus() {
  const today = restaurantConfig.brand.hours[(new Date().getDay() + 6) % 7];
  if (!today || today.closed) return { open: false, label: "Closed today" };
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const opens = toMinutes(today.opens);
  const closes = toMinutes(today.closes);
  const isOpen = closes > opens ? nowMin >= opens && nowMin < closes : nowMin >= opens || nowMin < closes;
  return { open: isOpen, label: isOpen ? `Open · till ${today.closes}` : `Opens ${today.opens}` };
}

export function Header({ onOpenWifi, onOpenReview, onOpenBooking }: HeaderProps) {
  const { brand, features, interaction } = restaurantConfig;
  const { orderMode, toggleOrderMode } = useCart();
  const { canInstall, installed, isIOS, install } = usePWAInstall();
  const { toast } = useToast();
  const { tap, select } = useHaptics();
  const status = useOpenStatus();

  const handleInstall = async () => {
    if (canInstall) {
      const ok = await install();
      toast(
        ok
          ? { title: "Installing Aura…", description: "Find it on your home screen", tone: "success" }
          : { title: "Install dismissed", description: "You can install anytime from the menu", tone: "info" }
      );
    } else if (isIOS) {
      toast({
        title: "Add to Home Screen",
        description: "Safari → Share → Add to Home Screen",
        tone: "info",
      });
    }
  };

  /* Quick-action grid — every tile is gated by a feature flag. */
  const quickActions = [
    ...(features.enableWifi
      ? [{ id: "wifi", icon: "Wifi", label: "Guest WiFi", onClick: onOpenWifi }]
      : []),
    {
      id: "whatsapp",
      icon: "MessageCircle",
      label: "WhatsApp",
      href: buildWhatsAppLink(
        brand.whatsappNumber,
        `Hi ${brand.name}! I'm at table ${interaction.tableId} and have a question.`
      ),
    },
    ...(features.enableReviews
      ? [{ id: "review", icon: "Star", label: "Rate Us", onClick: onOpenReview }]
      : []),
    ...(features.enableBookings
      ? [{ id: "booking", icon: "CalendarDays", label: "Book Table", onClick: onOpenBooking }]
      : []),
  ];

  return (
    <header>
      {/* ---------- Brand + live status + install ---------- */}
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="font-display text-[27px] leading-[1.05] font-semibold tracking-tight text-ink">
            {brand.name}
          </h1>
          <p className="mt-1.5 text-[10.5px] font-bold tracking-[0.22em] text-muted uppercase">
            {brand.subtitle}
          </p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-raised/70 px-2.5 py-1 text-[11px] font-bold text-ink">
            <span className="relative flex h-2 w-2">
              {status.open && (
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-60" />
              )}
              <span
                className={cn(
                  "relative inline-flex h-2 w-2 rounded-full",
                  status.open ? "bg-accent" : "bg-chili"
                )}
              />
            </span>
            {status.label}
          </span>
          {features.enableInstallPrompt && !installed && (canInstall || isIOS) && (
            <motion.button
              whileTap={{ scale: 0.92 }}
              transition={PRESS_SPRING}
              onClick={() => {
                tap();
                void handleInstall();
              }}
              className="inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-full border border-primary/35 bg-primary/12 px-3 text-[11.5px] font-bold text-primary"
            >
              <Download className="h-3.5 w-3.5" strokeWidth={2.75} />
              Get the app
            </motion.button>
          )}
        </div>
      </div>

      {/* ---------- NFC touchpoint context badge ---------- */}
      <motion.button
        whileTap={{ scale: 0.97 }}
        transition={PRESS_SPRING}
        onClick={() => {
          select();
          toggleOrderMode();
        }}
        disabled={!features.enableTakeaway}
        className={cn(
          "mt-4 flex w-full cursor-pointer items-center justify-between rounded-card border border-line bg-raised/50 px-3.5 py-2.5",
          !features.enableTakeaway && "cursor-default"
        )}
        title={features.enableTakeaway ? "Tap to switch order mode" : undefined}
      >
        <span className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-primary/15 text-primary">
            <Nfc className="h-4 w-4" strokeWidth={2.4} />
          </span>
          <span className="text-left">
            <span className="block text-[13px] leading-tight font-extrabold">
              Table {interaction.tableId}
            </span>
            <span className="block text-[10.5px] leading-tight font-semibold text-primary">
              {interaction.tapLabel}
            </span>
          </span>
        </span>
        <span className="flex items-center gap-1.5 rounded-full border border-line bg-surface px-3 py-1.5 text-[11.5px] font-bold">
          <DynamicIcon
            name={orderMode === "dine-in" ? "UtensilsCrossed" : "Bike"}
            className="h-3.5 w-3.5 text-primary"
            strokeWidth={2.5}
          />
          {orderMode === "dine-in" ? "Dine-In" : "Takeaway"}
        </span>
      </motion.button>

      {/* ---------- Quick action grid (icon-driven, flag-gated) ---------- */}
      <div
        className="mt-3 grid gap-2"
        style={{ gridTemplateColumns: `repeat(${quickActions.length}, minmax(0, 1fr))` }}
      >
        {quickActions.map((action, i) => {
          const inner = (
            <>
              <span className="grid h-10 w-10 place-items-center rounded-full border border-line bg-surface text-primary">
                <DynamicIcon name={action.icon} className="h-[19px] w-[19px]" strokeWidth={2.2} />
              </span>
              <span className="text-[11px] font-bold text-muted group-hover:text-ink">
                {action.label}
              </span>
            </>
          );
          const tileClass =
            "group flex min-h-[84px] cursor-pointer flex-col items-center justify-center gap-1.5 rounded-card border border-line bg-raised/40 transition-colors hover:bg-raised/80";
          return "href" in action && action.href ? (
            <motion.a
              key={action.id}
              href={action.href}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...PRESS_SPRING, delay: 0.05 + i * 0.05 }}
              whileTap={{ scale: 0.93 }}
              onClick={() => tap()}
              className={tileClass}
            >
              {inner}
            </motion.a>
          ) : (
            <motion.button
              key={action.id}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...PRESS_SPRING, delay: 0.05 + i * 0.05 }}
              whileTap={{ scale: 0.93 }}
              onClick={() => {
                tap();
                action.onClick?.();
              }}
              className={tileClass}
            >
              {inner}
            </motion.button>
          );
        })}
      </div>
    </header>
  );
}
