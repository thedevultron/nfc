import { useState } from "react";
import QRCode from "react-qr-code";
import { Copy, Eye, EyeOff, QrCode, Wifi } from "lucide-react";
import { restaurantConfig } from "@/config/restaurant.config";
import { useToast } from "@/components/ui/toast";
import { useHaptics } from "@/hooks/useHaptics";
import { BottomSheet } from "@/components/ui/drawer";

/* ============================================================================
 * INSTANT WIFI — SSID + password with a scannable WIFI:-scheme QR payload.
 * All credentials come from restaurant.config.ts → brand.wifi.
 * ==========================================================================*/

interface WifiModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WifiModal({ open, onOpenChange }: WifiModalProps) {
  const { ssid, pass, security } = restaurantConfig.brand.wifi;
  const { toast } = useToast();
  const { tap } = useHaptics();
  const [revealed, setRevealed] = useState(false);

  const wifiPayload = `WIFI:T:${security};S:${ssid};P:${pass};;`;

  const copy = async (value: string, what: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast({ title: `${what} copied`, description: value, tone: "success" });
    } catch {
      toast({ title: "Couldn't copy", description: "Long-press the text instead", tone: "error" });
    }
  };

  const row = (label: string, value: string, display: string, extra?: React.ReactNode) => (
    <div className="flex items-center justify-between gap-3 rounded-card border border-line bg-raised/50 px-3.5 py-3">
      <div className="min-w-0">
        <p className="text-[10.5px] font-bold tracking-[0.14em] text-muted uppercase">{label}</p>
        <p className="mt-0.5 truncate font-mono text-[15px] font-bold text-ink">{display}</p>
      </div>
      <div className="flex items-center gap-1">
        {extra}
        <button
          onClick={() => {
            tap();
            void copy(value, label);
          }}
          className="grid h-11 w-11 cursor-pointer place-items-center rounded-full text-muted transition-colors hover:bg-raised hover:text-primary"
          aria-label={`Copy ${label}`}
        >
          <Copy className="h-[17px] w-[17px]" strokeWidth={2.2} />
        </button>
      </div>
    </div>
  );

  return (
    <BottomSheet open={open} onOpenChange={onOpenChange} label="Guest WiFi">
      <div className="px-5 pt-1 pb-8">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-full bg-primary/15 text-primary">
            <Wifi className="h-5 w-5" strokeWidth={2.2} />
          </span>
          <div>
            <h2 className="font-display text-[22px] leading-tight font-semibold">Join Guest WiFi</h2>
            <p className="text-[12px] font-semibold text-muted">Scan the code or copy the details</p>
          </div>
        </div>

        {/* QR — dark modules on a light tile so any camera app can read it */}
        <div className="mt-5 flex justify-center">
          <div className="rounded-card border border-line bg-[hsl(40_45%_94%)] p-4">
            <QRCode value={wifiPayload} size={148} fgColor="#1c1610" bgColor="transparent" />
          </div>
        </div>

        <div className="mt-5 space-y-2">
          {row("Network", ssid, ssid)}
          {row("Password", pass, revealed ? pass : "•".repeat(pass.length), (
            <button
              onClick={() => {
                tap();
                setRevealed((r) => !r);
              }}
              className="grid h-11 w-11 cursor-pointer place-items-center rounded-full text-muted transition-colors hover:bg-raised hover:text-primary"
              aria-label={revealed ? "Hide password" : "Show password"}
            >
              {revealed ? (
                <EyeOff className="h-[17px] w-[17px]" strokeWidth={2.2} />
              ) : (
                <Eye className="h-[17px] w-[17px]" strokeWidth={2.2} />
              )}
            </button>
          ))}
        </div>

        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[11.5px] font-semibold text-muted">
          <QrCode className="h-3.5 w-3.5" />
          Point your camera at the code — most phones join automatically
        </p>
      </div>
    </BottomSheet>
  );
}
