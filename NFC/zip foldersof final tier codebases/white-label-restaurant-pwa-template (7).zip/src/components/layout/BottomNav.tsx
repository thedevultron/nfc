import { motion } from "framer-motion";
import { CalendarDays, Info, ShoppingBag, Star, UtensilsCrossed, type LucideIcon } from "lucide-react";
import { restaurantConfig } from "@/config/restaurant.config";
import { useCart } from "@/hooks/useCart";
import { useHaptics } from "@/hooks/useHaptics";
import { PRESS_SPRING } from "@/components/ui/button";
import { cn } from "@/utils/cn";

/* ============================================================================
 * FIXED BOTTOM NAV + CART FAB
 * Tabs are flag-gated (Book ↔ features.enableBookings, Rate ↔ enableReviews).
 * The active-tab pill and the cart badge animate with shared layout springs.
 * ==========================================================================*/

export type AppView = "menu" | "booking" | "about";

interface BottomNavProps {
  view: AppView;
  onNavigate: (view: AppView) => void;
  onOpenReview: () => void;
}

interface TabDef {
  id: string;
  icon: LucideIcon;
  label: string;
  view?: AppView;
  action?: () => void;
}

export function BottomNav({ view, onNavigate, onOpenReview }: BottomNavProps) {
  const { features } = restaurantConfig;
  const { count, openCart } = useCart();
  const { select } = useHaptics();

  const leftTabs: TabDef[] = [
    { id: "menu", icon: UtensilsCrossed, label: "Menu", view: "menu" },
    ...(features.enableBookings
      ? [{ id: "booking", icon: CalendarDays, label: "Book", view: "booking" as AppView }]
      : []),
  ];
  const rightTabs: TabDef[] = [
    ...(features.enableReviews
      ? [{ id: "reviews", icon: Star, label: "Rate", action: onOpenReview }]
      : []),
    { id: "about", icon: Info, label: "About", view: "about" },
  ];

  const renderTab = (tab: TabDef) => {
    const active = tab.view !== undefined && tab.view === view;
    return (
      <motion.button
        key={tab.id}
        whileTap={{ scale: 0.9 }}
        transition={PRESS_SPRING}
        onClick={() => {
          select();
          if (tab.view) onNavigate(tab.view);
          else tab.action?.();
        }}
        className={cn(
          "relative flex min-h-[52px] min-w-[64px] flex-1 cursor-pointer flex-col items-center justify-center gap-0.5 rounded-card",
          active ? "text-primary" : "text-muted hover:text-ink"
        )}
        aria-label={tab.label}
      >
        {active && (
          <motion.span
            layoutId="nav-pill"
            transition={PRESS_SPRING}
            className="absolute inset-x-2.5 top-1 bottom-1 rounded-full border border-line bg-raised"
          />
        )}
        <tab.icon className="relative z-10 h-5 w-5" strokeWidth={active ? 2.5 : 2.1} />
        <span className="relative z-10 text-[10px] font-extrabold tracking-wide">
          {tab.label}
        </span>
      </motion.button>
    );
  };

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40">
      <div className="app-surface mx-auto max-w-lg border-t border-line px-2 pt-1 pb-[calc(env(safe-area-inset-bottom)+8px)]">
        <div className="flex items-center gap-1">
          <div className="flex flex-1 items-center gap-1">
            {leftTabs.map(renderTab)}
          </div>

          {/* Center cart trigger */}
          <motion.button
            whileTap={{ scale: 0.88 }}
            transition={PRESS_SPRING}
            onClick={() => {
              select();
              openCart();
            }}
            aria-label={`Open cart, ${count} items`}
            className="relative -mt-8 grid h-14 w-14 shrink-0 cursor-pointer place-items-center rounded-full border-4 border-background bg-primary text-primary-ink shadow-[0_14px_34px_-10px] shadow-primary/60"
          >
            <ShoppingBag className="h-[22px] w-[22px]" strokeWidth={2.3} />
            {count > 0 && (
              <motion.span
                key={count}
                initial={{ scale: 0.4, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={PRESS_SPRING}
                className="absolute -top-0.5 -right-0.5 grid h-5 min-w-[20px] place-items-center rounded-full border-2 border-background bg-chili px-1 text-[11px] font-extrabold text-white"
              >
                {count}
              </motion.span>
            )}
          </motion.button>

          <div className="flex flex-1 items-center gap-1">
            {rightTabs.map(renderTab)}
          </div>
        </div>
      </div>
    </nav>
  );
}
