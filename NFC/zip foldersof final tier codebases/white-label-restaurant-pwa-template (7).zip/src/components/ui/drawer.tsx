import type { ReactNode } from "react";
import { Drawer as Vaul } from "vaul";
import { cn } from "@/utils/cn";

/* ============================================================================
 * DRAWER — vaul-powered bottom sheets with native spring drag-to-dismiss.
 * `BottomSheet` is the opinionated wrapper every feature sheet uses, so all
 * overlays share one grab-handle / safe-area / surface treatment.
 * ==========================================================================*/

/** Escape hatch: raw vaul primitives for bespoke compositions. */
export const Drawer = Vaul;

interface BottomSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Accessible sheet label (rendered screen-reader only) */
  label: string;
  children: ReactNode;
  className?: string;
}

export function BottomSheet({ open, onOpenChange, label, children, className }: BottomSheetProps) {
  return (
    <Vaul.Root open={open} onOpenChange={onOpenChange} shouldScaleBackground>
      <Vaul.Portal>
        <Vaul.Overlay className="fixed inset-0 z-50 bg-black/65" />
        <Vaul.Content
          className={cn(
            "app-surface fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-lg",
            "rounded-t-tile border-x border-t border-line pb-safe",
            "shadow-[0_-24px_80px_-24px_rgba(0,0,0,0.8)]",
            className
          )}
        >
          {/* Grab handle */}
          <div className="flex justify-center pt-3 pb-1">
            <div aria-hidden className="h-1.5 w-12 rounded-full bg-line" />
          </div>
          <Vaul.Title className="sr-only">{label}</Vaul.Title>
          <Vaul.Description className="sr-only">{label} panel</Vaul.Description>
          {children}
        </Vaul.Content>
      </Vaul.Portal>
    </Vaul.Root>
  );
}
