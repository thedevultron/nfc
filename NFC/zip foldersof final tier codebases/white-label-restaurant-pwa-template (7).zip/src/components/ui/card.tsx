import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

/* ============================================================================
 * CARD — surface tile. Padding follows theme.config `density` via --pad-card,
 * corner radius follows `radius` via the derived --radius-card token.
 * ==========================================================================*/

export function Card({ className, children, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "app-surface rounded-card border border-line p-[var(--pad-card)]",
        className
      )}
      {...rest}
    >
      {children}
    </div>
  );
}
