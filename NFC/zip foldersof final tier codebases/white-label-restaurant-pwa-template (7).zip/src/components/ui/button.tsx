import type { MouseEvent, ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { useHaptics } from "@/hooks/useHaptics";

/* ============================================================================
 * BUTTON — shared spring physics (stiffness 400 / damping 25) + haptic tick.
 * Pure presentation: it only references theme tokens, so it renders
 * identically for every client — only the tokens behind it change.
 * ==========================================================================*/

export const PRESS_SPRING = {
  type: "spring",
  stiffness: 400,
  damping: 25,
} as const;

type Variant = "primary" | "accent" | "soft" | "outline" | "ghost" | "danger";
type Size = "sm" | "md" | "lg" | "icon" | "iconSm";

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-primary text-primary-ink font-bold shadow-[0_10px_28px_-10px] shadow-primary/50",
  accent: "bg-accent text-accent-ink font-bold",
  soft: "bg-raised text-ink border border-line font-semibold",
  outline: "border border-line bg-transparent text-ink font-semibold hover:bg-raised/70",
  ghost: "text-muted font-semibold hover:text-ink hover:bg-raised/60",
  danger: "bg-chili/12 text-chili border border-chili/25 font-semibold",
};

const SIZES: Record<Size, string> = {
  sm: "h-9 px-3.5 text-[13px] gap-1.5",
  md: "h-11 px-4 text-sm gap-2",
  lg: "h-12 px-5 text-[15px] gap-2", // 48px — minimum touch target
  icon: "h-12 w-12",
  iconSm: "h-9 w-9",
};

export interface ButtonProps {
  variant?: Variant;
  size?: Size;
  /** Fire a 10ms vibration on press (respects features.enableHaptics) */
  haptic?: boolean;
  className?: string;
  children?: ReactNode;
  disabled?: boolean;
  type?: "button" | "submit";
  title?: string;
  "aria-label"?: string;
  onClick?: (e: MouseEvent<HTMLButtonElement>) => void;
}

export function Button({
  variant = "primary",
  size = "md",
  haptic = true,
  className,
  children,
  disabled,
  type = "button",
  title,
  onClick,
  ...aria
}: ButtonProps) {
  const { tap } = useHaptics();
  return (
    <motion.button
      type={type}
      title={title}
      disabled={disabled}
      whileTap={{ scale: 0.94 }}
      transition={PRESS_SPRING}
      className={cn(
        "inline-flex shrink-0 cursor-pointer items-center justify-center rounded-full transition-colors duration-200 select-none",
        "disabled:pointer-events-none disabled:opacity-45",
        VARIANTS[variant],
        SIZES[size],
        className
      )}
      onClick={(e) => {
        if (haptic) tap();
        onClick?.(e as unknown as MouseEvent<HTMLButtonElement>);
      }}
      {...aria}
    >
      {children}
    </motion.button>
  );
}
