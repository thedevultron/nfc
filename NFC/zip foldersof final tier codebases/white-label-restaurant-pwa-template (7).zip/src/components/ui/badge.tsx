import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

/* ============================================================================
 * BADGE — small pill used for dietary marks, "Sold Out", best-seller, etc.
 * ==========================================================================*/

type Tone = "neutral" | "primary" | "accent" | "chili" | "outline";

const TONES: Record<Tone, string> = {
  neutral: "bg-raised text-muted border-line",
  primary: "bg-primary/12 text-primary border-primary/30",
  accent: "bg-accent/12 text-accent border-accent/30",
  chili: "bg-chili/12 text-chili border-chili/30",
  outline: "bg-transparent text-muted border-line",
};

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: Tone;
}

export function Badge({ tone = "neutral", className, children, ...rest }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-[3px] text-[10.5px] font-bold tracking-wide uppercase",
        TONES[tone],
        className
      )}
      {...rest}
    >
      {children}
    </span>
  );
}
