import {
  createContext,
  useCallback,
  useContext,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Info, X } from "lucide-react";
import { cn } from "@/utils/cn";

/* ============================================================================
 * TOAST — lightweight feedback rail (added to cart, webhook dispatched,
 * WiFi password copied…). Lives above the bottom nav, below sheet overlays.
 * ==========================================================================*/

type Tone = "success" | "info" | "error";

interface ToastItem {
  id: number;
  title: string;
  description?: string;
  tone: Tone;
}

interface ToastContextValue {
  toast: (t: { title: string; description?: string; tone?: Tone }) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const TONE_STYLES: Record<Tone, { icon: ReactNode; ring: string }> = {
  success: {
    icon: <Check className="h-3.5 w-3.5" strokeWidth={3} />,
    ring: "bg-accent text-accent-ink",
  },
  info: {
    icon: <Info className="h-3.5 w-3.5" strokeWidth={2.75} />,
    ring: "bg-primary text-primary-ink",
  },
  error: {
    icon: <X className="h-3.5 w-3.5" strokeWidth={3} />,
    ring: "bg-chili text-white",
  },
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const counter = useRef(0);

  const dismiss = useCallback((id: number) => {
    setItems((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback<ToastContextValue["toast"]>(
    ({ title, description, tone = "info" }) => {
      const id = ++counter.current;
      setItems((prev) => [...prev.slice(-2), { id, title, description, tone }]);
      window.setTimeout(() => dismiss(id), 2600);
    },
    [dismiss]
  );

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      {/* Viewport */}
      <div className="pointer-events-none fixed inset-x-0 top-0 z-[80] flex flex-col items-center gap-2 px-4 pt-safe">
        <div className="mt-3 flex w-full max-w-sm flex-col items-center gap-2">
          <AnimatePresence mode="popLayout">
            {items.map((t) => (
              <motion.button
                key={t.id}
                layout
                initial={{ opacity: 0, y: -18, scale: 0.92 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -12, scale: 0.94 }}
                transition={{ type: "spring", stiffness: 400, damping: 28 }}
                onClick={() => dismiss(t.id)}
                className={cn(
                  "app-surface pointer-events-auto flex w-auto max-w-full cursor-pointer items-center gap-2.5 rounded-full border border-line py-2.5 pr-4 pl-2.5 text-left shadow-[0_16px_40px_-12px_rgba(0,0,0,0.7)]"
                )}
              >
                <span
                  className={cn(
                    "flex h-6 w-6 shrink-0 items-center justify-center rounded-full",
                    TONE_STYLES[t.tone].ring
                  )}
                >
                  {TONE_STYLES[t.tone].icon}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[13px] leading-tight font-bold">
                    {t.title}
                  </span>
                  {t.description && (
                    <span className="block truncate text-[11.5px] leading-tight text-muted">
                      {t.description}
                    </span>
                  )}
                </span>
              </motion.button>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside <ToastProvider>");
  return ctx;
}
