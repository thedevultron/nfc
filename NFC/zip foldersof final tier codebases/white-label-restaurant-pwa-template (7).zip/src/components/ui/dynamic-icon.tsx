import {
  Award, BadgeCheck, Ban, Beef, BellRing, Bike, CakeSlice, CalendarDays, Check,
  ChefHat, ChevronLeft, ChevronRight, CircleDot, Clock, Coffee, ConciergeBell,
  Cookie, Copy, Croissant, CupSoda, Download, Drumstick, EggFried, ExternalLink,
  Eye, EyeOff, Fish, Flame, Heart, History, IceCream, Info, Leaf,
  MapPin, Martini, MessageCircle, Minus, Nfc, NotebookPen, Phone, Pizza, Plus,
  QrCode, Salad, Sandwich, Search, Send, Share2, ShoppingBag, Shrimp, Soup,
  Sparkles, SquarePen, Star, Store, Timer, Trash2, Users, Utensils,
  UtensilsCrossed, Wifi, Wine, X, Zap,
  type LucideIcon,
  type LucideProps,
} from "lucide-react";

/* ============================================================================
 * DYNAMIC ICON — string-name → Lucide component resolver.
 * Config files store icon NAMES (plain strings) so a client can restyle the
 * whole catalog from /src/config without importing React anywhere.
 * To allow a new icon, add it to this registry — nothing else changes.
 * ==========================================================================*/

const REGISTRY = {
  Award, BadgeCheck, Ban, Beef, BellRing, Bike, CakeSlice, CalendarDays, Check,
  ChefHat, ChevronLeft, ChevronRight, CircleDot, Clock, Coffee, ConciergeBell,
  Cookie, Copy, Croissant, CupSoda, Download, Drumstick, EggFried, ExternalLink,
  Eye, EyeOff, Fish, Flame, Heart, History, IceCream, Info, Leaf,
  MapPin, Martini, MessageCircle, Minus, Nfc, NotebookPen, Phone, Pizza, Plus,
  QrCode, Salad, Sandwich, Search, Send, Share2, ShoppingBag, Shrimp, Soup,
  Sparkles, SquarePen, Star, Store, Timer, Trash2, Users, Utensils,
  UtensilsCrossed, Wifi, Wine, X, Zap,
} satisfies Record<string, LucideIcon>;

export type IconName = keyof typeof REGISTRY;

interface DynamicIconProps extends LucideProps {
  /** Lucide icon name from config/menu data. Unknown names fall back gracefully. */
  name: string;
}

export function DynamicIcon({ name, ...props }: DynamicIconProps) {
  const Component = (REGISTRY as Record<string, LucideIcon>)[name] ?? UtensilsCrossed;
  return <Component aria-hidden {...props} />;
}
