import { restaurantConfig } from "@/config/restaurant.config";
import type {
  FeedbackPayload,
  OrderPayload,
  ReservationPayload,
  WebhookResult,
} from "@/types/menu.types";
import { dispatchToN8n } from "./n8n.service";

/* ============================================================================
 * API FACADE
 * ----------------------------------------------------------------------------
 * Typed business endpoints consumed by the UI. Each call maps 1:1 onto an n8n
 * webhook URL declared in /src/config/restaurant.config.ts — the UI never
 * sees a URL, only these methods.
 * ==========================================================================*/

/** Small perceived-latency so loading → success transitions feel physical. */
const settle = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export const apiService = {
  /** Table booking — fired optimistically by ReservationSheet. */
  async sendReservation(payload: ReservationPayload): Promise<WebhookResult> {
    await settle(700);
    return dispatchToN8n(
      restaurantConfig.n8nWebhooks.reservationUrl,
      { ...payload, venue: restaurantConfig.brand.name },
      "reservation"
    );
  },

  /** Private <4★ feedback — routes straight to the manager, never public. */
  async sendFeedback(payload: FeedbackPayload): Promise<WebhookResult> {
    await settle(600);
    return dispatchToN8n(
      restaurantConfig.n8nWebhooks.feedbackUrl,
      { ...payload, venue: restaurantConfig.brand.name },
      "feedback"
    );
  },

  /** Full cart payload — kitchen webhook; WhatsApp pipeline reuses it too. */
  async sendOrder(payload: OrderPayload): Promise<WebhookResult> {
    await settle(800);
    return dispatchToN8n(
      restaurantConfig.n8nWebhooks.orderUrl,
      { ...payload, venue: restaurantConfig.brand.name },
      "order"
    );
  },
};
