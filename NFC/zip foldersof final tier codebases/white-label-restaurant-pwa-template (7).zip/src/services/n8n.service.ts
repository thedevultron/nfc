import type { WebhookResult } from "@/types/menu.types";

/* ============================================================================
 * N8N WEBHOOK TRANSPORT
 * ----------------------------------------------------------------------------
 * The ONLY place in the app that talks HTTP. Every feature (orders, bookings,
 * private feedback) funnels through `dispatchToN8n`, so swapping the backend
 * is a one-file job:
 *   • point restaurant.config.ts → n8nWebhooks.* at your n8n instance
 *   • n8n workflow receives JSON exactly matching /src/types/menu.types.ts
 *
 * Resilience policy: if the endpoint is unreachable (demo / offline table),
 * the dispatch resolves optimistically with { success: true, mock: true }
 * so the guest-facing flow never dead-ends.
 * ==========================================================================*/

const TIMEOUT_MS = 6000;

export async function dispatchToN8n(
  url: string,
  payload: unknown,
  label: "reservation" | "feedback" | "order"
): Promise<WebhookResult> {
  console.info(`[n8n:${label}] dispatching →`, url, payload);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`Webhook responded ${response.status}`);
    const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
    return { success: true, message: String(data.message ?? "Received"), ...data };
  } catch {
    /* Optimistic fallback — keeps demos & offline tables fully functional. */
    console.warn(`[n8n:${label}] endpoint unreachable → resolved optimistically (mock).`);
    return { success: true, mock: true, message: `${label} queued locally` };
  } finally {
    clearTimeout(timer);
  }
}

/** Builds the wa.me deep link used by the WhatsApp order pipeline. */
export function buildWhatsAppLink(phoneDigits: string, message: string): string {
  return `https://wa.me/${phoneDigits.replace(/[^\d]/g, "")}?text=${encodeURIComponent(message)}`;
}
