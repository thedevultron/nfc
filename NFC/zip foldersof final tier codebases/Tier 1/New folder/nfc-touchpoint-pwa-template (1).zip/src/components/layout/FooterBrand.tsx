/**
 * FooterBrand — subtle powered-by line. Pinned to the bottom via mt-auto.
 */
import { motion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";
import { motionConfig } from "@/config/motion.config";

export function FooterBrand() {
  return (
    <motion.footer
      className="mt-auto flex items-center justify-center gap-1.5 pt-8 text-center text-[0.7rem] text-muted/70"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ ...motionConfig.springs.smooth, delay: 0.3 }}
    >
      <Icon name="Zap" className="h-3 w-3 text-primary" />
      <span>
        Powered by <span className="font-medium text-muted">Tier1 TAP Engine</span>
      </span>
    </motion.footer>
  );
}
