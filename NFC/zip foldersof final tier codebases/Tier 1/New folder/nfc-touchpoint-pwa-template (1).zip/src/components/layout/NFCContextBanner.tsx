/**
 * NFCContextBanner — small "you tapped in" context pill.
 * Entry method + detail come from /src/config/client.config.ts (entry).
 */
import { motion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";
import { clientConfig } from "@/config/client.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

export function NFCContextBanner() {
  const reduced = useReducedMotion();
  return (
    <motion.div
      className="mt-4 inline-flex items-center gap-2 self-start rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-muted"
      initial={{ opacity: 0, y: reduced ? 0 : -6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={
        reduced
          ? { duration: 0.2, delay: 0.05 }
          : { ...motionConfig.springs.smooth, delay: 0.06 }
      }
    >
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-secondary opacity-60" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-secondary" />
      </span>
      <Icon name="Nfc" className="h-3.5 w-3.5" />
      <span className="tabular">
        {clientConfig.entry.method} · {clientConfig.entry.detail}
      </span>
    </motion.div>
  );
}
