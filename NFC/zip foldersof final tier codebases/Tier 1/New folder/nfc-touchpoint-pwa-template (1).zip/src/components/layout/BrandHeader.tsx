/**
 * BrandHeader — business identity + the Utensils brand mark.
 * ─────────────────────────────────────────────────────────────────
 * The brand icon does a gentle rotate-settle spring on load, evoking a
 * menu "opening". Copy + icon name come from config — edit
 * /src/config/client.config.ts and /src/config/touchpoints.config.ts.
 */
import { motion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

export function BrandHeader() {
  const reduced = useReducedMotion();
  return (
    <motion.header
      className="flex items-center gap-3.5"
      initial={{ opacity: 0, y: reduced ? 0 : 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={reduced ? { duration: 0.2 } : motionConfig.springs.smooth}
    >
      <motion.div
        className="grid h-12 w-12 shrink-0 place-items-center rounded-[1rem] border border-white/15 shadow-lg"
        style={{
          background:
            "linear-gradient(140deg, color-mix(in srgb, var(--c-primary) 92%, white), color-mix(in srgb, var(--c-primary) 68%, black))",
        }}
        initial={reduced ? false : { rotate: -14, scale: 0.7 }}
        animate={reduced ? {} : { rotate: 0, scale: 1 }}
        transition={reduced ? { duration: 0.2 } : motionConfig.springs.smooth}
      >
        <Icon
          name={touchpointsConfig.icons.primary}
          className="h-6 w-6 text-primary-foreground"
          strokeWidth={2.2}
        />
      </motion.div>
      <div className="min-w-0">
        <h1 className="truncate text-lg font-semibold leading-tight tracking-tight text-foreground">
          {clientConfig.businessName}
        </h1>
        <p className="truncate text-sm text-muted">{clientConfig.subtitle}</p>
      </div>
    </motion.header>
  );
}
