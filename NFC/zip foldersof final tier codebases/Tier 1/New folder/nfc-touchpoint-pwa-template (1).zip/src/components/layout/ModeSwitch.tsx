/**
 * ModeSwitch — segmented control toggling the two swipeable root panels.
 * ─────────────────────────────────────────────────────────────────
 * The active pill slides via a shared layoutId spring (snappy). Haptic
 * fires on change. Active mode labels are derived from config — edit
 * /src/config/client.config.ts (activeMode / secondaryMode).
 */
import { motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import type { PanelKey } from "@/types/template.types";

const OPTIONS: { key: PanelKey; label: string }[] = [
  { key: "review", label: "Review" },
  { key: "hub", label: "Explore" },
];

export function ModeSwitch({
  value,
  onChange,
}: {
  value: PanelKey;
  onChange: (key: PanelKey) => void;
}) {
  const reduced = useReducedMotion();
  return (
    <div className="mt-5 grid grid-cols-2 gap-1 rounded-card border border-white/10 bg-black/20 p-1">
      {OPTIONS.map((opt) => {
        const active = opt.key === value;
        return (
          <button
            key={opt.key}
            type="button"
            aria-pressed={active}
            onClick={() => {
              if (!active) {
                haptics.selection();
                onChange(opt.key);
              }
            }}
            className={cn(
              "relative h-9 rounded-[calc(var(--c-radius)-0.25rem)] text-sm font-medium transition-colors",
              active ? "text-primary-foreground" : "text-muted hover:text-foreground",
            )}
          >
            {active && (
              <motion.span
                layoutId="mode-pill"
                className="absolute inset-0 rounded-[calc(var(--c-radius)-0.25rem)] bg-primary"
                style={{ boxShadow: "0 0 24px var(--c-accent-glow)" }}
                transition={reduced ? { duration: 0.15 } : motionConfig.springs.snappy}
              />
            )}
            <span className="relative z-10">{opt.label}</span>
          </button>
        );
      })}
    </div>
  );
}
