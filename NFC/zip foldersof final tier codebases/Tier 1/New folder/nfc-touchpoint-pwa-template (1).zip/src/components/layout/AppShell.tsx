/**
 * AppShell — root frame: ambient background, max-width mobile column,
 * safe-area top/bottom padding. Edit /src/config/theme.config.ts to
 * change background / radius; this file only composes tokens.
 */
import type { ReactNode } from "react";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-[100dvh] w-full overflow-x-hidden bg-background text-foreground">
      {/* Ambient brand glow — soft, behind everything. */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10"
        style={{
          background:
            "radial-gradient(120% 75% at 50% -10%, color-mix(in srgb, var(--c-primary) 16%, transparent) 0%, transparent 60%)," +
            "radial-gradient(80% 55% at 100% 105%, color-mix(in srgb, var(--c-secondary) 12%, transparent) 0%, transparent 55%)",
        }}
      />
      <div
        className="relative mx-auto flex min-h-[100dvh] w-full max-w-md flex-col px-5"
        style={{
          paddingTop: "calc(env(safe-area-inset-top) + 0.75rem)",
          paddingBottom: "calc(env(safe-area-inset-bottom) + 1rem)",
        }}
      >
        {children}
      </div>
    </div>
  );
}
