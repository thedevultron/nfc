/**
 * ReviewRouter (MODULE A — Smart Review Router).
 * ─────────────────────────────────────────────────────────────────
 * 5 elastic-pop stars. Rating ≥ 4 reveals (staggered) a high-contrast CTA
 * "Post on Google Maps" with a confetti-lite burst on tap. Rating < 4
 * smoothly morphs into the FeedbackDrawer. Copy + destination from config
 * — edit /src/config/touchpoints.config.ts and /src/config/client.config.ts.
 */
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { StarRating } from "./StarRating";
import { FeedbackDrawer } from "./FeedbackDrawer";
import { ConfettiBurst } from "./ConfettiBurst";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";

const POSITIVE_THRESHOLD = 4;

export function ReviewRouter({
  track,
}: {
  track: (event: string, payload?: Record<string, unknown>) => void;
}) {
  const reduced = useReducedMotion();
  const [rating, setRating] = useState(0);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [confetti, setConfetti] = useState(0);

  // Rating < 4: morph the card into the feedback drawer (after the star pop).
  useEffect(() => {
    if (rating > 0 && rating < POSITIVE_THRESHOLD) {
      const t = window.setTimeout(() => setFeedbackOpen(true), 280);
      return () => window.clearTimeout(t);
    }
  }, [rating]);

  const handleRating = (v: number) => {
    setRating(v);
    track("rating_select", { rating: v });
  };

  const goToGoogle = () => {
    haptics.success();
    setConfetti((c) => c + 1);
    track("review_redirect", { rating });
    window.open(clientConfig.googleReviewUrl, "_blank", "noopener,noreferrer");
  };

  const isPositive = rating >= POSITIVE_THRESHOLD;

  const container = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: motionConfig.stagger.children,
        delayChildren: motionConfig.stagger.delayChildren,
      },
    },
  };
  const item = {
    hidden: { opacity: 0, y: reduced ? 0 : 14 },
    show: {
      opacity: 1,
      y: 0,
      transition: reduced ? { duration: 0.18 } : motionConfig.springs.smooth,
    },
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-4">
      <motion.div variants={item}>
        <Card className="relative overflow-hidden text-center">
          <div className="mb-1 flex justify-center">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-secondary/15 px-2.5 py-1 text-xs font-medium text-secondary">
              <Icon name="Star" className="h-3.5 w-3.5" fill="currentColor" />
              Review
            </span>
          </div>
          <h2 className="text-xl font-semibold tracking-tight">
            {touchpointsConfig.copy.reviewPrompt}
          </h2>
          <p className="mt-1 text-sm text-muted">
            {touchpointsConfig.copy.reviewSubtitle}
          </p>
          <StarRating value={rating} onChange={handleRating} className="my-5" />
          <AnimatePresence mode="wait">
            {rating > 0 && (
              <motion.div
                key="count"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-sm text-muted tabular"
              >
                {rating} / 5
              </motion.div>
            )}
          </AnimatePresence>
        </Card>
      </motion.div>

      <AnimatePresence mode="wait">
        {isPositive && (
          <motion.div
            key="positive"
            variants={item}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: reduced ? 0 : -10, transition: { duration: 0.15 } }}
            className="relative"
          >
            <ConfettiBurst trigger={confetti} />
            <Card className="space-y-3 border-primary/20">
              <div className="text-center">
                <h3 className="text-lg font-semibold tracking-tight text-primary">
                  {touchpointsConfig.copy.highRatingHeadline}
                </h3>
                <p className="mt-1 text-sm text-muted">
                  {touchpointsConfig.copy.highRatingSubtitle}
                </p>
              </div>
              <Button glow size="lg" className="w-full" onClick={goToGoogle}>
                <Icon name="ExternalLink" className="h-5 w-5" />
                {touchpointsConfig.copy.highRatingCta}
              </Button>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <FeedbackDrawer
        open={feedbackOpen}
        onOpenChange={setFeedbackOpen}
        rating={rating}
        track={track}
      />
    </motion.div>
  );
}
