/**
 * FeedbackDrawer — low-rating feedback sheet (part of MODULE A).
 * ─────────────────────────────────────────────────────────────────
 * Optimistic success: the spring checkmark appears IMMEDIATELY on submit,
 * then the retry-safe POST to n8nFeedbackWebhook fires in the background.
 * Payload: { rating, feedbackText, timestamp, touchpointId }.
 * Copy + endpoint come from config — edit /src/config/* not this file.
 */
import { useState } from "react";
import { Drawer } from "@/components/ui/Drawer";
import { Button } from "@/components/ui/Button";
import { Textarea } from "@/components/ui/Textarea";
import { Icon } from "@/components/ui/Icon";
import { SuccessRing } from "./SuccessRing";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { clientConfig } from "@/config/client.config";
import { postFeedback } from "@/services/api.service";
import { haptics } from "@/services/haptics.service";

const MAX_LEN = 500;

type Status = "idle" | "sending" | "done";

export function FeedbackDrawer({
  open,
  onOpenChange,
  rating,
  track,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  rating: number;
  track: (event: string, payload?: Record<string, unknown>) => void;
}) {
  const [text, setText] = useState("");
  const [status, setStatus] = useState<Status>("idle");

  const close = () => {
    onOpenChange(false);
    // Reset after the exit transition so reopens start fresh.
    window.setTimeout(() => {
      if (status === "done") {
        setText("");
        setStatus("idle");
      }
    }, 260);
  };

  const submit = () => {
    if (!text.trim()) {
      haptics.error();
      return;
    }
    setStatus("sending");
    haptics.success();
    track("feedback_submit", { rating });
    // Optimistic: show success state immediately.
    setStatus("done");
    // Fire-and-forget POST (retry-safe inside the service).
    void postFeedback({
      rating,
      feedbackText: text.trim(),
      timestamp: Date.now(),
      touchpointId: clientConfig.touchpointId,
    });
  };

  return (
    <Drawer open={open} onOpenChange={(o) => (o ? onOpenChange(true) : close())}>
      {status === "done" ? (
        <div className="flex flex-col items-center gap-3 px-6 pb-2 pt-1 text-center">
          <SuccessRing tone="success" />
          <h3 className="text-lg font-semibold tracking-tight">Message received</h3>
          <p className="max-w-xs text-sm text-muted">
            {touchpointsConfig.copy.feedbackSuccess}
          </p>
          <Button variant="outline" className="mt-2 w-full" onClick={close}>
            Done
          </Button>
        </div>
      ) : (
        <div className="space-y-4 px-6 pb-2 pt-1">
          <div className="flex items-start gap-2.5">
            <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-secondary/15 text-secondary">
              <Icon name="ShieldCheck" className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-base font-semibold tracking-tight">
                {touchpointsConfig.copy.lowRatingHeadline}
              </h3>
              <p className="text-sm text-muted">{touchpointsConfig.copy.lowRatingSubtitle}</p>
            </div>
          </div>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value.slice(0, MAX_LEN))}
            placeholder={touchpointsConfig.copy.feedbackPlaceholder}
            rows={4}
            autoFocus
          />
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted tabular">
              {text.length}/{MAX_LEN}
            </span>
            <Button
              size="sm"
              glow
              disabled={status === "sending"}
              onClick={submit}
            >
              {touchpointsConfig.copy.feedbackSubmit}
            </Button>
          </div>
        </div>
      )}
    </Drawer>
  );
}
