/**
 * SocialHub (MODULE D — HUB) — vertically staggered list of pill rows.
 * ─────────────────────────────────────────────────────────────────
 * Rows stagger in via staggerChildren from motion.config. Each row:
 * icon in a soft-tinted rounded square, label, and a chevron that nudges
 * 2px on hover. Rows either navigate (url) or dispatch an action.
 * Content + icon names come from /src/config/touchpoints.config.ts.
 */
import { motion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useSpringPress } from "@/hooks/useSpringPress";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { touchpointsConfig } from "@/config/touchpoints.config";
import type { HubActionType, HubItem } from "@/types/template.types";

export function SocialHub({
  onAction,
}: {
  onAction: (action: HubActionType) => void;
}) {
  const reduced = useReducedMotion();

  const list = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: motionConfig.stagger.children,
        delayChildren: motionConfig.stagger.delayChildren,
      },
    },
  };

  return (
    <motion.div
      variants={list}
      initial="hidden"
      animate="show"
      className="space-y-2.5"
      aria-label="Quick actions"
    >
      {touchpointsConfig.hub.map((hub) => (
        <HubRow key={hub.id} hub={hub} onAction={onAction} reduced={reduced} />
      ))}
    </motion.div>
  );
}

function HubRow({
  hub,
  onAction,
  reduced,
}: {
  hub: HubItem;
  onAction: (action: HubActionType) => void;
  reduced: boolean;
}) {
  const press = useSpringPress("tap");
  const isSecondary = hub.tint === "secondary";

  const item = {
    hidden: { opacity: 0, y: reduced ? 0 : 14 },
    show: {
      opacity: 1,
      y: 0,
      transition: reduced ? { duration: 0.18 } : motionConfig.springs.smooth,
    },
  };

  const handleClick = () => {
    haptics.selection();
    if (hub.action) {
      onAction(hub.action);
      return;
    }
    if (hub.url) {
      window.open(hub.url, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <motion.button
      variants={item}
      type="button"
      onClick={handleClick}
      {...press}
      className="group flex w-full items-center gap-3.5 rounded-card border border-white/10 bg-white/[0.03] p-3.5 text-left transition-colors hover:bg-white/[0.06]"
    >
      <span
        className={cn(
          "grid h-11 w-11 shrink-0 place-items-center rounded-[0.85rem]",
          isSecondary ? "bg-secondary/15 text-secondary" : "bg-primary/15 text-primary",
        )}
      >
        <Icon name={hub.icon} className="h-5 w-5" />
      </span>
      <span className="min-w-0 flex-1 font-medium tracking-tight text-foreground">
        {hub.label}
      </span>
      <Icon
        name="ChevronRight"
        className="h-5 w-5 text-muted transition-transform duration-200 group-hover:translate-x-0.5"
      />
    </motion.button>
  );
}
