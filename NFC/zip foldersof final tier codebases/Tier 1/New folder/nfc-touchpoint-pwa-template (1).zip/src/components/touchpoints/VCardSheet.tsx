/**
 * VCardSheet (MODULE C — Dynamic Contact / vCard).
 * ─────────────────────────────────────────────────────────────────
 * Large "Save Contact" CTA generating a downloadable .vcf blob client-side,
 * plus a staggered secondary row: WhatsApp (emerald glow) + Call (amber glow).
 * Contact fields come from /src/config/touchpoints.config.ts (vcard).
 */
import { motion } from "framer-motion";
import { Drawer } from "@/components/ui/Drawer";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { motionConfig } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useSpringPress } from "@/hooks/useSpringPress";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { touchpointsConfig } from "@/config/touchpoints.config";
import type { VCardConfig } from "@/types/template.types";

function buildVCard(v: VCardConfig): string {
  return [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `FN:${v.name}`,
    v.org && `ORG:${v.org}`,
    v.title && `TITLE:${v.title}`,
    v.phone && `TEL;TYPE=CELL:${v.phone}`,
    v.email && `EMAIL:${v.email}`,
    v.url && `URL:${v.url}`,
    v.address && `ADR:;;${v.address};;;;`,
    "END:VCARD",
  ]
    .filter(Boolean)
    .join("\r\n");
}

export function VCardSheet({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const reduced = useReducedMotion();
  const press = useSpringPress("selection");
  const v = touchpointsConfig.vcard;
  const digits = (v.phone ?? "").replace(/[^0-9]/g, "");

  const saveContact = () => {
    haptics.success();
    const blob = new Blob([buildVCard(v)], { type: "text/vcard" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${v.name.replace(/\s+/g, "_")}.vcf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const secondary = {
    hidden: { opacity: 0, y: reduced ? 0 : 12 },
    show: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        ...motionConfig.springs.smooth,
        delay: 0.05 + i * motionConfig.stagger.children,
      },
    }),
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <div className="space-y-4 px-6 pb-2 pt-1">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-[0.9rem] bg-primary/15 text-primary">
            <Icon name="UserPlus" className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h3 className="truncate text-base font-semibold tracking-tight">{v.name}</h3>
            <p className="truncate text-sm text-muted">
              {[v.title, v.org].filter(Boolean).join(" · ")}
            </p>
          </div>
        </div>

        <Button glow size="lg" className="w-full" onClick={saveContact}>
          <Icon name="UserPlus" className="h-5 w-5" />
          {touchpointsConfig.copy.saveContact}
        </Button>

        <div className="grid grid-cols-2 gap-2.5">
          <motion.a
            custom={0}
            variants={secondary}
            initial="hidden"
            animate="show"
            {...press}
            href={`https://wa.me/${digits}`}
            target="_blank"
            rel="noopener noreferrer"
            className="glow-secondary flex h-12 items-center justify-center gap-2 rounded-card border border-secondary/30 bg-secondary/10 text-sm font-medium text-secondary"
          >
            <Icon name="MessageCircle" className="h-4 w-4" />
            WhatsApp
          </motion.a>
          <motion.a
            custom={1}
            variants={secondary}
            initial="hidden"
            animate="show"
            {...press}
            href={`tel:${v.phone ?? ""}`}
            className="glow-primary flex h-12 items-center justify-center gap-2 rounded-card border border-primary/30 bg-primary/10 text-sm font-medium text-primary"
          >
            <Icon name="Phone" className="h-4 w-4" />
            Call
          </motion.a>
        </div>
      </div>
    </Drawer>
  );
}
