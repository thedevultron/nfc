/**
 * WifiCard (MODULE B — Instant WiFi Touchpoint).
 * ─────────────────────────────────────────────────────────────────
 * Glass card: SSID + masked password with eye-toggle reveal, "Copy
 * Password" (clipboard API + haptic success + inline checkmark morph),
 * and a native WiFi QR-code generator (WIFI:T:... payload). Credentials
 * come from /src/config/touchpoints.config.ts (wifi).
 */
import { useState } from "react";
import { motion } from "framer-motion";
import QRCode from "qrcode";
import { Drawer } from "@/components/ui/Drawer";
import { Dialog } from "@/components/ui/Dialog";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { useSpringPress } from "@/hooks/useSpringPress";
import { haptics } from "@/services/haptics.service";
import { touchpointsConfig } from "@/config/touchpoints.config";

/** Escape special characters per the WiFi QR spec. */
function escapeQR(value: string): string {
  return value.replace(/([\\;,:"])/g, "\\$1");
}

async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    // Legacy fallback for insecure contexts / older webviews.
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
}

export function WifiCard({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { ssid, password, encryption = "WPA" } = touchpointsConfig.wifi;
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [qrUrl, setQrUrl] = useState("");
  const revealPress = useSpringPress("tap");

  const handleCopy = async () => {
    await copyText(password);
    haptics.success();
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const openQr = async () => {
    haptics.selection();
    const payload = `WIFI:T:${encryption};S:${escapeQR(ssid)};P:${escapeQR(password)};;`;
    try {
      const url = await QRCode.toDataURL(payload, {
        margin: 1,
        width: 320,
        color: { dark: "#0a0e1a", light: "#ffffff" },
      });
      setQrUrl(url);
    } catch {
      setQrUrl("");
    }
    setQrOpen(true);
  };

  return (
    <>
      <Drawer open={open} onOpenChange={onOpenChange}>
        <div className="space-y-4 px-6 pb-2 pt-1">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-[0.9rem] bg-primary/15 text-primary">
              <Icon name="Wifi" className="h-5 w-5" />
            </span>
            <div>
              <h3 className="text-base font-semibold tracking-tight">
                {touchpointsConfig.copy.wifiLabel}
              </h3>
              <p className="text-sm text-muted">{touchpointsConfig.copy.wifiSubtitle}</p>
            </div>
          </div>

          <div className="rounded-card border border-white/10 bg-black/20 p-4">
            <div>
              <div className="text-[0.7rem] uppercase tracking-wide text-muted">Network</div>
              <div className="text-lg font-medium tracking-tight">{ssid}</div>
            </div>
            <div className="mt-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-[0.7rem] uppercase tracking-wide text-muted">Password</div>
                <div className="truncate font-mono text-base tracking-tight tabular">
                  {revealed ? password : "•".repeat(Math.min(password.length, 10))}
                </div>
              </div>
              <motion.button
                type="button"
                {...revealPress}
                aria-label={revealed ? "Hide password" : "Show password"}
                onClick={() => setRevealed((r) => !r)}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/5 text-muted hover:text-foreground"
              >
                <Icon name={revealed ? "EyeOff" : "Eye"} className="h-4 w-4" />
              </motion.button>
            </div>
          </div>

          <div className="flex gap-2.5">
            <Button glow className="flex-1" onClick={handleCopy}>
              <Icon name={copied ? "Check" : "Copy"} className="h-4 w-4" />
              {copied ? "Copied" : touchpointsConfig.copy.copyPassword}
            </Button>
            <Button variant="outline" onClick={openQr} aria-label={touchpointsConfig.copy.showQr}>
              <Icon name="QrCode" className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Drawer>

      <Dialog open={qrOpen} onOpenChange={setQrOpen} title={touchpointsConfig.copy.wifiLabel}>
        <div className="flex flex-col items-center gap-3">
          {qrUrl ? (
            <img
              src={qrUrl}
              alt={`WiFi QR code for ${ssid}`}
              className="h-48 w-48 rounded-card border border-white/10"
            />
          ) : (
            <div className="h-48 w-48 rounded-card skeleton-shimmer" />
          )}
          <p className="text-center text-sm text-muted">
            Point your camera here to connect to{" "}
            <span className="font-medium text-foreground">{ssid}</span>.
          </p>
        </div>
      </Dialog>
    </>
  );
}
