/**
 * StarRating — 5 interactive Lucide stars.
 * ─────────────────────────────────────────────────────────────────
 * On select each star does an elastic overshoot pop (scale [1, 1.35, 1]),
 * cascading a 40ms ripple across adjacent stars. Haptic `selection` fires
 * on tap-start. Physics from /src/config/motion.config.ts (elastic).
 */
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { useSpringPress } from "@/hooks/useSpringPress";

export interface StarRatingProps {
  value: number;
  max?: number;
  onChange: (value: number) => void;
  className?: string;
}

export function StarRating({ value, max = 5, onChange, className }: StarRatingProps) {
  const press = useSpringPress("selection");

  return (
    <div
      className={cn("flex items-center justify-center gap-2.5", className)}
      role="radiogroup"
      aria-label="Star rating"
    >
      {Array.from({ length: max }).map((_, i) => {
        const idx = i + 1;
        const active = idx <= value;
        return (
          <motion.button
            key={idx}
            type="button"
            role="radio"
            aria-checked={active}
            aria-label={`${idx} star${idx > 1 ? "s" : ""}`}
            className={cn(
              "grid h-12 w-12 place-items-center rounded-full transition-colors",
              active ? "text-primary" : "text-muted/40 hover:text-muted",
            )}
            onClick={() => onChange(idx)}
            {...press}
          >
            {/* keying by value remounts the inner icon on each rating change,
                replaying the cascade ripple for every active star. */}
            <motion.span
              key={`${idx}-${value}`}
              className="block"
              initial={{ scale: active ? 0.7 : 1 }}
              animate={{ scale: active ? [1, 1.35, 1] : 1 }}
              transition={
                active
                  ? { scale: { ...motionConfig.springs.elastic, delay: i * 0.04 } }
                  : { scale: motionConfig.springs.smooth }
              }
            >
              <Star
                className="h-9 w-9 drop-shadow-[0_4px_12px_rgba(0,0,0,0.45)]"
                fill={active ? "currentColor" : "none"}
                strokeWidth={1.6}
              />
            </motion.span>
          </motion.button>
        );
      })}
    </div>
  );
}
