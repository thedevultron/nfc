/**
 * SuccessRing — spring-in checkmark/x with a circular progress-ring wipe.
 * ─────────────────────────────────────────────────────────────────
 * Replaces plain toasts for success/error states. Physics from
 * /src/config/motion.config.ts (elastic + smooth).
 */
import { motion } from "framer-motion";
import { CheckCircle2, XCircle } from "lucide-react";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { cn } from "@/utils/cn";

export function SuccessRing({
  tone = "success",
  size = 84,
  className,
}: {
  tone?: "success" | "error";
  size?: number;
  className?: string;
}) {
  const reduced = useReducedMotion();
  const stroke = tone === "success" ? "var(--c-secondary)" : "#f87171";
  const IconCmp = tone === "success" ? CheckCircle2 : XCircle;

  return (
    <motion.div
      className={cn("relative grid place-items-center", className)}
      style={{ width: size, height: size }}
      initial={reduced ? { opacity: 0 } : { scale: 0.5, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={reduced ? { duration: 0.2 } : motionConfig.springs.elastic}
    >
      <svg
        viewBox="0 0 100 100"
        className="absolute inset-0 -rotate-90"
        width={size}
        height={size}
      >
        <circle
          cx="50"
          cy="50"
          r="44"
          fill="none"
          stroke="currentColor"
          strokeWidth="6"
          className="text-white/10"
        />
        <motion.circle
          cx="50"
          cy="50"
          r="44"
          fill="none"
          stroke={stroke}
          strokeWidth="6"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={
            reduced
              ? { duration: 0.25 }
              : { ...motionConfig.springs.smooth, duration: 0.6 }
          }
        />
      </svg>
      <motion.span
        style={{ color: stroke }}
        initial={reduced ? { opacity: 0 } : { scale: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={
          reduced ? { duration: 0.15 } : { ...motionConfig.springs.snappy, delay: 0.2 }
        }
      >
        <IconCmp style={{ width: size * 0.46, height: size * 0.46 }} strokeWidth={2.4} />
      </motion.span>
    </motion.div>
  );
}
