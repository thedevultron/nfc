/**
 * ConfettiBurst — confetti-lite micro burst (Lucide Sparkle particles).
 * ─────────────────────────────────────────────────────────────────
 * Triggered when the positive-review CTA is tapped. Particles fan outward
 * then fall and fade (gravity-ish ease). 6–8 particles, physics-based.
 */
import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Sparkles } from "lucide-react";

export interface ConfettiBurstProps {
  /** Increment to fire a new burst. */
  trigger: number;
  count?: number;
}

export function ConfettiBurst({ trigger, count = 7 }: ConfettiBurstProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (trigger === 0) return;
    setVisible(true);
    const t = window.setTimeout(() => setVisible(false), 950);
    return () => window.clearTimeout(t);
  }, [trigger]);

  const particles = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => ({
        id: `${trigger}-${i}`,
        // Fan across an upward arc.
        angle: (-90 + (i - (count - 1) / 2) * 24) * (Math.PI / 180),
        distance: 70 + Math.random() * 55,
        rotate: (Math.random() - 0.5) * 420,
        delay: Math.random() * 0.05,
        duration: 0.7 + Math.random() * 0.35,
        color: Math.random() > 0.5 ? "var(--c-primary)" : "var(--c-secondary)",
        size: 14 + Math.random() * 9,
      })),
    [count, trigger],
  );

  return (
    <div className="pointer-events-none absolute inset-0 z-20 grid place-items-center overflow-visible">
      <AnimatePresence>
        {visible &&
          particles.map((p) => {
            const dx = Math.cos(p.angle) * p.distance;
            const dy = Math.sin(p.angle) * p.distance;
            return (
              <motion.span
                key={p.id}
                className="absolute"
                style={{ color: p.color }}
                initial={{ x: 0, y: 0, opacity: 1, scale: 0.4, rotate: 0 }}
                animate={{ x: dx, y: dy + 48, opacity: 0, scale: 1, rotate: p.rotate }}
                exit={{ opacity: 0 }}
                transition={{
                  duration: p.duration,
                  delay: p.delay,
                  ease: [0.22, 0.61, 0.36, 1],
                }}
              >
                <Sparkles style={{ width: p.size, height: p.size }} fill="currentColor" strokeWidth={0} />
              </motion.span>
            );
          })}
      </AnimatePresence>
    </div>
  );
}
