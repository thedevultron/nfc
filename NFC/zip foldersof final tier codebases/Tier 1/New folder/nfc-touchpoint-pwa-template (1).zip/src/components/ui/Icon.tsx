/**
 * Icon registry — resolves Lucide icon NAMES (plain strings from config)
 * to actual Lucide React components.
 * ─────────────────────────────────────────────────────────────────
 * This is the ONLY place that imports Lucide. Config files stay pure
 * data (e.g. `icon: "Utensils"`). Add new icons to REGISTRY below to
 * make them available to config — never import Lucide inside config.
 */
import {
  Utensils,
  Star,
  Wifi,
  MessageSquare,
  BookOpen,
  ChevronRight,
  UserPlus,
  MessageCircle,
  Phone,
  ExternalLink,
  CheckCircle2,
  XCircle,
  Sparkles,
  Eye,
  EyeOff,
  Copy,
  Check,
  QrCode,
  X,
  ShieldCheck,
  MapPin,
  Clock,
  ArrowRight,
  Nfc,
  Zap,
  Heart,
  type LucideIcon,
  type LucideProps,
} from "lucide-react";

const REGISTRY: Record<string, LucideIcon> = {
  Utensils,
  Star,
  Wifi,
  MessageSquare,
  BookOpen,
  ChevronRight,
  UserPlus,
  MessageCircle,
  Phone,
  ExternalLink,
  CheckCircle2,
  XCircle,
  Sparkles,
  Eye,
  EyeOff,
  Copy,
  Check,
  QrCode,
  X,
  ShieldCheck,
  MapPin,
  Clock,
  ArrowRight,
  Nfc,
  Zap,
  Heart,
};

export interface IconProps extends LucideProps {
  name: string;
}

export function Icon({ name, ...props }: IconProps) {
  const Cmp = REGISTRY[name] ?? Star;
  return <Cmp {...props} />;
}
