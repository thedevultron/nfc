/**
 * Textarea — styled multiline form control (used by FeedbackDrawer).
 * Edit /src/config/theme.config.ts (primary token) to re-skin focus ring.
 */
import { forwardRef, type TextareaHTMLAttributes } from "react";
import { cn } from "@/utils/cn";

export const Textarea = forwardRef<
  HTMLTextAreaElement,
  TextareaHTMLAttributes<HTMLTextAreaElement>
>(function Textarea({ className, ...props }, ref) {
  return (
    <textarea
      ref={ref}
      className={cn(
        "w-full resize-none rounded-card border border-white/10 bg-black/20 p-3.5 text-foreground",
        "placeholder:text-muted/60 outline-none transition",
        "focus:border-primary/50 focus:ring-2 focus:ring-primary/30",
        className,
      )}
      {...props}
    />
  );
});
