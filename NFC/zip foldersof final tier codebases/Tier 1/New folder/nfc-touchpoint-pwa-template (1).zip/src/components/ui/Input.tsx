/**
 * Input — styled form control.
 * Edit /src/config/theme.config.ts (primary token) to re-skin focus ring.
 */
import { forwardRef, type InputHTMLAttributes } from "react";
import { cn } from "@/utils/cn";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return (
      <input
        ref={ref}
        className={cn(
          "h-11 w-full rounded-card border border-white/10 bg-black/20 px-4 text-foreground",
          "placeholder:text-muted/60 outline-none transition",
          "focus:border-primary/50 focus:ring-2 focus:ring-primary/30",
          className,
        )}
        {...props}
      />
    );
  },
);
