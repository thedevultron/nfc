/**
 * Drawer — iOS-style bottom sheet.
 * ─────────────────────────────────────────────────────────────────
 * Real drag-to-dismiss via Framer Motion: drag is initiated from the grab
 * handle (dragControls) so inner content scrolls naturally, dragConstraints
 * + dragElastic provide rubber-band overscroll resistance, and onDragEnd
 * snaps closed past a threshold or velocity. Physics from motion.config.
 * Safe-area inset padding on every fixed bottom element.
 * Edit /src/config/motion.config.ts (springs.drawer) + theme.config.ts.
 */
import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useDragControls, type PanInfo } from "framer-motion";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

export interface DrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
  className?: string;
}

const DISMISS_OFFSET = 140;
const DISMISS_VELOCITY = 600;

export function Drawer({ open, onOpenChange, children, className }: DrawerProps) {
  const reduced = useReducedMotion();
  const controls = useDragControls();
  const close = () => onOpenChange(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open]);

  const handleDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.y > DISMISS_OFFSET || info.velocity.y > DISMISS_VELOCITY) close();
  };

  const transition = reduced
    ? { duration: 0.18, ease: "easeOut" as const }
    : motionConfig.springs.drawer;

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={close}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            className={cn(
              "glass-strong relative max-h-[88vh] w-full max-w-md overflow-y-auto rounded-t-[1.5rem] rounded-b-card no-scrollbar",
              className,
            )}
            style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 1.25rem)" }}
            initial={reduced ? { opacity: 0 } : { y: "100%" }}
            animate={reduced ? { opacity: 1 } : { y: 0 }}
            exit={reduced ? { opacity: 0 } : { y: "100%" }}
            transition={transition}
            drag={reduced ? false : "y"}
            dragControls={controls}
            dragListener={false}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.55 }}
            dragMomentum={false}
            onDragEnd={handleDragEnd}
          >
            {/* Grab handle — the only drag-initiation zone. */}
            <div
              onPointerDown={(e) => controls.start(e)}
              className="sticky top-0 z-10 flex cursor-grab touch-none justify-center bg-transparent pb-2 pt-3 active:cursor-grabbing"
            >
              <div className="h-1.5 w-10 rounded-full bg-white/25" />
            </div>
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
