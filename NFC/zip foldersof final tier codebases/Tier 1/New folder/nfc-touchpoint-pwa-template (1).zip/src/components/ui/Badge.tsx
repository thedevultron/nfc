/**
 * Badge — small status pill.
 * Edit /src/config/theme.config.ts to re-skin.
 */
import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

type Variant = "default" | "outline" | "primary" | "secondary";

const variantCls: Record<Variant, string> = {
  default: "border-white/10 bg-white/5 text-muted",
  outline: "border-white/15 bg-transparent text-muted",
  primary: "border-primary/25 bg-primary/12 text-primary",
  secondary: "border-secondary/25 bg-secondary/12 text-secondary",
};

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: Variant;
}

export function Badge({ variant = "default", className, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium",
        variantCls[variant],
        className,
      )}
      {...props}
    />
  );
}
