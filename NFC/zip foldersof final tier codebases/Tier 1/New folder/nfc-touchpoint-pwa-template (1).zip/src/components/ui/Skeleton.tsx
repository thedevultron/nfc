/**
 * Skeleton — shimmer placeholder for the first 200–400ms of load.
 * The sweep animation is defined in index.css (.skeleton-shimmer) and
 * respects prefers-reduced-motion. Edit /src/config/theme.config.ts to
 * re-skin the base color.
 */
import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("skeleton-shimmer rounded-card", className)} {...props} />;
}
