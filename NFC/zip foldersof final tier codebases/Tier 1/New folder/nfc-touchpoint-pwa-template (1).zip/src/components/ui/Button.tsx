/**
 * Button — primary tappable primitive.
 * ─────────────────────────────────────────────────────────────────
 * Press physics + haptic come from useSpringPress() (motion.config).
 * The `glow` prop adds the ambient accent halo ("premium tell").
 * Edit /src/config/theme.config.ts for colors / radius.
 */
import { forwardRef } from "react";
import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "@/utils/cn";
import { useSpringPress } from "@/hooks/useSpringPress";

type Variant = "primary" | "secondary" | "outline" | "ghost";
type Size = "sm" | "md" | "lg";

const base =
  "relative inline-flex select-none items-center justify-center gap-2 rounded-card font-medium tracking-tight transition-colors duration-150 outline-none focus-visible:ring-2 focus-visible:ring-primary/60 disabled:pointer-events-none disabled:opacity-50";

const variantCls: Record<Variant, string> = {
  primary: "bg-primary text-primary-foreground",
  secondary: "bg-secondary text-secondary-foreground",
  outline: "border border-white/10 bg-transparent text-foreground hover:bg-white/5",
  ghost: "bg-transparent text-foreground hover:bg-white/5",
};

const sizeCls: Record<Size, string> = {
  sm: "h-9 px-3.5 text-sm",
  md: "h-11 px-5 text-[0.95rem]",
  lg: "h-14 px-6 text-base",
};

export interface ButtonProps extends HTMLMotionProps<"button"> {
  variant?: Variant;
  size?: Size;
  glow?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = "primary", size = "md", glow = false, className, children, type, ...props },
  ref,
) {
  const press = useSpringPress("tap");
  return (
    <motion.button
      ref={ref}
      type={type ?? "button"}
      className={cn(base, variantCls[variant], sizeCls[size], glow && "ambient-glow", className)}
      {...press}
      {...props}
    >
      {children}
    </motion.button>
  );
});
