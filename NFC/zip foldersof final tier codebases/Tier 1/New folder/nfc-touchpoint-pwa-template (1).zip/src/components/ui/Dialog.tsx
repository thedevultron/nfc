/**
 * Dialog — centered modal (used for the WiFi QR code).
 * ─────────────────────────────────────────────────────────────────
 * Spring scale-in + backdrop blur, Esc-to-close, scroll lock.
 * Edit /src/config/motion.config.ts (springs.smooth) + theme.config.ts.
 */
import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useSpringPress } from "@/hooks/useSpringPress";
import { Icon } from "./Icon";

export interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  children: ReactNode;
  className?: string;
}

export function Dialog({ open, onOpenChange, title, children, className }: DialogProps) {
  const reduced = useReducedMotion();
  const closePress = useSpringPress("tap");
  const close = () => onOpenChange(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
          <motion.div
            className="absolute inset-0 bg-black/70 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={close}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={title}
            className={cn(
              "glass-strong relative w-full max-w-sm rounded-[1.5rem] p-6",
              className,
            )}
            initial={reduced ? { opacity: 0 } : { opacity: 0, scale: 0.92, y: 10 }}
            animate={reduced ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={reduced ? { opacity: 0 } : { opacity: 0, scale: 0.96 }}
            transition={reduced ? { duration: 0.18 } : motionConfig.springs.smooth}
          >
            <motion.button
              type="button"
              aria-label="Close"
              onClick={close}
              className={cn(
                "absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full",
                "bg-white/5 text-muted hover:text-foreground",
              )}
              {...closePress}
            >
              <Icon name="X" className="h-4 w-4" />
            </motion.button>
            {title && (
              <h3 className="mb-3 pr-8 text-lg font-semibold tracking-tight">{title}</h3>
            )}
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
