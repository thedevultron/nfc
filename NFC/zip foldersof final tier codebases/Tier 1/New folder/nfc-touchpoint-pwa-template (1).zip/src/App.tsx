/**
 * App — root shell for the Tier 1 TAP Custom / Review Engine.
 * ─────────────────────────────────────────────────────────────────
 * Composition only: theme is applied from config on mount, a shimmer
 * skeleton holds the first paint (no blank flash), then the active
 * panel (REVIEW by default) and the secondary swipeable panel (HUB)
 * transition with a 20px vertical slide + opacity fade (AnimatePresence
 * mode="wait"). WiFi / Contact live as overlay sheets.
 *
 * Re-skin the whole app by editing ONLY /src/config/* — never this file.
 */
import { useEffect, useRef, useState, type TouchEvent as ReactTouchEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { applyTheme } from "@/config/theme.config";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig } from "@/config/motion.config";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { haptics } from "@/services/haptics.service";
import { AppShell } from "@/components/layout/AppShell";
import { BrandHeader } from "@/components/layout/BrandHeader";
import { NFCContextBanner } from "@/components/layout/NFCContextBanner";
import { ModeSwitch } from "@/components/layout/ModeSwitch";
import { FooterBrand } from "@/components/layout/FooterBrand";
import { Skeleton } from "@/components/ui/Skeleton";
import { ReviewRouter } from "@/components/touchpoints/ReviewRouter";
import { SocialHub } from "@/components/touchpoints/SocialHub";
import { WifiCard } from "@/components/touchpoints/WifiCard";
import { VCardSheet } from "@/components/touchpoints/VCardSheet";
import type { HubActionType, PanelKey } from "@/types/template.types";

const BOOT_MS = 380; // simulated config load window for the skeleton shimmer
const SWIPE_THRESHOLD = 60;

export default function App() {
  const reduced = useReducedMotion();
  const { track } = useTapAnalytics(clientConfig.touchpointId);

  const [booted, setBooted] = useState(false);
  const [panel, setPanel] = useState<PanelKey>("review");
  const [wifiOpen, setWifiOpen] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);

  useEffect(() => {
    applyTheme();
  }, []);

  useEffect(() => {
    const t = window.setTimeout(() => setBooted(true), BOOT_MS);
    return () => window.clearTimeout(t);
  }, []);

  const switchPanel = (key: PanelKey) => {
    setPanel(key);
    track("panel_switch", { panel: key });
  };

  const handleAction = (action: HubActionType) => {
    if (action === "wifi") setWifiOpen(true);
    else if (action === "contact") setContactOpen(true);
    else if (action === "review") switchPanel("review");
    else if (action === "switch-hub") switchPanel("hub");
  };

  // Horizontal swipe between the two panels (gesture-driven switch; the
  // visual transition still follows the global vertical-slide rule).
  const touchX = useRef<number | null>(null);
  const onTouchStart = (e: ReactTouchEvent) => {
    touchX.current = e.touches[0].clientX;
  };
  const onTouchEnd = (e: ReactTouchEvent) => {
    if (touchX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchX.current;
    if (Math.abs(dx) > SWIPE_THRESHOLD) {
      haptics.selection();
      if (dx < 0 && panel === "review") switchPanel("hub");
      else if (dx > 0 && panel === "hub") switchPanel("review");
    }
    touchX.current = null;
  };

  const panelVariants = {
    initial: { opacity: 0, y: reduced ? 0 : 20 },
    animate: {
      opacity: 1,
      y: 0,
      transition: reduced ? { duration: 0.18 } : motionConfig.springs.smooth,
    },
    exit: { opacity: 0, y: reduced ? 0 : -20, transition: { duration: 0.16 } },
  };

  return (
    <AppShell>
      <BrandHeader />
      <NFCContextBanner />
      <ModeSwitch value={panel} onChange={switchPanel} />

      <main
        className="mt-5 flex-1"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        {booted ? (
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={panel}
              variants={panelVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              {panel === "review" ? (
                <ReviewRouter track={track} />
              ) : (
                <SocialHub onAction={handleAction} />
              )}
            </motion.div>
          </AnimatePresence>
        ) : (
          <BootSkeleton />
        )}
      </main>

      <FooterBrand />

      {/* Overlay touchpoint modules */}
      <WifiCard open={wifiOpen} onOpenChange={setWifiOpen} />
      <VCardSheet open={contactOpen} onOpenChange={setContactOpen} />
    </AppShell>
  );
}

function BootSkeleton() {
  // "Setting your table…" — matches content layout to avoid CLS.
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-sm text-muted">
        <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
        {touchpointsConfig.copy.loading}
      </div>
      <Skeleton className="h-44 w-full" />
      <Skeleton className="h-5 w-2/3" />
      <Skeleton className="h-14 w-full" />
    </div>
  );
}
