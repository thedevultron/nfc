/**
 * THEME CONFIG — colors, radius, typography scale, light/dark.
 * ─────────────────────────────────────────────────────────────────
 * Edit THIS file to fully re-skin the app. Components never read or
 * set colors directly — they consume the CSS variables written by
 * applyTheme() below. Zero component changes required.
 *
 * Active preset: RESTAURANT — warm amber primary, emerald secondary.
 */
import type { ThemeMode, ThemeTokens } from "@/types/template.types";

export const themeConfig = {
  defaultMode: "dark" as ThemeMode,
  primaryColor: "hsl(38 92% 50%)", // Warm Amber
  secondaryAccent: "hsl(160 84% 39%)", // Emerald
  accentGlow: "hsl(38 92% 50% / 0.25)",
  borderRadius: "0.75rem",
  fontFamily: "'Geist', 'Inter', system-ui, -apple-system, sans-serif",
  enableGlassmorphism: true,
  modes: {
    dark: {
      background: "hsl(224 71.4% 4.1%)",
      surface: "hsl(224 40% 8%)",
      foreground: "hsl(210 40% 98%)",
      muted: "hsl(215 20.2% 65.1%)",
      border: "hsl(215 28% 17%)",
      primaryForeground: "hsl(224 71% 8%)",
      secondaryForeground: "hsl(210 40% 98%)",
    },
    light: {
      background: "hsl(36 44% 97%)",
      surface: "hsl(36 34% 95%)",
      foreground: "hsl(224 71% 8%)",
      muted: "hsl(220 9% 42%)",
      border: "hsl(220 13% 88%)",
      primaryForeground: "hsl(224 71% 8%)",
      secondaryForeground: "hsl(210 40% 98%)",
    },
  } as Record<ThemeMode, ThemeTokens>,
};

/**
 * Writes the theme tokens to :root as CSS variables. Called once on mount.
 * Keeping this here (not in a component) guarantees re-skinning only ever
 * touches /src/config/*.
 */
export function applyTheme(mode: ThemeMode = themeConfig.defaultMode): void {
  if (typeof document === "undefined") return;
  const t = themeConfig.modes[mode];
  const root = document.documentElement;
  root.style.setProperty("--c-background", t.background);
  root.style.setProperty("--c-surface", t.surface);
  root.style.setProperty("--c-foreground", t.foreground);
  root.style.setProperty("--c-muted", t.muted);
  root.style.setProperty("--c-border", t.border);
  root.style.setProperty("--c-primary-foreground", t.primaryForeground);
  root.style.setProperty("--c-secondary-foreground", t.secondaryForeground);
  root.style.setProperty("--c-primary", themeConfig.primaryColor);
  root.style.setProperty("--c-secondary", themeConfig.secondaryAccent);
  root.style.setProperty("--c-accent-glow", themeConfig.accentGlow);
  root.style.setProperty("--c-radius", themeConfig.borderRadius);
  root.style.setProperty("--c-font", themeConfig.fontFamily);
  root.style.colorScheme = mode;
}
