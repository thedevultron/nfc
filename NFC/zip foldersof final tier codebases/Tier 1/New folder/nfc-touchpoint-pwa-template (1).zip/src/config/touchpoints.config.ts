/**
 * TOUCHPOINTS CONFIG — vertical content: links, socials, WiFi, vCard, copy.
 * ─────────────────────────────────────────────────────────────────
 * Edit THIS file to change the hub links, WiFi credentials, contact
 * details, icon marks, and every piece of copy. Icon names are plain
 * strings resolved by the Icon registry — no component imports here.
 *
 * Active preset: RESTAURANT.
 *   primary icon: Utensils (brand mark)  · secondary icon: Star (review)
 */
import type { TouchpointsConfig } from "@/types/template.types";

export const touchpointsConfig: TouchpointsConfig = {
  vertical: "RESTAURANT",
  icons: { primary: "Utensils", secondary: "Star" },

  copy: {
    loading: "Setting your table…",
    reviewPrompt: "How was your meal?",
    reviewSubtitle: "Your feedback shapes every plate we serve.",
    highRatingHeadline: "You made our night!",
    highRatingCta: "Post on Google Maps",
    highRatingSubtitle: "It takes 10 seconds and means the world to our team.",
    lowRatingHeadline: "Tell us what went wrong",
    lowRatingSubtitle: "This goes straight to the owner — not public.",
    feedbackPlaceholder: "What could we do better next time?",
    feedbackSubmit: "Send to the owner",
    feedbackSuccess: "Thank you — we've got it, and we'll do better.",
    wifiLabel: "Guest WiFi",
    wifiSubtitle: "On the house — tap to connect.",
    copyPassword: "Copy Password",
    showQr: "Show QR Code",
    saveContact: "Save Contact",
  },

  hub: [
    {
      id: "reserve",
      label: "Reserve a Table",
      icon: "MessageSquare",
      url: "https://wa.me/919999999999",
      external: true,
      tint: "secondary",
    },
    {
      id: "menu",
      label: "View Digital Menu",
      icon: "BookOpen",
      url: "https://grandbistro.example/menu",
      external: true,
      tint: "primary",
    },
    {
      id: "wifi",
      label: "Connect to WiFi",
      icon: "Wifi",
      action: "wifi",
      tint: "primary",
    },
    {
      id: "review",
      label: "Leave a Review",
      icon: "Star",
      action: "review",
      tint: "primary",
    },
    {
      id: "contact",
      label: "Save Our Contact",
      icon: "UserPlus",
      action: "contact",
      tint: "secondary",
    },
  ],

  wifi: { ssid: "Bistro_Guest", password: "welcome123", encryption: "WPA" },

  vcard: {
    name: "The Grand Bistro",
    phone: "+919999999999",
    org: "Hospitality",
    title: "Reservations",
    url: "https://grandbistro.example",
  },
};
