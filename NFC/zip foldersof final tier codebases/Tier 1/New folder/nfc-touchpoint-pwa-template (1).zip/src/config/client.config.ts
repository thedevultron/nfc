/**
 * CLIENT CONFIG — business metadata, active mode, webhook URLs.
 * ─────────────────────────────────────────────────────────────────
 * Edit THIS file to swap the business identity, the default landing
 * mode, the secondary swipeable panel, the review destination, and
 * the n8n webhook endpoints. No component edits required.
 *
 * Active preset: RESTAURANT — "The Grand Bistro".
 */
import type { ClientConfig } from "@/types/template.types";

export const clientConfig: ClientConfig = {
  businessName: "The Grand Bistro",
  subtitle: "Thanks for dining with us today",
  tagline: "Pune · Touchpoint #01",
  touchpointId: "tier1-bistro-01",
  // Default landing panel is REVIEW; HUB is the secondary swipeable panel.
  activeMode: "REVIEW",
  secondaryMode: "HUB",
  entry: { method: "NFC tap", detail: "Table 12" },
  googleReviewUrl: "https://maps.google.com/?q=the+grand+bistro+pune",
  n8nWebhookUrl: "https://n8n.yourdomain.com/webhook/tier1-analytics",
  n8nFeedbackWebhook: "https://n8n.yourdomain.com/webhook/tier1-feedback",
};
