/**
 * MOTION CONFIG — single source of truth for ALL animation physics.
 * ─────────────────────────────────────────────────────────────────
 * Edit THIS file to change spring feel, stagger timing, easing, press
 * depth, hover lift, and haptic patterns. Never hard-code animation
 * values inside /src/components/, /src/hooks/, or /src/services/.
 */
export const motionConfig = {
  springs: {
    /** Buttons, taps — tight and decisive. */
    snappy: { type: "spring" as const, stiffness: 500, damping: 32, mass: 0.9 },
    /** Card entrances, panel transitions — confident but soft. */
    smooth: { type: "spring" as const, stiffness: 300, damping: 30, mass: 1 },
    /** Star-rating pop — overshoots slightly for delight. */
    elastic: { type: "spring" as const, stiffness: 420, damping: 18, mass: 1 },
    /** Bottom sheets — heavier, settles without bounce. */
    drawer: { type: "spring" as const, stiffness: 380, damping: 38 },
  },
  stagger: { children: 0.045, delayChildren: 0.08 },
  press: { scale: 0.96, brightness: 0.94 },
  hover: { scale: 1.02 },
  /** navigator.vibrate patterns (ms). No-op on unsupported devices. */
  haptics: {
    tap: 8,
    selection: 12,
    success: [10, 40, 10],
    error: [20, 30, 20, 30],
  },
} as const;

export type MotionConfig = typeof motionConfig;
