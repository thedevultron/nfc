/**
 * API SERVICE — n8n webhook POST handlers.
 * ─────────────────────────────────────────────────────────────────
 * - postFeedback(): retry-safe POST for the feedback drawer. Components
 *   render the optimistic success state immediately and fire this in the
 *   background; it retries with exponential backoff and never blocks UI.
 * - postAnalyticsBeacon(): non-blocking telemetry using sendBeacon with a
 *   keepalive fetch fallback. Fired by useTapAnalytics, debounced.
 * Endpoints live in /src/config/client.config.ts — edit there, not here.
 */
import { clientConfig } from "@/config/client.config";
import type { AnalyticsEvent, FeedbackPayload } from "@/types/template.types";

const MAX_RETRIES = 3;
const BASE_DELAY = 400;

async function postWithRetry(
  url: string,
  body: unknown,
  retries = MAX_RETRIES,
): Promise<boolean> {
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        keepalive: true,
      });
      if (res.ok || res.status === 204) return true;
      throw new Error(`HTTP ${res.status}`);
    } catch {
      if (attempt === retries - 1) return false;
      await new Promise((r) => setTimeout(r, BASE_DELAY * 2 ** attempt));
    }
  }
  return false;
}

export async function postFeedback(
  payload: FeedbackPayload,
): Promise<{ ok: boolean }> {
  const ok = await postWithRetry(clientConfig.n8nFeedbackWebhook, payload);
  return { ok };
}

export function postAnalyticsBeacon(events: AnalyticsEvent[]): void {
  if (events.length === 0) return;
  const payload = JSON.stringify({
    batch: events,
    source: clientConfig.touchpointId,
  });

  try {
    if (
      typeof navigator !== "undefined" &&
      typeof navigator.sendBeacon === "function"
    ) {
      const blob = new Blob([payload], { type: "application/json" });
      if (navigator.sendBeacon(clientConfig.n8nWebhookUrl, blob)) return;
    }
  } catch {
    /* fall through to fetch fallback */
  }

  // Fire-and-forget fallback so analytics never blocks the main thread.
  fetch(clientConfig.n8nWebhookUrl, {
    method: "POST",
    keepalive: true,
    headers: { "Content-Type": "application/json" },
    body: payload,
  }).catch(() => {});
}
