/**
 * HAPTICS SERVICE — navigator.vibrate abstraction.
 * ─────────────────────────────────────────────────────────────────
 * Pattern presets come from /src/config/motion.config.ts (haptics key).
 * Components call haptics.tap() / .selection() / .success() / .error().
 * Silently no-ops on devices without vibration (iOS Safari, desktop).
 * Edit /src/config/motion.config.ts to change patterns — not this file.
 */
import { motionConfig } from "@/config/motion.config";
import type { HapticName } from "@/types/template.types";

const isSupported =
  typeof navigator !== "undefined" && typeof navigator.vibrate === "function";

function run(pattern: number | readonly number[]): void {
  if (!isSupported) return;
  try {
    navigator.vibrate(pattern as number | number[]);
  } catch {
    /* vibration can throw on some embedded webviews — swallow it */
  }
}

export const haptics = {
  tap: () => run(motionConfig.haptics.tap),
  selection: () => run(motionConfig.haptics.selection),
  success: () => run(motionConfig.haptics.success),
  error: () => run(motionConfig.haptics.error),
  /** Trigger a pattern by name (mapped to motion.config). */
  pattern: (name: HapticName) => run(motionConfig.haptics[name]),
};

export type HapticsService = typeof haptics;
