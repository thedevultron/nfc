/**
 * Shared type definitions for the Tier 1 TAP Custom / Review Engine.
 * These describe the SHAPE of the decoupled config files only — they contain
 * zero design tokens, copy, or business identity. All values live in /src/config/*.
 */

export type TouchpointMode = "REVIEW" | "WIFI" | "CONTACT" | "HUB";

/** The two swipeable root panels rendered by App.tsx. */
export type PanelKey = "review" | "hub";

export type ThemeMode = "dark" | "light";

export type Vertical =
  | "RESTAURANT"
  | "SALON"
  | "CLINIC"
  | "RETAIL"
  | "FITNESS"
  | (string & {});

/** Haptic pattern names mapped 1:1 to motion.config presets. */
export type HapticName = "tap" | "selection" | "success" | "error";

export interface SpringPreset {
  type: "spring";
  stiffness: number;
  damping: number;
  mass?: number;
}

export interface ThemeTokens {
  background: string;
  surface: string;
  foreground: string;
  muted: string;
  border: string;
  primaryForeground: string;
  secondaryForeground: string;
}

/** Actions a hub row can trigger instead of navigating to a URL. */
export type HubActionType = "review" | "wifi" | "contact" | "switch-hub";

export interface HubItem {
  id: string;
  label: string;
  /** Lucide icon name (string) — resolved by the Icon registry in components. */
  icon: string;
  url?: string;
  external?: boolean;
  action?: HubActionType;
  tint?: "primary" | "secondary";
}

export interface WifiConfig {
  ssid: string;
  password: string;
  hidden?: boolean;
  encryption?: "WPA" | "WEP" | "nopass";
}

export interface VCardConfig {
  name: string;
  phone?: string;
  email?: string;
  org?: string;
  title?: string;
  url?: string;
  address?: string;
}

/** Every user-facing string lives here so copy can be re-skinned via config. */
export interface TouchpointCopy {
  loading: string;
  reviewPrompt: string;
  reviewSubtitle: string;
  highRatingHeadline: string;
  highRatingCta: string;
  highRatingSubtitle: string;
  lowRatingHeadline: string;
  lowRatingSubtitle: string;
  feedbackPlaceholder: string;
  feedbackSubmit: string;
  feedbackSuccess: string;
  wifiLabel: string;
  wifiSubtitle: string;
  copyPassword: string;
  showQr: string;
  saveContact: string;
}

export interface TouchpointsIconSet {
  primary: string;
  secondary: string;
}

export interface TouchpointsConfig {
  vertical: Vertical;
  icons: TouchpointsIconSet;
  copy: TouchpointCopy;
  hub: HubItem[];
  wifi: WifiConfig;
  vcard: VCardConfig;
}

export interface ClientConfig {
  businessName: string;
  subtitle: string;
  tagline: string;
  touchpointId: string;
  activeMode: TouchpointMode;
  secondaryMode: TouchpointMode;
  entry: { method: string; detail: string };
  googleReviewUrl: string;
  n8nWebhookUrl: string;
  n8nFeedbackWebhook: string;
}

export interface FeedbackPayload {
  rating: number;
  feedbackText: string;
  timestamp: number;
  touchpointId: string;
}

export interface AnalyticsEvent {
  event: string;
  touchpointId: string;
  timestamp: number;
  [key: string]: unknown;
}
