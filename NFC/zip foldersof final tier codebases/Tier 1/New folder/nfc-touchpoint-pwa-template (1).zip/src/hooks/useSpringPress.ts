/**
 * useSpringPress — reusable "press-down" scale + brightness + haptic hook.
 * ─────────────────────────────────────────────────────────────────
 * Spread the returned props onto any motion.* tappable to get consistent,
 * config-driven press feedback with a haptic on tap-start. Physics and
 * haptic patterns come from /src/config/motion.config.ts — do not inline
 * animation values in components.
 *
 *   const press = useSpringPress("selection");
 *   <motion.button {...press} onClick={...} />
 */
import { motionConfig } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import type { HapticName } from "@/types/template.types";

const HAPTIC_MAP: Record<HapticName, () => void> = {
  tap: haptics.tap,
  selection: haptics.selection,
  success: haptics.success,
  error: haptics.error,
};

export interface SpringPressProps {
  whileHover: { scale: number };
  whileTap: { scale: number; filter: string };
  onTapStart: () => void;
}

export function useSpringPress(hapticName: HapticName = "tap"): SpringPressProps {
  const fire = HAPTIC_MAP[hapticName];
  return {
    whileHover: { scale: motionConfig.hover.scale },
    whileTap: {
      scale: motionConfig.press.scale,
      filter: `brightness(${motionConfig.press.brightness})`,
    },
    onTapStart: () => fire(),
  };
}
