/**
 * useReducedMotion — respects prefers-reduced-motion.
 * ─────────────────────────────────────────────────────────────────
 * Components branch on this to swap springs for simple ~150ms ease-out
 * fades and disable drag/overscroll overkill. The actual thresholds and
 * physics live in /src/config/motion.config.ts.
 */
import { useEffect, useState } from "react";

export function useReducedMotion(): boolean {
  const [reduced, setReduced] = useState<boolean>(() => {
    if (typeof window === "undefined" || !window.matchMedia) return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  });

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  return reduced;
}
