/**
 * useTapAnalytics — fires on mount + on every tracked CTA tap.
 * ─────────────────────────────────────────────────────────────────
 * Events are queued and flushed (a) debounced after 600ms of quiet, and
 * (b) non-blockingly via sendBeacon on tab-hide / unmount — so telemetry
 * never delays interaction. Endpoints come from /src/config/client.config.ts.
 */
import { useCallback, useEffect, useRef } from "react";
import { clientConfig } from "@/config/client.config";
import { postAnalyticsBeacon } from "@/services/api.service";
import type { AnalyticsEvent } from "@/types/template.types";

const FLUSH_DEBOUNCE_MS = 600;

export function useTapAnalytics(touchpointId: string) {
  const queue = useRef<AnalyticsEvent[]>([]);
  const timer = useRef<number | null>(null);

  const flush = useCallback(() => {
    if (timer.current !== null) {
      clearTimeout(timer.current);
      timer.current = null;
    }
    if (queue.current.length === 0) return;
    const batch = queue.current.splice(0);
    postAnalyticsBeacon(batch);
  }, []);

  const track = useCallback(
    (event: string, payload: Record<string, unknown> = {}) => {
      queue.current.push({
        event,
        touchpointId,
        timestamp: Date.now(),
        ...payload,
      });
      if (timer.current !== null) clearTimeout(timer.current);
      timer.current = window.setTimeout(flush, FLUSH_DEBOUNCE_MS);
    },
    [flush, touchpointId],
  );

  useEffect(() => {
    // Initial "tap view" — the moment the touchpoint loads.
    track("tap_view", { mode: clientConfig.activeMode });

    const onHide = () => flush();
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("pagehide", onHide);

    return () => {
      document.removeEventListener("visibilitychange", onHide);
      window.removeEventListener("pagehide", onHide);
      flush();
    };
  }, [track, flush]);

  return { track, flush };
}
