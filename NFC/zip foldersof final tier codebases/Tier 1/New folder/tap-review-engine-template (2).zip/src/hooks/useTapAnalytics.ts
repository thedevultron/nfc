import { useCallback, useEffect, useRef } from "react";
import { sendAnalytics } from "@/services/api.service";
import { clientConfig } from "@/config/client.config";
import type { TouchpointMode } from "@/types/template.types";

/*
  ─────────────────────────────────────────────────────────────
  useTapAnalytics — fires a "touchpoint_open" event on mount and
  returns a debounced, non-blocking `track()` for CTA taps.
  Endpoint + touchpointId come from /src/config/client.config.ts.
  ─────────────────────────────────────────────────────────────
*/

const DEBOUNCE_MS = 250;

export function useTapAnalytics(mode: TouchpointMode) {
  const lastFired = useRef<Record<string, number>>({});

  useEffect(() => {
    sendAnalytics({
      event: "touchpoint_open",
      touchpointId: clientConfig.touchpointId,
      mode,
      timestamp: new Date().toISOString(),
    });
    // Fire once per mount — mode is the initial landing mode.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const track = useCallback(
    (event: string, meta?: Record<string, unknown>) => {
      const now = Date.now();
      const key = event + JSON.stringify(meta ?? {});
      if (now - (lastFired.current[key] ?? 0) < DEBOUNCE_MS) return;
      lastFired.current[key] = now;

      sendAnalytics({
        event,
        touchpointId: clientConfig.touchpointId,
        mode,
        meta,
        timestamp: new Date().toISOString(),
      });
    },
    [mode],
  );

  return { track };
}
