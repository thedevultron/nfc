import { useMemo } from "react";
import type { TargetAndTransition, Transition } from "framer-motion";
import { motionConfig } from "@/config/motion.config";
import { haptic } from "@/services/haptics.service";
import { useReducedMotion } from "./useReducedMotion";
import type { HapticPattern } from "@/types/template.types";

/*
  ─────────────────────────────────────────────────────────────
  useSpringPress — reusable "press-down" interaction.
  Returns Framer Motion props (whileTap / whileHover / transition)
  and an onTapStart handler that fires the configured haptic.
  All physics come from /src/config/motion.config.ts.
  ─────────────────────────────────────────────────────────────
*/

interface SpringPressOptions {
  haptic?: HapticPattern;
  spring?: keyof typeof motionConfig.springs;
  enableHover?: boolean;
}

interface SpringPressReturn {
  whileTap: TargetAndTransition;
  whileHover?: TargetAndTransition;
  transition: Transition;
  onTapStart: () => void;
}

export function useSpringPress(
  options: SpringPressOptions = {},
): SpringPressReturn {
  const {
    haptic: hapticPattern = "tap",
    spring = "snappy",
    enableHover = true,
  } = options;
  const reduced = useReducedMotion();

  return useMemo(() => {
    const transition: Transition = reduced
      ? { duration: motionConfig.reducedFade.duration, ease: "easeOut" }
      : motionConfig.springs[spring];

    const whileTap: TargetAndTransition = reduced
      ? { opacity: 0.85 }
      : {
          scale: motionConfig.press.scale,
          filter: `brightness(${motionConfig.press.brightness})`,
        };

    const whileHover: TargetAndTransition | undefined =
      reduced || !enableHover ? undefined : { scale: motionConfig.hover.scale };

    return {
      whileTap,
      whileHover,
      transition,
      onTapStart: () => haptic(hapticPattern),
    };
  }, [reduced, spring, enableHover, hapticPattern]);
}
