import type { ThemeConfig } from "@/types/template.types";

/*
  ═══════════════════════════════════════════════════════════════
  THEME CONFIG — Colors, radius, light/dark, typography.
  Edit THIS file to re-skin the app. Do not touch /src/components/.
  Colors accept any CSS color string; HSL triplets are extracted
  automatically by <ThemeProvider> so glows/opacity math works.
  ═══════════════════════════════════════════════════════════════
*/

export const themeConfig: ThemeConfig = {
  primaryColor: "hsl(38 92% 50%)", // Warm Amber
  secondaryAccent: "hsl(160 84% 39%)", // Emerald
  accentGlow: "hsl(38 92% 50% / 0.25)",
  backgroundColor: "hsl(224 71.4% 4.1%)", // true black-adjacent, never #000
  surfaceColor: "hsl(224 40% 8%)",
  foregroundColor: "hsl(210 20% 98%)",
  mutedColor: "hsl(217 15% 62%)",
  borderRadius: "0.75rem",
  fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
  enableGlassmorphism: true,
  defaultMode: "dark",
};
