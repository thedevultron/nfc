import type { MotionConfig } from "@/types/template.types";

/*
  ═══════════════════════════════════════════════════════════════
  MOTION CONFIG — the SINGLE source of truth for all animation
  physics and haptic patterns. Edit THIS file to change how the
  whole app "feels". No component should ever inline spring values.
  ═══════════════════════════════════════════════════════════════
*/

export const motionConfig: MotionConfig = {
  springs: {
    snappy: { type: "spring", stiffness: 500, damping: 32, mass: 0.9 }, // buttons, taps
    smooth: { type: "spring", stiffness: 300, damping: 30, mass: 1 }, // card entrances
    elastic: { type: "spring", stiffness: 420, damping: 18, mass: 1 }, // star rating pop
    drawer: { type: "spring", stiffness: 380, damping: 38 }, // bottom sheets
  },
  stagger: { children: 0.045, delayChildren: 0.08 },
  press: { scale: 0.96, brightness: 0.94 },
  hover: { scale: 1.02 },
  reducedFade: { duration: 0.15 },
  haptics: {
    tap: 8,
    selection: 12,
    success: [10, 40, 10],
    error: [20, 30, 20, 30],
  },
};
