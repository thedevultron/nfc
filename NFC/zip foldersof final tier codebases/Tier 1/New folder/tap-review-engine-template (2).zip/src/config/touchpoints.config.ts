import type { TouchpointsConfig } from "@/types/template.types";

/*
  ═══════════════════════════════════════════════════════════════
  TOUCHPOINTS CONFIG — Vertical content: links, socials, WiFi
  creds, vCard fields, and every user-facing copy string.
  Edit THIS file to change what each module shows. Icons are
  referenced by Lucide name (string) — see lucide.dev/icons.
  ═══════════════════════════════════════════════════════════════
*/

export const touchpointsConfig: TouchpointsConfig = {
  vertical: "RESTAURANT",
  icons: {
    primary: "Utensils", // brand mark
    secondary: "Star", // review accent
  },
  hub: [
    {
      label: "Reserve a Table",
      sublabel: "Chat with us on WhatsApp",
      icon: "MessageSquare",
      url: "https://wa.me/91XXXXXXXXXX",
      external: true,
      tint: "secondary",
    },
    {
      label: "View Digital Menu",
      sublabel: "Tonight's specials & wine list",
      icon: "BookOpen",
      url: "/menu",
      external: false,
      tint: "primary",
    },
    {
      label: "Connect to WiFi",
      sublabel: "Free guest network",
      icon: "Wifi",
      url: "#wifi",
      external: false,
      action: "wifi",
      tint: "primary",
    },
    {
      label: "Leave a Review",
      sublabel: "Tell us how we did",
      icon: "Star",
      url: "#review",
      external: false,
      action: "review",
      tint: "secondary",
    },
  ],
  wifi: {
    ssid: "Bistro_Guest",
    password: "welcome123",
    encryption: "WPA",
  },
  vcard: {
    name: "The Grand Bistro",
    phone: "+919000000000",
    org: "Hospitality",
    email: "reservations@grandbistro.example",
    whatsapp: "919000000000",
    website: "https://grandbistro.example",
  },
  copy: {
    reviewPrompt: "How was your experience?",
    reviewHighTitle: "You made our day! ✨",
    reviewHighCta: "Post on Google Maps",
    reviewLowTitle: "We'd love a second chance",
    reviewLowSubtitle:
      "Tell us what went wrong — this goes straight to the owner, not public.",
    reviewPlaceholder: "The more detail, the better we can fix it…",
    reviewSubmit: "Send to the owner",
    feedbackSuccess: "Thank you — the owner has been notified.",
    wifiTitle: "Table WiFi",
    wifiSubtitle: "Tap to reveal & copy the password",
    contactTitle: "Save our details",
    contactSubtitle: "Add The Grand Bistro to your contacts",
    hubTitle: "Everything at your table",
    loading: "Setting your table…",
  },
};
