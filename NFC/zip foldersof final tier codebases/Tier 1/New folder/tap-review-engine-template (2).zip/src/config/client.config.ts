import type { ClientConfig } from "@/types/template.types";

/*
  ═══════════════════════════════════════════════════════════════
  CLIENT CONFIG — Business identity, active touchpoint, webhooks.
  Edit THIS file to change business copy, landing mode, or the
  n8n endpoints. Do not touch /src/components/ or /src/services/.
  ═══════════════════════════════════════════════════════════════
*/

export const clientConfig: ClientConfig = {
  businessName: "The Grand Bistro",
  subtitle: "Pune · Touchpoint #01",
  greeting: "Thanks for dining with us today",
  activeMode: "REVIEW", // default landing panel
  secondaryMode: "HUB", // swipeable secondary panel
  touchpointId: "grand-bistro-tp-01",
  googleReviewUrl: "https://maps.google.com/?q=your_place_id",
  n8nWebhookUrl: "https://n8n.yourdomain.com/webhook/tier1-analytics",
  n8nFeedbackWebhook: "https://n8n.yourdomain.com/webhook/tier1-feedback",
};
