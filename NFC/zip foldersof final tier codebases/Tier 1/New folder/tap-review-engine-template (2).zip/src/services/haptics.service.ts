import { motionConfig } from "@/config/motion.config";
import type { HapticPattern } from "@/types/template.types";

/*
  ─────────────────────────────────────────────────────────────
  HAPTICS SERVICE — thin abstraction over navigator.vibrate.
  Patterns come from /src/config/motion.config.ts (haptics key).
  To change how taps feel, edit motion.config — not this file.
  ─────────────────────────────────────────────────────────────
*/

let userHasInteracted = false;

// Vibration only works after a user gesture on most browsers.
if (typeof window !== "undefined") {
  const markInteracted = () => {
    userHasInteracted = true;
    window.removeEventListener("pointerdown", markInteracted);
    window.removeEventListener("keydown", markInteracted);
  };
  window.addEventListener("pointerdown", markInteracted, { once: true });
  window.addEventListener("keydown", markInteracted, { once: true });
}

function canVibrate(): boolean {
  return (
    typeof navigator !== "undefined" &&
    typeof navigator.vibrate === "function" &&
    userHasInteracted
  );
}

/** Fire a named haptic pattern defined in motion.config. Never throws. */
export function haptic(pattern: HapticPattern): void {
  if (!canVibrate()) return;
  try {
    navigator.vibrate(motionConfig.haptics[pattern]);
  } catch {
    /* haptics are best-effort; silently ignore */
  }
}

/** Convenience named helpers for readability at call sites. */
export const haptics = {
  tap: () => haptic("tap"),
  selection: () => haptic("selection"),
  success: () => haptic("success"),
  error: () => haptic("error"),
};
