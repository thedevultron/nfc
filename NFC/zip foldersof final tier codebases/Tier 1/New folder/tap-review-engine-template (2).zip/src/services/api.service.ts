import type {
  AnalyticsPayload,
  FeedbackPayload,
} from "@/types/template.types";
import { clientConfig } from "@/config/client.config";

/*
  ─────────────────────────────────────────────────────────────
  API SERVICE — retry-safe, non-blocking n8n webhook POSTs.
  Endpoints are read from /src/config/client.config.ts.
  Analytics use `keepalive` + navigator.sendBeacon so they never
  block navigation or UI. Feedback uses a small retry with backoff.
  ─────────────────────────────────────────────────────────────
*/

const RETRIES = 2;
const BASE_DELAY = 400;

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function isPlaceholderUrl(url: string): boolean {
  // Prevents noisy console errors in the template's default state.
  return !url || url.includes("yourdomain.com");
}

async function postWithRetry(
  url: string,
  body: unknown,
  attempt = 0,
): Promise<boolean> {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      keepalive: true,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (err) {
    if (attempt < RETRIES) {
      await sleep(BASE_DELAY * Math.pow(2, attempt));
      return postWithRetry(url, body, attempt + 1);
    }
    console.warn("[api.service] POST failed after retries:", err);
    return false;
  }
}

/** Fire-and-forget analytics. Uses sendBeacon when available. */
export function sendAnalytics(payload: AnalyticsPayload): void {
  const url = clientConfig.n8nWebhookUrl;
  if (isPlaceholderUrl(url)) {
    if (import.meta.env.DEV) console.info("[analytics:dev]", payload);
    return;
  }
  try {
    const blob = new Blob([JSON.stringify(payload)], {
      type: "application/json",
    });
    if (typeof navigator !== "undefined" && navigator.sendBeacon) {
      navigator.sendBeacon(url, blob);
      return;
    }
  } catch {
    /* fall through to fetch */
  }
  void postWithRetry(url, payload);
}

/** Submit private feedback. Resolves true on success, false otherwise. */
export async function sendFeedback(payload: FeedbackPayload): Promise<boolean> {
  const url = clientConfig.n8nFeedbackWebhook;
  if (isPlaceholderUrl(url)) {
    if (import.meta.env.DEV) console.info("[feedback:dev]", payload);
    // Simulate a realistic network round-trip for the optimistic UI demo.
    await sleep(650);
    return true;
  }
  return postWithRetry(url, payload);
}
