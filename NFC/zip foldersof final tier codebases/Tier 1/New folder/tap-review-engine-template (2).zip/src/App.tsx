import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { PanInfo } from "framer-motion";
import { ThemeProvider } from "@/components/layout/ThemeProvider";
import { AppShell } from "@/components/layout/AppShell";
import { NFCContextBanner } from "@/components/layout/NFCContextBanner";
import { FooterBrand } from "@/components/layout/FooterBrand";
import { LoadingScreen } from "@/components/layout/LoadingScreen";
import { Drawer } from "@/components/ui/Drawer";
import { Icon } from "@/components/ui/Icon";
import { ReviewRouter } from "@/components/touchpoints/ReviewRouter";
import { SocialHub } from "@/components/touchpoints/SocialHub";
import { WifiCard } from "@/components/touchpoints/WifiCard";
import { VCardSheet } from "@/components/touchpoints/VCardSheet";
import { clientConfig } from "@/config/client.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { haptic } from "@/services/haptics.service";
import { cn } from "@/utils/cn";
import type { HubItem, LucideIconName, TouchpointMode } from "@/types/template.types";

/*
  ═══════════════════════════════════════════════════════════════
  App.tsx — root shell. Wires ThemeProvider, load skeleton, panel
  switching (activeMode + secondaryMode) with swipe + tabs, and the
  overlay drawers for hub-triggered WiFi / Contact touchpoints.
  All behavior is driven by /src/config/*.ts — do not hardcode here.
  ═══════════════════════════════════════════════════════════════
*/

const MODE_META: Record<TouchpointMode, { label: string; icon: LucideIconName }> =
  {
    REVIEW: { label: "Review", icon: "Star" },
    HUB: { label: "Explore", icon: "LayoutGrid" },
    WIFI: { label: "WiFi", icon: "Wifi" },
    CONTACT: { label: "Contact", icon: "UserPlus" },
  };

export default function App() {
  return (
    <ThemeProvider>
      <TouchpointApp />
    </ThemeProvider>
  );
}

function TouchpointApp() {
  const reduced = useReducedMotion();
  const [ready, setReady] = useState(false);

  // Configured panels: primary landing + optional secondary.
  const panels = useMemo<TouchpointMode[]>(() => {
    const list = [clientConfig.activeMode];
    if (
      clientConfig.secondaryMode &&
      clientConfig.secondaryMode !== clientConfig.activeMode
    ) {
      list.push(clientConfig.secondaryMode);
    }
    return list;
  }, []);

  const [mode, setMode] = useState<TouchpointMode>(clientConfig.activeMode);
  const [overlay, setOverlay] = useState<"WIFI" | "CONTACT" | null>(null);
  const { track } = useTapAnalytics(clientConfig.activeMode);

  // Simulate instant config resolution (200-400ms) — never blank flash.
  useEffect(() => {
    const t = window.setTimeout(() => setReady(true), 320);
    return () => window.clearTimeout(t);
  }, []);

  const handleHubAction = (action: NonNullable<HubItem["action"]>) => {
    if (action === "wifi") setOverlay("WIFI");
    else if (action === "contact") setOverlay("CONTACT");
    else if (action === "review") switchMode("REVIEW");
  };

  const switchMode = (next: TouchpointMode) => {
    if (next === mode) return;
    haptic("selection");
    track("panel_switch", { to: next });
    setMode(next);
  };

  // Swipe-to-switch between the two panels (iOS-style).
  const handleSwipe = (_e: unknown, info: PanInfo) => {
    if (panels.length < 2) return;
    const threshold = 60;
    const idx = panels.indexOf(mode);
    if (info.offset.x < -threshold && idx < panels.length - 1) {
      switchMode(panels[idx + 1]);
    } else if (info.offset.x > threshold && idx > 0) {
      switchMode(panels[idx - 1]);
    }
  };

  const panelTransition = reduced
    ? { duration: motionConfig.reducedFade.duration, ease: "easeOut" as const }
    : motionConfig.springs.smooth;

  return (
    <AppShell>
      <NFCContextBanner />

      <div className="mt-6 flex flex-1 flex-col">
        <AnimatePresence mode="wait">
          {!ready ? (
            <LoadingScreen key="loading" />
          ) : (
            <motion.div
              key="content"
              className="flex flex-1 flex-col"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.2 }}
            >
              {/* Segmented panel switcher */}
              {panels.length > 1 && (
                <ModeSwitcher
                  panels={panels}
                  current={mode}
                  onSelect={switchMode}
                  reduced={reduced}
                />
              )}

              {/* Swipeable panel area */}
              <motion.div
                className="relative mt-4 flex-1"
                drag={panels.length > 1 ? "x" : false}
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.18}
                dragSnapToOrigin
                onDragEnd={handleSwipe}
              >
                <AnimatePresence mode="wait">
                  <motion.div
                    key={mode}
                    initial={{ opacity: 0, y: reduced ? 0 : 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: reduced ? 0 : -20 }}
                    transition={panelTransition}
                  >
                    <ModuleRenderer
                      mode={mode}
                      onTrack={track}
                      onAction={handleHubAction}
                    />
                  </motion.div>
                </AnimatePresence>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <FooterBrand />

      {/* Overlay touchpoints triggered from the hub */}
      <Drawer open={overlay === "WIFI"} onClose={() => setOverlay(null)}>
        <WifiCard onTrack={track} />
      </Drawer>
      <Drawer open={overlay === "CONTACT"} onClose={() => setOverlay(null)}>
        <VCardSheet onTrack={track} />
      </Drawer>
    </AppShell>
  );
}

function ModuleRenderer({
  mode,
  onTrack,
  onAction,
}: {
  mode: TouchpointMode;
  onTrack: (event: string, meta?: Record<string, unknown>) => void;
  onAction: (action: NonNullable<HubItem["action"]>) => void;
}) {
  switch (mode) {
    case "REVIEW":
      return <ReviewRouter onTrack={onTrack} />;
    case "HUB":
      return <SocialHub onAction={onAction} onTrack={onTrack} />;
    case "WIFI":
      return <WifiCard onTrack={onTrack} />;
    case "CONTACT":
      return <VCardSheet onTrack={onTrack} />;
    default:
      return null;
  }
}

function ModeSwitcher({
  panels,
  current,
  onSelect,
  reduced,
}: {
  panels: TouchpointMode[];
  current: TouchpointMode;
  onSelect: (m: TouchpointMode) => void;
  reduced: boolean;
}) {
  return (
    <div className="flex rounded-full border border-white/10 bg-foreground/[0.04] p-1 backdrop-blur-xl">
      {panels.map((m) => {
        const active = m === current;
        const meta = MODE_META[m];
        return (
          <button
            key={m}
            onClick={() => onSelect(m)}
            className={cn(
              "relative flex flex-1 items-center justify-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium tracking-[-0.01em] transition-colors",
              active ? "text-primary-foreground" : "text-muted hover:text-foreground",
            )}
          >
            {active && (
              <motion.span
                layoutId="mode-pill"
                className="absolute inset-0 rounded-full bg-primary shadow-[0_0_24px_-6px_hsl(var(--accent-glow))]"
                transition={
                  reduced
                    ? { duration: motionConfig.reducedFade.duration }
                    : motionConfig.springs.snappy
                }
              />
            )}
            <span className="relative z-10 inline-flex items-center gap-1.5">
              <Icon name={meta.icon} className="h-4 w-4" />
              {meta.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
