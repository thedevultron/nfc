import { useRef } from "react";
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useTransform,
} from "framer-motion";
import type { PanInfo } from "framer-motion";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { haptic } from "@/services/haptics.service";

/*
  ─────────────────────────────────────────────────────────────
  Drawer — iOS Control-Center-style bottom sheet.
  Real drag-to-dismiss: drag="y", velocity-based snap on release,
  rubber-band overscroll resistance at the top edge.
  Spring physics come from motion.config (springs.drawer).
  ─────────────────────────────────────────────────────────────
*/

interface DrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  className?: string;
}

// If dragged past this distance OR flicked faster than this, dismiss.
const DISMISS_DISTANCE = 120;
const DISMISS_VELOCITY = 500;

export function Drawer({
  open,
  onClose,
  title,
  children,
  className,
}: DrawerProps) {
  const reduced = useReducedMotion();
  const y = useMotionValue(0);
  const sheetRef = useRef<HTMLDivElement>(null);

  // Backdrop fades as the sheet is dragged down.
  const backdropOpacity = useTransform(y, [0, 300], [1, 0.2]);

  const handleDragEnd = (_e: unknown, info: PanInfo) => {
    if (info.offset.y > DISMISS_DISTANCE || info.velocity.y > DISMISS_VELOCITY) {
      haptic("tap");
      onClose();
    } else {
      // Snap back into place.
      y.set(0);
    }
  };

  const drawerSpring = reduced
    ? { duration: motionConfig.reducedFade.duration, ease: "easeOut" as const }
    : motionConfig.springs.drawer;

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-[2px]"
            style={{ opacity: backdropOpacity }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
          />

          {/* Sheet */}
          <motion.div
            ref={sheetRef}
            className={cn(
              "relative w-full max-w-md rounded-t-2xl border-t border-white/10",
              themeConfig.enableGlassmorphism
                ? "backdrop-blur-2xl bg-background/85"
                : "bg-surface",
              "shadow-[0_-8px_40px_rgba(0,0,0,0.5)]",
              className,
            )}
            style={{ y }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            // Rubber-band: near-free downward, heavy resistance upward.
            dragElastic={{ top: 0.04, bottom: 0.7 }}
            onDragEnd={handleDragEnd}
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={drawerSpring}
          >
            {/* Grabber */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="h-1.5 w-11 rounded-full bg-foreground/20" />
            </div>

            <div
              className="px-5 pt-2"
              style={{
                paddingBottom: "calc(1.5rem + env(safe-area-inset-bottom))",
              }}
            >
              {title && (
                <h2 className="mb-3 text-lg font-semibold tracking-[-0.02em]">
                  {title}
                </h2>
              )}
              {children}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
