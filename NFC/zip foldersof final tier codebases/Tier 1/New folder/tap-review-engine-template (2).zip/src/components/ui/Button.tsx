import { forwardRef } from "react";
import { motion } from "framer-motion";
import type { HTMLMotionProps } from "framer-motion";
import { cn } from "@/utils/cn";
import { useSpringPress } from "@/hooks/useSpringPress";
import type { HapticPattern } from "@/types/template.types";

/*
  ─────────────────────────────────────────────────────────────
  Button — spring-pressed, haptic-tight primitive.
  Every visual token (color/radius/glow) is theme-driven.
  To restyle globally, edit /src/config/theme.config.ts.
  ─────────────────────────────────────────────────────────────
*/

type Variant = "primary" | "secondary" | "glass" | "ghost" | "outline";
type Size = "sm" | "md" | "lg";

interface ButtonProps extends Omit<HTMLMotionProps<"button">, "ref"> {
  variant?: Variant;
  size?: Size;
  haptic?: HapticPattern;
  glow?: boolean;
  fullWidth?: boolean;
}

const variantClasses: Record<Variant, string> = {
  primary:
    "bg-primary text-primary-foreground font-semibold hover:brightness-105",
  secondary:
    "bg-secondary-accent text-primary-foreground font-semibold hover:brightness-105",
  glass:
    "backdrop-blur-xl bg-foreground/[0.04] text-foreground border border-white/10 hover:bg-foreground/[0.07]",
  ghost: "bg-transparent text-foreground hover:bg-foreground/[0.06]",
  outline:
    "bg-transparent text-foreground border border-white/15 hover:bg-foreground/[0.05]",
};

const sizeClasses: Record<Size, string> = {
  sm: "h-9 px-3.5 text-sm rounded-md gap-1.5",
  md: "h-11 px-5 text-[0.95rem] rounded-lg gap-2",
  lg: "h-14 px-6 text-base rounded-xl gap-2.5",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  function Button(
    {
      className,
      variant = "primary",
      size = "md",
      haptic = "tap",
      glow = false,
      fullWidth = false,
      children,
      ...props
    },
    ref,
  ) {
    const press = useSpringPress({ haptic });

    return (
      <motion.button
        ref={ref}
        whileTap={press.whileTap}
        whileHover={press.whileHover}
        transition={press.transition}
        onTapStart={press.onTapStart}
        className={cn(
          "relative inline-flex select-none items-center justify-center whitespace-nowrap font-medium tracking-[-0.01em] outline-none transition-colors",
          "focus-visible:ring-2 focus-visible:ring-primary/60 disabled:pointer-events-none disabled:opacity-50",
          variantClasses[variant],
          sizeClasses[size],
          fullWidth && "w-full",
          // Premium ambient glow behind primary CTAs.
          glow &&
            (variant === "secondary"
              ? "shadow-[0_0_40px_-4px_hsl(var(--secondary-accent)/0.45)]"
              : "shadow-[0_0_40px_-4px_hsl(var(--accent-glow)/0.9)]"),
          className,
        )}
        {...props}
      >
        {children}
      </motion.button>
    );
  },
);
