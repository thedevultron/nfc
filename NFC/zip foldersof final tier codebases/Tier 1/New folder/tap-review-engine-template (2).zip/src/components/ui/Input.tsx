import { forwardRef } from "react";
import { cn } from "@/utils/cn";

/*
  ─────────────────────────────────────────────────────────────
  Input & Textarea — theme-driven form primitives.
  ─────────────────────────────────────────────────────────────
*/

export const Input = forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement>
>(function Input({ className, ...props }, ref) {
  return (
    <input
      ref={ref}
      className={cn(
        "h-11 w-full rounded-lg border border-white/10 bg-foreground/[0.04] px-4 text-[0.95rem] text-foreground",
        "placeholder:text-muted/70 outline-none transition-colors",
        "focus-visible:border-primary/50 focus-visible:ring-2 focus-visible:ring-primary/30",
        className,
      )}
      {...props}
    />
  );
});

export const Textarea = forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement>
>(function Textarea({ className, ...props }, ref) {
  return (
    <textarea
      ref={ref}
      className={cn(
        "min-h-[110px] w-full resize-none rounded-lg border border-white/10 bg-foreground/[0.04] px-4 py-3 text-[0.95rem] text-foreground",
        "placeholder:text-muted/70 outline-none transition-colors",
        "focus-visible:border-primary/50 focus-visible:ring-2 focus-visible:ring-primary/30",
        className,
      )}
      {...props}
    />
  );
});
