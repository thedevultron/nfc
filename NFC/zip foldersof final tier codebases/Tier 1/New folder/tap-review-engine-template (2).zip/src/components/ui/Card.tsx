import { forwardRef } from "react";
import { motion } from "framer-motion";
import type { HTMLMotionProps } from "framer-motion";
import { cn } from "@/utils/cn";

/*
  ─────────────────────────────────────────────────────────────
  Card — glassmorphism surface. Radius follows the theme token.
  Edit /src/config/theme.config.ts to change surface/radius.
  ─────────────────────────────────────────────────────────────
*/

interface CardProps extends Omit<HTMLMotionProps<"div">, "ref"> {
  glass?: boolean;
  padded?: boolean;
}

export const Card = forwardRef<HTMLDivElement, CardProps>(function Card(
  { className, glass = true, padded = true, children, ...props },
  ref,
) {
  return (
    <motion.div
      ref={ref}
      className={cn(
        "relative overflow-hidden rounded-2xl",
        glass
          ? "backdrop-blur-xl bg-background/70 border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.35)]"
          : "bg-surface border border-white/5",
        padded && "p-5",
        className,
      )}
      {...props}
    >
      {children}
    </motion.div>
  );
});
