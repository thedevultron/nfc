import { cn } from "@/utils/cn";

/*
  ─────────────────────────────────────────────────────────────
  Badge — small pill label. Theme-tinted; no hardcoded colors.
  ─────────────────────────────────────────────────────────────
*/

type Tone = "neutral" | "primary" | "secondary";

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: Tone;
}

const toneClasses: Record<Tone, string> = {
  neutral: "bg-foreground/[0.06] text-muted border-white/10",
  primary: "bg-primary/10 text-primary border-primary/20",
  secondary: "bg-secondary-accent/10 text-secondary-accent border-secondary-accent/20",
};

export function Badge({ className, tone = "neutral", ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium tracking-[-0.01em]",
        toneClasses[tone],
        className,
      )}
      {...props}
    />
  );
}
