import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useSpringPress } from "@/hooks/useSpringPress";

/*
  ─────────────────────────────────────────────────────────────
  Dialog — centered modal (Linear-style). Spring pop-in.
  ─────────────────────────────────────────────────────────────
*/

interface DialogProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  className?: string;
}

export function Dialog({
  open,
  onClose,
  title,
  children,
  className,
}: DialogProps) {
  const reduced = useReducedMotion();
  const closePress = useSpringPress({ haptic: "tap" });

  const spring = reduced
    ? { duration: motionConfig.reducedFade.duration, ease: "easeOut" as const }
    : motionConfig.springs.smooth;

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-5">
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
          />
          <motion.div
            className={cn(
              "relative w-full max-w-sm rounded-2xl border border-white/10 backdrop-blur-2xl bg-background/85 p-5 shadow-[0_8px_40px_rgba(0,0,0,0.5)]",
              className,
            )}
            initial={{ opacity: 0, scale: reduced ? 1 : 0.92, y: reduced ? 0 : 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: reduced ? 1 : 0.95, y: reduced ? 0 : 8 }}
            transition={spring}
          >
            <div className="mb-3 flex items-center justify-between">
              {title && (
                <h2 className="text-lg font-semibold tracking-[-0.02em]">
                  {title}
                </h2>
              )}
              <motion.button
                onClick={onClose}
                whileTap={closePress.whileTap}
                onTapStart={closePress.onTapStart}
                transition={closePress.transition}
                className="ml-auto grid h-8 w-8 place-items-center rounded-full bg-foreground/[0.06] text-muted hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </motion.button>
            </div>
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
