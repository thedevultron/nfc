import { memo } from "react";
import * as Icons from "lucide-react";
import type { LucideProps } from "lucide-react";
import type { LucideIconName } from "@/types/template.types";

/*
  ─────────────────────────────────────────────────────────────
  Icon — renders a Lucide icon by its config string name.
  Lets /src/config/*.ts reference icons without importing them.
  Falls back to `Circle` if a name is misspelled in config.
  ─────────────────────────────────────────────────────────────
*/

interface IconProps extends LucideProps {
  name: LucideIconName;
}

export const Icon = memo(function Icon({ name, ...props }: IconProps) {
  const Cmp = (Icons[name] ?? Icons.Circle) as React.ComponentType<LucideProps>;
  return <Cmp {...props} />;
});
