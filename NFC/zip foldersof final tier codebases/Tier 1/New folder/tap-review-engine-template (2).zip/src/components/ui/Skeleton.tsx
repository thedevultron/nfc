import { cn } from "@/utils/cn";

/*
  ─────────────────────────────────────────────────────────────
  Skeleton — shimmer placeholder. The sweep animation lives in
  /src/index.css (.shimmer). Prevents any blank flash on load.
  ─────────────────────────────────────────────────────────────
*/

export function Skeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "shimmer relative overflow-hidden rounded-lg bg-foreground/[0.05]",
        className,
      )}
      {...props}
    />
  );
}
