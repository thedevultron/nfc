import { motion } from "framer-motion";
import { CheckCircle2, XCircle } from "lucide-react";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/*
  ─────────────────────────────────────────────────────────────
  StatusFeedback — spring-in success/error icon with a circular
  progress-ring wipe (not a plain toast). Physics from motion.config.
  ─────────────────────────────────────────────────────────────
*/

interface StatusFeedbackProps {
  status: "success" | "error";
  title: string;
  message?: string;
}

export function StatusFeedback({ status, title, message }: StatusFeedbackProps) {
  const reduced = useReducedMotion();
  const isSuccess = status === "success";
  const IconCmp = isSuccess ? CheckCircle2 : XCircle;
  const ringColor = isSuccess
    ? "hsl(var(--secondary-accent))"
    : "hsl(0 72% 55%)";

  const spring = reduced
    ? { duration: motionConfig.reducedFade.duration, ease: "easeOut" as const }
    : motionConfig.springs.elastic;

  return (
    <div className="flex flex-col items-center py-4 text-center">
      <div className="relative h-20 w-20">
        {/* Progress-ring wipe */}
        <svg className="absolute inset-0 h-20 w-20 -rotate-90" viewBox="0 0 80 80">
          <circle
            cx="40"
            cy="40"
            r="36"
            fill="none"
            stroke={ringColor}
            strokeOpacity={0.18}
            strokeWidth={4}
          />
          <motion.circle
            cx="40"
            cy="40"
            r="36"
            fill="none"
            stroke={ringColor}
            strokeWidth={4}
            strokeLinecap="round"
            pathLength={1}
            initial={{ pathLength: reduced ? 1 : 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: reduced ? 0 : 0.45, ease: "easeOut" }}
          />
        </svg>
        <motion.div
          className="absolute inset-0 grid place-items-center"
          initial={{ scale: reduced ? 1 : 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ ...spring, delay: reduced ? 0 : 0.12 }}
        >
          <IconCmp
            className="h-9 w-9"
            style={{ color: ringColor }}
            strokeWidth={2.2}
          />
        </motion.div>
      </div>

      <motion.h3
        className="mt-4 text-lg font-semibold tracking-[-0.02em]"
        initial={{ opacity: 0, y: reduced ? 0 : 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: reduced ? 0 : 0.2 }}
      >
        {title}
      </motion.h3>
      {message && (
        <motion.p
          className="mt-1.5 max-w-xs text-sm text-muted"
          initial={{ opacity: 0, y: reduced ? 0 : 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: reduced ? 0 : 0.26 }}
        >
          {message}
        </motion.p>
      )}
    </div>
  );
}
