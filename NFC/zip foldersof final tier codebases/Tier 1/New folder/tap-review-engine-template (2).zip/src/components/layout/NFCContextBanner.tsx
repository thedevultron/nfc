import { motion } from "framer-motion";
import { Nfc } from "lucide-react";
import { Icon } from "@/components/ui/Icon";
import { Badge } from "@/components/ui/Badge";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/*
  ─────────────────────────────────────────────────────────────
  NFCContextBanner — header with brand mark + hospitality greeting.
  Copy comes from client.config; the brand icon from touchpoints.config.
  The Utensils "menu opening" rotate-settle detail lives here.
  ─────────────────────────────────────────────────────────────
*/

export function NFCContextBanner() {
  const reduced = useReducedMotion();

  const iconSettle = reduced
    ? { rotate: 0 }
    : {
        rotate: [-6, 0],
        transition: motionConfig.springs.elastic,
      };

  return (
    <header className="pt-2">
      <motion.div
        className="flex items-center gap-1.5"
        initial={{ opacity: 0, y: reduced ? 0 : -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={
          reduced
            ? { duration: motionConfig.reducedFade.duration }
            : motionConfig.springs.smooth
        }
      >
        <Badge tone="primary">
          <Nfc className="h-3 w-3" />
          Tapped
        </Badge>
        <span className="text-xs text-muted">{clientConfig.subtitle}</span>
      </motion.div>

      <div className="mt-4 flex items-center gap-3.5">
        <motion.div
          className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-primary/12 text-primary ring-1 ring-primary/25 shadow-[0_0_30px_-8px_hsl(var(--accent-glow))]"
          initial={{ scale: reduced ? 1 : 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1, ...iconSettle }}
          transition={
            reduced
              ? { duration: motionConfig.reducedFade.duration }
              : { ...motionConfig.springs.smooth, delay: 0.05 }
          }
        >
          <Icon
            name={touchpointsConfig.icons.primary}
            className="h-7 w-7"
            strokeWidth={1.9}
          />
        </motion.div>

        <div className="min-w-0">
          <motion.h1
            className="truncate text-[1.6rem] font-bold leading-tight tracking-[-0.03em]"
            initial={{ opacity: 0, y: reduced ? 0 : 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={
              reduced
                ? { duration: motionConfig.reducedFade.duration }
                : { ...motionConfig.springs.smooth, delay: 0.08 }
            }
          >
            {clientConfig.businessName}
          </motion.h1>
          <motion.p
            className="mt-0.5 text-sm text-muted"
            initial={{ opacity: 0, y: reduced ? 0 : 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={
              reduced
                ? { duration: motionConfig.reducedFade.duration }
                : { ...motionConfig.springs.smooth, delay: 0.13 }
            }
          >
            {clientConfig.greeting}
          </motion.p>
        </div>
      </div>
    </header>
  );
}
