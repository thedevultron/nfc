import { motion } from "framer-motion";
import { cn } from "@/utils/cn";

/*
  ─────────────────────────────────────────────────────────────
  AppShell — root layout. Centered mobile column, ambient accent
  glow backdrop, and status-bar / safe-area aware padding.
  ─────────────────────────────────────────────────────────────
*/

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative min-h-full w-full overflow-x-hidden bg-background">
      {/* Ambient accent glow — the premium "tell". */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[46vh]"
        style={{
          background:
            "radial-gradient(120% 80% at 50% -10%, hsl(var(--primary)/0.16), transparent 60%)",
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 h-[36vh]"
        style={{
          background:
            "radial-gradient(120% 80% at 50% 110%, hsl(var(--secondary-accent)/0.10), transparent 60%)",
        }}
      />

      <motion.main
        className={cn(
          "relative z-10 mx-auto flex min-h-full w-full max-w-md flex-col px-5",
        )}
        style={{
          paddingTop: "calc(1.25rem + env(safe-area-inset-top))",
          paddingBottom: "calc(1.25rem + env(safe-area-inset-bottom))",
        }}
      >
        {children}
      </motion.main>
    </div>
  );
}
