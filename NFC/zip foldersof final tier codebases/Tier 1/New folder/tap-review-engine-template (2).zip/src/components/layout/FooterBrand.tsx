import { motion } from "framer-motion";
import { Zap } from "lucide-react";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/*
  ─────────────────────────────────────────────────────────────
  FooterBrand — subtle "powered by" mark. Icon-only branding.
  ─────────────────────────────────────────────────────────────
*/

export function FooterBrand() {
  const reduced = useReducedMotion();
  return (
    <motion.footer
      className="mt-auto flex items-center justify-center gap-1.5 pt-8 text-xs text-muted/70"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={
        reduced
          ? { duration: motionConfig.reducedFade.duration }
          : { delay: 0.4, ...motionConfig.springs.smooth }
      }
    >
      <Zap className="h-3 w-3 text-primary" fill="currentColor" />
      <span className="tracking-[-0.01em]">
        Powered by <span className="font-medium text-foreground/80">TAP Engine</span>
      </span>
    </motion.footer>
  );
}
