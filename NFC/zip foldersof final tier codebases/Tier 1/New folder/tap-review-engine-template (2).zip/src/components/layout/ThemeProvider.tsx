import { useEffect } from "react";
import { themeConfig } from "@/config/theme.config";

/*
  ─────────────────────────────────────────────────────────────
  ThemeProvider — injects CSS variables from theme.config.ts onto
  :root at runtime. This is what makes the app fully re-skinnable
  by editing ONLY /src/config/theme.config.ts.
  Do not hardcode colors in components — add tokens here instead.
  ─────────────────────────────────────────────────────────────
*/

/** Extract the "H S% L%" triplet from any hsl(...) string, dropping alpha. */
function hslTriplet(color: string): string {
  const inner = color.replace(/hsla?\(/i, "").replace(/\)/g, "");
  // Drop an optional "/ alpha" segment.
  const withoutAlpha = inner.split("/")[0];
  return withoutAlpha.replace(/,/g, " ").trim();
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    const root = document.documentElement;
    const set = (k: string, v: string) => root.style.setProperty(k, v);

    set("--background", hslTriplet(themeConfig.backgroundColor));
    set("--surface", hslTriplet(themeConfig.surfaceColor));
    set("--foreground", hslTriplet(themeConfig.foregroundColor));
    set("--muted", hslTriplet(themeConfig.mutedColor));
    set("--primary", hslTriplet(themeConfig.primaryColor));
    set("--secondary-accent", hslTriplet(themeConfig.secondaryAccent));
    set("--accent-glow", hslTriplet(themeConfig.accentGlow));
    set("--radius", themeConfig.borderRadius);
    set("--font-family", themeConfig.fontFamily);

    root.classList.toggle("dark", themeConfig.defaultMode === "dark");
    root.style.colorScheme = themeConfig.defaultMode;
  }, []);

  return <>{children}</>;
}
