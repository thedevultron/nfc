import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/Skeleton";
import { Icon } from "@/components/ui/Icon";
import { touchpointsConfig } from "@/config/touchpoints.config";

/*
  ─────────────────────────────────────────────────────────────
  LoadingScreen — shimmer skeleton shown for the first 200-400ms
  while config resolves. Prevents any blank white/black flash.
  Loading copy comes from touchpoints.config (copy.loading).
  ─────────────────────────────────────────────────────────────
*/

export function LoadingScreen() {
  return (
    <motion.div
      className="flex flex-col gap-5 pt-2"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    >
      <div className="flex items-center gap-3.5">
        <motion.div
          className="grid h-14 w-14 place-items-center rounded-2xl bg-primary/10 text-primary/70"
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.4, repeat: Infinity }}
        >
          <Icon name={touchpointsConfig.icons.primary} className="h-7 w-7" />
        </motion.div>
        <div className="flex-1 space-y-2">
          <Skeleton className="h-6 w-2/3" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      </div>

      <Skeleton className="h-11 w-full rounded-full" />

      <div className="space-y-4 rounded-2xl border border-white/10 bg-foreground/[0.02] p-5">
        <Skeleton className="mx-auto h-4 w-1/2" />
        <div className="flex justify-center gap-2.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-11 w-11 rounded-lg" />
          ))}
        </div>
        <Skeleton className="h-14 w-full" />
      </div>

      <p className="text-center text-sm text-muted">
        {touchpointsConfig.copy.loading}
      </p>
    </motion.div>
  );
}
