import { useMemo } from "react";
import { motion } from "framer-motion";
import { Sparkle } from "lucide-react";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/*
  ─────────────────────────────────────────────────────────────
  ConfettiBurst — 7 physics-based Sparkle particles for a moment
  of delight. Disabled under prefers-reduced-motion.
  ─────────────────────────────────────────────────────────────
*/

const PARTICLES = 7;

export function ConfettiBurst({ trigger }: { trigger: number }) {
  const reduced = useReducedMotion();

  const particles = useMemo(
    () =>
      Array.from({ length: PARTICLES }).map((_, i) => {
        const angle = (Math.PI * (i + 0.5)) / PARTICLES; // upward fan
        const distance = 70 + Math.random() * 60;
        return {
          id: i,
          x: Math.cos(angle) * distance * (Math.random() > 0.5 ? 1 : -1),
          y: -(40 + Math.random() * 90),
          rotate: (Math.random() - 0.5) * 240,
          scale: 0.6 + Math.random() * 0.7,
          delay: Math.random() * 0.05,
        };
      }),
    // Re-randomize on each trigger.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [trigger],
  );

  if (reduced || trigger === 0) return null;

  return (
    <div className="pointer-events-none absolute left-1/2 top-1/2 z-20 h-0 w-0">
      {particles.map((p) => (
        <motion.span
          key={`${trigger}-${p.id}`}
          className="absolute text-primary"
          initial={{ x: 0, y: 0, opacity: 1, scale: 0, rotate: 0 }}
          animate={{
            x: p.x,
            y: [0, p.y, p.y + 60], // rise then fall
            opacity: [1, 1, 0],
            scale: [0, p.scale, p.scale * 0.85],
            rotate: p.rotate,
          }}
          transition={{
            duration: 0.9,
            delay: p.delay,
            ease: "easeOut",
            times: [0, 0.5, 1],
          }}
        >
          <Sparkle className="h-4 w-4" fill="currentColor" />
        </motion.span>
      ))}
    </div>
  );
}
