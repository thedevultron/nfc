import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Send, ShieldCheck } from "lucide-react";
import { Drawer } from "@/components/ui/Drawer";
import { Button } from "@/components/ui/Button";
import { Textarea } from "@/components/ui/Input";
import { StatusFeedback } from "@/components/ui/StatusFeedback";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { clientConfig } from "@/config/client.config";
import { motionConfig } from "@/config/motion.config";
import { sendFeedback } from "@/services/api.service";
import { haptic } from "@/services/haptics.service";

/*
  ─────────────────────────────────────────────────────────────
  FeedbackDrawer — private low-rating feedback path.
  Optimistic: shows the spring checkmark immediately, THEN POSTs
  to n8nFeedbackWebhook via api.service. Copy from touchpoints.config.
  ─────────────────────────────────────────────────────────────
*/

interface FeedbackDrawerProps {
  open: boolean;
  rating: number;
  onClose: () => void;
  onTrack: (event: string, meta?: Record<string, unknown>) => void;
}

export function FeedbackDrawer({
  open,
  rating,
  onClose,
  onTrack,
}: FeedbackDrawerProps) {
  const { copy } = touchpointsConfig;
  const [text, setText] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);

  const handleSubmit = async () => {
    if (sending) return;
    setSending(true);
    // Optimistic: flip to success immediately.
    setSubmitted(true);
    haptic("success");
    onTrack("feedback_submitted", { rating });

    await sendFeedback({
      rating,
      feedbackText: text.trim(),
      touchpointId: clientConfig.touchpointId,
      timestamp: new Date().toISOString(),
    });

    // Auto-close shortly after the success animation.
    window.setTimeout(() => {
      onClose();
      // Reset for a potential re-open.
      window.setTimeout(() => {
        setSubmitted(false);
        setSending(false);
        setText("");
      }, 350);
    }, 1600);
  };

  return (
    <Drawer
      open={open}
      onClose={submitted ? () => {} : onClose}
      title={submitted ? undefined : copy.reviewLowTitle}
    >
      <AnimatePresence mode="wait">
        {submitted ? (
          <motion.div
            key="success"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
          >
            <StatusFeedback
              status="success"
              title={copy.feedbackSuccess}
              message="We take every note personally."
            />
          </motion.div>
        ) : (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={motionConfig.springs.smooth}
          >
            <div className="mb-3 flex items-start gap-2 rounded-lg bg-secondary-accent/10 px-3 py-2.5 text-sm text-secondary-accent">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
              <span className="text-[0.85rem] leading-snug">
                {copy.reviewLowSubtitle}
              </span>
            </div>

            <Textarea
              autoFocus
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={copy.reviewPlaceholder}
            />

            <Button
              variant="secondary"
              size="lg"
              fullWidth
              glow
              haptic="success"
              className="mt-4"
              disabled={sending}
              onClick={handleSubmit}
            >
              <Send className="h-4 w-4" />
              {copy.reviewSubmit}
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </Drawer>
  );
}
