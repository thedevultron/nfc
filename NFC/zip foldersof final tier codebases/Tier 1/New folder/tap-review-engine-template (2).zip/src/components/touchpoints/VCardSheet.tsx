import { motion } from "framer-motion";
import { UserPlus, MessageCircle, Phone } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { haptic } from "@/services/haptics.service";

/*
  ─────────────────────────────────────────────────────────────
  VCardSheet (MODULE C) — Dynamic contact / vCard.
  "Save Contact" builds a .vcf blob client-side. WhatsApp + Call
  secondary row staggers in. Fields from touchpoints.config (vcard).
  ─────────────────────────────────────────────────────────────
*/

interface VCardSheetProps {
  onTrack: (event: string, meta?: Record<string, unknown>) => void;
}

function buildVCard(): string {
  const { vcard } = touchpointsConfig;
  const lines = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `FN:${vcard.name}`,
    `N:${vcard.name};;;;`,
    `ORG:${vcard.org}`,
    `TEL;TYPE=CELL:${vcard.phone}`,
    vcard.email ? `EMAIL:${vcard.email}` : "",
    vcard.website ? `URL:${vcard.website}` : "",
    "END:VCARD",
  ].filter(Boolean);
  return lines.join("\r\n");
}

export function VCardSheet({ onTrack }: VCardSheetProps) {
  const { vcard, copy } = touchpointsConfig;
  const reduced = useReducedMotion();

  const handleSave = () => {
    haptic("success");
    onTrack("vcard_download");
    const blob = new Blob([buildVCard()], { type: "text/vcard;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${vcard.name.replace(/\s+/g, "_")}.vcf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const container = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: motionConfig.stagger.children,
        delayChildren: motionConfig.stagger.delayChildren,
      },
    },
  };
  const item = {
    hidden: { opacity: 0, y: reduced ? 0 : 12 },
    show: {
      opacity: 1,
      y: 0,
      transition: reduced
        ? { duration: motionConfig.reducedFade.duration }
        : motionConfig.springs.snappy,
    },
  };

  return (
    <Card>
      <div className="mb-4 text-center">
        <div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-primary/12 text-primary ring-1 ring-primary/20">
          <UserPlus className="h-7 w-7" strokeWidth={1.9} />
        </div>
        <h2 className="text-lg font-semibold tracking-[-0.02em]">
          {copy.contactTitle}
        </h2>
        <p className="mt-0.5 text-sm text-muted">{copy.contactSubtitle}</p>
      </div>

      <Button
        variant="primary"
        size="lg"
        fullWidth
        glow
        haptic="success"
        onClick={handleSave}
      >
        <UserPlus className="h-4 w-4" />
        Save Contact
      </Button>

      <motion.div
        className="mt-3 grid grid-cols-2 gap-2.5"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {vcard.whatsapp && (
          <motion.div variants={item}>
            <Button
              variant="glass"
              size="lg"
              fullWidth
              className="shadow-[0_0_30px_-10px_hsl(var(--secondary-accent)/0.7)]"
              onClick={() => {
                onTrack("vcard_whatsapp");
                window.open(
                  `https://wa.me/${vcard.whatsapp}`,
                  "_blank",
                  "noopener,noreferrer",
                );
              }}
            >
              <MessageCircle className="h-4 w-4 text-secondary-accent" />
              WhatsApp
            </Button>
          </motion.div>
        )}
        <motion.div variants={item}>
          <Button
            variant="glass"
            size="lg"
            fullWidth
            className="shadow-[0_0_30px_-10px_hsl(var(--accent-glow))]"
            onClick={() => {
              onTrack("vcard_call");
              window.location.href = `tel:${vcard.phone}`;
            }}
          >
            <Phone className="h-4 w-4 text-primary" />
            Call
          </Button>
        </motion.div>
      </motion.div>
    </Card>
  );
}
