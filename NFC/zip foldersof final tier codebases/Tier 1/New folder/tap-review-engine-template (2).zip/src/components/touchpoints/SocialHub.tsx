import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { Icon } from "@/components/ui/Icon";
import { cn } from "@/utils/cn";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { haptic } from "@/services/haptics.service";
import type { HubItem } from "@/types/template.types";

/*
  ─────────────────────────────────────────────────────────────
  SocialHub (MODULE D) — multi-link hub. Rows stagger in.
  Each row: tinted icon square, label/sublabel, nudging chevron.
  Items (incl. internal `action`) come from touchpoints.config.hub.
  ─────────────────────────────────────────────────────────────
*/

interface SocialHubProps {
  onAction: (action: NonNullable<HubItem["action"]>) => void;
  onTrack: (event: string, meta?: Record<string, unknown>) => void;
}

export function SocialHub({ onAction, onTrack }: SocialHubProps) {
  const { hub, copy } = touchpointsConfig;
  const reduced = useReducedMotion();

  const handleItem = (item: HubItem) => {
    haptic("tap");
    onTrack("hub_item_click", { label: item.label });
    if (item.action) {
      onAction(item.action);
    } else if (item.external) {
      window.open(item.url, "_blank", "noopener,noreferrer");
    } else {
      window.location.href = item.url;
    }
  };

  const container = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: motionConfig.stagger.children,
        delayChildren: motionConfig.stagger.delayChildren,
      },
    },
  };
  const row = {
    hidden: { opacity: 0, y: reduced ? 0 : 14 },
    show: {
      opacity: 1,
      y: 0,
      transition: reduced
        ? { duration: motionConfig.reducedFade.duration }
        : motionConfig.springs.snappy,
    },
  };

  return (
    <div>
      <h2 className="mb-3 px-1 text-sm font-medium text-muted">
        {copy.hubTitle}
      </h2>
      <motion.ul
        className="flex flex-col gap-2.5"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {hub.map((item) => {
          const isSecondary = item.tint === "secondary";
          return (
            <motion.li key={item.label} variants={row}>
              <motion.button
                type="button"
                onClick={() => handleItem(item)}
                whileTap={reduced ? { opacity: 0.85 } : { scale: 0.98 }}
                whileHover={reduced ? undefined : { scale: 1.01 }}
                transition={motionConfig.springs.snappy}
                className="group flex w-full items-center gap-3.5 rounded-xl border border-white/10 bg-foreground/[0.03] p-3 text-left backdrop-blur-xl transition-colors hover:bg-foreground/[0.06]"
              >
                <span
                  className={cn(
                    "grid h-11 w-11 shrink-0 place-items-center rounded-xl ring-1",
                    isSecondary
                      ? "bg-secondary-accent/12 text-secondary-accent ring-secondary-accent/20"
                      : "bg-primary/12 text-primary ring-primary/20",
                  )}
                >
                  <Icon name={item.icon} className="h-5 w-5" strokeWidth={1.9} />
                </span>

                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium tracking-[-0.01em]">
                    {item.label}
                  </span>
                  {item.sublabel && (
                    <span className="block truncate text-xs text-muted">
                      {item.sublabel}
                    </span>
                  )}
                </span>

                <motion.span
                  className="text-muted"
                  variants={{
                    hidden: {},
                    show: {},
                  }}
                  whileHover={reduced ? undefined : { x: 2 }}
                  animate={reduced ? undefined : { x: 0 }}
                >
                  <ChevronRight className="h-5 w-5 transition-transform duration-200 group-hover:translate-x-0.5" />
                </motion.span>
              </motion.button>
            </motion.li>
          );
        })}
      </motion.ul>
    </div>
  );
}
