import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ExternalLink } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { StarRating } from "./StarRating";
import { ConfettiBurst } from "./ConfettiBurst";
import { FeedbackDrawer } from "./FeedbackDrawer";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { clientConfig } from "@/config/client.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { haptic } from "@/services/haptics.service";

/*
  ─────────────────────────────────────────────────────────────
  ReviewRouter (MODULE A) — Smart Review Router.
  rating >= 4 → staggered Google Maps CTA + confetti burst.
  rating <  4 → opens the private FeedbackDrawer.
  Threshold copy/urls come from config, physics from motion.config.
  ─────────────────────────────────────────────────────────────
*/

const HIGH_THRESHOLD = 4;

interface ReviewRouterProps {
  onTrack: (event: string, meta?: Record<string, unknown>) => void;
}

export function ReviewRouter({ onTrack }: ReviewRouterProps) {
  const { copy } = touchpointsConfig;
  const reduced = useReducedMotion();
  const [rating, setRating] = useState(0);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [confettiKey, setConfettiKey] = useState(0);

  const isHigh = rating >= HIGH_THRESHOLD;

  useEffect(() => {
    if (rating === 0) return;
    onTrack("rating_selected", { rating });
    if (rating < HIGH_THRESHOLD) {
      setDrawerOpen(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rating]);

  const handleGoogle = () => {
    setConfettiKey((k) => k + 1);
    haptic("success");
    onTrack("google_review_click", { rating });
    window.open(clientConfig.googleReviewUrl, "_blank", "noopener,noreferrer");
  };

  const revealSpring = reduced
    ? { duration: motionConfig.reducedFade.duration, ease: "easeOut" as const }
    : motionConfig.springs.smooth;

  return (
    <>
      <Card className="relative">
        <ConfettiBurst trigger={confettiKey} />

        <p className="text-center text-sm font-medium text-muted">
          {copy.reviewPrompt}
        </p>

        <div className="my-5">
          <StarRating value={rating} onChange={setRating} />
        </div>

        <AnimatePresence mode="wait">
          {isHigh && (
            <motion.div
              key="high"
              initial={{ opacity: 0, y: reduced ? 0 : 14, height: 0 }}
              animate={{ opacity: 1, y: 0, height: "auto" }}
              exit={{ opacity: 0, y: reduced ? 0 : 10, height: 0 }}
              transition={revealSpring}
              className="overflow-hidden"
            >
              <motion.div
                variants={{
                  hidden: {},
                  show: {
                    transition: {
                      staggerChildren: motionConfig.stagger.children,
                      delayChildren: motionConfig.stagger.delayChildren,
                    },
                  },
                }}
                initial="hidden"
                animate="show"
                className="flex flex-col items-center gap-3"
              >
                <motion.p
                  variants={itemVariants(reduced)}
                  className="text-center text-base font-semibold tracking-[-0.02em]"
                >
                  {copy.reviewHighTitle}
                </motion.p>
                <motion.div variants={itemVariants(reduced)} className="w-full">
                  <Button
                    variant="primary"
                    size="lg"
                    fullWidth
                    glow
                    haptic="success"
                    onClick={handleGoogle}
                  >
                    {copy.reviewHighCta}
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      <FeedbackDrawer
        open={drawerOpen}
        rating={rating}
        onClose={() => {
          setDrawerOpen(false);
          setRating(0);
        }}
        onTrack={onTrack}
      />
    </>
  );
}

function itemVariants(reduced: boolean) {
  return {
    hidden: { opacity: 0, y: reduced ? 0 : 12 },
    show: {
      opacity: 1,
      y: 0,
      transition: reduced
        ? { duration: motionConfig.reducedFade.duration }
        : motionConfig.springs.snappy,
    },
  };
}
