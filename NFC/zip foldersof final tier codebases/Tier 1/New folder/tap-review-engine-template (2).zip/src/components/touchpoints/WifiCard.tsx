import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import QRCode from "qrcode";
import { Wifi, Eye, EyeOff, Copy, Check, QrCode } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Dialog } from "@/components/ui/Dialog";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useSpringPress } from "@/hooks/useSpringPress";
import { haptic } from "@/services/haptics.service";

/*
  ─────────────────────────────────────────────────────────────
  WifiCard (MODULE B) — Instant WiFi touchpoint.
  Masked password + eye toggle, copy-to-clipboard with inline
  checkmark morph (no toast spam), and a WiFi QR payload generator.
  Credentials come from /src/config/touchpoints.config.ts (wifi).
  ─────────────────────────────────────────────────────────────
*/

interface WifiCardProps {
  onTrack: (event: string, meta?: Record<string, unknown>) => void;
}

export function WifiCard({ onTrack }: WifiCardProps) {
  const { wifi, copy } = touchpointsConfig;
  const reduced = useReducedMotion();
  const revealPress = useSpringPress({ haptic: "selection", enableHover: false });
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState("");

  const wifiPayload = `WIFI:T:${wifi.encryption};S:${wifi.ssid};P:${wifi.password};;`;

  useEffect(() => {
    if (!qrOpen || qrDataUrl) return;
    QRCode.toDataURL(wifiPayload, {
      margin: 1,
      width: 320,
      color: { dark: "#0b1220", light: "#ffffff" },
    })
      .then(setQrDataUrl)
      .catch(() => setQrDataUrl(""));
  }, [qrOpen, qrDataUrl, wifiPayload]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(wifi.password);
      haptic("success");
      setCopied(true);
      onTrack("wifi_copy_password");
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      haptic("error");
    }
  };

  const spring = reduced
    ? { duration: motionConfig.reducedFade.duration }
    : motionConfig.springs.snappy;

  return (
    <>
      <Card>
        <div className="mb-4 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/12 text-primary ring-1 ring-primary/20">
            <Wifi className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-semibold tracking-[-0.02em]">
              {copy.wifiTitle}
            </h2>
            <p className="text-xs text-muted">{copy.wifiSubtitle}</p>
          </div>
        </div>

        {/* SSID */}
        <div className="rounded-lg border border-white/10 bg-foreground/[0.03] px-4 py-3">
          <p className="text-[0.7rem] uppercase tracking-wide text-muted">
            Network
          </p>
          <p className="mt-0.5 font-medium">{wifi.ssid}</p>
        </div>

        {/* Password */}
        <div className="mt-3 flex items-center gap-2 rounded-lg border border-white/10 bg-foreground/[0.03] px-4 py-3">
          <div className="min-w-0 flex-1">
            <p className="text-[0.7rem] uppercase tracking-wide text-muted">
              Password
            </p>
            <p className="mt-0.5 truncate font-mono font-medium tracking-wide">
              {revealed ? wifi.password : "•".repeat(wifi.password.length)}
            </p>
          </div>
          <motion.button
            onClick={() => setRevealed((v) => !v)}
            whileTap={revealPress.whileTap}
            onTapStart={revealPress.onTapStart}
            transition={revealPress.transition}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-foreground/[0.06] text-muted hover:text-foreground"
            aria-label={revealed ? "Hide password" : "Reveal password"}
          >
            {revealed ? (
              <EyeOff className="h-4 w-4" />
            ) : (
              <Eye className="h-4 w-4" />
            )}
          </motion.button>
        </div>

        <Button
          variant="primary"
          size="lg"
          fullWidth
          glow
          haptic="success"
          className="mt-4"
          onClick={handleCopy}
        >
          <AnimatePresence mode="wait" initial={false}>
            {copied ? (
              <motion.span
                key="copied"
                className="inline-flex items-center gap-2"
                initial={{ opacity: 0, scale: reduced ? 1 : 0.7 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: reduced ? 1 : 0.7 }}
                transition={spring}
              >
                <Check className="h-4 w-4" />
                Copied!
              </motion.span>
            ) : (
              <motion.span
                key="copy"
                className="inline-flex items-center gap-2"
                initial={{ opacity: 0, scale: reduced ? 1 : 0.7 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: reduced ? 1 : 0.7 }}
                transition={spring}
              >
                <Copy className="h-4 w-4" />
                Copy Password
              </motion.span>
            )}
          </AnimatePresence>
        </Button>

        <Button
          variant="glass"
          size="md"
          fullWidth
          className="mt-2.5"
          onClick={() => {
            setQrOpen(true);
            onTrack("wifi_qr_open");
          }}
        >
          <QrCode className="h-4 w-4" />
          Show WiFi QR
        </Button>
      </Card>

      <Dialog
        open={qrOpen}
        onClose={() => setQrOpen(false)}
        title="Scan to connect"
      >
        <div className="flex flex-col items-center gap-3 pb-1">
          <div className="rounded-xl bg-white p-3">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="WiFi QR code"
                className="h-52 w-52"
                width={208}
                height={208}
              />
            ) : (
              <div className="h-52 w-52 animate-pulse rounded bg-black/10" />
            )}
          </div>
          <p className="text-center text-sm text-muted">
            Point your camera here to join{" "}
            <span className="font-medium text-foreground">{wifi.ssid}</span>
          </p>
        </div>
      </Dialog>
    </>
  );
}
