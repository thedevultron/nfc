import { useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { haptic } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/*
  ─────────────────────────────────────────────────────────────
  StarRating — 5 stars with an elastic overshoot pop on select and
  a 40ms-per-star "ripple" cascade. Haptic `selection` on each tap.
  Physics from motion.config.springs.elastic.
  ─────────────────────────────────────────────────────────────
*/

interface StarRatingProps {
  value: number;
  onChange: (rating: number) => void;
}

const STARS = [1, 2, 3, 4, 5];
const RIPPLE_STEP = 0.04; // 40ms per adjacent star

export function StarRating({ value, onChange }: StarRatingProps) {
  const reduced = useReducedMotion();
  const [hover, setHover] = useState(0);
  const active = hover || value;

  const handleSelect = (rating: number) => {
    haptic("selection");
    onChange(rating);
  };

  return (
    <div className="flex items-center justify-center gap-2.5">
      {STARS.map((star) => {
        const filled = star <= active;
        // Ripple: distance from the selected star drives the delay.
        const rippleDelay =
          value > 0 ? Math.abs(star - value) * RIPPLE_STEP : 0;

        return (
          <motion.button
            key={star}
            type="button"
            aria-label={`${star} star${star > 1 ? "s" : ""}`}
            onClick={() => handleSelect(star)}
            onHoverStart={() => setHover(star)}
            onHoverEnd={() => setHover(0)}
            whileTap={reduced ? { opacity: 0.8 } : { scale: 0.9 }}
            className="p-1"
          >
            <motion.span
              className="block"
              animate={
                reduced
                  ? {}
                  : filled
                    ? { scale: [1, 1.35, 1] }
                    : { scale: 1 }
              }
              transition={
                reduced
                  ? { duration: motionConfig.reducedFade.duration }
                  : { ...motionConfig.springs.elastic, delay: rippleDelay }
              }
            >
              <Star
                className={cn(
                  "h-11 w-11 transition-colors duration-150",
                  filled
                    ? "fill-primary text-primary drop-shadow-[0_0_12px_hsl(var(--accent-glow))]"
                    : "fill-transparent text-foreground/25",
                )}
                strokeWidth={1.75}
              />
            </motion.span>
          </motion.button>
        );
      })}
    </div>
  );
}
