/*
  ─────────────────────────────────────────────────────────────
  SHARED TYPE CONTRACTS
  These types describe the shape of the config objects and the
  service payloads. Editing config files must stay compatible with
  these contracts. Do not put copy/design values here.
  ─────────────────────────────────────────────────────────────
*/

import type * as Icons from "lucide-react";

/** Any valid Lucide icon name, referenced by string in config files. */
export type LucideIconName = keyof typeof Icons;

/* ───────────── THEME ───────────── */
export type ColorMode = "dark" | "light";

export interface ThemeConfig {
  primaryColor: string;
  secondaryAccent: string;
  accentGlow: string;
  backgroundColor: string;
  surfaceColor: string;
  foregroundColor: string;
  mutedColor: string;
  borderRadius: string;
  fontFamily: string;
  enableGlassmorphism: boolean;
  defaultMode: ColorMode;
}

/* ───────────── MOTION ───────────── */
export interface SpringPreset {
  type: "spring";
  stiffness: number;
  damping: number;
  mass?: number;
}

export interface MotionConfig {
  springs: {
    snappy: SpringPreset;
    smooth: SpringPreset;
    elastic: SpringPreset;
    drawer: SpringPreset;
  };
  stagger: { children: number; delayChildren: number };
  press: { scale: number; brightness: number };
  hover: { scale: number };
  reducedFade: { duration: number };
  haptics: {
    tap: number;
    selection: number;
    success: number[];
    error: number[];
  };
}

export type HapticPattern = keyof MotionConfig["haptics"];

/* ───────────── CLIENT ───────────── */
export type TouchpointMode = "REVIEW" | "WIFI" | "CONTACT" | "HUB";

export interface ClientConfig {
  businessName: string;
  subtitle: string;
  greeting: string;
  activeMode: TouchpointMode;
  secondaryMode: TouchpointMode | null;
  touchpointId: string;
  googleReviewUrl: string;
  n8nWebhookUrl: string;
  n8nFeedbackWebhook: string;
}

/* ───────────── TOUCHPOINTS ───────────── */
export interface HubItem {
  label: string;
  sublabel?: string;
  icon: LucideIconName;
  url: string;
  external: boolean;
  /** Optional internal action instead of navigation. */
  action?: "wifi" | "review" | "contact";
  tint?: "primary" | "secondary";
}

export interface TouchpointsConfig {
  vertical: string;
  icons: {
    primary: LucideIconName;
    secondary: LucideIconName;
  };
  hub: HubItem[];
  wifi: {
    ssid: string;
    password: string;
    encryption: "WPA" | "WEP" | "nopass";
  };
  vcard: {
    name: string;
    phone: string;
    org: string;
    email?: string;
    whatsapp?: string;
    website?: string;
  };
  copy: {
    reviewPrompt: string;
    reviewHighTitle: string;
    reviewHighCta: string;
    reviewLowTitle: string;
    reviewLowSubtitle: string;
    reviewPlaceholder: string;
    reviewSubmit: string;
    feedbackSuccess: string;
    wifiTitle: string;
    wifiSubtitle: string;
    contactTitle: string;
    contactSubtitle: string;
    hubTitle: string;
    loading: string;
  };
}

/* ───────────── SERVICE PAYLOADS ───────────── */
export interface AnalyticsPayload {
  event: string;
  touchpointId: string;
  mode: TouchpointMode;
  meta?: Record<string, unknown>;
  timestamp: string;
}

export interface FeedbackPayload {
  rating: number;
  feedbackText: string;
  touchpointId: string;
  timestamp: string;
}
