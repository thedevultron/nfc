/**
 * Shared session state for panels, drawers, and rating.
 * Values are behavioural — visual tokens still live in /src/config.
 */
import { createContext, useContext } from "react";
import type { HubItem, PanelId } from "@/types/template.types";

export interface TapContextValue {
  panel: PanelId;
  setPanel: (panel: PanelId) => void;
  wifiOpen: boolean;
  setWifiOpen: (open: boolean) => void;
  contactOpen: boolean;
  setContactOpen: (open: boolean) => void;
  menuOpen: boolean;
  setMenuOpen: (open: boolean) => void;
  feedbackOpen: boolean;
  setFeedbackOpen: (open: boolean) => void;
  rating: number;
  setRating: (value: number) => void;
  handleHubItem: (item: HubItem) => void;
}

export const TapContext = createContext<TapContextValue | null>(null);

export function useTapContext(): TapContextValue {
  const value = useContext(TapContext);
  if (!value) {
    throw new Error("useTapContext must be used within TapProvider");
  }
  return value;
}
