/**
 * Reusable press-down scale + brightness interaction.
 * Every tappable surface should spread these props onto a motion element.
 *
 * Edit /src/config/motion.config.ts to change press/hover feel —
 * do not modify this file.
 */
import { useCallback, useMemo } from "react";
import { motionConfig, reducedMotionPreset } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import type { HapticName } from "@/types/template.types";

interface SpringPressOptions {
  haptic?: HapticName;
  hover?: boolean;
}

export function useSpringPress(options: SpringPressOptions = {}) {
  const { haptic = "tap", hover = true } = options;
  const reduced = useReducedMotion();

  const onTapStart = useCallback(() => {
    haptics.play(haptic);
  }, [haptic]);

  return useMemo(
    () => ({
      whileTap: reduced
        ? { opacity: 0.86 }
        : {
            scale: motionConfig.press.scale,
            filter: `brightness(${motionConfig.press.brightness})`,
          },
      whileHover:
        reduced || !hover
          ? undefined
          : {
              scale: motionConfig.hover.scale,
            },
      transition: reduced ? reducedMotionPreset : motionConfig.springs.snappy,
      onTapStart,
    }),
    [reduced, hover, onTapStart],
  );
}
