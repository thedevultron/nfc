/**
 * Respects prefers-reduced-motion. When true, swap springs for a 150ms fade.
 *
 * Edit /src/config/motion.config.ts to change the reduced-motion duration —
 * do not modify this file.
 */
import { useEffect, useState } from "react";
import { motionConfig, reducedMotionPreset } from "@/config/motion.config";
import type { SpringName } from "@/types/template.types";

const QUERY = "(prefers-reduced-motion: reduce)";

export function useReducedMotion(): boolean {
  const [reduced, setReduced] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia(QUERY).matches;
  });

  useEffect(() => {
    const media = window.matchMedia(QUERY);
    const onChange = () => setReduced(media.matches);
    onChange();
    media.addEventListener("change", onChange);
    return () => media.removeEventListener("change", onChange);
  }, []);

  return reduced;
}

/** Resolve a spring token or a short ease-out fade. */
export function useMotionTransition(preset: SpringName) {
  const reduced = useReducedMotion();
  if (reduced) return reducedMotionPreset;
  return motionConfig.springs[preset];
}

export function usePageVariants() {
  const reduced = useReducedMotion();
  const y = reduced ? 0 : motionConfig.pageSlideY;
  const transition = reduced ? reducedMotionPreset : motionConfig.springs.smooth;

  return {
    initial: { opacity: 0, y },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: reduced ? 0 : -y },
    transition,
  };
}
