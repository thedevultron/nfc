/**
 * Fires on mount and on every CTA tap. Debounced, non-blocking.
 *
 * Edit /src/config/client.config.ts to change the analytics webhook —
 * do not modify this file.
 */
import { useCallback, useEffect, useRef } from "react";
import { clientConfig } from "@/config/client.config";
import { api } from "@/services/api.service";
import type { AnalyticsEvent } from "@/types/template.types";

const DEBOUNCE_MS = 240;

export function useTapAnalytics(options: { fireMount?: boolean } = {}) {
  const lastStamp = useRef<Record<string, number>>({});
  const { fireMount = false } = options;

  const track = useCallback(
    (type: AnalyticsEvent["type"], meta?: AnalyticsEvent["meta"]) => {
      const key = `${type}:${JSON.stringify(meta ?? {})}`;
      const now = Date.now();
      const previous = lastStamp.current[key] ?? 0;
      if (now - previous < DEBOUNCE_MS) return;
      lastStamp.current[key] = now;

      api.track({
        type,
        touchpointId: clientConfig.touchpointId,
        timestamp: new Date().toISOString(),
        meta: {
          mode: clientConfig.activeMode,
          business: clientConfig.businessName,
          ...meta,
        },
      });
    },
    [],
  );

  useEffect(() => {
    if (fireMount) track("mount");
  }, [track, fireMount]);

  return { track };
}
