/**
 * Root shell — AnimatePresence mode transitions, suspense-free first paint.
 * Edit /src/config/client.config.ts to change landing mode —
 * do not modify this file.
 * Edit /src/config/motion.config.ts to change page slide / skeleton timing —
 * do not modify this file.
 */
import { AnimatePresence, motion, type PanInfo } from "framer-motion";
import { useEffect, useState } from "react";
import { clientConfig } from "@/config/client.config";
import { motionConfig } from "@/config/motion.config";
import { applyTheme } from "@/config/theme.config";
import { usePageVariants, useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapContext } from "@/hooks/useTapContext";
import { AppShell } from "@/components/layout/AppShell";
import { LoadingScreen } from "@/components/layout/LoadingScreen";
import { OverlaySheets } from "@/components/layout/OverlaySheets";
import { PanelSwitcher } from "@/components/layout/PanelSwitcher";
import { TapProvider } from "@/components/layout/TapProvider";
import { ReviewRouter } from "@/components/touchpoints/ReviewRouter";
import { SocialHub } from "@/components/touchpoints/SocialHub";
import { VCardSheet } from "@/components/touchpoints/VCardSheet";
import { WifiCard } from "@/components/touchpoints/WifiCard";

applyTheme();

function LandingSurface() {
  const landing = clientConfig.activeMode;
  const reduced = useReducedMotion();
  const page = usePageVariants();
  const { panel, setPanel } = useTapContext();

  const onDragEnd = (_: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (Math.abs(info.offset.x) < motionConfig.swipeThreshold) return;
    if (info.offset.x < 0) setPanel("HUB");
    if (info.offset.x > 0) setPanel("REVIEW");
  };

  if (landing === "WIFI") return <WifiCard />;
  if (landing === "CONTACT") return <VCardSheet />;

  const showSwitcher = landing === "REVIEW" || landing === "HUB";

  return (
    <div className="flex flex-1 flex-col gap-4">
      {showSwitcher ? <PanelSwitcher /> : null}

      <motion.div
        className="flex-1 touch-pan-y"
        drag={reduced ? false : "x"}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={motionConfig.rubberBandTop}
        dragMomentum={false}
        onDragEnd={onDragEnd}
      >
        <AnimatePresence mode="wait">
          {panel === "HUB" ? (
            <motion.div key="hub" {...page}>
              <SocialHub />
            </motion.div>
          ) : (
            <motion.div key="review" {...page}>
              <ReviewRouter />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

export default function App() {
  const [ready, setReady] = useState(false);
  const page = usePageVariants();

  useEffect(() => {
    applyTheme();
    const wait = motionConfig.skeletonMinMs;
    const timer = window.setTimeout(() => setReady(true), wait);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <TapProvider>
      <div className="relative min-h-dvh overflow-x-hidden bg-background text-foreground">
        <div aria-hidden className="grain pointer-events-none fixed inset-0 z-10" />
        <AnimatePresence mode="wait">
          {ready ? (
            <motion.div key="app" {...page}>
              <AppShell>
                <LandingSurface />
              </AppShell>
              <OverlaySheets />
            </motion.div>
          ) : (
            <motion.div key="boot" {...page}>
              <LoadingScreen />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </TapProvider>
  );
}
