/**
 * App chrome — safe-area padding, brand lockup, utensils settle.
 * Edit /src/config/theme.config.ts to change surfaces —
 * do not modify this file.
 * Edit /src/config/motion.config.ts to change the utensils settle rotate —
 * do not modify this file.
 * Edit /src/config/client.config.ts to change name / subtitle —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { clientConfig } from "@/config/client.config";
import { motionConfig } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition, useReducedMotion } from "@/hooks/useReducedMotion";
import { getIcon } from "@/services/icon.service";
import { FooterBrand } from "@/components/layout/FooterBrand";
import { NFCContextBanner } from "@/components/layout/NFCContextBanner";

interface AppShellProps {
  children: ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const reduced = useReducedMotion();
  const settle = useMotionTransition("elastic");
  const fade = useMotionTransition("smooth");
  const BrandIcon = getIcon(touchpointsConfig.icons.primary);

  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-lg flex-col px-5">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-64 bg-[radial-gradient(ellipse_at_50%_0%,var(--app-accent-glow),transparent_70%)]"
      />

      <header className="relative pt-[max(1.25rem,env(safe-area-inset-top))]">
        <NFCContextBanner />

        <div className="mt-8 flex flex-col items-center text-center">
          <motion.div
            className="flex size-16 items-center justify-center rounded-[var(--app-radius-lg)] border border-border bg-[var(--app-surface-elevated)] shadow-[0_0_40px_var(--app-accent-glow)]"
            initial={
              reduced
                ? { opacity: 0 }
                : { opacity: 0, rotate: -motionConfig.iconSettleRotate, scale: 0.92 }
            }
            animate={{ opacity: 1, rotate: 0, scale: 1 }}
            transition={settle}
          >
            <BrandIcon className="size-7 text-primary" strokeWidth={1.6} />
          </motion.div>

          <motion.div
            className="mt-4"
            initial={{ opacity: 0, y: reduced ? 0 : 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={fade}
          >
            <h1 className="text-[1.65rem] font-semibold leading-tight tracking-[-0.02em] text-foreground">
              {clientConfig.businessName}
            </h1>
            <p className="mt-1.5 text-[15px] leading-relaxed text-muted-foreground">
              {clientConfig.subtitle}
            </p>
          </motion.div>
        </div>
      </header>

      <main className="relative flex flex-1 flex-col pt-7">{children}</main>

      <FooterBrand />
    </div>
  );
}
