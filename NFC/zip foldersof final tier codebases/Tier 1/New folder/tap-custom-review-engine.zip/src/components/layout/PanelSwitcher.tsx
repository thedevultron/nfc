/**
 * Segmented Review / Explore control with a sliding pill.
 * Edit /src/config/touchpoints.config.ts to change panel labels —
 * do not modify this file.
 * Edit /src/config/motion.config.ts to change the pill spring —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition } from "@/hooks/useReducedMotion";
import { useSpringPress } from "@/hooks/useSpringPress";
import { useTapContext } from "@/hooks/useTapContext";
import type { PanelId } from "@/types/template.types";
import { cn } from "@/utils/cn";

const PANELS: PanelId[] = ["REVIEW", "HUB"];

export function PanelSwitcher() {
  const { panel, setPanel } = useTapContext();
  const copy = touchpointsConfig.copy;
  const pill = useMotionTransition("snappy");
  const reviewPress = useSpringPress({ haptic: "selection", hover: false });
  const hubPress = useSpringPress({ haptic: "selection", hover: false });

  const label = (id: PanelId) => (id === "REVIEW" ? copy.panelReview : copy.panelExplore);

  return (
    <div className="relative grid grid-cols-2 rounded-full bg-[var(--app-muted)] p-1">
      {PANELS.map((id) => {
        const active = panel === id;
        const press = id === "REVIEW" ? reviewPress : hubPress;
        return (
          <motion.button
            key={id}
            type="button"
            className={cn(
              "relative z-10 h-9 rounded-full text-[13px] font-medium tracking-[-0.01em]",
              active ? "text-foreground" : "text-muted-foreground",
            )}
            whileTap={press.whileTap}
            onTapStart={press.onTapStart}
            onClick={() => setPanel(id)}
          >
            {active ? (
              <motion.span
                layoutId="panel-pill"
                className="absolute inset-0 rounded-full bg-[var(--app-surface-elevated)] shadow-[0_1px_2px_rgba(0,0,0,0.35)]"
                transition={pill}
              />
            ) : null}
            <span className="relative z-10">{label(id)}</span>
          </motion.button>
        );
      })}
    </div>
  );
}
