/**
 * Overlay drawers for Wi-Fi, contact, menu, and private feedback.
 * Edit /src/config/client.config.ts to change which mode lands as a page —
 * do not modify this file.
 * Edit /src/config/touchpoints.config.ts to change sheet titles —
 * do not modify this file.
 */
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useTapContext } from "@/hooks/useTapContext";
import { Drawer } from "@/components/ui/drawer";
import { FeedbackDrawer } from "@/components/touchpoints/FeedbackDrawer";
import { MenuSheet } from "@/components/touchpoints/MenuSheet";
import { VCardSheet } from "@/components/touchpoints/VCardSheet";
import { WifiCard } from "@/components/touchpoints/WifiCard";

export function OverlaySheets() {
  const { wifiOpen, setWifiOpen, contactOpen, setContactOpen } = useTapContext();
  const copy = touchpointsConfig.copy;
  const landing = clientConfig.activeMode;

  return (
    <>
      {landing !== "WIFI" ? (
        <Drawer
          open={wifiOpen}
          onOpenChange={setWifiOpen}
          title={copy.wifiTitle}
          subtitle={copy.wifiSubtitle}
        >
          <WifiCard embedded />
        </Drawer>
      ) : null}

      {landing !== "CONTACT" ? (
        <Drawer
          open={contactOpen}
          onOpenChange={setContactOpen}
          title={copy.contactTitle}
          subtitle={copy.contactSubtitle}
        >
          <VCardSheet embedded />
        </Drawer>
      ) : null}

      <MenuSheet />
      <FeedbackDrawer />
    </>
  );
}
