/**
 * Session orchestrator — panels, drawers, hub routing.
 * Edit /src/config/client.config.ts to change landing mode and URLs —
 * do not modify this file.
 * Edit /src/config/touchpoints.config.ts to change hub actions —
 * do not modify this file.
 */
import { useCallback, useMemo, useState, type ReactNode } from "react";
import { clientConfig } from "@/config/client.config";
import { TapContext } from "@/hooks/useTapContext";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import type { HubItem, PanelId } from "@/types/template.types";

interface TapProviderProps {
  children: ReactNode;
}

function initialPanel(): PanelId {
  if (clientConfig.activeMode === "HUB") return "HUB";
  return "REVIEW";
}

export function TapProvider({ children }: TapProviderProps) {
  const { track } = useTapAnalytics({ fireMount: true });
  const [panel, setPanelState] = useState<PanelId>(initialPanel);
  const [wifiOpen, setWifiOpen] = useState(clientConfig.activeMode === "WIFI");
  const [contactOpen, setContactOpen] = useState(clientConfig.activeMode === "CONTACT");
  const [menuOpen, setMenuOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [rating, setRating] = useState(0);

  const setPanel = useCallback(
    (next: PanelId) => {
      setPanelState(next);
      track("cta", { panel: next });
    },
    [track],
  );

  const handleHubItem = useCallback(
    (item: HubItem) => {
      track("hub", { id: item.id, action: item.action });

      switch (item.action) {
        case "wifi":
          setWifiOpen(true);
          return;
        case "contact":
          setContactOpen(true);
          return;
        case "menu":
          setMenuOpen(true);
          return;
        case "review":
          setPanelState("REVIEW");
          return;
        case "external":
          if (item.url) {
            window.open(item.url, "_blank", "noopener,noreferrer");
          }
          return;
        case "internal":
          if (item.url) {
            window.location.assign(item.url);
          }
          return;
        default:
          return;
      }
    },
    [track],
  );

  const value = useMemo(
    () => ({
      panel,
      setPanel,
      wifiOpen,
      setWifiOpen,
      contactOpen,
      setContactOpen,
      menuOpen,
      setMenuOpen,
      feedbackOpen,
      setFeedbackOpen,
      rating,
      setRating,
      handleHubItem,
    }),
    [
      panel,
      setPanel,
      wifiOpen,
      contactOpen,
      menuOpen,
      feedbackOpen,
      rating,
      handleHubItem,
    ],
  );

  return <TapContext.Provider value={value}>{children}</TapContext.Provider>;
}
