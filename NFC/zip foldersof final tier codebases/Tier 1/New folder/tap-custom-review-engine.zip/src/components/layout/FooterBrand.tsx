/**
 * Footer lockup.
 * Edit /src/config/client.config.ts to change the business name —
 * do not modify this file.
 * Edit /src/config/touchpoints.config.ts to change footer copy —
 * do not modify this file.
 */
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";

export function FooterBrand() {
  return (
    <footer className="pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-6 text-center">
      <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground/70">
        {clientConfig.businessName}
      </p>
      <p className="mt-1 text-[12px] text-muted-foreground/55">{touchpointsConfig.copy.footer}</p>
    </footer>
  );
}
