/**
 * Quiet NFC context chip — status-bar safe.
 * Edit /src/config/touchpoints.config.ts to change banner copy —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { Nfc } from "lucide-react";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition } from "@/hooks/useReducedMotion";
import { Badge } from "@/components/ui/badge";

export function NFCContextBanner() {
  const copy = touchpointsConfig.copy;
  const enter = useMotionTransition("smooth");

  return (
    <motion.div
      className="flex items-center justify-between"
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={enter}
    >
      <div className="inline-flex items-center gap-2 text-[12px] text-muted-foreground">
        <span className="flex size-6 items-center justify-center rounded-full bg-[var(--app-muted)]">
          <Nfc className="size-3.5" strokeWidth={1.75} />
        </span>
        <span className="tracking-[-0.01em]">{copy.nfcBanner}</span>
      </div>
      <Badge variant="live">
        <span className="relative flex size-1.5">
          <span className="absolute inline-flex size-full animate-ping rounded-full bg-accent opacity-60" />
          <span className="relative inline-flex size-1.5 rounded-full bg-accent" />
        </span>
        {copy.nfcLive}
      </Badge>
    </motion.div>
  );
}
