/**
 * First-paint skeleton — never a blank flash.
 * Edit /src/config/touchpoints.config.ts to change loading copy —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition } from "@/hooks/useReducedMotion";
import { getIcon } from "@/services/icon.service";
import { Skeleton } from "@/components/ui/skeleton";

export function LoadingScreen() {
  const copy = touchpointsConfig.copy;
  const fade = useMotionTransition("smooth");
  const BrandIcon = getIcon(touchpointsConfig.icons.primary);

  return (
    <motion.div
      className="mx-auto flex min-h-dvh w-full max-w-lg flex-col items-center px-5 pt-[max(4.5rem,env(safe-area-inset-top))]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={fade}
    >
      <div className="flex size-16 items-center justify-center rounded-[var(--app-radius-lg)] border border-border bg-[var(--app-surface-elevated)] shadow-[0_0_40px_var(--app-accent-glow)]">
        <BrandIcon className="size-7 text-primary" strokeWidth={1.6} />
      </div>
      <p className="mt-5 text-[15px] font-medium tracking-[-0.01em] text-foreground">
        {copy.loading}
      </p>
      <p className="mt-1 text-sm text-muted-foreground">{copy.loadingHint}</p>

      <div className="mt-10 flex w-full flex-col gap-3">
        <Skeleton className="h-11 w-full rounded-full" />
        <Skeleton className="h-48 w-full rounded-[var(--app-radius-lg)]" />
        <Skeleton className="h-12 w-full" />
      </div>
    </motion.div>
  );
}
