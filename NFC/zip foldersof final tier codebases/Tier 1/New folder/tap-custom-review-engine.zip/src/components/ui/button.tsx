/**
 * Button primitive.
 * Edit /src/config/theme.config.ts to change color, radius, glow —
 * do not modify this file.
 * Edit /src/config/motion.config.ts to change press feel —
 * do not modify this file.
 */
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { motion, type HTMLMotionProps } from "framer-motion";
import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/utils/cn";
import { useSpringPress } from "@/hooks/useSpringPress";
import type { HapticName } from "@/types/template.types";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium tracking-tight select-none outline-none transition-[box-shadow,background-color,color] disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-primary text-[var(--app-primary-foreground)] shadow-[0_0_40px_var(--app-accent-glow)]",
        secondary:
          "bg-[var(--app-surface-elevated)] text-foreground border border-border",
        outline:
          "border border-border bg-transparent text-foreground hover:bg-[var(--app-muted)]",
        ghost: "bg-transparent text-foreground hover:bg-[var(--app-muted)]",
        glow: "bg-primary text-[var(--app-primary-foreground)] shadow-[0_0_40px_var(--app-accent-glow),0_8px_24px_rgba(0,0,0,0.35)]",
        accent:
          "bg-accent text-[var(--app-primary-foreground)] shadow-[0_0_32px_hsl(160_84%_39%/0.28)]",
        destructive: "bg-red-500/90 text-white",
      },
      size: {
        sm: "h-9 px-3 text-sm rounded-[var(--app-radius-sm)]",
        md: "h-11 px-4 text-[15px] rounded-[var(--app-radius-md)]",
        lg: "h-12 px-5 text-base rounded-[var(--app-radius-lg)]",
        icon: "size-11 rounded-[var(--app-radius-md)]",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
    },
  },
);

type NativeButton = ButtonHTMLAttributes<HTMLButtonElement>;

export interface ButtonProps
  extends Omit<NativeButton, "onDrag" | "onDragStart" | "onDragEnd" | "onAnimationStart">,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  haptic?: HapticName;
}

const MotionButton = motion.button;

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      asChild = false,
      haptic = "tap",
      type = "button",
      children,
      ...props
    },
    ref,
  ) => {
    const press = useSpringPress({ haptic });

    if (asChild) {
      return (
        <Slot className={cn(buttonVariants({ variant, size }), className)} ref={ref} {...props}>
          {children}
        </Slot>
      );
    }

    return (
      <MotionButton
        ref={ref}
        type={type}
        className={cn(buttonVariants({ variant, size }), className)}
        whileTap={press.whileTap}
        whileHover={press.whileHover}
        transition={press.transition}
        onTapStart={press.onTapStart}
        {...(props as HTMLMotionProps<"button">)}
      >
        {children}
      </MotionButton>
    );
  },
);

Button.displayName = "Button";

export { buttonVariants };
