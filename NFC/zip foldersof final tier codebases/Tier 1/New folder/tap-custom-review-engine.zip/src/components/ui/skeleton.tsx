/**
 * Skeleton + shimmer.
 * Edit /src/config/theme.config.ts to change surface tokens —
 * do not modify this file.
 */
import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-[var(--app-radius-md)] bg-[var(--app-muted)]",
        "skeleton-shimmer",
        className,
      )}
      {...props}
    />
  );
}
