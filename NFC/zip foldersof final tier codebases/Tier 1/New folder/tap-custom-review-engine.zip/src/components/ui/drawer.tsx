/**
 * iOS-style bottom sheet with drag-to-dismiss, velocity snap, rubber-band.
 * Drag is bound to the handle / header so inner scroll and text fields stay usable.
 *
 * Edit /src/config/motion.config.ts to change drawer spring, dismiss
 * thresholds, and rubber-band — do not modify this file.
 * Edit /src/config/touchpoints.config.ts to change the close label —
 * do not modify this file.
 */
import { AnimatePresence, motion, useDragControls, type PanInfo } from "framer-motion";
import { X } from "lucide-react";
import { useCallback, useEffect, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { motionConfig, reducedMotionPreset } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { haptics } from "@/services/haptics.service";
import { cn } from "@/utils/cn";

interface DrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
  title?: string;
  subtitle?: string;
  className?: string;
}

export function Drawer({
  open,
  onOpenChange,
  children,
  title,
  subtitle,
  className,
}: DrawerProps) {
  const reduced = useReducedMotion();
  const copy = touchpointsConfig.copy;
  const dragControls = useDragControls();

  const close = useCallback(() => {
    haptics.tap();
    onOpenChange(false);
  }, [onOpenChange]);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  const onDragEnd = useCallback(
    (_: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
      const shouldDismiss =
        info.offset.y > motionConfig.drawerDismissOffset ||
        info.velocity.y > motionConfig.drawerDismissVelocity;
      if (shouldDismiss) close();
    },
    [close],
  );

  const startDrag = (event: ReactPointerEvent) => {
    if (reduced) return;
    dragControls.start(event);
  };

  if (typeof document === "undefined") return null;

  const sheetTransition = reduced ? reducedMotionPreset : motionConfig.springs.drawer;

  return createPortal(
    <AnimatePresence>
      {open ? (
        <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={title}>
          <motion.button
            type="button"
            aria-label={copy.close}
            className="absolute inset-0 bg-black/55 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={reducedMotionPreset}
            onClick={close}
          />

          <motion.div
            className={cn(
              "absolute inset-x-0 bottom-0 mx-auto w-full max-w-lg",
              "rounded-t-[var(--app-radius-xl)] border border-border border-b-0",
              "bg-[var(--app-surface)]/95 backdrop-blur-xl",
              "shadow-[0_-12px_40px_rgba(0,0,0,0.45)]",
              "px-5 pt-3 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
              className,
            )}
            initial={reduced ? { opacity: 0 } : { y: "100%" }}
            animate={reduced ? { opacity: 1 } : { y: 0 }}
            exit={reduced ? { opacity: 0 } : { y: "100%" }}
            transition={sheetTransition}
            drag={reduced ? false : "y"}
            dragControls={dragControls}
            dragListener={false}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: motionConfig.rubberBandTop, bottom: motionConfig.rubberBand }}
            onDragEnd={onDragEnd}
          >
            <div className="cursor-grab active:cursor-grabbing" onPointerDown={startDrag}>
              <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-white/15" />

              <div className="mb-4 flex items-start justify-between gap-3">
                <div className="min-w-0">
                  {title ? (
                    <h2 className="text-[17px] font-semibold tracking-[-0.02em] text-foreground">
                      {title}
                    </h2>
                  ) : null}
                  {subtitle ? (
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{subtitle}</p>
                  ) : null}
                </div>
                <button
                  type="button"
                  onClick={close}
                  aria-label={copy.close}
                  className="flex size-8 shrink-0 items-center justify-center rounded-full bg-[var(--app-muted)] text-muted-foreground"
                >
                  <X className="size-4" />
                </button>
              </div>
            </div>

            <div className="overscroll-contain">{children}</div>
          </motion.div>
        </div>
      ) : null}
    </AnimatePresence>,
    document.body,
  );
}
