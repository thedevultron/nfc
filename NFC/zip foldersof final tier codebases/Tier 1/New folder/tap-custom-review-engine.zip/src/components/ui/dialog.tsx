/**
 * Dialog primitive (Radix + motion).
 * Edit /src/config/motion.config.ts to change entrance spring —
 * do not modify this file.
 * Edit /src/config/touchpoints.config.ts to change the close label —
 * do not modify this file.
 */
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { motionConfig, reducedMotionPreset } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { cn } from "@/utils/cn";

export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;
export const DialogPortal = DialogPrimitive.Portal;

export function DialogOverlay({
  className,
  ...props
}: ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>) {
  return (
    <DialogPrimitive.Overlay
      className={cn("fixed inset-0 z-50 bg-black/55 backdrop-blur-[2px]", className)}
      {...props}
    />
  );
}

interface DialogContentProps {
  open: boolean;
  children: ReactNode;
  className?: string;
  title?: string;
}

export function DialogContent({ open, children, className, title }: DialogContentProps) {
  const reduced = useReducedMotion();
  const copy = touchpointsConfig.copy;
  const transition = reduced ? reducedMotionPreset : motionConfig.springs.smooth;

  return (
    <AnimatePresence>
      {open ? (
        <DialogPortal forceMount>
          <DialogPrimitive.Overlay asChild forceMount>
            <motion.div
              className="fixed inset-0 z-50 bg-black/55 backdrop-blur-[2px]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={reduced ? reducedMotionPreset : { duration: 0.2 }}
            />
          </DialogPrimitive.Overlay>
          <DialogPrimitive.Content asChild forceMount aria-label={title}>
            <motion.div
              className={cn(
                "fixed left-1/2 top-1/2 z-50 w-[min(92vw,28rem)] -translate-x-1/2 -translate-y-1/2",
                "rounded-[var(--app-radius-lg)] border border-border",
                "bg-[var(--app-surface)]/95 p-5 shadow-[0_8px_30px_rgba(0,0,0,0.35)] backdrop-blur-xl",
                className,
              )}
              initial={reduced ? { opacity: 0 } : { opacity: 0, y: motionConfig.pageSlideY, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={reduced ? { opacity: 0 } : { opacity: 0, y: motionConfig.pageSlideY, scale: 0.98 }}
              transition={transition}
            >
              <DialogPrimitive.Close
                className="absolute right-3 top-3 flex size-8 items-center justify-center rounded-full bg-[var(--app-muted)] text-muted-foreground"
                aria-label={copy.close}
              >
                <X className="size-4" />
              </DialogPrimitive.Close>
              {children}
            </motion.div>
          </DialogPrimitive.Content>
        </DialogPortal>
      ) : null}
    </AnimatePresence>
  );
}
