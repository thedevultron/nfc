/**
 * Success / error confirmation — spring checkmark with circular ring wipe.
 * Not a toast.
 *
 * Edit /src/config/motion.config.ts to change ring and spring feel —
 * do not modify this file.
 * Edit /src/config/touchpoints.config.ts to change success/error copy —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { CheckCircle2, XCircle } from "lucide-react";
import { motionConfig, reducedMotionPreset } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition, useReducedMotion } from "@/hooks/useReducedMotion";
import { Button } from "@/components/ui/button";

interface StatusBurstProps {
  tone: "success" | "error";
  onRetry?: () => void;
  onDone?: () => void;
}

export function StatusBurst({ tone, onRetry, onDone }: StatusBurstProps) {
  const reduced = useReducedMotion();
  const pop = useMotionTransition("elastic");
  const fade = useMotionTransition("smooth");
  const copy = touchpointsConfig.copy;
  const isSuccess = tone === "success";
  const Icon = isSuccess ? CheckCircle2 : XCircle;

  return (
    <motion.div
      className="flex flex-col items-center px-4 py-8 text-center"
      initial={{ opacity: 0, y: reduced ? 0 : 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={fade}
    >
      <div className="relative mb-5 size-20">
        <svg viewBox="0 0 100 100" className="absolute inset-0 size-20 -rotate-90">
          <circle
            cx="50"
            cy="50"
            r="46"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            className="text-white/8"
          />
          <motion.circle
            cx="50"
            cy="50"
            r="46"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            className={isSuccess ? "text-accent" : "text-red-400"}
            strokeDasharray={motionConfig.ringCircumference}
            initial={{ strokeDashoffset: motionConfig.ringCircumference }}
            animate={{ strokeDashoffset: 0 }}
            transition={
              reduced
                ? reducedMotionPreset
                : { ...motionConfig.springs.smooth, duration: 0.42 }
            }
          />
        </svg>
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={pop}
        >
          <Icon
            className={isSuccess ? "size-9 text-accent" : "size-9 text-red-400"}
            strokeWidth={1.75}
          />
        </motion.div>
      </div>

      <h3 className="text-lg font-semibold tracking-[-0.02em] text-foreground">
        {isSuccess ? copy.successTitle : copy.errorTitle}
      </h3>
      <p className="mt-1.5 max-w-[16rem] text-sm leading-relaxed text-muted-foreground">
        {isSuccess ? copy.successSubtitle : copy.errorSubtitle}
      </p>

      {isSuccess ? (
        onDone ? (
          <Button variant="ghost" className="mt-6" onClick={onDone}>
            {copy.close}
          </Button>
        ) : null
      ) : (
        onRetry ? (
          <Button variant="secondary" className="mt-6" onClick={onRetry} haptic="tap">
            {copy.retry}
          </Button>
        ) : null
      )}
    </motion.div>
  );
}
