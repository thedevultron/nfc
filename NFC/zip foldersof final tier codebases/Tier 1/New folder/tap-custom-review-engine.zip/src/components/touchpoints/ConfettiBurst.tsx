/**
 * Confetti-lite — Lucide Sparkle particles with physics-based fall.
 * Edit /src/config/motion.config.ts to change count, spread, fall —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { Sparkle } from "lucide-react";
import { useMemo } from "react";
import { motionConfig, reducedMotionPreset } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface ConfettiBurstProps {
  seed: number;
}

export function ConfettiBurst({ seed }: ConfettiBurstProps) {
  const reduced = useReducedMotion();
  const { count, spread, fall, duration } = motionConfig.confetti;

  const particles = useMemo(() => {
    return Array.from({ length: count }, (_, i) => {
      const t = (i + 1) / (count + 1);
      const dir = i % 2 === 0 ? -1 : 1;
      const x = dir * spread * t + ((seed + i * 17) % 13) - 6;
      const y = fall * (0.7 + ((seed + i) % 5) / 12);
      const rotate = dir * (40 + ((seed + i * 9) % 50));
      const tint = i % 3 === 0 ? "text-accent" : "text-primary";
      return { x, y, rotate, tint, delay: i * 0.018 };
    });
  }, [count, spread, fall, seed]);

  if (reduced) return null;

  return (
    <div className="pointer-events-none absolute inset-0 overflow-visible" aria-hidden>
      {particles.map((p, i) => (
        <motion.div
          key={`${seed}-${i}`}
          className="absolute left-1/2 top-1/2"
          initial={{ opacity: 1, x: 0, y: 0, scale: 0.55, rotate: 0 }}
          animate={{
            opacity: [1, 1, 0],
            x: p.x,
            y: p.y,
            scale: [0.55, 1.15, 0.8],
            rotate: p.rotate,
          }}
          transition={{
            duration,
            delay: p.delay,
            ease: "easeOut",
          }}
        >
          <Sparkle className={`size-3.5 ${p.tint}`} strokeWidth={2} />
        </motion.div>
      ))}
    </div>
  );
}

// Keep reducedMotionPreset referenced so the token stays the source of truth.
void reducedMotionPreset;
