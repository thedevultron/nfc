/**
 * Dynamic contact / vCard — client-side .vcf download.
 * Edit /src/config/touchpoints.config.ts to change vCard fields and copy —
 * do not modify this file.
 * Edit /src/config/client.config.ts to change WhatsApp / call URLs —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { Check, MessageCircle, Phone, UserPlus } from "lucide-react";
import { useState } from "react";
import { clientConfig } from "@/config/client.config";
import { listItem, listStagger } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition, useReducedMotion } from "@/hooks/useReducedMotion";
import { useSpringPress } from "@/hooks/useSpringPress";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { haptics } from "@/services/haptics.service";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/utils/cn";

function buildVCard(): string {
  const { name, phone, org, email, website, note } = touchpointsConfig.vcard;
  const lines = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `FN:${name}`,
    `ORG:${org}`,
    `TEL;TYPE=CELL:${phone}`,
  ];
  if (email) lines.push(`EMAIL:${email}`);
  if (website) lines.push(`URL:${website}`);
  if (note) lines.push(`NOTE:${note}`);
  lines.push("END:VCARD");
  return lines.join("\r\n");
}

function downloadVCard(): void {
  const blob = new Blob([buildVCard()], { type: "text/vcard;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  const slug = touchpointsConfig.vcard.name.toLowerCase().replace(/\s+/g, "-");
  anchor.href = url;
  anchor.download = `${slug}.vcf`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

interface VCardSheetProps {
  embedded?: boolean;
}

export function VCardSheet({ embedded = false }: VCardSheetProps) {
  const copy = touchpointsConfig.copy;
  const { track } = useTapAnalytics();
  const reduced = useReducedMotion();
  const fade = useMotionTransition("smooth");
  const [saved, setSaved] = useState(false);
  const whatsappPress = useSpringPress({ haptic: "tap" });
  const callPress = useSpringPress({ haptic: "tap" });

  const save = () => {
    downloadVCard();
    haptics.success();
    setSaved(true);
    track("vcard", { action: "save" });
    window.setTimeout(() => setSaved(false), 1800);
  };

  const body = (
    <div className={embedded ? "flex flex-col gap-5" : "flex flex-col gap-5 py-6"}>
      {embedded ? null : (
        <motion.div
          initial={{ opacity: 0, y: reduced ? 0 : 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={fade}
        >
          <h2 className="text-[17px] font-semibold tracking-[-0.02em] text-foreground">
            {copy.contactTitle}
          </h2>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            {copy.contactSubtitle}
          </p>
        </motion.div>
      )}

      <Button variant="glow" size="lg" className="w-full" haptic="success" onClick={save}>
        {saved ? <Check className="size-4" /> : <UserPlus className="size-4" />}
        {saved ? copy.contactSaved : copy.contactSave}
      </Button>

      <motion.div
        className="grid grid-cols-2 gap-2.5"
        variants={reduced ? undefined : listStagger}
        initial="hidden"
        animate="show"
      >
        <motion.a
          variants={listItem}
          transition={fade}
          href={clientConfig.whatsappUrl}
          target="_blank"
          rel="noreferrer"
          className={cn(
            "inline-flex h-12 items-center justify-center gap-2 rounded-[var(--app-radius-md)]",
            "border border-accent/25 bg-accent/12 text-sm font-medium text-accent",
            "shadow-[0_0_28px_hsl(160_84%_39%/0.18)]",
          )}
          whileTap={whatsappPress.whileTap}
          whileHover={whatsappPress.whileHover}
          onTapStart={whatsappPress.onTapStart}
          onClick={() => track("cta", { target: "whatsapp" })}
        >
          <MessageCircle className="size-4" />
          {copy.contactWhatsapp}
        </motion.a>

        <motion.a
          variants={listItem}
          transition={fade}
          href={clientConfig.callUrl}
          className={cn(
            "inline-flex h-12 items-center justify-center gap-2 rounded-[var(--app-radius-md)]",
            "border border-primary/25 bg-primary/12 text-sm font-medium text-primary",
            "shadow-[0_0_28px_var(--app-accent-glow)]",
          )}
          whileTap={callPress.whileTap}
          whileHover={callPress.whileHover}
          onTapStart={callPress.onTapStart}
          onClick={() => track("cta", { target: "call" })}
        >
          <Phone className="size-4" />
          {copy.contactCall}
        </motion.a>
      </motion.div>

      <p className="text-center text-[12px] tabular-nums text-muted-foreground">
        {touchpointsConfig.vcard.phone}
      </p>
    </div>
  );

  if (embedded) return body;

  return (
    <Card>
      <CardContent className="p-0 px-5">{body}</CardContent>
    </Card>
  );
}
