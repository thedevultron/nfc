/**
 * Private feedback sheet — owner-only, not public.
 * Edit /src/config/touchpoints.config.ts to change copy —
 * do not modify this file.
 * Edit /src/config/client.config.ts to change the feedback webhook —
 * do not modify this file.
 */
import { useState } from "react";
import { Send } from "lucide-react";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useTapContext } from "@/hooks/useTapContext";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { api } from "@/services/api.service";
import { haptics } from "@/services/haptics.service";
import { Button } from "@/components/ui/button";
import { Drawer } from "@/components/ui/drawer";
import { Textarea } from "@/components/ui/textarea";
import { StatusBurst } from "@/components/ui/status-burst";

export function FeedbackDrawer() {
  const { feedbackOpen, setFeedbackOpen, rating } = useTapContext();
  const { track } = useTapAnalytics();
  const copy = touchpointsConfig.copy;
  const [text, setText] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  const submit = async () => {
    if (!text.trim() || status === "sending") return;
    const payload = {
      rating,
      feedbackText: text.trim(),
      timestamp: new Date().toISOString(),
      touchpointId: clientConfig.touchpointId,
    };

    // Optimistic success, then confirm with the webhook.
    setStatus("success");
    haptics.success();
    track("feedback", { rating, length: payload.feedbackText.length });

    const result = await api.sendFeedback(payload);
    if (!result.ok) {
      haptics.error();
      setStatus("error");
    }
  };

  const handleOpenChange = (open: boolean) => {
    setFeedbackOpen(open);
    if (!open) {
      setStatus("idle");
      setText("");
    }
  };

  return (
    <Drawer
      open={feedbackOpen}
      onOpenChange={handleOpenChange}
      title={copy.reviewLowTitle}
      subtitle={copy.reviewLowSubtitle}
    >
      {status === "success" || status === "error" ? (
        <StatusBurst
          tone={status}
          onRetry={() => setStatus("idle")}
          onDone={() => handleOpenChange(false)}
        />
      ) : (
        <div className="flex flex-col gap-4">
          <Textarea
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder={copy.feedbackPlaceholder}
            maxLength={800}
            aria-label={copy.reviewLowTitle}
          />
          <Button
            variant="glow"
            size="lg"
            className="w-full"
            haptic="selection"
            disabled={!text.trim() || status === "sending"}
            onClick={() => void submit()}
          >
            <Send className="size-4" />
            {status === "sending" ? copy.feedbackSending : copy.feedbackSubmit}
          </Button>
        </div>
      )}
    </Drawer>
  );
}
