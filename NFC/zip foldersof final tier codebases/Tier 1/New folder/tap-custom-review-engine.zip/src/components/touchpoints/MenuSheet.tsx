/**
 * Digital menu drawer — content from touchpoints.config.
 * Edit /src/config/touchpoints.config.ts to change dishes and copy —
 * do not modify this file.
 */
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useTapContext } from "@/hooks/useTapContext";
import { Drawer } from "@/components/ui/drawer";

export function MenuSheet() {
  const { menuOpen, setMenuOpen } = useTapContext();
  const copy = touchpointsConfig.copy;

  return (
    <Drawer
      open={menuOpen}
      onOpenChange={setMenuOpen}
      title={copy.menuTitle}
      subtitle={copy.menuSubtitle}
    >
      <div className="flex max-h-[62dvh] flex-col gap-6 overflow-y-auto pr-1">
        {touchpointsConfig.menu.map((category) => (
          <section key={category.name}>
            <h3 className="mb-2.5 text-[11px] font-medium uppercase tracking-[0.16em] text-primary">
              {category.name}
            </h3>
            <ul className="flex flex-col gap-3">
              {category.items.map((item) => (
                <li key={item.name} className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <p className="text-[15px] font-medium tracking-[-0.01em] text-foreground">
                      {item.name}
                    </p>
                    <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                  <p className="shrink-0 tabular-nums text-[15px] text-primary">₹{item.price}</p>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </Drawer>
  );
}
