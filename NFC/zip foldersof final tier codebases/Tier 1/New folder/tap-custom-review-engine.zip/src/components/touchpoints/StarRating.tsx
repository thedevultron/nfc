/**
 * Five-star rating with elastic pop + adjacent ripple.
 * Edit /src/config/motion.config.ts to change pop scale and ripple delay —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { motionConfig, reducedMotionPreset } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { haptics } from "@/services/haptics.service";
import { cn } from "@/utils/cn";

interface StarRatingProps {
  value: number;
  onChange: (next: number) => void;
}

export function StarRating({ value, onChange }: StarRatingProps) {
  const reduced = useReducedMotion();

  return (
    <div
      className="flex items-center justify-center gap-2"
      role="radiogroup"
      aria-label="Rating"
    >
      {Array.from({ length: 5 }, (_, index) => {
        const star = index + 1;
        const filled = star <= value;
        const rippleDelay = reduced ? 0 : (star - 1) * (motionConfig.starRippleMs / 1000);

        return (
          <motion.button
            key={star}
            type="button"
            role="radio"
            aria-checked={value === star}
            aria-label={`${star} star${star === 1 ? "" : "s"}`}
            className="relative flex size-12 items-center justify-center rounded-[var(--app-radius-md)]"
            whileTap={reduced ? { opacity: 0.8 } : { scale: motionConfig.press.scale }}
            transition={reduced ? reducedMotionPreset : motionConfig.springs.snappy}
            onTapStart={() => haptics.selection()}
            onClick={() => onChange(star)}
          >
            <motion.span
              className="flex"
              animate={
                filled
                  ? reduced
                    ? { scale: 1 }
                    : { scale: motionConfig.starPop }
                  : { scale: 1 }
              }
              transition={
                reduced
                  ? reducedMotionPreset
                  : { ...motionConfig.springs.elastic, delay: rippleDelay }
              }
            >
              <Star
                className={cn(
                  "size-9 transition-colors",
                  filled
                    ? "fill-primary text-primary drop-shadow-[0_0_12px_var(--app-accent-glow)]"
                    : "fill-transparent text-white/25",
                )}
                strokeWidth={1.5}
              />
            </motion.span>
          </motion.button>
        );
      })}
    </div>
  );
}
