/**
 * Instant Wi-Fi touchpoint — copy, reveal, optional QR.
 * Edit /src/config/touchpoints.config.ts to change SSID / password / copy —
 * do not modify this file.
 */
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy, Eye, EyeOff, QrCode } from "lucide-react";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { motionConfig } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition, useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { haptics } from "@/services/haptics.service";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { getIcon } from "@/services/icon.service";

function wifiPayload(): string {
  const { ssid, password, security } = touchpointsConfig.wifi;
  return `WIFI:T:${security};S:${ssid};P:${password};;`;
}

interface WifiCardProps {
  embedded?: boolean;
}

export function WifiCard({ embedded = false }: WifiCardProps) {
  const copy = touchpointsConfig.copy;
  const { ssid, password } = touchpointsConfig.wifi;
  const { track } = useTapAnalytics();
  const reduced = useReducedMotion();
  const fade = useMotionTransition("smooth");
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [qrUrl, setQrUrl] = useState<string | null>(null);
  const WifiIcon = getIcon(touchpointsConfig.icons.wifi);

  useEffect(() => {
    let cancelled = false;
    void QRCode.toDataURL(wifiPayload(), {
      margin: 1,
      width: 240,
      color: { dark: "#1a1408", light: "#fff8e8" },
    }).then((url) => {
      if (!cancelled) setQrUrl(url);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const copyPassword = async () => {
    try {
      await navigator.clipboard.writeText(password);
      haptics.success();
      setCopied(true);
      track("copy", { target: "wifi-password" });
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      haptics.error();
    }
  };

  const body = (
      <div className={embedded ? "flex flex-col gap-5" : "flex flex-col gap-5 py-6"}>
        {embedded ? null : (
          <div className="flex items-start gap-3">
            <div className="flex size-11 items-center justify-center rounded-[var(--app-radius-md)] bg-primary/12 text-primary">
              <WifiIcon className="size-5" strokeWidth={1.75} />
            </div>
            <div>
              <h2 className="text-[17px] font-semibold tracking-[-0.02em] text-foreground">
                {copy.wifiTitle}
              </h2>
              <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">
                {copy.wifiSubtitle}
              </p>
            </div>
          </div>
        )}

        <div className="grid gap-2">
          <div className="flex items-center justify-between rounded-[var(--app-radius-md)] border border-border bg-[var(--app-surface-elevated)] px-3.5 py-3">
            <div>
              <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                {copy.wifiNetwork}
              </p>
              <p className="mt-0.5 font-medium tracking-[-0.01em] text-foreground">{ssid}</p>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-[var(--app-radius-md)] border border-border bg-[var(--app-surface-elevated)] px-3.5 py-3">
            <div className="min-w-0">
              <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                {copy.wifiPassword}
              </p>
              <p className="mt-0.5 font-medium tracking-[-0.01em] text-foreground tabular-nums">
                {revealed ? password : "•".repeat(Math.max(password.length, 8))}
              </p>
            </div>
            <button
              type="button"
              className="flex size-9 items-center justify-center rounded-full text-muted-foreground"
              aria-label={revealed ? copy.wifiHideQr : copy.wifiPassword}
              onClick={() => {
                haptics.tap();
                setRevealed((value) => !value);
              }}
            >
              {revealed ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>

        <Button variant="glow" size="lg" className="w-full" haptic="success" onClick={() => void copyPassword()}>
          <AnimatePresence mode="wait" initial={false}>
            {copied ? (
              <motion.span
                key="copied"
                className="inline-flex items-center gap-2"
                initial={{ opacity: 0, y: reduced ? 0 : 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: reduced ? 0 : -6 }}
                transition={fade}
              >
                <Check className="size-4" />
                {copy.wifiCopied}
              </motion.span>
            ) : (
              <motion.span
                key="copy"
                className="inline-flex items-center gap-2"
                initial={{ opacity: 0, y: reduced ? 0 : 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: reduced ? 0 : -6 }}
                transition={fade}
              >
                <Copy className="size-4" />
                {copy.wifiCopyPassword}
              </motion.span>
            )}
          </AnimatePresence>
        </Button>

        <Button
          variant="outline"
          className="w-full"
          haptic="tap"
          onClick={() => setShowQr((value) => !value)}
        >
          <QrCode className="size-4" />
          {showQr ? copy.wifiHideQr : copy.wifiShowQr}
        </Button>

        <AnimatePresence>
          {showQr && qrUrl ? (
            <motion.div
              className="flex justify-center"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={reduced ? fade : motionConfig.springs.smooth}
            >
              <img
                src={qrUrl}
                alt={ssid}
                width={180}
                height={180}
                className="rounded-[var(--app-radius-md)] border border-border"
              />
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
  );

  if (embedded) return body;

  return (
    <Card>
      <CardContent className="p-0 px-5">{body}</CardContent>
    </Card>
  );
}
