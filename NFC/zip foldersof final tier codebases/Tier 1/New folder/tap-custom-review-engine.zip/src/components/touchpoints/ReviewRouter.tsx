/**
 * Smart review router — ≥4 opens Google, <4 opens private feedback.
 * Edit /src/config/client.config.ts to change the Google review URL —
 * do not modify this file.
 * Edit /src/config/touchpoints.config.ts to change review copy —
 * do not modify this file.
 * Edit /src/config/motion.config.ts to change stagger / springs —
 * do not modify this file.
 */
import { AnimatePresence, motion } from "framer-motion";
import { ExternalLink } from "lucide-react";
import { useState } from "react";
import { clientConfig } from "@/config/client.config";
import { listItem, listStagger, motionConfig } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition, useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { useTapContext } from "@/hooks/useTapContext";
import { haptics } from "@/services/haptics.service";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ConfettiBurst } from "@/components/touchpoints/ConfettiBurst";
import { StarRating } from "@/components/touchpoints/StarRating";

export function ReviewRouter() {
  const { rating, setRating, setFeedbackOpen } = useTapContext();
  const { track } = useTapAnalytics();
  const reduced = useReducedMotion();
  const fade = useMotionTransition("smooth");
  const copy = touchpointsConfig.copy;
  const [burst, setBurst] = useState(0);

  const onRate = (next: number) => {
    setRating(next);
    track("rating", { rating: next });

    if (next < 4) {
      window.setTimeout(
        () => setFeedbackOpen(true),
        reduced ? motionConfig.reducedMotionMs / 2 : motionConfig.reducedMotionMs,
      );
    }
  };

  const postToGoogle = () => {
    haptics.success();
    setBurst((value) => value + 1);
    track("cta", { target: "google-review", rating });
    window.setTimeout(() => {
      window.open(clientConfig.googleReviewUrl, "_blank", "noopener,noreferrer");
    }, motionConfig.reducedMotionMs);
  };

  const high = rating >= 4;

  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-5 py-7">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: reduced ? 0 : 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={fade}
        >
          <h2 className="text-[1.35rem] font-semibold tracking-[-0.02em] text-foreground">
            {copy.greeting}
          </h2>
          <p className="mt-1.5 text-sm text-muted-foreground">{copy.greetingHint}</p>
        </motion.div>

        <StarRating value={rating} onChange={onRate} />

        <p className="min-h-5 tabular-nums text-[13px] tracking-[-0.01em] text-muted-foreground">
          {rating > 0 ? `${rating} / 5` : "\u00a0"}
        </p>

        <AnimatePresence mode="wait">
          {high ? (
            <motion.div
              key="high"
              className="relative flex w-full flex-col items-center gap-3"
              variants={reduced ? undefined : listStagger}
              initial="hidden"
              animate="show"
              exit={{ opacity: 0, y: reduced ? 0 : -8 }}
            >
              <motion.p
                variants={listItem}
                transition={fade}
                className="text-center text-[15px] font-medium tracking-[-0.01em] text-foreground"
              >
                {copy.reviewHighTitle}
              </motion.p>
              <motion.p
                variants={listItem}
                transition={fade}
                className="max-w-[18rem] text-center text-sm leading-relaxed text-muted-foreground"
              >
                {copy.reviewHighSubtitle}
              </motion.p>
              <motion.div variants={listItem} transition={fade} className="relative w-full">
                {burst > 0 ? <ConfettiBurst seed={burst} /> : null}
                <Button
                  variant="glow"
                  size="lg"
                  className="w-full"
                  haptic="success"
                  onClick={postToGoogle}
                >
                  {copy.reviewHighCta}
                  <ExternalLink className="size-4" />
                </Button>
              </motion.div>
            </motion.div>
          ) : rating > 0 ? (
            <motion.p
              key="low"
              className="text-center text-sm text-muted-foreground"
              initial={{ opacity: 0, y: reduced ? 0 : motionConfig.pageSlideY / 2 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={fade}
            >
              {copy.reviewLowSubtitle}
            </motion.p>
          ) : (
            <motion.div
              key="idle"
              className="h-5"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}
