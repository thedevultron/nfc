/**
 * Multi-link social hub — staggered pill rows from config.
 * Edit /src/config/touchpoints.config.ts to change hub items —
 * do not modify this file.
 * Edit /src/config/motion.config.ts to change stagger and chevron nudge —
 * do not modify this file.
 */
import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { listItem, listStagger, motionConfig } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useMotionTransition, useReducedMotion } from "@/hooks/useReducedMotion";
import { useSpringPress } from "@/hooks/useSpringPress";
import { useTapContext } from "@/hooks/useTapContext";
import { getIcon } from "@/services/icon.service";
import { Card, CardContent } from "@/components/ui/card";
import type { HubItem } from "@/types/template.types";

function HubRow({ item }: { item: HubItem }) {
  const press = useSpringPress({ haptic: "tap" });
  const Icon = getIcon(item.icon);
  const { handleHubItem } = useTapContext();

  return (
    <motion.button
      type="button"
      variants={listItem}
      className="group flex w-full items-center gap-3 rounded-[var(--app-radius-md)] border border-border bg-[var(--app-surface-elevated)] px-3 py-3 text-left"
      whileTap={press.whileTap}
      onTapStart={press.onTapStart}
      onClick={() => handleHubItem(item)}
    >
      <span className="flex size-10 items-center justify-center rounded-[var(--app-radius-sm)] bg-primary/12 text-primary">
        <Icon className="size-5" strokeWidth={1.75} />
      </span>
      <span className="flex-1 text-[15px] font-medium tracking-[-0.01em] text-foreground">
        {item.label}
      </span>
      <ChevronRight
        className="size-4 text-muted-foreground transition-transform duration-150 group-hover:translate-x-[var(--nudge)] group-active:translate-x-[var(--nudge)]"
        style={{ ["--nudge" as string]: `${motionConfig.chevronNudge}px` }}
      />
    </motion.button>
  );
}

export function SocialHub() {
  const copy = touchpointsConfig.copy;
  const reduced = useReducedMotion();
  const fade = useMotionTransition("smooth");

  return (
    <Card>
      <CardContent className="flex flex-col gap-4 py-6">
        <motion.div initial={{ opacity: 0, y: reduced ? 0 : 8 }} animate={{ opacity: 1, y: 0 }} transition={fade}>
          <h2 className="text-[17px] font-semibold tracking-[-0.02em] text-foreground">
            {copy.hubTitle}
          </h2>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{copy.hubSubtitle}</p>
        </motion.div>

        <motion.div
          className="flex flex-col gap-2"
          variants={reduced ? undefined : listStagger}
          initial="hidden"
          animate="show"
        >
          {touchpointsConfig.hub.map((item) => (
            <HubRow key={item.id} item={item} />
          ))}
        </motion.div>
      </CardContent>
    </Card>
  );
}
