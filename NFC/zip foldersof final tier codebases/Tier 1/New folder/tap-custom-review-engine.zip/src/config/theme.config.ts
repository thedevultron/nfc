/**
 * THEME — single source of truth for color, radius, type, and mode.
 * Re-skin the entire app by editing this file only.
 *
 * Edit /src/config/theme.config.ts to change colors, radius, and type.
 */
import type { ThemeConfig, ThemeMode } from "@/types/template.types";

export const themeConfig: ThemeConfig = {
  // Warm amber — candlelight on dark wood.
  primaryColor: "hsl(38 92% 50%)",
  // Emerald — fresh herb accent.
  secondaryAccent: "hsl(160 84% 39%)",
  accentGlow: "hsl(38 92% 50% / 0.25)",
  backgroundColor: "hsl(224 71.4% 4.1%)",
  surfaceColor: "hsl(224 40% 8%)",
  borderRadius: "0.75rem",
  radius: {
    sm: "0.5rem",
    md: "0.75rem",
    lg: "1rem",
    xl: "1.25rem",
    full: "9999px",
  },
  fontFamily: "'Inter', 'Geist', ui-sans-serif, system-ui, sans-serif",
  enableGlassmorphism: true,
  defaultMode: "dark",
  modes: {
    dark: {
      background: "hsl(224 71.4% 4.1%)",
      foreground: "hsl(40 22% 96%)",
      surface: "hsl(224 32% 7.5%)",
      surfaceElevated: "hsl(224 28% 11%)",
      muted: "hsl(224 22% 14%)",
      mutedForeground: "hsl(220 12% 62%)",
      border: "hsla(40, 20%, 100%, 0.08)",
      primaryForeground: "hsl(224 71.4% 6%)",
    },
    light: {
      background: "hsl(40 24% 97%)",
      foreground: "hsl(224 40% 10%)",
      surface: "hsl(40 30% 99%)",
      surfaceElevated: "hsl(40 20% 94%)",
      muted: "hsl(40 16% 92%)",
      mutedForeground: "hsl(224 10% 40%)",
      border: "hsla(224, 20%, 10%, 0.08)",
      primaryForeground: "hsl(224 71.4% 6%)",
    },
  },
};

/** Apply CSS custom properties from this config. Call once before first paint. */
export function applyTheme(mode?: ThemeMode): void {
  if (typeof document === "undefined") return;

  const resolved: ThemeMode = mode ?? themeConfig.defaultMode;
  const palette = themeConfig.modes[resolved];
  const root = document.documentElement;

  root.dataset.theme = resolved;
  root.style.colorScheme = resolved;

  root.style.setProperty("--app-primary", themeConfig.primaryColor);
  root.style.setProperty("--app-accent", themeConfig.secondaryAccent);
  root.style.setProperty("--app-accent-glow", themeConfig.accentGlow);
  root.style.setProperty("--app-background", palette.background);
  root.style.setProperty("--app-foreground", palette.foreground);
  root.style.setProperty("--app-surface", palette.surface);
  root.style.setProperty("--app-surface-elevated", palette.surfaceElevated);
  root.style.setProperty("--app-muted", palette.muted);
  root.style.setProperty("--app-muted-foreground", palette.mutedForeground);
  root.style.setProperty("--app-border", palette.border);
  root.style.setProperty("--app-primary-foreground", palette.primaryForeground);
  root.style.setProperty("--app-radius", themeConfig.borderRadius);
  root.style.setProperty("--app-radius-sm", themeConfig.radius.sm);
  root.style.setProperty("--app-radius-md", themeConfig.radius.md);
  root.style.setProperty("--app-radius-lg", themeConfig.radius.lg);
  root.style.setProperty("--app-radius-xl", themeConfig.radius.xl);
  root.style.setProperty("--app-font", themeConfig.fontFamily);
  root.style.setProperty(
    "--app-glass",
    themeConfig.enableGlassmorphism ? "1" : "0",
  );
}

applyTheme();
