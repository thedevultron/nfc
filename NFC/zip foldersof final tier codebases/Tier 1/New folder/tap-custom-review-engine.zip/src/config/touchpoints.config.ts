/**
 * TOUCHPOINTS — vertical content, copy, hub links, Wi-Fi, vCard, menu.
 * Every user-facing string lives here.
 *
 * Edit /src/config/touchpoints.config.ts to change copy, links, and
 * credentials — do not modify components.
 */
import type { TouchpointsConfig } from "@/types/template.types";

export const touchpointsConfig: TouchpointsConfig = {
  vertical: "RESTAURANT",
  icons: {
    primary: "Utensils",
    secondary: "Star",
    wifi: "Wifi",
    reservations: "MessageSquare",
  },
  hub: [
    {
      id: "reserve",
      label: "Reserve a Table",
      icon: "MessageSquare",
      url: "https://wa.me/919876543210",
      external: true,
      action: "external",
    },
    {
      id: "menu",
      label: "View Digital Menu",
      icon: "BookOpen",
      url: "/menu",
      external: false,
      action: "menu",
    },
    {
      id: "wifi",
      label: "Connect to WiFi",
      icon: "Wifi",
      action: "wifi",
    },
    {
      id: "review",
      label: "Leave a Review",
      icon: "Star",
      action: "review",
    },
  ],
  wifi: {
    ssid: "Bistro_Guest",
    password: "welcome123",
    security: "WPA",
  },
  vcard: {
    name: "The Grand Bistro",
    phone: "+919876543210",
    org: "Hospitality",
    email: "hello@thegrandbistro.example",
    website: "https://thegrandbistro.example",
    note: "Pune · Reservations & private dining",
  },
  menu: [
    {
      name: "To begin",
      items: [
        {
          name: "Truffle Burrata",
          description: "Heirloom tomato, basil oil, warm focaccia",
          price: "890",
        },
        {
          name: "Charred Octopus",
          description: "Smoked paprika, lemon, fennel pollen",
          price: "1,140",
        },
      ],
    },
    {
      name: "From the kitchen",
      items: [
        {
          name: "Slow-roasted Lamb",
          description: "Rosemary jus, pomme purée, charred leek",
          price: "2,240",
        },
        {
          name: "Catch of the Day",
          description: "Brown butter, capers, garden herbs",
          price: "1,980",
        },
        {
          name: "Wild Mushroom Risotto",
          description: "Aged parmesan, thyme, white truffle oil",
          price: "1,460",
        },
      ],
    },
    {
      name: "To finish",
      items: [
        {
          name: "Dark Chocolate Fondant",
          description: "Vanilla bean ice cream, sea salt",
          price: "720",
        },
      ],
    },
  ],
  copy: {
    loading: "Setting your table...",
    loadingHint: "A moment, please.",
    nfcBanner: "Table-side touchpoint",
    nfcLive: "Live",
    greeting: "How was your meal?",
    greetingHint: "Tap a star — it takes two seconds.",
    reviewHighTitle: "We're delighted.",
    reviewHighSubtitle: "A public note helps other diners find our table.",
    reviewHighCta: "Post on Google Maps",
    reviewLowTitle: "Tell us what went wrong",
    reviewLowSubtitle: "This goes straight to the owner, not public.",
    feedbackPlaceholder:
      "The service, the timing, the dish — whatever we should know.",
    feedbackSubmit: "Send privately",
    feedbackSending: "Sending…",
    successTitle: "Received — thank you.",
    successSubtitle: "The owner will see this today.",
    errorTitle: "Couldn't send just now",
    errorSubtitle: "Please try again in a moment.",
    wifiTitle: "Table Wi-Fi",
    wifiSubtitle: "Connect in one tap. The password never leaves this card.",
    wifiCopyPassword: "Copy Password",
    wifiCopied: "Copied",
    wifiShowQr: "Show QR code",
    wifiHideQr: "Hide QR code",
    wifiNetwork: "Network",
    wifiPassword: "Password",
    contactTitle: "Keep us close",
    contactSubtitle: "Save the bistro to your phone.",
    contactSave: "Save Contact",
    contactSaved: "Saved",
    contactWhatsapp: "WhatsApp",
    contactCall: "Call",
    hubTitle: "At your table",
    hubSubtitle: "Reservations, the menu, Wi-Fi, and a quiet word.",
    menuTitle: "Tonight's menu",
    menuSubtitle: "Seasonal, from the kitchen.",
    footer: "A private dining touchpoint",
    panelReview: "Review",
    panelExplore: "Explore",
    close: "Close",
    retry: "Try again",
  },
};
