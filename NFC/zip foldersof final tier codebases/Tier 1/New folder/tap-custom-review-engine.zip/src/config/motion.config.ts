/**
 * MOTION — single source of truth for ALL animation physics and haptics.
 * Components must import tokens from here. Never hardcode springs, scales,
 * stagger timings, or vibrate patterns inline.
 *
 * Edit /src/config/motion.config.ts to change feel — do not modify components.
 */
import type { MotionConfig, ReducedMotionPreset } from "@/types/template.types";

export const motionConfig: MotionConfig = {
  springs: {
    // Buttons, taps, press feedback.
    snappy: { type: "spring", stiffness: 500, damping: 32, mass: 0.9 },
    // Card entrances, page transitions.
    smooth: { type: "spring", stiffness: 300, damping: 30, mass: 1 },
    // Star rating pop, delight moments.
    elastic: { type: "spring", stiffness: 420, damping: 18, mass: 1 },
    // Bottom sheets, drawers.
    drawer: { type: "spring", stiffness: 380, damping: 38 },
  },
  stagger: {
    children: 0.045,
    delayChildren: 0.08,
  },
  press: {
    scale: 0.96,
    brightness: 0.94,
  },
  hover: {
    scale: 1.02,
  },
  haptics: {
    tap: 8,
    selection: 12,
    success: [10, 40, 10],
    error: [20, 30, 20, 30],
  },
  reducedMotionMs: 150,
  pageSlideY: 20,
  drawerDismissVelocity: 500,
  drawerDismissOffset: 120,
  rubberBand: 0.45,
  rubberBandTop: 0.06,
  starPop: [1, 1.35, 1],
  starRippleMs: 40,
  chevronNudge: 2,
  iconSettleRotate: 6,
  skeletonMinMs: 280,
  skeletonMaxMs: 380,
  maxDurationMs: 500,
  confetti: {
    count: 8,
    spread: 86,
    fall: 148,
    duration: 0.48,
  },
  ringCircumference: 289,
  swipeThreshold: 64,
};

export const reducedMotionPreset: ReducedMotionPreset = {
  duration: motionConfig.reducedMotionMs / 1000,
  ease: "easeOut",
};

export const listStagger = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: motionConfig.stagger.children,
      delayChildren: motionConfig.stagger.delayChildren,
    },
  },
};

export const listItem = {
  hidden: { opacity: 0, y: motionConfig.pageSlideY },
  show: { opacity: 1, y: 0 },
};
