/**
 * CLIENT — business identity, landing mode, and webhook endpoints.
 *
 * Edit /src/config/client.config.ts to change business name, mode,
 * Google review URL, and n8n webhooks — do not modify components.
 */
import type { ClientConfig } from "@/types/template.types";

export const clientConfig: ClientConfig = {
  businessName: "The Grand Bistro",
  subtitle: "Thanks for dining with us today",
  activeMode: "REVIEW",
  secondaryPanel: "HUB",
  googleReviewUrl: "https://maps.google.com/?q=The+Grand+Bistro+Pune",
  n8nWebhookUrl: "https://n8n.yourdomain.com/webhook/tier1-analytics",
  n8nFeedbackWebhook: "https://n8n.yourdomain.com/webhook/tier1-feedback",
  touchpointId: "tap-grand-bistro-01",
  whatsappUrl: "https://wa.me/919876543210",
  callUrl: "tel:+919876543210",
};
