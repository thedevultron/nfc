/**
 * Shared contracts for the TAP Custom / Review Engine.
 * Components, hooks, and services MUST consume these types —
 * never hardcode business, motion, or theme shapes inline.
 *
 * Edit /src/config/*.ts to change values. Edit this file only
 * when introducing a new configurable surface.
 */

export type ActiveMode = "REVIEW" | "WIFI" | "CONTACT" | "HUB";

export type ThemeMode = "dark" | "light";

export type Vertical =
  | "RESTAURANT"
  | "HOTEL"
  | "RETAIL"
  | "SALON"
  | "CLINIC"
  | "GENERIC";

export type HubAction =
  | "external"
  | "internal"
  | "wifi"
  | "review"
  | "contact"
  | "menu";

export type HapticName = "tap" | "selection" | "success" | "error";

export type SpringName = "snappy" | "smooth" | "elastic" | "drawer";

export type PanelId = "REVIEW" | "HUB";

export interface SpringPreset {
  type: "spring";
  stiffness: number;
  damping: number;
  mass?: number;
}

export interface ReducedMotionPreset {
  duration: number;
  ease: "easeOut" | "linear" | "easeInOut";
}

export interface MotionConfig {
  springs: Record<SpringName, SpringPreset>;
  stagger: {
    children: number;
    delayChildren: number;
  };
  press: {
    scale: number;
    brightness: number;
  };
  hover: {
    scale: number;
  };
  haptics: {
    tap: number;
    selection: number;
    success: number[];
    error: number[];
  };
  reducedMotionMs: number;
  pageSlideY: number;
  drawerDismissVelocity: number;
  drawerDismissOffset: number;
  rubberBand: number;
  rubberBandTop: number;
  starPop: number[];
  starRippleMs: number;
  chevronNudge: number;
  iconSettleRotate: number;
  skeletonMinMs: number;
  skeletonMaxMs: number;
  maxDurationMs: number;
  confetti: {
    count: number;
    spread: number;
    fall: number;
    duration: number;
  };
  ringCircumference: number;
  swipeThreshold: number;
}

export interface ThemePalette {
  background: string;
  foreground: string;
  surface: string;
  surfaceElevated: string;
  muted: string;
  mutedForeground: string;
  border: string;
  primaryForeground: string;
}

export interface RadiusScale {
  sm: string;
  md: string;
  lg: string;
  xl: string;
  full: string;
}

export interface ThemeConfig {
  primaryColor: string;
  secondaryAccent: string;
  accentGlow: string;
  backgroundColor: string;
  surfaceColor: string;
  borderRadius: string;
  radius: RadiusScale;
  fontFamily: string;
  enableGlassmorphism: boolean;
  defaultMode: ThemeMode;
  modes: Record<ThemeMode, ThemePalette>;
}

export interface ClientConfig {
  businessName: string;
  subtitle: string;
  activeMode: ActiveMode;
  secondaryPanel: PanelId;
  googleReviewUrl: string;
  n8nWebhookUrl: string;
  n8nFeedbackWebhook: string;
  touchpointId: string;
  whatsappUrl: string;
  callUrl: string;
}

export interface HubItem {
  id: string;
  label: string;
  icon: string;
  url?: string;
  external?: boolean;
  action: HubAction;
}

export interface WifiCredentials {
  ssid: string;
  password: string;
  security: "WPA" | "WEP" | "nopass";
}

export interface VCardFields {
  name: string;
  phone: string;
  org: string;
  email?: string;
  website?: string;
  note?: string;
}

export interface MenuItem {
  name: string;
  description: string;
  price: string;
}

export interface MenuCategory {
  name: string;
  items: MenuItem[];
}

export interface TouchpointCopy {
  loading: string;
  loadingHint: string;
  nfcBanner: string;
  nfcLive: string;
  greeting: string;
  greetingHint: string;
  reviewHighTitle: string;
  reviewHighSubtitle: string;
  reviewHighCta: string;
  reviewLowTitle: string;
  reviewLowSubtitle: string;
  feedbackPlaceholder: string;
  feedbackSubmit: string;
  feedbackSending: string;
  successTitle: string;
  successSubtitle: string;
  errorTitle: string;
  errorSubtitle: string;
  wifiTitle: string;
  wifiSubtitle: string;
  wifiCopyPassword: string;
  wifiCopied: string;
  wifiShowQr: string;
  wifiHideQr: string;
  wifiNetwork: string;
  wifiPassword: string;
  contactTitle: string;
  contactSubtitle: string;
  contactSave: string;
  contactSaved: string;
  contactWhatsapp: string;
  contactCall: string;
  hubTitle: string;
  hubSubtitle: string;
  menuTitle: string;
  menuSubtitle: string;
  footer: string;
  panelReview: string;
  panelExplore: string;
  close: string;
  retry: string;
}

export interface TouchpointsConfig {
  vertical: Vertical;
  icons: {
    primary: string;
    secondary: string;
    wifi: string;
    reservations: string;
  };
  hub: HubItem[];
  wifi: WifiCredentials;
  vcard: VCardFields;
  menu: MenuCategory[];
  copy: TouchpointCopy;
}

export interface AnalyticsEvent {
  type: "mount" | "cta" | "rating" | "feedback" | "copy" | "vcard" | "hub";
  touchpointId: string;
  timestamp: string;
  meta?: Record<string, string | number | boolean | null>;
}

export interface FeedbackPayload {
  rating: number;
  feedbackText: string;
  timestamp: string;
  touchpointId: string;
}

export interface ApiResult {
  ok: boolean;
  status?: number;
}

export type IconName = string;
