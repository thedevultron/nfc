/**
 * Icon registry — maps config string names to Lucide components.
 * Add a name here when introducing a new icon token in touchpoints.config.
 *
 * Edit /src/config/touchpoints.config.ts to pick an icon by name —
 * do not modify calling components.
 */
import type { LucideIcon } from "lucide-react";
import {
  BookOpen,
  ChefHat,
  ChevronRight,
  Circle,
  Clock,
  Copy,
  ExternalLink,
  MapPin,
  MessageCircle,
  MessageSquare,
  Nfc,
  Phone,
  QrCode,
  Sparkle,
  Star,
  UserPlus,
  Utensils,
  Wifi,
} from "lucide-react";

const ICON_MAP: Record<string, LucideIcon> = {
  BookOpen,
  ChefHat,
  ChevronRight,
  Circle,
  Clock,
  Copy,
  ExternalLink,
  MapPin,
  MessageCircle,
  MessageSquare,
  Nfc,
  Phone,
  QrCode,
  Sparkle,
  Star,
  UserPlus,
  Utensils,
  Wifi,
};

export function getIcon(name: string): LucideIcon {
  return ICON_MAP[name] ?? Circle;
}
