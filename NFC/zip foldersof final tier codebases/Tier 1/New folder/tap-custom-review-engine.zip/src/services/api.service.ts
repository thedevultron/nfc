/**
 * API — retry-safe n8n webhook POSTs. Non-blocking, keepalive-friendly.
 * Optimistic UI is the caller's responsibility; this module never throws
 * into the render path.
 *
 * Edit /src/config/client.config.ts to change webhook URLs —
 * do not modify this file.
 */
import { clientConfig } from "@/config/client.config";
import type { AnalyticsEvent, ApiResult, FeedbackPayload } from "@/types/template.types";

const MAX_RETRIES = 3;
const BASE_BACKOFF_MS = 400;

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function payloadOf(body: unknown): string {
  return JSON.stringify(body);
}

async function postWithRetry(url: string, body: unknown): Promise<ApiResult> {
  const serialized = payloadOf(body);

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: serialized,
        keepalive: true,
        mode: "cors",
      });

      if (response.ok) {
        return { ok: true, status: response.status };
      }

      if (response.status >= 400 && response.status < 500 && response.status !== 429) {
        return { ok: false, status: response.status };
      }
    } catch {
      // Network failure — retry.
    }

    if (attempt < MAX_RETRIES) {
      await sleep(BASE_BACKOFF_MS * 2 ** attempt);
    }
  }

  return { ok: false };
}

function beaconOrFetch(url: string, body: unknown): void {
  const serialized = payloadOf(body);

  if (typeof navigator !== "undefined" && typeof navigator.sendBeacon === "function") {
    try {
      const blob = new Blob([serialized], { type: "application/json" });
      const queued = navigator.sendBeacon(url, blob);
      if (queued) return;
    } catch {
      // Fall through to fetch.
    }
  }

  void postWithRetry(url, body);
}

export const api = {
  /** Fire-and-forget analytics. Never blocks the UI. */
  track(event: AnalyticsEvent): void {
    beaconOrFetch(clientConfig.n8nWebhookUrl, event);
  },

  /** Private feedback. Awaited so the UI can confirm delivery. */
  async sendFeedback(payload: FeedbackPayload): Promise<ApiResult> {
    return postWithRetry(clientConfig.n8nFeedbackWebhook, payload);
  },
};
