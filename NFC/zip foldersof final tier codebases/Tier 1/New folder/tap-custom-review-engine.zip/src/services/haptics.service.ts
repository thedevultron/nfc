/**
 * Haptics — navigator.vibrate abstraction.
 * Pattern values come exclusively from motion.config.
 *
 * Edit /src/config/motion.config.ts to change haptic patterns —
 * do not modify this file.
 */
import { motionConfig } from "@/config/motion.config";
import type { HapticName } from "@/types/template.types";

function canVibrate(): boolean {
  return typeof navigator !== "undefined" && typeof navigator.vibrate === "function";
}

export const haptics = {
  play(name: HapticName): void {
    if (!canVibrate()) return;
    const pattern = motionConfig.haptics[name];
    try {
      navigator.vibrate(pattern);
    } catch {
      // Some browsers expose vibrate but reject it outside a user gesture.
    }
  },
  tap(): void {
    this.play("tap");
  },
  selection(): void {
    this.play("selection");
  },
  success(): void {
    this.play("success");
  },
  error(): void {
    this.play("error");
  },
};
