/**
 * Shared contracts for the Tier-1 Tap Custom / Review Engine.
 * Components, hooks and services all program against these shapes —
 * the /src/config files provide the runtime values.
 */
import type { Transition, Variants } from "framer-motion";

/* ── Modes ─────────────────────────────────────────────────── */

export type ActiveMode = "REVIEW" | "WIFI" | "CONTACT" | "HUB";

/* ── Theme ─────────────────────────────────────────────────── */

export interface ThemeConfig {
  /** Primary brand color — full hsl() string. */
  primaryColor: string;
  /** Secondary accent (badges, WhatsApp glow, success tints). */
  secondaryAccent: string;
  /** Ambient glow painted behind primary CTAs (primary @ ~25% alpha). */
  accentGlow: string;
  /** Secondary glow for emerald-tinted actions. */
  secondaryGlow: string;
  backgroundColor: string;
  surfaceColor: string;
  elevatedColor: string;
  foregroundColor: string;
  mutedForegroundColor: string;
  successColor: string;
  dangerColor: string;
  /** Single radius token shared by cards, buttons, drawers. */
  borderRadius: string;
  fontFamily: string;
  /** Tight tracking for display type, e.g. "-0.02em". */
  headingTracking: string;
  enableGlassmorphism: boolean;
  defaultMode: "dark" | "light";
}

/* ── Motion ────────────────────────────────────────────────── */

export type SpringName = "snappy" | "smooth" | "elastic" | "drawer";
export type HapticPatternName = "tap" | "selection" | "success" | "error";

export interface MotionConfig {
  springs: Record<SpringName, Transition>;
  stagger: { children: number; delayChildren: number };
  press: { scale: number; brightness: number };
  hover: { scale: number };
  /** Page / mode transitions: vertical slide (px) + exit duration (s). */
  page: { offsetY: number; exitDuration: number };
  /** Star rating physics: overshoot keyframes + per-adjacent-star ripple delay (s). */
  star: { pop: [number, number, number]; rippleDelay: number };
  /** Confetti-lite burst on the public review CTA. */
  confetti: { count: number; rise: number; fall: number; spread: number; duration: number };
  /** Brand mark "menu opening" settle (degrees, negative = counter-clockwise). */
  brand: { rotateSettle: number };
  /** iOS-sheet dismiss thresholds for drag-to-close drawers. */
  sheet: { dismissDistance: number; dismissVelocity: number };
  /** Horizontal swipe distance (px) that flips between landing panels. */
  swipe: { distance: number };
  /** Fallback timing when prefers-reduced-motion is set. */
  reduced: { duration: number };
  haptics: Record<HapticPatternName, number | number[]>;
}

/* ── Client / business ─────────────────────────────────────── */

export interface ClientConfig {
  businessName: string;
  subtitle: string;
  activeMode: ActiveMode;
  googleReviewUrl: string;
  n8nWebhookUrl: string;
  n8nFeedbackWebhook: string;
  /** Stable id attached to every analytics + feedback payload. */
  touchpointId: string;
  /** Human label shown in the NFC context banner, e.g. "Table 12". */
  tableLabel: string;
}

/* ── Touchpoints / vertical content ────────────────────────── */

export interface HubLink {
  label: string;
  sublabel?: string;
  /** Lucide icon name — resolved through the shared icon registry. */
  icon: string;
  /**
   * `https://…`      → opens externally
   * `/menu`          → in-app digital menu sheet
   * `internal:MODE`  → switches the active mode (WIFI / CONTACT / REVIEW / HUB)
   */
  url: string;
  external: boolean;
  /** Tint of the leading icon chip. */
  tint?: "primary" | "secondary";
}

export interface WifiConfig {
  ssid: string;
  password: string;
  security: "WPA" | "WEP" | "nopass";
}

export interface VCardConfig {
  name: string;
  org: string;
  phone: string;
  email: string;
  url: string;
  address: string;
}

export interface MenuItem {
  name: string;
  price: string;
  note?: string;
}

export interface MenuCategory {
  category: string;
  items: MenuItem[];
}

export interface ReviewCopy {
  prompt: string;
  labels: [string, string, string, string, string];
  publicTitle: string;
  publicBody: string;
  publicCta: string;
  feedbackTitle: string;
  privatePrompt: string;
  feedbackPlaceholder: string;
  feedbackHint: string;
  feedbackSubmit: string;
  feedbackSuccess: string;
  feedbackDone: string;
  resetRating: string;
  thanksTitle: string;
}

export interface CopyStrings {
  loading: string;
  nfcConnected: string;
  nfcJustNow: string;
  segmentReview: string;
  segmentHub: string;
  backToHub: string;
  review: ReviewCopy;
  wifi: {
    title: string;
    subtitle: string;
    networkLabel: string;
    securityLabel: string;
    passwordLabel: string;
    copyPassword: string;
    copied: string;
    qrButton: string;
    qrTitle: string;
    qrHint: string;
    qrCopy: string;
  };
  contact: {
    title: string;
    body: string;
    saveCta: string;
    saved: string;
    whatsapp: string;
    call: string;
  };
  hub: { title: string; body: string; swipeHint: string };
  menu: { title: string; subtitle: string };
  footer: string;
  footerBadge: string;
}

export interface TouchpointsConfig {
  vertical: string;
  touchpointIdNote: string;
  icons: { primary: string; secondary: string };
  copy: CopyStrings;
  hub: HubLink[];
  wifi: WifiConfig;
  vcard: VCardConfig;
  whatsappNumber: string;
  menu: MenuCategory[];
}

/* ── Analytics / API ───────────────────────────────────────── */

export interface AnalyticsPayload {
  event: string;
  sessionId: string;
  touchpointId: string;
  mode: ActiveMode;
  timestamp: string;
  [key: string]: unknown;
}

export interface FeedbackPayload {
  rating: number;
  feedbackText: string;
  timestamp: string;
  touchpointId: string;
}

/** Centralised variant factories live in motion.config.ts. */
export type VariantFactory = (reduced: boolean) => Variants;
