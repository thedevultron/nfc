import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
// Self-hosted variable font — zero network round-trips, PWA-safe.
import "@fontsource-variable/geist";
import "./index.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
