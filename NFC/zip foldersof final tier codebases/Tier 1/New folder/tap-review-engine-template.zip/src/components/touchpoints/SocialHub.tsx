import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { cn } from "@/utils/cn";
import { listVariants, listItemVariants, cardVariants } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { useSpringPress } from "@/hooks/useSpringPress";
import { resolveIcon } from "@/components/touchpoints/iconRegistry";
import { MenuSheet } from "@/components/touchpoints/MenuSheet";
import type { ActiveMode, HubLink } from "@/types/template.types";

/**
 * MODULE D — MULTI-LINK SOCIAL HUB.
 * Rows are 100% data-driven from /src/config/touchpoints.config.ts → hub.
 * `internal:MODE` urls switch panels, `/menu` opens the menu sheet,
 * anything else opens externally. Edit config — do not modify this file.
 */
export interface SocialHubProps {
  onNavigate: (mode: ActiveMode) => void;
}

function HubRow({ link, onPress }: { link: HubLink; onPress: () => void }) {
  const press = useSpringPress("tap");
  const Icon = resolveIcon(link.icon);
  const tint =
    link.tint === "secondary"
      ? "border-secondary/25 bg-secondary/15 text-secondary"
      : "border-primary/25 bg-primary/15 text-primary";

  return (
    <motion.button
      type="button"
      onClick={onPress}
      whileTap={press.whileTap}
      transition={press.transition}
      className="group glass flex w-full items-center gap-3.5 rounded-card p-3.5 text-left transition-colors duration-200 hover:bg-white/10"
    >
      <span
        className={cn(
          "flex h-10 w-10 shrink-0 items-center justify-center rounded-[calc(var(--radius)*0.66)] border",
          tint
        )}
      >
        <Icon className="h-5 w-5" strokeWidth={2} aria-hidden />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-medium text-foreground">{link.label}</span>
        {link.sublabel && (
          <span className="mt-0.5 block truncate text-[12px] text-muted">{link.sublabel}</span>
        )}
      </span>
      {/* Chevron nudges 2px on hover/press — the affordance tick. */}
      <ChevronRight
        className="h-4 w-4 shrink-0 text-muted transition-transform duration-200 group-hover:translate-x-[2px] group-active:translate-x-[2px]"
        aria-hidden
      />
    </motion.button>
  );
}

export default function SocialHub({ onNavigate }: SocialHubProps) {
  const track = useTapAnalytics();
  const reduced = useReducedMotion();
  const copy = touchpointsConfig.copy.hub;
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLink = (link: HubLink) => {
    track("hub_link_tapped", { label: link.label, url: link.url });
    if (link.url.startsWith("internal:")) {
      const target = link.url.split(":")[1] as ActiveMode;
      haptics.play("selection");
      onNavigate(target);
    } else if (link.url === "/menu") {
      setMenuOpen(true);
    } else {
      window.open(link.url, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <section className="flex flex-col gap-4">
      <motion.header variants={cardVariants(reduced)} initial="hidden" animate="show" className="px-1">
        <h2
          className="text-xl font-semibold text-foreground"
          style={{ letterSpacing: themeConfig.headingTracking }}
        >
          {copy.title}
        </h2>
        <p className="mt-1 text-sm text-muted">{copy.body}</p>
      </motion.header>

      <motion.ul
        variants={listVariants(reduced)}
        initial="hidden"
        animate="show"
        className="flex flex-col gap-2.5"
      >
        {touchpointsConfig.hub.map((link) => (
          <motion.li key={link.label} variants={listItemVariants(reduced)} className="list-none">
            <HubRow link={link} onPress={() => handleLink(link)} />
          </motion.li>
        ))}
      </motion.ul>

      <motion.p
        variants={cardVariants(reduced)}
        initial="hidden"
        animate="show"
        className="px-1 text-center text-[11px] text-muted/60"
      >
        {copy.swipeHint}
      </motion.p>

      <MenuSheet open={menuOpen} onClose={() => setMenuOpen(false)} />
    </section>
  );
}
