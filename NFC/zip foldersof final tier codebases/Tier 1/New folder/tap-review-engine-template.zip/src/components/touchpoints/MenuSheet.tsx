import { motion } from "framer-motion";
import { Badge } from "@/components/ui/Badge";
import { Drawer } from "@/components/ui/Drawer";
import { listVariants, listItemVariants } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/**
 * MENU SHEET — serves the internal `/menu` hub link so no tap is a dead end.
 * Menu content lives in /src/config/touchpoints.config.ts → menu.
 * Do not modify this file — edit config to change dishes/prices.
 */
export interface MenuSheetProps {
  open: boolean;
  onClose: () => void;
}

export function MenuSheet({ open, onClose }: MenuSheetProps) {
  const reduced = useReducedMotion();
  const { menu } = touchpointsConfig;
  const copy = touchpointsConfig.copy.menu;

  return (
    <Drawer open={open} onClose={onClose} title={copy.title}>
      <Badge variant="primary" className="mb-4 tabular-nums">
        {copy.subtitle}
      </Badge>
      <motion.div
        variants={listVariants(reduced)}
        initial="hidden"
        animate={open ? "show" : "hidden"}
        className="flex flex-col gap-5 pb-1"
      >
        {menu.map((section) => (
          <motion.section key={section.category} variants={listItemVariants(reduced)}>
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary/90">
              {section.category}
            </h3>
            <ul className="mt-2 flex flex-col">
              {section.items.map((item) => (
                <li
                  key={item.name}
                  className="flex items-baseline justify-between gap-4 border-b border-white/5 py-2.5 last:border-0"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-foreground">{item.name}</p>
                    {item.note && <p className="mt-0.5 truncate text-[12px] text-muted">{item.note}</p>}
                  </div>
                  <span className="shrink-0 text-sm font-semibold tabular-nums text-primary">{item.price}</span>
                </li>
              ))}
            </ul>
          </motion.section>
        ))}
      </motion.div>
    </Drawer>
  );
}
