import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, MessageCircle, Phone, UserPlus } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { cardVariants, listVariants, listItemVariants, spring } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";

/**
 * MODULE C — DYNAMIC CONTACT / VCARD.
 * vCard fields from /src/config/touchpoints.config.ts → vcard.
 * Generates a downloadable .vcf blob 100% client-side.
 * Do not modify this file — edit touchpoints.config for new venues.
 */
export default function VCardSheet() {
  const track = useTapAnalytics();
  const reduced = useReducedMotion();
  const copy = touchpointsConfig.copy.contact;
  const { vcard, whatsappNumber } = touchpointsConfig;
  const [saved, setSaved] = useState(false);

  const buildVcf = () =>
    [
      "BEGIN:VCARD",
      "VERSION:3.0",
      `N:;${vcard.name};;;`,
      `FN:${vcard.name}`,
      `ORG:${vcard.org}`,
      `TEL;TYPE=CELL:${vcard.phone}`,
      `EMAIL:${vcard.email}`,
      `URL:${vcard.url}`,
      `ADR;TYPE=WORK:;;${vcard.address}`,
      "END:VCARD",
      "",
    ].join("\r\n");

  const handleSave = () => {
    const blob = new Blob([buildVcf()], { type: "text/vcard;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${vcard.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.vcf`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);
    haptics.play("success");
    track("vcard_saved");
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };

  return (
    <motion.div variants={listVariants(reduced)} initial="hidden" animate="show" className="flex flex-col gap-4">
      <motion.div variants={cardVariants(reduced)}>
        <Card className="p-6">
          <span className="flex h-12 w-12 items-center justify-center rounded-[calc(var(--radius)*0.72)] border border-secondary/25 bg-secondary/15 text-secondary glow-secondary">
            <UserPlus className="h-6 w-6" strokeWidth={2} aria-hidden />
          </span>
          <h2
            className="mt-4 text-xl font-semibold text-foreground"
            style={{ letterSpacing: themeConfig.headingTracking }}
          >
            {copy.title}
          </h2>
          <p className="mt-1.5 text-sm leading-relaxed text-muted">{copy.body}</p>

          <div className="relative mt-5">
            <Button variant={saved ? "success" : "primary"} size="lg" glow={!saved} className="w-full" onClick={handleSave}>
              <AnimatePresence mode="wait" initial={false}>
                <motion.span
                  key={saved ? "saved" : "save"}
                  initial={{ opacity: 0, y: reduced ? 0 : 6, scale: reduced ? 1 : 0.7 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: reduced ? 0 : -6, scale: reduced ? 1 : 0.7 }}
                  transition={spring("snappy", reduced)}
                  className="flex items-center gap-2"
                >
                  {saved ? <Check className="h-4 w-4" aria-hidden /> : <UserPlus className="h-4 w-4" aria-hidden />}
                  {saved ? copy.saved : copy.saveCta}
                </motion.span>
              </AnimatePresence>
            </Button>
          </div>
        </Card>
      </motion.div>

      {/* Secondary row — staggered in, each with its own brand-tint glow. */}
      <motion.div variants={listVariants(reduced)} className="grid grid-cols-2 gap-2.5">
        <motion.div variants={listItemVariants(reduced)}>
          <Button
            href={`https://wa.me/${whatsappNumber}`}
            external
            variant="secondary"
            size="lg"
            className="w-full border-secondary/25 text-foreground glow-secondary"
          >
            <MessageCircle className="h-4 w-4 text-secondary" aria-hidden />
            {copy.whatsapp}
          </Button>
        </motion.div>
        <motion.div variants={listItemVariants(reduced)}>
          <Button
            href={`tel:${vcard.phone}`}
            variant="secondary"
            size="lg"
            className="w-full border-primary/25 text-foreground glow-primary"
          >
            <Phone className="h-4 w-4 text-primary" aria-hidden />
            {copy.call}
          </Button>
        </motion.div>
      </motion.div>

      <motion.p
        variants={listItemVariants(reduced)}
        className="text-center text-[12px] tabular-nums text-muted/70"
      >
        {vcard.phone} · {vcard.org}
      </motion.p>
    </motion.div>
  );
}
