import {
  AtSign,
  BookOpen,
  CalendarClock,
  Camera,
  Coffee,
  ExternalLink,
  Gift,
  Globe,
  Mail,
  MapPin,
  MessageCircle,
  MessageSquare,
  Music,
  Phone,
  ShoppingBag,
  Star,
  UserPlus,
  Utensils,
  Wifi,
  Wine,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

/**
 * ICON REGISTRY — resolves the string icon names stored in
 * /src/config/touchpoints.config.ts to Lucide components.
 * To offer a new icon in config, add its Lucide import here
 * (this is the ONLY component-side mapping; content stays in config).
 */
export const iconRegistry: Record<string, LucideIcon> = {
  AtSign,
  BookOpen,
  CalendarClock,
  Camera,
  Coffee,
  ExternalLink,
  Gift,
  Globe,
  Mail,
  MapPin,
  MessageCircle,
  MessageSquare,
  Music,
  Phone,
  ShoppingBag,
  Star,
  UserPlus,
  Utensils,
  Wifi,
  Wine,
};

export function resolveIcon(name: string): LucideIcon {
  return iconRegistry[name] ?? Globe;
}
