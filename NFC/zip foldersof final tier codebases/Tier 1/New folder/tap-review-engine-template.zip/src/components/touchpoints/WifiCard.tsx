import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy, Eye, EyeOff, QrCode, Wifi } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Dialog } from "@/components/ui/Dialog";
import { motionConfig, cardVariants, spring } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { haptics } from "@/services/haptics.service";
import { copyToClipboard } from "@/utils/clipboard";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";

/**
 * MODULE B — INSTANT WIFI TOUCHPOINT.
 * SSID/password/security come from /src/config/touchpoints.config.ts → wifi.
 * Copy → clipboard + success haptic + inline checkmark morph (no toasts).
 * Do not modify this file — edit touchpoints.config to change credentials.
 */
export default function WifiCard() {
  const track = useTapAnalytics();
  const reduced = useReducedMotion();
  const copy = touchpointsConfig.copy.wifi;
  const { wifi } = touchpointsConfig;

  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [payloadCopied, setPayloadCopied] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const timers = useRef<number[]>([]);

  // Native WiFi provisioning payload — scannable by any QR generator.
  const payload = `WIFI:T:${wifi.security};S:${wifi.ssid};P:${wifi.password};;`;

  const handleCopyPassword = async () => {
    const ok = await copyToClipboard(wifi.password);
    if (!ok) {
      haptics.play("error");
      return;
    }
    haptics.play("success");
    setCopied(true);
    track("wifi_password_copied");
    timers.current.push(window.setTimeout(() => setCopied(false), 1800));
  };

  const handleCopyPayload = async () => {
    const ok = await copyToClipboard(payload);
    if (!ok) {
      haptics.play("error");
      return;
    }
    haptics.play("success");
    setPayloadCopied(true);
    track("wifi_payload_copied");
    timers.current.push(window.setTimeout(() => setPayloadCopied(false), 1800));
  };

  return (
    <motion.div variants={cardVariants(reduced)} initial="hidden" animate="show" className="flex flex-col gap-5">
      <Card className="p-5">
        <div className="flex items-center gap-3.5">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[calc(var(--radius)*0.72)] border border-primary/25 bg-primary/15 text-primary shadow-[0_0_24px_var(--accent-glow)]">
            <Wifi className="h-5 w-5" strokeWidth={2} aria-hidden />
          </span>
          <div className="min-w-0">
            <h2
              className="text-base font-semibold text-foreground"
              style={{ letterSpacing: themeConfig.headingTracking }}
            >
              {copy.title}
            </h2>
            <p className="mt-0.5 text-[13px] text-muted">{copy.subtitle}</p>
          </div>
        </div>

        <div className="mt-5 flex flex-col divide-y divide-white/6">
          <div className="flex items-center justify-between py-3">
            <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted/80">
              {copy.networkLabel}
            </span>
            <span className="truncate pl-4 text-sm font-medium text-foreground">{wifi.ssid}</span>
          </div>
          <div className="flex items-center justify-between py-3">
            <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted/80">
              {copy.securityLabel}
            </span>
            <Badge variant="outline" className="tabular-nums">{wifi.security}</Badge>
          </div>
          <div className="flex items-center justify-between gap-3 py-3">
            <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted/80">
              {copy.passwordLabel}
            </span>
            <span className="flex items-center gap-2">
              <span className="truncate font-mono text-sm tabular-nums text-foreground">
                {revealed ? wifi.password : "•".repeat(Math.max(wifi.password.length, 10))}
              </span>
              <motion.button
                type="button"
                aria-label={revealed ? "Hide password" : "Show password"}
                aria-pressed={revealed}
                whileTap={{ scale: motionConfig.press.scale }}
                onTapStart={() => haptics.play("tap")}
                onClick={() => setRevealed((r) => !r)}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-muted transition-colors duration-200 hover:text-foreground"
              >
                <AnimatePresence mode="wait" initial={false}>
                  <motion.span
                    key={revealed ? "hide" : "show"}
                    initial={{ opacity: 0, scale: 0.5, rotate: reduced ? 0 : -40 }}
                    animate={{ opacity: 1, scale: 1, rotate: 0 }}
                    exit={{ opacity: 0, scale: 0.5, rotate: reduced ? 0 : 40 }}
                    transition={spring("snappy", reduced)}
                    className="flex"
                  >
                    {revealed ? <EyeOff className="h-4 w-4" aria-hidden /> : <Eye className="h-4 w-4" aria-hidden />}
                  </motion.span>
                </AnimatePresence>
              </motion.button>
            </span>
          </div>
        </div>

        <div className="mt-2 flex gap-2.5">
          <Button variant="primary" glow className="flex-1" onClick={handleCopyPassword}>
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={copied ? "done" : "copy"}
                initial={{ opacity: 0, y: reduced ? 0 : 6, scale: reduced ? 1 : 0.7 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: reduced ? 0 : -6, scale: reduced ? 1 : 0.7 }}
                transition={spring("snappy", reduced)}
                className="flex items-center gap-2"
              >
                {copied ? <Check className="h-4 w-4" aria-hidden /> : <Copy className="h-4 w-4" aria-hidden />}
                {copied ? copy.copied : copy.copyPassword}
              </motion.span>
            </AnimatePresence>
          </Button>
          <Button variant="secondary" onClick={() => setQrOpen(true)}>
            <QrCode className="h-4 w-4" aria-hidden />
            {copy.qrButton}
          </Button>
        </div>
      </Card>

      <Dialog open={qrOpen} onClose={() => setQrOpen(false)} title={copy.qrTitle}>
        <p className="text-[13px] leading-relaxed text-muted">{copy.qrHint}</p>
        <code className="mt-3 block break-all rounded-[calc(var(--radius)*0.66)] border border-white/10 bg-black/40 p-3 font-mono text-[12px] leading-relaxed text-primary">
          {payload}
        </code>
        <Button variant="secondary" size="sm" className="mt-4 w-full" onClick={handleCopyPayload}>
          <AnimatePresence mode="wait" initial={false}>
            <motion.span
              key={payloadCopied ? "done" : "copy"}
              initial={{ opacity: 0, scale: reduced ? 1 : 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: reduced ? 1 : 0.8 }}
              transition={spring("snappy", reduced)}
              className="flex items-center gap-2"
            >
              {payloadCopied ? <Check className="h-3.5 w-3.5" aria-hidden /> : <Copy className="h-3.5 w-3.5" aria-hidden />}
              {payloadCopied ? copy.copied : copy.qrCopy}
            </motion.span>
          </AnimatePresence>
        </Button>
      </Dialog>
    </motion.div>
  );
}
