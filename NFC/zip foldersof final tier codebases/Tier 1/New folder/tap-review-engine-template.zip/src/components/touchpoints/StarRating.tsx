import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { cn } from "@/utils/cn";
import { motionConfig, spring } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/**
 * STAR RATING — elastic overshoot pop with a 40ms-per-adjacent-star
 * ripple cascade. Pop keyframes + ripple delay + haptic pattern come
 * from /src/config/motion.config.ts — edit config, do not modify this file.
 */
const STARS = [1, 2, 3, 4, 5] as const;

export interface StarRatingProps {
  value: number;
  onChange: (value: number) => void;
}

export function StarRating({ value, onChange }: StarRatingProps) {
  const reduced = useReducedMotion();

  return (
    <div role="radiogroup" aria-label="Rate your visit" className="flex items-center justify-center gap-0.5">
      {STARS.map((star, idx) => {
        const filled = star <= value;
        const distance = value > 0 ? Math.abs(star - value) : 0;
        return (
          <motion.button
            key={star}
            type="button"
            role="radio"
            aria-checked={value === star}
            aria-label={`${star} star${star > 1 ? "s" : ""}`}
            initial={reduced ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.85 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ ...spring("smooth", reduced), delay: motionConfig.stagger.delayChildren + idx * motionConfig.stagger.children }}
            whileTap={{ scale: motionConfig.press.scale }}
            onTapStart={() => haptics.play("selection")}
            onClick={() => onChange(star)}
            className="rounded-full p-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
          >
            {/* Inner span owns the pop so it never fights the entrance animation. */}
            <motion.span
              className="block"
              animate={
                value > 0
                  ? { scale: [...motionConfig.star.pop], rotate: [0, -7, 0] }
                  : { scale: 1, rotate: 0 }
              }
              transition={{
                duration: reduced ? motionConfig.reduced.duration : 0.5,
                delay: distance * motionConfig.star.rippleDelay,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              <Star
                className={cn(
                  "h-9 w-9 transition-colors duration-200",
                  filled
                    ? "fill-primary text-primary drop-shadow-[0_0_14px_var(--accent-glow)]"
                    : "fill-white/5 text-white/25 hover:text-white/45"
                )}
                strokeWidth={1.8}
                aria-hidden
              />
            </motion.span>
          </motion.button>
        );
      })}
    </div>
  );
}
