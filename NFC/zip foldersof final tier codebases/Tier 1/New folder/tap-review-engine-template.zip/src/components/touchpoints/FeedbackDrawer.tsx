import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Send } from "lucide-react";
import { Drawer } from "@/components/ui/Drawer";
import { Textarea } from "@/components/ui/Textarea";
import { Button } from "@/components/ui/Button";
import { SuccessRing } from "@/components/ui/SuccessRing";
import { motionConfig } from "@/config/motion.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { clientConfig } from "@/config/client.config";
import { haptics } from "@/services/haptics.service";
import { submitFeedback } from "@/services/api.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import type { TrackFn } from "@/hooks/useTapAnalytics";

/**
 * FEEDBACK DRAWER — private "low rating" path.
 * Optimistic UI: the spring success ring renders BEFORE the network call;
 * the payload { rating, feedbackText, timestamp, touchpointId } posts to
 * /src/config/client.config.ts → n8nFeedbackWebhook via api.service
 * (retry-safe, offline-queued). Copy lives in touchpoints.config.
 */
export interface FeedbackDrawerProps {
  open: boolean;
  rating: number;
  /** Dismissed without submitting — parent returns to the rating card. */
  onClose: () => void;
  /** Success state finished displaying — parent morphs to thanks. */
  onSubmitted: () => void;
  track: TrackFn;
}

export function FeedbackDrawer({ open, rating, onClose, onSubmitted, track }: FeedbackDrawerProps) {
  const copy = touchpointsConfig.copy.review;
  const reduced = useReducedMotion();
  const [text, setText] = useState("");
  const [invalid, setInvalid] = useState(false);
  const [status, setStatus] = useState<"idle" | "sent">("idle");
  const closeTimer = useRef<number | null>(null);

  useEffect(() => {
    if (open) {
      setText("");
      setInvalid(false);
      setStatus("idle");
    }
    return () => {
      if (closeTimer.current !== null) window.clearTimeout(closeTimer.current);
    };
  }, [open]);

  const handleSubmit = () => {
    if (status === "sent") return;
    const trimmed = text.trim();
    if (!trimmed) {
      setInvalid(true);
      haptics.play("error");
      return;
    }
    haptics.play("success");
    setStatus("sent"); // optimistic — success first, network second
    submitFeedback({
      rating,
      feedbackText: trimmed,
      timestamp: new Date().toISOString(),
      touchpointId: clientConfig.touchpointId,
    });
    track("feedback_submitted", { rating, length: trimmed.length });
    closeTimer.current = window.setTimeout(onSubmitted, reduced ? 1100 : 1700);
  };

  return (
    <Drawer
      open={open}
      onClose={status === "sent" ? () => undefined : onClose}
      title={status === "sent" ? undefined : copy.feedbackTitle}
      description={status === "sent" ? undefined : copy.privatePrompt}
    >
      <AnimatePresence mode="wait" initial={false}>
        {status === "idle" ? (
          <motion.form
            key="form"
            onSubmit={(e) => {
              e.preventDefault();
              handleSubmit();
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: reduced ? 0 : -10 }}
            transition={{ duration: reduced ? motionConfig.reduced.duration : 0.18, ease: "easeOut" }}
          >
            <Textarea
              autoFocus
              rows={4}
              value={text}
              invalid={invalid}
              placeholder={copy.feedbackPlaceholder}
              aria-label={copy.feedbackTitle}
              onChange={(e) => {
                setText(e.target.value);
                if (invalid && e.target.value.trim()) setInvalid(false);
              }}
            />
            <p className={`mt-2 text-[12px] leading-relaxed ${invalid ? "text-danger" : "text-muted/80"}`}>
              {copy.feedbackHint}
            </p>
            <Button type="submit" variant="primary" size="lg" glow className="mt-4 w-full">
              <Send className="h-4 w-4" aria-hidden />
              {copy.feedbackSubmit}
            </Button>
          </motion.form>
        ) : (
          <motion.div
            key="sent"
            initial={{ opacity: 0, scale: reduced ? 1 : 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: reduced ? motionConfig.reduced.duration : 0.2, ease: "easeOut" }}
            className="flex flex-col items-center py-4"
          >
            <SuccessRing state="success" label={copy.feedbackSuccess} />
          </motion.div>
        )}
      </AnimatePresence>
    </Drawer>
  );
}
