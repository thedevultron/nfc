import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ExternalLink, RotateCcw, Sparkles, Star } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { SuccessRing } from "@/components/ui/SuccessRing";
import { motionConfig, cardVariants, listVariants, listItemVariants, spring } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { StarRating } from "@/components/touchpoints/StarRating";
import { FeedbackDrawer } from "@/components/touchpoints/FeedbackDrawer";

/**
 * MODULE A — SMART REVIEW ROUTER.
 * Rating ≥ 4 → public Google review CTA with confetti-lite burst.
 * Rating < 4 → morphs into the private FeedbackDrawer.
 * All copy/URLs from /src/config, all physics from motion.config.
 * Do not modify this file — edit config to change behavior.
 */
type Phase = "rate" | "public" | "feedback" | "thanks";

/** Deterministic confetti-lite burst — 6-8 Sparkles with physics-based fall. */
function ConfettiBurst() {
  const { confetti } = motionConfig;
  const colors = ["var(--primary)", "var(--secondary)", "hsl(38 100% 72%)", "hsl(210 20% 96%)"];
  const half = (confetti.count - 1) / 2;
  const particles = Array.from({ length: confetti.count }, (_, i) => ({
    dx: (i - half) * (confetti.spread / half) * 0.55,
    rotate: (i % 2 === 0 ? 1 : -1) * (50 + i * 18),
    color: colors[i % colors.length],
  }));

  return (
    <span className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center overflow-visible" aria-hidden>
      {particles.map((p, i) => (
        <motion.span
          key={i}
          className="absolute"
          style={{ color: p.color }}
          initial={{ x: 0, y: 0, opacity: 1, scale: 0.4, rotate: 0 }}
          animate={{
            x: p.dx,
            y: [0, confetti.rise, confetti.fall],
            opacity: [1, 1, 0],
            scale: [0.4, 1, 0.6],
            rotate: p.rotate,
          }}
          transition={{ duration: confetti.duration, ease: "easeOut", times: [0, 0.32, 1] }}
        >
          <Sparkles className="h-4 w-4" fill="currentColor" strokeWidth={1.5} />
        </motion.span>
      ))}
    </span>
  );
}

export default function ReviewRouter() {
  const track = useTapAnalytics();
  const reduced = useReducedMotion();
  const copy = touchpointsConfig.copy.review;

  const [rating, setRating] = useState(0);
  const [phase, setPhase] = useState<Phase>("rate");
  const [burstId, setBurstId] = useState(0);

  const handleRating = (value: number) => {
    setRating(value);
    track("rating_selected", { rating: value });
    setPhase(value >= 4 ? "public" : "feedback");
  };

  const handleReset = () => {
    setRating(0);
    setPhase("rate");
  };

  const handleGoogleTap = () => {
    track("google_review_tapped", { rating });
    haptics.play("success");
    setBurstId(Date.now());
    // Open synchronously inside the tap gesture — popup blockers on iOS
    // Safari will swallow a deferred window.open.
    window.open(clientConfig.googleReviewUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <section className="flex flex-col gap-5">
      {/* Rating card — always visible while rating/public/feedback. */}
      {phase !== "thanks" && (
        <motion.div variants={cardVariants(reduced)} initial="hidden" animate="show">
          <Card className="p-6">
            <div className="flex justify-center">
              <Badge variant="primary" className="mb-4">
                <Star className="h-3 w-3 fill-current" aria-hidden />
                {touchpointsConfig.vertical.toLowerCase()} review
              </Badge>
            </div>
            <h2
              className="text-center text-xl font-semibold text-foreground"
              style={{ letterSpacing: themeConfig.headingTracking }}
            >
              {copy.prompt}
            </h2>
            <div className="mt-4">
              <StarRating value={rating} onChange={handleRating} />
            </div>
            {/* Fixed-height label row — zero CLS while the label swaps. */}
            <div className="mt-2 h-6 text-center">
              <AnimatePresence mode="wait">
                {rating > 0 && (
                  <motion.p
                    key={rating}
                    initial={{ opacity: 0, y: reduced ? 0 : 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: reduced ? 0 : -6 }}
                    transition={spring("snappy", reduced)}
                    className="text-[13px] font-medium text-primary"
                  >
                    {copy.labels[rating - 1]}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          </Card>
        </motion.div>
      )}

      {/* Public path — staggered reveal. */}
      <AnimatePresence>
        {phase === "public" && (
          <motion.div
            key="public"
            variants={listVariants(reduced)}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: reduced ? 0 : -8, transition: { duration: 0.15 } }}
            className="flex flex-col gap-4"
          >
            <motion.div variants={listItemVariants(reduced)} className="px-1">
              <h3
                className="text-lg font-semibold text-foreground"
                style={{ letterSpacing: themeConfig.headingTracking }}
              >
                {copy.publicTitle}
              </h3>
              <p className="mt-1 text-sm leading-relaxed text-muted">{copy.publicBody}</p>
            </motion.div>
            <motion.div variants={listItemVariants(reduced)} className="relative">
              <Button variant="primary" size="lg" glow className="w-full" onClick={handleGoogleTap}>
                {copy.publicCta}
                <ExternalLink className="h-4 w-4" aria-hidden />
              </Button>
              {burstId > 0 && <ConfettiBurst key={burstId} />}
            </motion.div>
            <motion.div variants={listItemVariants(reduced)} className="flex justify-center">
              <Button variant="ghost" size="sm" onClick={handleReset}>
                <RotateCcw className="h-3.5 w-3.5" aria-hidden />
                {copy.resetRating}
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Private path success — after the drawer finishes its ring. */}
      <AnimatePresence>
        {phase === "thanks" && (
          <motion.div
            key="thanks"
            variants={cardVariants(reduced)}
            initial="hidden"
            animate="show"
            exit="hidden"
          >
            <Card className="flex flex-col items-center p-6">
              <SuccessRing state="success" />
              <h3
                className="mt-4 text-lg font-semibold text-foreground"
                style={{ letterSpacing: themeConfig.headingTracking }}
              >
                {copy.thanksTitle}
              </h3>
              <p className="mt-1 max-w-[280px] text-center text-sm leading-relaxed text-muted">
                {copy.feedbackSuccess}
              </p>
              <Button variant="ghost" size="sm" className="mt-4" onClick={handleReset}>
                <RotateCcw className="h-3.5 w-3.5" aria-hidden />
                {copy.resetRating}
              </Button>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <FeedbackDrawer
        open={phase === "feedback"}
        rating={rating}
        onClose={() => setPhase("rate")}
        onSubmitted={() => setPhase("thanks")}
        track={track}
      />
    </section>
  );
}
