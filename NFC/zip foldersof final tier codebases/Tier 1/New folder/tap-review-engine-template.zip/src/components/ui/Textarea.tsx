import { forwardRef, type TextareaHTMLAttributes } from "react";
import { cn } from "@/utils/cn";

/**
 * TEXTAREA — token-driven field, used by the private feedback drawer.
 * Colors/radius track /src/config/theme.config.ts.
 */
export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  /** Flags the danger ring (e.g. empty feedback submit). */
  invalid?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  function Textarea({ className, invalid, ...rest }, ref) {
    return (
      <textarea
        ref={ref}
        className={cn(
          "min-h-[120px] w-full resize-none rounded-card border border-white/10 bg-white/5 px-3.5 py-3 text-sm leading-relaxed text-foreground",
          "placeholder:text-muted/60 transition-colors duration-200",
          "focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20",
          invalid && "border-danger/60 focus:border-danger/60 focus:ring-danger/20",
          className
        )}
        {...rest}
      />
    );
  }
);
