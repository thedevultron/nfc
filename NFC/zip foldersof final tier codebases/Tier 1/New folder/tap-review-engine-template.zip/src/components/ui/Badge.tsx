import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

/**
 * BADGE — small status pill. Colors resolve to theme tokens,
 * so /src/config/theme.config.ts re-skins it automatically.
 */
type Variant = "neutral" | "primary" | "success" | "outline";

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: Variant;
}

const VARIANTS: Record<Variant, string> = {
  neutral: "bg-white/8 text-muted border-white/10",
  primary: "bg-primary/12 text-primary border-primary/25",
  success: "bg-success/12 text-success border-success/25",
  outline: "border-white/15 text-muted",
};

export function Badge({ variant = "neutral", className, children, ...rest }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium tracking-wide",
        VARIANTS[variant],
        className
      )}
      {...rest}
    >
      {children}
    </span>
  );
}
