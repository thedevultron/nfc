import { motion } from "framer-motion";
import { CheckCircle2, XCircle } from "lucide-react";
import { motionConfig } from "@/config/motion.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { cn } from "@/utils/cn";

/**
 * SUCCESS RING — circular progress-ring wipe with a spring-in
 * CheckCircle2 / XCircle. Timing sourced from motion.config —
 * edit /src/config/motion.config.ts, do not modify this file.
 */
const RADIUS = 26;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export interface SuccessRingProps {
  state: "success" | "error";
  label?: string;
  className?: string;
}

export function SuccessRing({ state, label, className }: SuccessRingProps) {
  const reduced = useReducedMotion();
  const color = state === "success" ? "var(--success)" : "var(--danger)";
  const Icon = state === "success" ? CheckCircle2 : XCircle;

  return (
    <div className={cn("flex flex-col items-center gap-3", className)}>
      <div className="relative h-16 w-16">
        <svg viewBox="0 0 64 64" className="h-16 w-16 -rotate-90">
          <circle cx="32" cy="32" r={RADIUS} fill="none" stroke="rgb(255 255 255 / 0.08)" strokeWidth="4" />
          <motion.circle
            cx="32"
            cy="32"
            r={RADIUS}
            fill="none"
            stroke={color}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={CIRCUMFERENCE}
            initial={{ strokeDashoffset: CIRCUMFERENCE }}
            animate={{ strokeDashoffset: 0 }}
            transition={
              reduced
                ? { duration: motionConfig.reduced.duration }
                : { duration: 0.45, ease: [0.65, 0, 0.35, 1] }
            }
          />
        </svg>
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={
            reduced
              ? { duration: motionConfig.reduced.duration, delay: 0.05 }
              : { ...motionConfig.springs.elastic, delay: 0.14 }
          }
        >
          <Icon className="h-7 w-7" style={{ color }} strokeWidth={2.2} aria-hidden />
        </motion.div>
      </div>
      {label && (
        <motion.p
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: reduced ? 0.05 : 0.28, duration: 0.25, ease: "easeOut" }}
          className="max-w-[260px] text-center text-sm leading-relaxed text-muted"
        >
          {label}
        </motion.p>
      )}
    </div>
  );
}
