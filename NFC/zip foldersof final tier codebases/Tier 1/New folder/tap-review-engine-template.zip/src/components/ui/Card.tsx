import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";
import { themeConfig } from "@/config/theme.config";

/**
 * CARD — the glass surface. Radius comes from theme.config → borderRadius;
 * the glass recipe lives in index.css and is gated by
 * theme.config → enableGlassmorphism. Edit config — do not modify this file.
 */
export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  /** Opaque surface for overlays/drawers where readability must not bleed. */
  solid?: boolean;
}

export function Card({ className, solid = false, style, children, ...rest }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-card",
        themeConfig.enableGlassmorphism && !solid ? "glass" : "border border-white/10 bg-surface",
        solid && "bg-surface",
        className
      )}
      style={style}
      {...rest}
    >
      {children}
    </div>
  );
}
