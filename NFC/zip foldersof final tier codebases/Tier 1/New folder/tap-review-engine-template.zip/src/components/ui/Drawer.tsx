import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { motionConfig, spring } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/**
 * DRAWER — iOS Control-Center-style bottom sheet.
 * Real `drag="y"` dismiss with rubber-band overscroll resistance and
 * velocity-based snap logic. Physics + dismiss thresholds come from
 * /src/config/motion.config.ts — edit that file, do not modify this one.
 */
export interface DrawerProps {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  className?: string;
}

export function Drawer({ open, onClose, title, description, children, className }: DrawerProps) {
  const reduced = useReducedMotion();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.documentElement.style.overflow;
    document.documentElement.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.documentElement.style.overflow = prev;
    };
  }, [open, onClose]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50" role="dialog" aria-modal="true">
          <motion.button
            type="button"
            aria-label="Dismiss sheet"
            className="absolute inset-0 h-full w-full cursor-default bg-black/60 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduced ? motionConfig.reduced.duration : 0.2, ease: "easeOut" }}
            onClick={onClose}
          />
          <motion.div
            className={cn(
              "glass-solid absolute inset-x-0 bottom-0 mx-auto w-full max-w-[430px] touch-pan-y rounded-t-card px-5 pt-2",
              className
            )}
            style={{ paddingBottom: "max(env(safe-area-inset-bottom), 20px)" }}
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={spring("drawer", reduced)}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0.02, bottom: 0.5 }}
            dragTransition={{ power: 0.15, timeConstant: 180, bounceStiffness: 500, bounceDamping: 32 }}
            onDragEnd={(_event, info) => {
              if (
                info.offset.y > motionConfig.sheet.dismissDistance ||
                info.velocity.y > motionConfig.sheet.dismissVelocity
              ) {
                haptics.play("tap");
                onClose();
              }
            }}
          >
            {/* Grabber */}
            <div className="mx-auto mb-4 mt-1 h-1 w-9 rounded-full bg-white/20" />
            {(title || description) && (
              <header className="mb-4">
                {title && (
                  <h2
                    className="text-lg font-semibold text-foreground"
                    style={{ letterSpacing: themeConfig.headingTracking }}
                  >
                    {title}
                  </h2>
                )}
                {description && <p className="mt-1 text-sm leading-relaxed text-muted">{description}</p>}
              </header>
            )}
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}
