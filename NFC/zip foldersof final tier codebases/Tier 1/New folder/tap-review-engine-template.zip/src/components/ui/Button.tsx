import type { MouseEvent as ReactMouseEvent, ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { motionConfig } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import type { HapticPatternName } from "@/types/template.types";

/**
 * BUTTON — press physics, haptics and glow are sourced from
 * /src/config/motion.config.ts and /src/config/theme.config.ts.
 * Edit those files to change feel — do not modify this file.
 * Pass `href` to render an anchor (external links auto-get target=_blank).
 *
 * Props are intentionally narrow (no raw DOM spread) so Framer Motion's
 * `onDrag` / `onAnimationStart` typings never collide with React's.
 */

type Variant = "primary" | "secondary" | "ghost" | "outline" | "success";
type Size = "sm" | "md" | "lg";

export interface ButtonProps {
  variant?: Variant;
  size?: Size;
  /** Paints the ambient accent glow — the "premium tell". */
  glow?: boolean;
  hapticPattern?: HapticPatternName;
  href?: string;
  external?: boolean;
  className?: string;
  children: ReactNode;
  onClick?: (event: ReactMouseEvent<HTMLButtonElement>) => void;
  disabled?: boolean;
  type?: "button" | "submit" | "reset";
  id?: string;
  "aria-label"?: string;
}

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-primary text-[hsl(224_71%_6%)] font-semibold hover:brightness-110 active:brightness-95",
  secondary: "glass text-foreground hover:bg-white/10",
  ghost: "text-muted hover:text-foreground hover:bg-white/5",
  outline: "border border-white/15 text-foreground hover:bg-white/5",
  success: "bg-success/15 text-success border border-success/30 hover:bg-success/20",
};

const SIZES: Record<Size, string> = {
  sm: "h-9 px-3.5 text-[13px]",
  md: "h-11 px-5 text-sm",
  lg: "h-[52px] px-6 text-[15px]",
};

export function Button({
  variant = "secondary",
  size = "md",
  glow = false,
  hapticPattern = "tap",
  href,
  external = false,
  className,
  children,
  disabled,
  type,
  onClick,
  id,
  "aria-label": ariaLabel,
}: ButtonProps) {
  const reduced = useReducedMotion();

  const press = {
    whileTap: disabled
      ? undefined
      : { scale: motionConfig.press.scale, filter: `brightness(${motionConfig.press.brightness})` },
    transition: reduced
      ? { duration: motionConfig.reduced.duration, ease: "easeOut" as const }
      : motionConfig.springs.snappy,
    onTapStart: () => {
      if (!disabled) haptics.play(hapticPattern);
    },
  };

  const classes = cn(
    "inline-flex select-none items-center justify-center gap-2 whitespace-nowrap rounded-card font-medium",
    "transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60",
    VARIANTS[variant],
    SIZES[size],
    glow && !disabled && "glow-primary",
    disabled && "pointer-events-none opacity-45",
    className
  );

  if (href) {
    return (
      <motion.a
        href={href}
        {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
        className={classes}
        whileTap={press.whileTap}
        transition={press.transition}
        onTapStart={press.onTapStart}
      >
        {children}
      </motion.a>
    );
  }

  return (
    <motion.button
      id={id}
      aria-label={ariaLabel}
      type={type ?? "button"}
      disabled={disabled}
      onClick={onClick}
      className={classes}
      whileTap={press.whileTap}
      transition={press.transition}
      onTapStart={press.onTapStart}
    >
      {children}
    </motion.button>
  );
}
