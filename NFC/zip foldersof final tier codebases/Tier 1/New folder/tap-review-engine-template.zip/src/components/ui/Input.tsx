import { forwardRef, type InputHTMLAttributes } from "react";
import { cn } from "@/utils/cn";

/**
 * INPUT — token-driven field. Radius/color track theme.config automatically.
 */
export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...rest }, ref) {
    return (
      <input
        ref={ref}
        className={cn(
          "h-11 w-full rounded-card border border-white/10 bg-white/5 px-3.5 text-sm text-foreground",
          "placeholder:text-muted/60 transition-colors duration-200",
          "focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20",
          className
        )}
        {...rest}
      />
    );
  }
);
