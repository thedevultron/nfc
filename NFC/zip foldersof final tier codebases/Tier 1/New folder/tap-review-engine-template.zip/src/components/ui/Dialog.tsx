import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { motionConfig, spring } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/**
 * DIALOG — centered Linear-style modal. Scale+fade entrance on the
 * snappy spring from /src/config/motion.config.ts. Edit config, not this file.
 */
export interface DialogProps {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  className?: string;
}

export function Dialog({ open, onClose, title, children, className }: DialogProps) {
  const reduced = useReducedMotion();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.documentElement.style.overflow;
    document.documentElement.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.documentElement.style.overflow = prev;
    };
  }, [open, onClose]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6" role="dialog" aria-modal="true">
          <motion.button
            type="button"
            aria-label="Close dialog"
            className="absolute inset-0 h-full w-full cursor-default bg-black/60 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduced ? motionConfig.reduced.duration : 0.2, ease: "easeOut" }}
            onClick={onClose}
          />
          <motion.div
            className={cn(
              "glass-solid relative w-full max-w-sm rounded-card p-5",
              className
            )}
            initial={{ opacity: 0, scale: reduced ? 1 : 0.92, y: reduced ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: reduced ? 1 : 0.95, y: reduced ? 0 : 6 }}
            transition={spring("snappy", reduced)}
          >
            {title && (
              <h2
                className="mb-3 text-base font-semibold text-foreground"
                style={{ letterSpacing: themeConfig.headingTracking }}
              >
                {title}
              </h2>
            )}
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}
