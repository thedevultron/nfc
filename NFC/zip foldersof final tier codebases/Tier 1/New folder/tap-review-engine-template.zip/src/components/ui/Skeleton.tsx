import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

/**
 * SKELETON — shimmer sweep lives in index.css (.skeleton-shimmer)
 * and auto-disables under prefers-reduced-motion.
 */
export function Skeleton({ className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return <div aria-hidden className={cn("skeleton-shimmer rounded-card", className)} {...rest} />;
}
