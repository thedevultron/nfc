import type { ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft } from "lucide-react";
import { cn } from "@/utils/cn";
import { motionConfig, spring } from "@/config/motion.config";
import { themeConfig } from "@/config/theme.config";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { resolveIcon } from "@/components/touchpoints/iconRegistry";
import { NFCContextBanner } from "@/components/layout/NFCContextBanner";
import { FooterBrand } from "@/components/layout/FooterBrand";
import type { ActiveMode } from "@/types/template.types";

/**
 * APP SHELL — phone-framed column, ambient scene, brand header,
 * mode switcher and status-bar-safe padding.
 * All identity/copy/physics resolve from /src/config/*.ts —
 * edit config to re-skin; do not modify this file.
 */

const LANDING_MODES: ActiveMode[] = ["REVIEW", "HUB"];

interface SegmentedProps {
  mode: ActiveMode;
  onModeChange: (mode: ActiveMode) => void;
}

function SegmentedControl({ mode, onModeChange }: SegmentedProps) {
  const reduced = useReducedMotion();
  const copy = touchpointsConfig.copy;
  const options: Array<{ id: ActiveMode; label: string }> = [
    { id: "REVIEW", label: copy.segmentReview },
    { id: "HUB", label: copy.segmentHub },
  ];

  return (
    <div
      role="tablist"
      aria-label="Touchpoint mode"
      className="relative grid grid-cols-2 rounded-card border border-white/10 bg-white/5 p-1"
    >
      {options.map((opt) => {
        const active = mode === opt.id;
        return (
          <button
            key={opt.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => {
              if (active) return;
              haptics.play("selection");
              onModeChange(opt.id);
            }}
            className={cn(
              "relative z-10 h-9 rounded-[calc(var(--radius)-4px)] text-[13px] font-medium transition-colors duration-200",
              active ? "text-foreground" : "text-muted hover:text-foreground"
            )}
          >
            {active && (
              <motion.span
                layoutId="segment-pill"
                aria-hidden
                className="absolute inset-0 -z-10 rounded-[calc(var(--radius)-4px)] border border-white/12 bg-elevated shadow-[0_2px_12px_rgba(0,0,0,0.4)]"
                transition={spring("snappy", reduced)}
              />
            )}
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

function BackChip({ onBack }: { onBack: () => void }) {
  return (
    <motion.button
      type="button"
      onClick={() => {
        haptics.play("tap");
        onBack();
      }}
      whileTap={{ scale: motionConfig.press.scale }}
      className="inline-flex h-8 items-center gap-1 self-start rounded-full border border-white/10 bg-white/5 pl-1.5 pr-3 text-[12px] font-medium text-muted transition-colors duration-200 hover:text-foreground"
    >
      <ChevronLeft className="h-4 w-4" aria-hidden />
      {touchpointsConfig.copy.backToHub}
    </motion.button>
  );
}

export interface AppShellProps {
  mode: ActiveMode;
  onModeChange: (mode: ActiveMode) => void;
  children: ReactNode;
}

export function AppShell({ mode, onModeChange, children }: AppShellProps) {
  const reduced = useReducedMotion();
  const BrandIcon = resolveIcon(touchpointsConfig.icons.primary);
  const isLanding = LANDING_MODES.includes(mode);

  return (
    <div className="relative min-h-dvh overflow-hidden">
      {/* Ambient scene — layered light, faint grid, breathing glow. */}
      <div className="ambient-scene pointer-events-none fixed inset-0" aria-hidden />
      <div className="ambient-grid pointer-events-none fixed inset-0" aria-hidden />
      <div
        className="breathing pointer-events-none fixed -top-24 left-1/2 h-64 w-[430px] -translate-x-1/2 rounded-full opacity-60 blur-3xl"
        style={{ background: "radial-gradient(closest-side, var(--accent-glow), transparent 70%)" }}
        aria-hidden
      />

      <div
        className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[430px] flex-col px-5"
        style={{
          paddingTop: "max(env(safe-area-inset-top), 24px)",
          paddingBottom: "max(env(safe-area-inset-bottom), 24px)",
        }}
      >
        {/* Header */}
        <header className="flex flex-col gap-4">
          <div className="flex items-center justify-between gap-3">
            <NFCContextBanner />
          </div>

          <div className="flex items-center gap-3.5">
            <motion.div
              initial={reduced ? { opacity: 0 } : { rotate: motionConfig.brand.rotateSettle, y: -6, opacity: 0 }}
              animate={{ rotate: 0, y: 0, opacity: 1 }}
              transition={spring("smooth", reduced)}
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-card border border-primary/25 bg-primary/15 text-primary shadow-[0_0_28px_var(--accent-glow)]"
            >
              <BrandIcon className="h-6 w-6" strokeWidth={2} aria-hidden />
            </motion.div>
            <div className="min-w-0">
              <h1
                className="truncate text-[17px] font-semibold text-foreground"
                style={{ letterSpacing: themeConfig.headingTracking }}
              >
                {clientConfig.businessName}
              </h1>
              <p className="mt-0.5 truncate text-[13px] text-muted">{clientConfig.subtitle}</p>
            </div>
          </div>

          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={isLanding ? "segmented" : "back"}
              initial={{ opacity: 0, y: reduced ? 0 : 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: reduced ? 0 : -6 }}
              transition={spring("snappy", reduced)}
            >
              {isLanding ? (
                <SegmentedControl mode={mode} onModeChange={onModeChange} />
              ) : (
                <BackChip onBack={() => onModeChange("HUB")} />
              )}
            </motion.div>
          </AnimatePresence>
        </header>

        {/* Active touchpoint panel */}
        <main className="flex flex-1 flex-col py-6">{children}</main>

        <FooterBrand />
      </div>
    </div>
  );
}
