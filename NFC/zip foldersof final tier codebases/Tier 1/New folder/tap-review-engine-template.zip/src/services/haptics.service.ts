import { motionConfig } from "@/config/motion.config";
import type { HapticPatternName } from "@/types/template.types";

/**
 * HAPTICS — navigator.vibrate abstraction.
 * Patterns live in /src/config/motion.config.ts → haptics.
 * Edit that file to retune feedback intensity — do not modify this file.
 * No-ops silently where vibration is unavailable (iOS Safari).
 */
export const haptics = {
  get supported(): boolean {
    return typeof navigator !== "undefined" && typeof navigator.vibrate === "function";
  },

  /** Fire a named pattern: "tap" | "selection" | "success" | "error". */
  play(name: HapticPatternName): void {
    if (!this.supported) return;
    try {
      navigator.vibrate(motionConfig.haptics[name]);
    } catch {
      /* vibration refused — never surface to the user */
    }
  },

  /** Raw pattern escape hatch (still config-sourced upstream). */
  pattern(value: number | number[]): void {
    if (!this.supported) return;
    try {
      navigator.vibrate(value);
    } catch {
      /* no-op */
    }
  },
};
