import { clientConfig } from "@/config/client.config";
import type { AnalyticsPayload, FeedbackPayload } from "@/types/template.types";

/**
 * API — n8n webhook transport.
 * Webhook URLs live in /src/config/client.config.ts — edit that file
 * to rewire endpoints; do not modify this file.
 *
 * Design rules:
 *  • Optimistic UI: callers update state FIRST, then fire-and-forget.
 *  • Retry-safe: bounded retries with backoff, then a persisted queue.
 *  • Offline-proof: failed payloads queue in localStorage and flush on "online".
 *  • CORS-friendly: `text/plain` body avoids preflight on n8n webhooks
 *    (n8n parses the JSON body regardless).
 */

const QUEUE_KEY = "tap-tier1:webhook-queue";
const MAX_QUEUE = 24;

interface QueueItem {
  url: string;
  body: string;
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function readQueue(): QueueItem[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? (parsed as QueueItem[]) : [];
  } catch {
    return [];
  }
}

function writeQueue(items: QueueItem[]): void {
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(items.slice(-MAX_QUEUE)));
  } catch {
    /* storage full / private mode — drop silently */
  }
}

function enqueue(item: QueueItem): void {
  writeQueue([...readQueue(), item]);
}

async function postOnce(url: string, body: string, timeoutMs: number): Promise<boolean> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=UTF-8" },
      body,
      signal: controller.signal,
      keepalive: true,
    });
    return res.ok;
  } catch {
    return false;
  } finally {
    window.clearTimeout(timer);
  }
}

/**
 * POST JSON to a webhook with bounded retries.
 * Resolves `true` on delivery, `false` after queueing for later —
 * it NEVER throws, so optimistic UI flows stay uninterrupted.
 */
export async function postJson(
  url: string,
  payload: unknown,
  options: { retries?: number; timeoutMs?: number } = {}
): Promise<boolean> {
  const { retries = 2, timeoutMs = 4000 } = options;
  const body = JSON.stringify(payload);

  for (let attempt = 0; attempt <= retries; attempt++) {
    const ok = await postOnce(url, body, timeoutMs);
    if (ok) {
      void flushQueue();
      return true;
    }
    if (attempt < retries) await delay(300 * (attempt + 1));
  }

  enqueue({ url, body });
  return false;
}

/** Replay any payloads that failed while offline. Wired to the "online" event in App.tsx. */
export async function flushQueue(): Promise<void> {
  const items = readQueue();
  if (items.length === 0) return;
  const remaining: QueueItem[] = [];
  for (const item of items) {
    const ok = await postOnce(item.url, item.body, 4000);
    if (!ok) remaining.push(item);
  }
  writeQueue(remaining);
}

/** Non-blocking analytics fire (debouncing handled by useTapAnalytics). */
export function sendAnalytics(payload: AnalyticsPayload): void {
  void postJson(clientConfig.n8nWebhookUrl, payload, { retries: 1, timeoutMs: 3000 });
}

/** Private feedback delivery — called AFTER the optimistic success state is shown. */
export function submitFeedback(payload: FeedbackPayload): void {
  void postJson(clientConfig.n8nFeedbackWebhook, payload, { retries: 2 });
}
