import { useSyncExternalStore } from "react";

/**
 * REDUCED MOTION — tracks prefers-reduced-motion reactively.
 * When true, consumers swap springs for a 150ms ease-out fade
 * (duration sourced from /src/config/motion.config.ts → reduced).
 */
const QUERY = "(prefers-reduced-motion: reduce)";

function subscribe(onChange: () => void): () => void {
  const mql = window.matchMedia(QUERY);
  mql.addEventListener("change", onChange);
  return () => mql.removeEventListener("change", onChange);
}

function getSnapshot(): boolean {
  return window.matchMedia(QUERY).matches;
}

function getServerSnapshot(): boolean {
  return false;
}

export function useReducedMotion(): boolean {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}
