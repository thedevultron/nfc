import { motionConfig } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import type { HapticPatternName } from "@/types/template.types";

/**
 * SPRING PRESS — the reusable "press-down" interaction.
 * Physics + haptics come from /src/config/motion.config.ts;
 * edit that file to change tap feel — do not modify this file.
 *
 * Spread the result onto any motion.* element:
 *   <motion.button {...useSpringPress()} />
 */
export function useSpringPress(pattern: HapticPatternName = "tap") {
  const reduced = useReducedMotion();

  return {
    whileTap: {
      scale: motionConfig.press.scale,
      filter: `brightness(${motionConfig.press.brightness})`,
    },
    whileHover: { scale: reduced ? 1 : motionConfig.hover.scale },
    onTapStart: () => haptics.play(pattern),
    transition: reduced
      ? { duration: motionConfig.reduced.duration, ease: "easeOut" as const }
      : motionConfig.springs.snappy,
  };
}
