import { useCallback, useEffect, useRef } from "react";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { sendAnalytics } from "@/services/api.service";

/**
 * TAP ANALYTICS — fires `touchpoint_opened` on mount plus any
 * tracked CTA tap. Trailing-debounced (250ms) and fully non-blocking:
 * delivery failures queue offline via api.service and never touch the UI.
 * Endpoint: /src/config/client.config.ts → n8nWebhookUrl.
 */

const sessionId =
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID().slice(0, 12)
    : Math.random().toString(36).slice(2, 14);

export type TrackFn = (event: string, data?: Record<string, unknown>) => void;

export function useTapAnalytics(): TrackFn {
  const timerRef = useRef<number | null>(null);

  const track = useCallback<TrackFn>((event, data = {}) => {
    if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => {
      sendAnalytics({
        event,
        sessionId,
        touchpointId: clientConfig.touchpointId,
        mode: clientConfig.activeMode,
        timestamp: new Date().toISOString(),
        vertical: touchpointsConfig.vertical,
        ...data,
      });
    }, 250);
  }, []);

  useEffect(() => {
    track("touchpoint_opened", { tableLabel: clientConfig.tableLabel });
    return () => {
      if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    };
  }, [track]);

  return track;
}
