import type { ThemeConfig } from "@/types/template.types";

/**
 * ─────────────────────────────────────────────────────────────
 * THEME — colors, radius, typography, glass + mode.
 * Edit THIS file to re-skin the entire app. It is pushed onto CSS
 * variables at boot; every component reads tokens, never raw values.
 * Do not hard-code colors in /src/components.
 * ─────────────────────────────────────────────────────────────
 * RESTAURANT preset: warm amber key light + emerald hospitality accent.
 */
export const themeConfig: ThemeConfig = {
  primaryColor: "hsl(38 92% 50%)", // Warm Amber — the "candlelight" accent
  secondaryAccent: "hsl(160 84% 39%)", // Emerald — WhatsApp / success tints
  accentGlow: "hsl(38 92% 50% / 0.25)",
  secondaryGlow: "hsl(160 84% 39% / 0.22)",
  backgroundColor: "hsl(224 71.4% 4.1%)", // true-black-adjacent, never #000
  surfaceColor: "hsl(224 40% 8%)",
  elevatedColor: "hsl(224 36% 11%)",
  foregroundColor: "hsl(210 20% 96%)",
  mutedForegroundColor: "hsl(223 15% 62%)",
  successColor: "hsl(152 69% 45%)",
  dangerColor: "hsl(0 78% 62%)",
  borderRadius: "0.75rem", // single shared token: cards, buttons, drawers
  fontFamily: "'Geist Variable', 'Geist', 'Inter', ui-sans-serif, system-ui, sans-serif",
  headingTracking: "-0.02em",
  enableGlassmorphism: true,
  defaultMode: "dark" as const,
};
