import type { Variants } from "framer-motion";
import type { MotionConfig, SpringName, VariantFactory } from "@/types/template.types";

/**
 * ─────────────────────────────────────────────────────────────
 * MOTION — the single source of truth for ALL animation physics.
 * Edit THIS file to change how the app feels (spring weights,
 * stagger rhythm, haptic patterns). Components must never contain
 * ad-hoc animation values — they consume this config + the
 * variant factories exported below.
 * ─────────────────────────────────────────────────────────────
 */
export const motionConfig: MotionConfig = {
  springs: {
    snappy: { type: "spring", stiffness: 500, damping: 32, mass: 0.9 }, // buttons, taps
    smooth: { type: "spring", stiffness: 300, damping: 30, mass: 1 }, // card entrances
    elastic: { type: "spring", stiffness: 420, damping: 18, mass: 1 }, // star rating pop
    drawer: { type: "spring", stiffness: 380, damping: 38 }, // bottom sheets
  },
  stagger: { children: 0.045, delayChildren: 0.08 },
  press: { scale: 0.96, brightness: 0.94 },
  hover: { scale: 1.02 },
  page: { offsetY: 20, exitDuration: 0.16 },
  star: { pop: [1, 1.35, 1], rippleDelay: 0.04 },
  confetti: { count: 8, rise: -56, fall: 120, spread: 150, duration: 0.7 },
  brand: { rotateSettle: -6 },
  sheet: { dismissDistance: 120, dismissVelocity: 550 },
  swipe: { distance: 80 },
  reduced: { duration: 0.15 },
  haptics: {
    tap: 8,
    selection: 12,
    success: [10, 40, 10],
    error: [20, 30, 20, 30],
  },
};

/* ── Shared transition resolver ────────────────────────────── */

/** Spring by name, or the reduced-motion 150ms ease-out fallback. */
export function spring(name: SpringName, reduced: boolean) {
  return reduced
    ? { duration: motionConfig.reduced.duration, ease: "easeOut" as const }
    : motionConfig.springs[name];
}

/* ── Variant factories (components import these, never literals) ── */

/** Page / mode transitions: 20px vertical slide + opacity, never a hard cut. */
export const pageVariants: VariantFactory = (reduced) => ({
  enter: { opacity: 0, y: reduced ? 0 : motionConfig.page.offsetY },
  center: {
    opacity: 1,
    y: 0,
    transition: spring("smooth", reduced),
  },
  exit: {
    opacity: 0,
    y: reduced ? 0 : -Math.round(motionConfig.page.offsetY / 2),
    transition: { duration: reduced ? motionConfig.reduced.duration : motionConfig.page.exitDuration, ease: "easeIn" },
  },
});

/** Staggered list container. */
export const listVariants: VariantFactory = (reduced) => ({
  hidden: { opacity: reduced ? 0 : 1 },
  show: {
    opacity: 1,
    transition: reduced
      ? { duration: motionConfig.reduced.duration }
      : { staggerChildren: motionConfig.stagger.children, delayChildren: motionConfig.stagger.delayChildren },
  },
});

/** Staggered list item. */
export const listItemVariants: VariantFactory = (reduced) => ({
  hidden: { opacity: 0, y: reduced ? 0 : 14, scale: reduced ? 1 : 0.98 },
  show: { opacity: 1, y: 0, scale: 1, transition: spring("smooth", reduced) },
});

/** Card / panel entrance. */
export const cardVariants: VariantFactory = (reduced) => ({
  hidden: { opacity: 0, y: reduced ? 0 : 18, scale: reduced ? 1 : 0.985 },
  show: { opacity: 1, y: 0, scale: 1, transition: spring("smooth", reduced) },
});

export type { Variants };
