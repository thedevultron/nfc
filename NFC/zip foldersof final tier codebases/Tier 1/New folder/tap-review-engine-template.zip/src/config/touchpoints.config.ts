import type { TouchpointsConfig } from "@/types/template.types";

/**
 * ─────────────────────────────────────────────────────────────
 * TOUCHPOINTS — vertical content: hub links, WiFi creds, vCard
 * fields, menu, and every copy string in the app.
 * Edit THIS file to change wording or content per venue.
 * Icons are Lucide names resolved by the shared registry —
 * any of: Utensils, Star, Wifi, MessageSquare, MessageCircle,
 * BookOpen, Phone, MapPin, Instagram, Facebook, Globe, Mail,
 * CalendarClock, UserPlus, Coffee, Wine, Gift, Music, ShoppingBag.
 * ─────────────────────────────────────────────────────────────
 * Vertical preset: RESTAURANT
 */
export const touchpointsConfig: TouchpointsConfig = {
  vertical: "RESTAURANT",
  touchpointIdNote: "Stable id lives in client.config.ts → touchpointId",
  icons: { primary: "Utensils", secondary: "Star" },
  copy: {
    loading: "Setting your table...",
    nfcConnected: "Connected via NFC",
    nfcJustNow: "just now",
    segmentReview: "Review",
    segmentHub: "Explore",
    backToHub: "Back to Explore",
    review: {
      prompt: "How was everything today?",
      labels: [
        "Ouch — tell us everything",
        "Not your best evening",
        "It was okay, honestly",
        "Lovely — we're blushing",
        "Chef's kiss. Perfection.",
      ],
      publicTitle: "That made our day",
      publicBody:
        "Would you mind sharing it with other food lovers? It takes ten seconds, and it genuinely helps our kitchen.",
      publicCta: "Post on Google Maps",
      feedbackTitle: "Straight to the owner",
      privatePrompt:
        "Tell us what went wrong — this goes straight to the owner, not public. No stars, no screenshots, just us.",
      feedbackPlaceholder: "e.g. the pasta arrived cold and we waited 20 minutes for the bill...",
      feedbackHint: "A sentence or two is all the owner needs to fix it.",
      feedbackSubmit: "Send to the owner",
      feedbackSuccess: "Thank you — the owner has this. It genuinely helps.",
      feedbackDone: "Done",
      resetRating: "Rate again",
      thanksTitle: "Noted, with gratitude",
    },
    wifi: {
      title: "Table WiFi",
      subtitle: "One tap and you're back online",
      networkLabel: "Network",
      securityLabel: "Security",
      passwordLabel: "Password",
      copyPassword: "Copy password",
      copied: "Copied",
      qrButton: "WiFi QR payload",
      qrTitle: "Native WiFi payload",
      qrHint: "Scan this string with any QR generator, or paste it into a router provisioning tool — devices join automatically.",
      qrCopy: "Copy payload",
    },
    contact: {
      title: "Keep in touch",
      body: "Save us to your phone — reservations, private dinners and tasting menus are one tap away.",
      saveCta: "Save Contact",
      saved: "Saved to your device",
      whatsapp: "WhatsApp",
      call: "Call us",
    },
    hub: {
      title: "Everything, one tap away",
      body: "Reserve a table, browse the menu, or jump on the guest WiFi.",
      swipeHint: "Tip: swipe sideways to flip between review and explore",
    },
    menu: {
      title: "Digital Menu",
      subtitle: "Seasonal · v2.4 · prices incl. taxes",
    },
    footer: "Crafted for The Grand Bistro · Powered by TapTier",
    footerBadge: "Tier 1 · NFC",
  },
  hub: [
    {
      label: "Reserve a Table",
      sublabel: "WhatsApp us — we reply in minutes",
      icon: "MessageSquare",
      url: "https://wa.me/919876543210",
      external: true,
      tint: "secondary",
    },
    {
      label: "View Digital Menu",
      sublabel: "Seasonal menu · updated weekly",
      icon: "BookOpen",
      url: "/menu",
      external: false,
      tint: "primary",
    },
    {
      label: "Connect to WiFi",
      sublabel: "Bistro_Guest · free for diners",
      icon: "Wifi",
      url: "internal:WIFI",
      external: false,
      tint: "primary",
    },
    {
      label: "Leave a Review",
      sublabel: "60 seconds, promise",
      icon: "Star",
      url: "internal:REVIEW",
      external: false,
      tint: "primary",
    },
    {
      label: "Save Contact Card",
      sublabel: "Add the bistro to your phone",
      icon: "UserPlus",
      url: "internal:CONTACT",
      external: false,
      tint: "secondary",
    },
  ],
  wifi: { ssid: "Bistro_Guest", password: "truffle&thyme42", security: "WPA" },
  vcard: {
    name: "The Grand Bistro",
    org: "Fine Dining & Bar",
    phone: "+919876543210",
    email: "hello@grandbistro.in",
    url: "https://grandbistro.in",
    address: "12 Koregaon Park, Pune 411001",
  },
  whatsappNumber: "919876543210",
  menu: [
    {
      category: "Small Plates",
      items: [
        { name: "Burrata & Charred Peach", price: "₹620", note: "basil oil, sourdough crisp" },
        { name: "Goan Prawn Balchão", price: "₹540", note: "tomato-chilli pickle, steamed rice" },
        { name: "Beetroot Carpaccio", price: "₹420", note: "whipped feta, pistachio" },
      ],
    },
    {
      category: "Mains",
      items: [
        { name: "48-Hour Short Rib", price: "₹1,150", note: "smoked jus, pomme purée" },
        { name: "Malabar Meen Curry", price: "₹880", note: "kingfish, kokum, appam" },
        { name: "Wild Mushroom Risotto", price: "₹760", note: "aged parmesan, truffle oil" },
      ],
    },
    {
      category: "Desserts",
      items: [
        { name: "Burnt Basque Cheesecake", price: "₹380", note: "macerated berries" },
        { name: "Dark Chocolate Fondant", price: "₹420", note: "salted caramel, vanilla bean" },
      ],
    },
  ],
};
