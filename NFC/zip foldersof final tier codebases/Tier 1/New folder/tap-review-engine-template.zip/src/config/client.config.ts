import type { ClientConfig } from "@/types/template.types";

/**
 * ─────────────────────────────────────────────────────────────
 * CLIENT — business metadata + deployment wiring.
 * Edit THIS file to point the template at a new business:
 * name, landing mode, Google review link, n8n webhooks.
 * Do not touch /src/components for a new client deploy.
 * ─────────────────────────────────────────────────────────────
 */
export const clientConfig: ClientConfig = {
  businessName: "The Grand Bistro",
  subtitle: "Thanks for dining with us today",
  activeMode: "REVIEW", // default landing; HUB is the secondary swipeable panel
  googleReviewUrl: "https://maps.google.com/?q=The+Grand+Bistro+Pune",
  n8nWebhookUrl: "https://n8n.yourdomain.com/webhook/tier1-analytics",
  n8nFeedbackWebhook: "https://n8n.yourdomain.com/webhook/tier1-feedback",
  touchpointId: "tap-01-grand-bistro-pune",
  tableLabel: "Table 12",
};
