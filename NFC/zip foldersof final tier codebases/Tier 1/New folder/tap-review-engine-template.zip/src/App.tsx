import { lazy, Suspense, useEffect, useState } from "react";
import { AnimatePresence, motion, type PanInfo } from "framer-motion";
import { Utensils } from "lucide-react";
import { themeConfig } from "@/config/theme.config";
import { clientConfig } from "@/config/client.config";
import { touchpointsConfig } from "@/config/touchpoints.config";
import { motionConfig, pageVariants } from "@/config/motion.config";
import { haptics } from "@/services/haptics.service";
import { flushQueue } from "@/services/api.service";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useTapAnalytics } from "@/hooks/useTapAnalytics";
import { AppShell } from "@/components/layout/AppShell";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/Skeleton";
import type { ActiveMode } from "@/types/template.types";

/**
 * ROOT — owns activeMode, the page-transition AnimatePresence and the
 * boot skeleton. Everything visual/content/physics resolves from
 * /src/config/*.ts; edit config to re-deploy — do not modify components.
 */

// Lazy panels: each touchpoint ships as its own chunk boundary.
const ReviewRouter = lazy(() => import("@/components/touchpoints/ReviewRouter"));
const WifiCard = lazy(() => import("@/components/touchpoints/WifiCard"));
const VCardSheet = lazy(() => import("@/components/touchpoints/VCardSheet"));
const SocialHub = lazy(() => import("@/components/touchpoints/SocialHub"));

const LANDING_MODES: ActiveMode[] = ["REVIEW", "HUB"];

/** Pushes theme.config onto CSS variables — the runtime re-skin path. */
function useApplyTheme() {
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--background", themeConfig.backgroundColor);
    root.style.setProperty("--surface", themeConfig.surfaceColor);
    root.style.setProperty("--elevated", themeConfig.elevatedColor);
    root.style.setProperty("--primary", themeConfig.primaryColor);
    root.style.setProperty("--secondary", themeConfig.secondaryAccent);
    root.style.setProperty("--foreground", themeConfig.foregroundColor);
    root.style.setProperty("--muted", themeConfig.mutedForegroundColor);
    root.style.setProperty("--success", themeConfig.successColor);
    root.style.setProperty("--danger", themeConfig.dangerColor);
    root.style.setProperty("--accent-glow", themeConfig.accentGlow);
    root.style.setProperty("--secondary-glow", themeConfig.secondaryGlow);
    root.style.setProperty("--radius", themeConfig.borderRadius);
    root.style.setProperty("--font-family", themeConfig.fontFamily);
    root.style.colorScheme = themeConfig.defaultMode;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", themeConfig.backgroundColor);
  }, []);
}

/** "Setting your table..." — shimmer shell for the first ~600ms. Never a blank flash. */
function BootScreen() {
  return (
    <div className="flex flex-1 flex-col gap-5" aria-busy="true" aria-live="polite">
      <Card className="p-6">
        <Skeleton className="mx-auto h-5 w-44" />
        <div className="mt-6 flex justify-center gap-1.5">
          {[0, 1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-10 w-10 rounded-full" />
          ))}
        </div>
        <Skeleton className="mx-auto mt-6 h-3 w-32" />
      </Card>
      <div className="flex flex-col gap-2.5">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
      </div>
      <div className="flex items-center justify-center gap-2 pt-1 text-[13px] text-muted">
        <Utensils className="h-3.5 w-3.5 text-primary" aria-hidden />
        {touchpointsConfig.copy.loading}
        <span className="ml-0.5 flex gap-1" aria-hidden>
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="loading-dot inline-block h-1 w-1 rounded-full bg-primary"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </span>
      </div>
    </div>
  );
}

/** Suspense fallback while a lazy panel chunk resolves. */
function PanelSkeleton() {
  return (
    <div className="flex flex-1 flex-col gap-4">
      <Skeleton className="h-44 w-full" />
      <Skeleton className="h-16 w-full" />
    </div>
  );
}

function ActivePanel({ mode, onNavigate }: { mode: ActiveMode; onNavigate: (m: ActiveMode) => void }) {
  switch (mode) {
    case "REVIEW":
      return <ReviewRouter />;
    case "WIFI":
      return <WifiCard />;
    case "CONTACT":
      return <VCardSheet />;
    case "HUB":
      return <SocialHub onNavigate={onNavigate} />;
  }
}

export default function App() {
  useApplyTheme();
  const track = useTapAnalytics();
  const reduced = useReducedMotion();
  const [mode, setMode] = useState<ActiveMode>(clientConfig.activeMode);
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    const timer = window.setTimeout(() => setBooting(false), 620);
    return () => window.clearTimeout(timer);
  }, []);

  // Replay any webhooks that failed while offline.
  useEffect(() => {
    const onOnline = () => void flushQueue();
    window.addEventListener("online", onOnline);
    return () => window.removeEventListener("online", onOnline);
  }, []);

  const handleModeChange = (next: ActiveMode) => {
    if (next === mode) return;
    track("mode_switched", { to: next });
    setMode(next);
  };

  const handleSwipeEnd = (_event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (!LANDING_MODES.includes(mode)) return;
    if (mode === "REVIEW" && info.offset.x < -motionConfig.swipe.distance) {
      haptics.play("selection");
      handleModeChange("HUB");
    } else if (mode === "HUB" && info.offset.x > motionConfig.swipe.distance) {
      haptics.play("selection");
      handleModeChange("REVIEW");
    }
  };

  const isLanding = LANDING_MODES.includes(mode);

  return (
    <AppShell mode={mode} onModeChange={handleModeChange}>
      <AnimatePresence mode="wait">
        {booting ? (
          <motion.div
            key="boot"
            className="flex flex-1 flex-col"
            exit={{ opacity: 0, transition: { duration: reduced ? motionConfig.reduced.duration : 0.16 } }}
          >
            <BootScreen />
          </motion.div>
        ) : (
          <motion.div
            key="live"
            className="flex flex-1 flex-col"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: reduced ? motionConfig.reduced.duration : 0.2 }}
          >
            {/* Swipeable stage — drag right/left flips Review ↔ Explore. */}
            <motion.div
              className="flex flex-1 flex-col"
              drag={isLanding ? "x" : false}
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.12}
              dragTransition={{ power: 0.1, timeConstant: 150, bounceStiffness: 500, bounceDamping: 30 }}
              onDragEnd={handleSwipeEnd}
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.section
                  key={mode}
                  variants={pageVariants(reduced)}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  className="flex flex-1 flex-col"
                >
                  <Suspense fallback={<PanelSkeleton />}>
                    <ActivePanel mode={mode} onNavigate={handleModeChange} />
                  </Suspense>
                </motion.section>
              </AnimatePresence>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </AppShell>
  );
}
