// API Service — n8n webhook handlers with retry-safe, optimistic UI support
// Edit /src/config/client.config.ts to change webhook URLs — do not modify this file

import { clientConfig } from "../config/client.config";
import type { AnalyticsPayload, FeedbackPayload } from "../types/template.types";

class ApiService {
  private async postToWebhook(url: string, payload: unknown, retries = 2): Promise<boolean> {
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok && retries > 0) {
        return this.postToWebhook(url, payload, retries - 1);
      }

      return response.ok;
    } catch (error) {
      if (retries > 0) {
        return this.postToWebhook(url, payload, retries - 1);
      }
      console.error("Webhook POST failed:", error);
      return false;
    }
  }

  async trackAnalytics(payload: AnalyticsPayload): Promise<boolean> {
    return this.postToWebhook(clientConfig.n8nWebhookUrl, payload);
  }

  async submitFeedback(payload: FeedbackPayload): Promise<boolean> {
    return this.postToWebhook(clientConfig.n8nFeedbackWebhook, payload);
  }
}

export const apiService = new ApiService();
