// Haptics Service — Abstraction for navigator.vibrate with pattern presets from motion.config
// Edit /src/config/motion.config.ts to change haptic patterns — do not modify this file

import { motionConfig } from "../config/motion.config";

class HapticsService {
  private isSupported(): boolean {
    return typeof navigator !== "undefined" && "vibrate" in navigator;
  }

  tap(): void {
    if (this.isSupported()) {
      navigator.vibrate(motionConfig.haptics.tap);
    }
  }

  selection(): void {
    if (this.isSupported()) {
      navigator.vibrate(motionConfig.haptics.selection);
    }
  }

  success(): void {
    if (this.isSupported()) {
      navigator.vibrate(motionConfig.haptics.success);
    }
  }

  error(): void {
    if (this.isSupported()) {
      navigator.vibrate(motionConfig.haptics.error);
    }
  }
}

export const hapticsService = new HapticsService();
