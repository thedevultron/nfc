// ReviewRouter Component — Routes users based on rating (Google Review or Feedback)
// Edit /src/config/client.config.ts to change Google Review URL — do not modify this file

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ExternalLink, Sparkle } from "lucide-react";
import { Card, CardContent } from "../ui/Card";
import { Button } from "../ui/Button";
import { StarRating } from "./StarRating";
import { FeedbackDrawer } from "./FeedbackDrawer";
import { clientConfig } from "../../config/client.config";
import { motionConfig } from "../../config/motion.config";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";
import { hapticsService } from "../../services/haptics.service";

export function ReviewRouter() {
  const [rating, setRating] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const { trackInteraction } = useTapAnalytics("review_router");

  const handleRate = (value: number) => {
    setRating(value);
    trackInteraction({ rating: value });

    if (value < 4) {
      setTimeout(() => setShowFeedback(true), 400);
    }
  };

  const handleGoogleReview = () => {
    hapticsService.success();
    setShowConfetti(true);
    trackInteraction({ action: "google_review" });

    setTimeout(() => {
      window.open(clientConfig.googleReviewUrl, "_blank");
    }, 600);
  };

  return (
    <div className="relative">
      <Card glass className="p-6">
        <CardContent className="p-0">
          <motion.div
            layout
            transition={motionConfig.springs.smooth}
            className="text-center"
          >
            <h2
              className="text-2xl font-semibold mb-2"
              style={{ fontFamily: clientConfig.businessName ? undefined : undefined }}
            >
              How was your experience?
            </h2>
            <p className="text-sm text-white/60 mb-6">{clientConfig.subtitle}</p>

            <div className="flex justify-center">
              <StarRating onRate={handleRate} value={rating} />
            </div>

            <AnimatePresence mode="wait">
              {rating >= 4 && (
                <motion.div
                  key="google-cta"
                  initial={{ opacity: 0, y: 20, scale: 0.9 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.9 }}
                  transition={motionConfig.springs.elastic}
                  className="mt-6"
                >
                  <Button onClick={handleGoogleReview} fullWidth size="lg">
                    <ExternalLink className="w-5 h-5" />
                    Post on Google Maps
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </CardContent>
      </Card>

      {/* Confetti burst */}
      <AnimatePresence>
        {showConfetti && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute"
                style={{
                  left: `${20 + Math.random() * 60}%`,
                  top: "50%",
                }}
                initial={{ opacity: 1, y: 0, rotate: 0 }}
                animate={{
                  opacity: 0,
                  y: -200 - Math.random() * 100,
                  x: (Math.random() - 0.5) * 200,
                  rotate: Math.random() * 360,
                }}
                exit={{ opacity: 0 }}
                transition={{
                  duration: 1.2,
                  ease: "easeOut",
                  delay: i * 0.05,
                }}
              >
                <Sparkle
                  className="w-6 h-6"
                  style={{ color: i % 2 === 0 ? "hsl(38 92% 50%)" : "hsl(160 84% 39%)" }}
                />
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>

      <FeedbackDrawer
        isOpen={showFeedback}
        onClose={() => setShowFeedback(false)}
        rating={rating}
      />
    </div>
  );
}
