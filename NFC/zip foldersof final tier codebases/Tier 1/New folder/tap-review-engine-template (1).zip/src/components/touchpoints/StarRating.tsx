// StarRating Component — Interactive 5-star rating with elastic pop animation
// Edit /src/config/motion.config.ts to change spring physics — do not modify this file

import { useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { hapticsService } from "../../services/haptics.service";
import { useReducedMotion } from "../../hooks/useReducedMotion";

interface StarRatingProps {
  onRate: (rating: number) => void;
  value?: number;
}

export function StarRating({ onRate, value = 0 }: StarRatingProps) {
  const [hovered, setHovered] = useState(0);
  const reducedMotion = useReducedMotion();

  const handleSelect = (rating: number) => {
    hapticsService.selection();
    onRate(rating);
  };

  return (
    <div className="flex items-center gap-3 py-4">
      {[1, 2, 3, 4, 5].map((star, index) => {
        const isActive = star <= (hovered || value);
        return (
          <motion.button
            key={star}
            onClick={() => handleSelect(star)}
            onMouseEnter={() => setHovered(star)}
            onMouseLeave={() => setHovered(0)}
            className="focus:outline-none"
            whileTap={reducedMotion ? {} : { scale: 0.85 }}
            animate={
              reducedMotion
                ? {}
                : {
                    scale: isActive ? [1, 1.35, 1] : 1,
                    rotate: isActive ? [0, -6, 6, 0] : 0,
                  }
            }
            transition={{
              ...motionConfig.springs.elastic,
              delay: index * 0.04,
            }}
            aria-label={`Rate ${star} stars`}
          >
            <Star
              className="w-12 h-12 transition-colors duration-200"
              style={{
                color: isActive ? "hsl(38 92% 50%)" : "hsl(224 20% 30%)",
                fill: isActive ? "hsl(38 92% 50%)" : "transparent",
                strokeWidth: 1.5,
              }}
            />
          </motion.button>
        );
      })}
    </div>
  );
}
