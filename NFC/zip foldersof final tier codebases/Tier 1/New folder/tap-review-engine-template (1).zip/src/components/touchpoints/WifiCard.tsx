// WifiCard Component — Glass card showing SSID + password with reveal toggle
// Edit /src/config/touchpoints.config.ts to change WiFi credentials — do not modify this file

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Wifi, Eye, EyeOff, CheckCircle2, Copy } from "lucide-react";
import { Card, CardContent } from "../ui/Card";
import { Button } from "../ui/Button";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { motionConfig } from "../../config/motion.config";
import { hapticsService } from "../../services/haptics.service";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";

export function WifiCard() {
  const [showPassword, setShowPassword] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const { trackInteraction } = useTapAnalytics("wifi");

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(touchpointsConfig.wifi.password);
      hapticsService.success();
      setIsCopied(true);
      trackInteraction({ action: "copy_password" });

      setTimeout(() => setIsCopied(false), 2000);
    } catch (error) {
      hapticsService.error();
    }
  };

  const handleReveal = () => {
    setShowPassword(!showPassword);
    hapticsService.tap();
    trackInteraction({ action: showPassword ? "hide_password" : "reveal_password" });
  };

  return (
    <Card glass className="p-6">
      <CardContent className="p-0 space-y-6">
        <div className="flex items-center gap-3">
          <div
            className="p-3 rounded-xl"
            style={{
              background: "hsl(38 92% 50% / 0.1)",
              border: "1px solid hsl(38 92% 50% / 0.2)",
            }}
          >
            <Wifi className="w-6 h-6" style={{ color: "hsl(38 92% 50%)" }} />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Guest WiFi</h3>
            <p className="text-sm text-white/60">Connect to our network</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="text-xs text-white/50 mb-1">Network</div>
            <div className="text-lg font-medium">{touchpointsConfig.wifi.ssid}</div>
          </div>

          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="flex items-center justify-between mb-1">
              <div className="text-xs text-white/50">Password</div>
              <button
                onClick={handleReveal}
                className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4 text-white/60" />
                ) : (
                  <Eye className="w-4 h-4 text-white/60" />
                )}
              </button>
            </div>
            <AnimatePresence mode="wait">
              <motion.div
                key={showPassword ? "visible" : "hidden"}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.15 }}
                className="text-lg font-mono"
              >
                {showPassword
                  ? touchpointsConfig.wifi.password
                  : "••••••••••••"}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        <Button onClick={handleCopy} fullWidth>
          <AnimatePresence mode="wait">
            {isCopied ? (
              <motion.div
                key="copied"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                transition={motionConfig.springs.elastic}
                className="flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Copied!
              </motion.div>
            ) : (
              <motion.div
                key="copy"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="flex items-center gap-2"
              >
                <Copy className="w-4 h-4" />
                Copy Password
              </motion.div>
            )}
          </AnimatePresence>
        </Button>
      </CardContent>
    </Card>
  );
}
