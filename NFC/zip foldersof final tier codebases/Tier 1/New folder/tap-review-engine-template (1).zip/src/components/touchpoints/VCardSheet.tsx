// VCardSheet Component — Bottom sheet with Save Contact CTA and quick actions
// Edit /src/config/touchpoints.config.ts to change vCard details — do not modify this file

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { UserPlus, Phone, MessageCircle, CheckCircle2 } from "lucide-react";
import { Card, CardContent } from "../ui/Card";
import { Button } from "../ui/Button";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { motionConfig } from "../../config/motion.config";
import { hapticsService } from "../../services/haptics.service";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";

export function VCardSheet() {
  const [isSaved, setIsSaved] = useState(false);
  const { trackInteraction } = useTapAnalytics("vcard");

  const generateVCard = () => {
    const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${touchpointsConfig.vcard.name}
ORG:${touchpointsConfig.vcard.org}
TITLE:${touchpointsConfig.vcard.title}
TEL:${touchpointsConfig.vcard.phone}
EMAIL:${touchpointsConfig.vcard.email}
URL:${touchpointsConfig.vcard.url}
END:VCARD`;

    const blob = new Blob([vcard], { type: "text/vcard" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${touchpointsConfig.vcard.name.replace(/\s+/g, "_")}.vcf`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveContact = () => {
    hapticsService.success();
    setIsSaved(true);
    generateVCard();
    trackInteraction({ action: "save_contact" });

    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleCall = () => {
    hapticsService.tap();
    trackInteraction({ action: "call" });
    window.location.href = `tel:${touchpointsConfig.vcard.phone}`;
  };

  const handleWhatsApp = () => {
    hapticsService.tap();
    trackInteraction({ action: "whatsapp" });
    const phone = touchpointsConfig.vcard.phone.replace(/\D/g, "");
    window.open(`https://wa.me/${phone}`, "_blank");
  };

  return (
    <Card glass className="p-6">
      <CardContent className="p-0 space-y-6">
        <div className="text-center">
          <motion.div
            className="inline-flex p-4 rounded-2xl mb-4"
            style={{
              background: "hsl(160 84% 39% / 0.1)",
              border: "1px solid hsl(160 84% 39% / 0.2)",
            }}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <UserPlus className="w-8 h-8" style={{ color: "hsl(160 84% 39%)" }} />
          </motion.div>
          <h3 className="text-xl font-semibold mb-1">{touchpointsConfig.vcard.name}</h3>
          <p className="text-sm text-white/60">{touchpointsConfig.vcard.title}</p>
        </div>

        <Button onClick={handleSaveContact} fullWidth size="lg" disabled={isSaved}>
          <AnimatePresence mode="wait">
            {isSaved ? (
              <motion.div
                key="saved"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                transition={motionConfig.springs.elastic}
                className="flex items-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5" />
                Contact Saved
              </motion.div>
            ) : (
              <motion.div
                key="save"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="flex items-center gap-2"
              >
                <UserPlus className="w-5 h-5" />
                Save Contact
              </motion.div>
            )}
          </AnimatePresence>
        </Button>

        <div className="grid grid-cols-2 gap-3">
          <Button onClick={handleWhatsApp} variant="secondary" size="lg">
            <MessageCircle className="w-5 h-5" />
            WhatsApp
          </Button>
          <Button onClick={handleCall} variant="outline" size="lg">
            <Phone className="w-5 h-5" />
            Call
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
