// SocialHub Component — Multi-link hub with staggered list animation
// Edit /src/config/touchpoints.config.ts to change hub links — do not modify this file

import { motion } from "framer-motion";
import { ChevronRight, MessageSquare, BookOpen, Wifi, Star, ExternalLink } from "lucide-react";
import { Card } from "../ui/Card";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { motionConfig } from "../../config/motion.config";
import { hapticsService } from "../../services/haptics.service";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";
import { useReducedMotion } from "../../hooks/useReducedMotion";

const iconMap: Record<string, React.ComponentType<any>> = {
  MessageSquare,
  BookOpen,
  Wifi,
  Star,
};

export function SocialHub() {
  const { trackInteraction } = useTapAnalytics("social_hub");
  const reducedMotion = useReducedMotion();

  const handleItemClick = (item: typeof touchpointsConfig.hub[0]) => {
    hapticsService.tap();
    trackInteraction({ label: item.label, url: item.url });

    if (item.external) {
      window.open(item.url, "_blank");
    } else if (item.url) {
      window.location.href = item.url;
    }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            delayChildren: motionConfig.stagger.delayChildren,
            staggerChildren: motionConfig.stagger.children,
          },
        },
      }}
      className="space-y-3"
    >
      {touchpointsConfig.hub.map((item, index) => {
        const Icon = iconMap[item.icon] || ExternalLink;
        const colors = [
          "hsl(38 92% 50% / 0.1)",
          "hsl(160 84% 39% / 0.1)",
          "hsl(221.2 83.2% 53.3% / 0.1)",
          "hsl(280 84% 39% / 0.1)",
        ];
        const borderColors = [
          "hsl(38 92% 50% / 0.2)",
          "hsl(160 84% 39% / 0.2)",
          "hsl(221.2 83.2% 53.3% / 0.2)",
          "hsl(280 84% 39% / 0.2)",
        ];

        return (
          <motion.div
            key={item.label}
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: reducedMotion
                ? { opacity: 1, y: 0 }
                : { opacity: 1, y: 0, transition: motionConfig.springs.smooth },
            }}
          >
            <Card glass className="overflow-hidden">
              <motion.button
                className="w-full p-4 flex items-center gap-4 text-left group"
                whileTap={reducedMotion ? {} : { scale: motionConfig.press.scale }}
                whileHover={reducedMotion ? {} : { scale: motionConfig.hover.scale }}
                transition={motionConfig.springs.snappy}
                onTapStart={() => hapticsService.tap()}
                onClick={() => handleItemClick(item)}
              >
                <div
                  className="p-3 rounded-xl flex-shrink-0"
                  style={{
                    background: colors[index % colors.length],
                    border: `1px solid ${borderColors[index % borderColors.length]}`,
                  }}
                >
                  <Icon className="w-6 h-6" style={{ color: borderColors[index % borderColors.length].replace(" / 0.2)", ")") }} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="font-medium">{item.label}</div>
                  {item.external && (
                    <div className="text-xs text-white/50 mt-0.5">Opens in new tab</div>
                  )}
                </div>

                <motion.div
                  animate={{ x: [0, 2, 0] }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <ChevronRight className="w-5 h-5 text-white/40" />
                </motion.div>
              </motion.button>
            </Card>
          </motion.div>
        );
      })}
    </motion.div>
  );
}
