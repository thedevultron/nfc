// FeedbackDrawer Component — Bottom sheet for low ratings with textarea
// Edit /src/config/motion.config.ts to change spring physics — do not modify this file

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Send } from "lucide-react";
import { Drawer } from "../ui/Drawer";
import { Textarea } from "../ui/Input";
import { Button } from "../ui/Button";
import { apiService } from "../../services/api.service";
import { motionConfig } from "../../config/motion.config";
import { hapticsService } from "../../services/haptics.service";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";

interface FeedbackDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  rating: number;
}

export function FeedbackDrawer({ isOpen, onClose, rating }: FeedbackDrawerProps) {
  const [feedback, setFeedback] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const { trackInteraction, touchpointId } = useTapAnalytics("feedback");

  const handleSubmit = async () => {
    if (!feedback.trim()) return;

    setIsSubmitting(true);
    trackInteraction({ rating, feedback });

    // Optimistic UI
    setTimeout(() => {
      setIsSuccess(true);
      hapticsService.success();
    }, 800);

    // Fire webhook (non-blocking)
    apiService
      .submitFeedback({
        rating,
        feedbackText: feedback,
        timestamp: Date.now(),
        touchpointId,
      })
      .catch(() => {
        // Silent fail — optimistic UI already shown
      });

    setTimeout(() => {
      onClose();
      setIsSubmitting(false);
      setIsSuccess(false);
      setFeedback("");
    }, 2000);
  };

  return (
    <Drawer isOpen={isOpen} onClose={onClose} title="Tell us what went wrong">
      <AnimatePresence mode="wait">
        {!isSuccess ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={motionConfig.springs.smooth}
            className="space-y-4"
          >
            <p className="text-sm text-white/60">
              This goes straight to the owner, not public. Your feedback helps us improve.
            </p>

            <Textarea
              placeholder="What could we have done better?"
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              className="min-h-[120px]"
            />

            <Button
              onClick={handleSubmit}
              fullWidth
              disabled={!feedback.trim() || isSubmitting}
              isLoading={isSubmitting}
            >
              <Send className="w-4 h-4" />
              Send Feedback
            </Button>
          </motion.div>
        ) : (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={motionConfig.springs.elastic}
            className="flex flex-col items-center justify-center py-8 space-y-4"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={motionConfig.springs.elastic}
            >
              <CheckCircle2
                className="w-16 h-16"
                style={{ color: "hsl(160 84% 39%)" }}
              />
            </motion.div>
            <p className="text-lg font-medium">Thank you!</p>
            <p className="text-sm text-white/60 text-center">
              Your feedback has been sent to the owner.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </Drawer>
  );
}
