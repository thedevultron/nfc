// Button Component — Shadcn-style primitive
// Edit /src/config/theme.config.ts to change colors, radius, typography — do not modify this file

import { forwardRef } from "react";
import { motion } from "framer-motion";
import { cn } from "../../utils/cn";
import { themeConfig } from "../../config/theme.config";
import { motionConfig } from "../../config/motion.config";
import { hapticsService } from "../../services/haptics.service";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "outline";
  size?: "sm" | "md" | "lg";
  fullWidth?: boolean;
  isLoading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant = "primary",
      size = "md",
      fullWidth,
      isLoading,
      children,
      onClick,
      disabled,
      type = "button",
      style,
    },
    ref
  ) => {
    const baseStyles =
      "inline-flex items-center justify-center gap-2 font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50";

    const variants = {
      primary: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_40px_var(--accent-glow)]",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
      ghost: "hover:bg-accent hover:text-accent-foreground",
      outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
    };

    const sizes = {
      sm: "h-9 px-3 text-sm",
      md: "h-10 px-4 text-base",
      lg: "h-12 px-6 text-lg",
    };

    return (
      <motion.button
        ref={ref}
        type={type}
        className={cn(
          baseStyles,
          variants[variant],
          sizes[size],
          fullWidth && "w-full",
          className
        )}
        style={{
          borderRadius: themeConfig.borderRadius,
          fontFamily: themeConfig.fontFamily,
          ["--accent-glow" as string]: themeConfig.accentGlow,
          ["--primary" as string]: themeConfig.primaryColor,
          ["--primary-foreground" as string]: "hsl(0 0% 9%)",
          ["--secondary" as string]: themeConfig.secondaryAccent,
          ["--secondary-foreground" as string]: "hsl(0 0% 98%)",
          ["--background" as string]: themeConfig.backgroundColor,
          ["--accent" as string]: "hsl(224 40% 12%)",
          ["--accent-foreground" as string]: "hsl(0 0% 98%)",
          ["--input" as string]: "hsl(224 20% 20%)",
          ...style,
        }}
        whileTap={motionConfig.press}
        whileHover={{ scale: motionConfig.hover.scale }}
        transition={motionConfig.springs.snappy}
        onTapStart={() => hapticsService.tap()}
        onClick={onClick}
        disabled={isLoading || disabled}
      >
        {isLoading ? (
          <motion.div
            className="h-4 w-4 border-2 border-current border-t-transparent rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
        ) : (
          children
        )}
      </motion.button>
    );
  }
);

Button.displayName = "Button";
