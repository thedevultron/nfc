// Skeleton Component — Shadcn-style with custom gradient sweep animation
// Edit /src/config/theme.config.ts to change colors — do not modify this file

import { cn } from "../../utils/cn";
import { themeConfig } from "../../config/theme.config";

export function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("animate-shimmer rounded-lg bg-white/5", className)}
      style={{
        borderRadius: themeConfig.borderRadius,
        backgroundImage: `linear-gradient(
          90deg,
          rgba(255, 255, 255, 0) 0%,
          rgba(255, 255, 255, 0.05) 50%,
          rgba(255, 255, 255, 0) 100%
        )`,
        backgroundSize: "200% 100%",
      }}
      {...props}
    />
  );
}
