// Drawer Component — iOS-style bottom sheet with drag-to-dismiss gesture
// Edit /src/config/motion.config.ts to change spring physics — do not modify this file

import { useEffect } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform } from "framer-motion";
import { X } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { themeConfig } from "../../config/theme.config";
import { cn } from "../../utils/cn";

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  className?: string;
}

export function Drawer({ isOpen, onClose, title, children, className }: DrawerProps) {
  const y = useMotionValue(0);
  const opacity = useTransform(y, [0, 200], [1, 0]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const handleDragEnd = (_event: unknown, info: { offset: { y: number }; velocity: { y: number } }) => {
    if (info.offset.y > 150 || info.velocity.y > 500) {
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            className={cn(
              "fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl overflow-hidden",
              themeConfig.enableGlassmorphism && "backdrop-blur-xl bg-background/80 border-t border-white/10",
              className
            )}
            style={{
              borderRadius: `${themeConfig.borderRadius} ${themeConfig.borderRadius} 0 0`,
              ["--background" as string]: themeConfig.backgroundColor,
              paddingBottom: "env(safe-area-inset-bottom)",
              y,
              opacity,
            }}
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={motionConfig.springs.drawer}
            drag="y"
            dragConstraints={{ top: 0 }}
            dragElastic={0.2}
            onDragEnd={handleDragEnd}
          aria-modal="true"
          >
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-2">
              <div className="w-12 h-1.5 bg-white/20 rounded-full" />
            </div>

            {/* Header */}
            {title && (
              <div className="flex items-center justify-between px-6 pb-4">
                <h2
                  className="text-xl font-semibold"
                  style={{ fontFamily: themeConfig.fontFamily, letterSpacing: "-0.01em" }}
                >
                  {title}
                </h2>
                <button
                  onClick={onClose}
                  className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            )}

            {/* Content */}
            <div className="px-6 pb-6 max-h-[80vh] overflow-y-auto">
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
