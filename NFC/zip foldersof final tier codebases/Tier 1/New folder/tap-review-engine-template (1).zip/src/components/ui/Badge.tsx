// Badge Component — Shadcn-style primitive
// Edit /src/config/theme.config.ts to change colors, radius — do not modify this file

import { cn } from "../../utils/cn";
import { themeConfig } from "../../config/theme.config";

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "secondary" | "outline";
}

export function Badge({ className, variant = "default", ...props }: BadgeProps) {
  const variants = {
    default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
    secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
    outline: "text-foreground border border-input",
  };

  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
        variants[variant],
        className
      )}
      style={{
        ["--primary" as string]: themeConfig.primaryColor,
        ["--primary-foreground" as string]: "hsl(0 0% 9%)",
        ["--secondary" as string]: themeConfig.secondaryAccent,
        ["--secondary-foreground" as string]: "hsl(0 0% 98%)",
        ["--foreground" as string]: "hsl(0 0% 98%)",
        ["--input" as string]: "hsl(224 20% 20%)",
      }}
      {...props}
    />
  );
}
