// Input & Textarea Components — Shadcn-style primitives
// Edit /src/config/theme.config.ts to change colors, radius — do not modify this file

import { forwardRef } from "react";
import { cn } from "../../utils/cn";
import { themeConfig } from "../../config/theme.config";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        style={{
          borderRadius: themeConfig.borderRadius,
          fontFamily: themeConfig.fontFamily,
          ["--input" as string]: "hsl(224 20% 20%)",
          ["--background" as string]: themeConfig.backgroundColor,
          ["--ring" as string]: themeConfig.primaryColor,
          ["--muted-foreground" as string]: "hsl(224 20% 50%)",
        }}
        ref={ref}
        {...props}
      />
    );
  }
);
Input.displayName = "Input";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, ...props }, ref) => {
    return (
      <textarea
        className={cn(
          "flex min-h-[80px] w-full rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        style={{
          borderRadius: themeConfig.borderRadius,
          fontFamily: themeConfig.fontFamily,
          ["--input" as string]: "hsl(224 20% 20%)",
          ["--background" as string]: themeConfig.backgroundColor,
          ["--ring" as string]: themeConfig.primaryColor,
          ["--muted-foreground" as string]: "hsl(224 20% 50%)",
        }}
        ref={ref}
        {...props}
      />
    );
  }
);
Textarea.displayName = "Textarea";
