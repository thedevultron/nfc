// Card Component — Shadcn-style primitive with glassmorphism support
// Edit /src/config/theme.config.ts to change colors, radius — do not modify this file

import { forwardRef } from "react";
import { motion } from "framer-motion";
import { cn } from "../../utils/cn";
import { themeConfig } from "../../config/theme.config";
import { motionConfig } from "../../config/motion.config";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  glass?: boolean;
}

export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ className, glass, children, style }, ref) => {
    const glassStyles =
      glass && themeConfig.enableGlassmorphism
        ? "backdrop-blur-xl bg-background/70 border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.35)]"
        : "bg-surface border border-white/5";

    return (
      <motion.div
        ref={ref}
        className={cn("rounded-lg", glassStyles, className)}
        style={{
          borderRadius: themeConfig.borderRadius,
          ["--background" as string]: themeConfig.backgroundColor,
          ["--surface" as string]: themeConfig.surfaceColor,
          ...style,
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={motionConfig.springs.smooth}
      >
        {children}
      </motion.div>
    );
  }
);

Card.displayName = "Card";

export const CardHeader = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-1.5 p-6", className)} {...props} />
  )
);
CardHeader.displayName = "CardHeader";

export const CardTitle = forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3
      ref={ref}
      className={cn("text-2xl font-semibold leading-none tracking-tight", className)}
      style={{ fontFamily: themeConfig.fontFamily, letterSpacing: "-0.02em" }}
      {...props}
    />
  )
);
CardTitle.displayName = "CardTitle";

export const CardContent = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />
  )
);
CardContent.displayName = "CardContent";
