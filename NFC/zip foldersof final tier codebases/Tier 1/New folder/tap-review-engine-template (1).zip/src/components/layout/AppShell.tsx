// AppShell Component — Root layout with status-bar-safe padding
// Edit /src/config/theme.config.ts to change background, colors — do not modify this file

import { motion } from "framer-motion";
import { themeConfig } from "../../config/theme.config";
import { cn } from "../../utils/cn";

interface AppShellProps {
  children: React.ReactNode;
  className?: string;
}

export function AppShell({ children, className }: AppShellProps) {
  return (
    <motion.div
      className={cn(
        "min-h-screen w-full flex flex-col",
        "pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]",
        className
      )}
      style={{
        background: `linear-gradient(180deg, ${themeConfig.backgroundColor} 0%, ${themeConfig.surfaceColor} 100%)`,
        fontFamily: themeConfig.fontFamily,
        color: "hsl(0 0% 98%)",
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
}
