// NFCContextBanner — Top banner showing tap/scan context indicator
// Edit /src/config/client.config.ts to change business identity — do not modify this file

import { motion } from "framer-motion";
import { Wifi, QrCode } from "lucide-react";
import { Badge } from "../ui/Badge";
import { motionConfig } from "../../config/motion.config";

export function NFCContextBanner() {
  return (
    <motion.div
      className="flex items-center justify-center gap-2 py-3 px-4"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={motionConfig.springs.smooth}
    >
      <Badge variant="outline" className="gap-1.5 text-xs">
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Wifi className="w-3 h-3" />
        </motion.div>
        <span className="opacity-70">NFC Tap Detected</span>
      </Badge>
      <Badge variant="outline" className="gap-1.5 text-xs">
        <QrCode className="w-3 h-3" />
        <span className="opacity-70">Touchpoint #01</span>
      </Badge>
    </motion.div>
  );
}
