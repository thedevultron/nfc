// FooterBrand — Bottom branding with safe-area padding
// Edit /src/config/theme.config.ts to change colors, typography — do not modify this file

import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { themeConfig } from "../../config/theme.config";
import { motionConfig } from "../../config/motion.config";

export function FooterBrand() {
  return (
    <motion.footer
      className="mt-auto py-6 flex items-center justify-center gap-2 text-xs text-white/40"
      style={{
        fontFamily: themeConfig.fontFamily,
        paddingBottom: "calc(1.5rem + env(safe-area-inset-bottom))",
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ ...motionConfig.springs.smooth, delay: 0.5 }}
    >
      <motion.div
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      >
        <Sparkles className="w-3 h-3" />
      </motion.div>
      <span>Powered by Tier 1 • TAP Engine</span>
    </motion.footer>
  );
}
