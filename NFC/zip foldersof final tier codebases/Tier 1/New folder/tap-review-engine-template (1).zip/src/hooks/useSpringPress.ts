// useSpringPress Hook — Reusable "press-down" scale+shadow interaction
// Edit /src/config/motion.config.ts to change press scale — do not modify this file

import { useState } from "react";
import { motionConfig } from "../config/motion.config";
import { hapticsService } from "../services/haptics.service";

export function useSpringPress() {
  const [isPressed, setIsPressed] = useState(false);

  const bind = {
    onTapStart: () => {
      setIsPressed(true);
      hapticsService.tap();
    },
    onTap: () => {
      setIsPressed(false);
    },
    onTapCancel: () => {
      setIsPressed(false);
    },
    whileTap: {
      scale: motionConfig.press.scale,
      filter: `brightness(${motionConfig.press.brightness})`,
    },
    animate: {
      scale: isPressed ? motionConfig.press.scale : 1,
    },
  };

  return bind;
}
