// useTapAnalytics Hook — Fires on mount + on every CTA tap, debounced, non-blocking
// Edit /src/config/client.config.ts to change webhook URLs — do not modify this file

import { useEffect } from "react";
import { apiService } from "../services/api.service";
import type { AnalyticsPayload } from "../types/template.types";

export function useTapAnalytics(eventName: string, metadata?: Record<string, unknown>) {
  const touchpointId = `tp_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  useEffect(() => {
    // Fire mount event
    const payload: AnalyticsPayload = {
      event: `${eventName}_view`,
      timestamp: Date.now(),
      touchpointId,
      metadata,
    };

    // Non-blocking fire-and-forget
    apiService.trackAnalytics(payload).catch(() => {
      // Silent fail — analytics should never block UI
    });
  }, [eventName, metadata, touchpointId]);

  const trackInteraction = (interactionMetadata?: Record<string, unknown>) => {
    const payload: AnalyticsPayload = {
      event: `${eventName}_tap`,
      timestamp: Date.now(),
      touchpointId,
      metadata: { ...metadata, ...interactionMetadata },
    };

    apiService.trackAnalytics(payload).catch(() => {
      // Silent fail
    });
  };

  return { trackInteraction, touchpointId };
}
