// Type definitions for Tier 1: TAP Custom / Review Engine
// Edit /src/config/*.ts to change business logic — do not modify this file.

export type ActiveMode = "REVIEW" | "WIFI" | "CONTACT" | "HUB";

export type Vertical = "RESTAURANT" | "RETAIL" | "HOSPITALITY" | "SALON" | "GYM" | "CUSTOM";

export interface HubItem {
  label: string;
  icon: string; // Lucide icon name
  url: string;
  external: boolean;
  action?: "link" | "wifi" | "review" | "contact"; // Internal action override
}

export interface WiFiConfig {
  ssid: string;
  password: string;
}

export interface VCardConfig {
  name: string;
  phone: string;
  email?: string;
  org?: string;
  title?: string;
  url?: string;
}

export interface ClientConfig {
  businessName: string;
  subtitle: string;
  activeMode: ActiveMode;
  googleReviewUrl: string;
  n8nWebhookUrl: string;
  n8nFeedbackWebhook: string;
}

export interface ThemeConfig {
  primaryColor: string;
  secondaryAccent: string;
  accentGlow: string;
  backgroundColor: string;
  surfaceColor: string;
  borderRadius: string;
  fontFamily: string;
  enableGlassmorphism: boolean;
  defaultMode: "light" | "dark";
}

export interface MotionConfig {
  springs: {
    snappy: { type: "spring"; stiffness: number; damping: number; mass: number };
    smooth: { type: "spring"; stiffness: number; damping: number; mass: number };
    elastic: { type: "spring"; stiffness: number; damping: number; mass: number };
    drawer: { type: "spring"; stiffness: number; damping: number };
  };
  stagger: { children: number; delayChildren: number };
  press: { scale: number; brightness: number };
  hover: { scale: number };
  haptics: {
    tap: number;
    selection: number;
    success: number[];
    error: number[];
  };
}

export interface FeedbackPayload {
  rating: number;
  feedbackText: string;
  timestamp: number;
  touchpointId: string;
}

export interface AnalyticsPayload {
  event: string;
  timestamp: number;
  touchpointId: string;
  metadata?: Record<string, unknown>;
}
