// Touchpoints Configuration — Edit ONLY this file to change content, links, and vertical presets
// Do NOT modify components to change content — they read from this config

import type { HubItem, WiFiConfig, VCardConfig, Vertical } from "../types/template.types";

export const touchpointsConfig = {
  vertical: "RESTAURANT" as Vertical,
  icons: {
    primary: "Utensils", // Brand mark
    secondary: "Star", // Review icon
  },
  hub: [
    {
      label: "Reserve a Table",
      icon: "MessageSquare",
      url: "https://wa.me/91XXXXXXXXXX",
      external: true,
      action: "link" as const,
    },
    {
      label: "View Digital Menu",
      icon: "BookOpen",
      url: "/menu",
      external: false,
      action: "link" as const,
    },
    {
      label: "Connect to WiFi",
      icon: "Wifi",
      url: "",
      external: false,
      action: "wifi" as const,
    },
    {
      label: "Leave a Review",
      icon: "Star",
      url: "",
      external: false,
      action: "review" as const,
    },
  ] as HubItem[],
  wifi: {
    ssid: "Bistro_Guest",
    password: "welcome123",
  } as WiFiConfig,
  vcard: {
    name: "The Grand Bistro",
    phone: "+91XXXXXXXXXX",
    email: "hello@thegrandbistro.com",
    org: "Hospitality",
    title: "Fine Dining",
    url: "https://thegrandbistro.com",
  } as VCardConfig,
};
