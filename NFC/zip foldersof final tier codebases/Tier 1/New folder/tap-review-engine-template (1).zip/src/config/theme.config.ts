// Theme Configuration — Edit ONLY this file to change colors, typography, and visual tokens
// Do NOT modify components to change appearance — they read from this config

import type { ThemeConfig } from "../types/template.types";

export const themeConfig: ThemeConfig = {
  primaryColor: "hsl(38 92% 50%)", // Warm Amber
  secondaryAccent: "hsl(160 84% 39%)", // Emerald
  accentGlow: "hsl(38 92% 50% / 0.25)",
  backgroundColor: "hsl(224 71.4% 4.1%)",
  surfaceColor: "hsl(224 40% 8%)",
  borderRadius: "0.75rem",
  fontFamily: "'Geist', 'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
  enableGlassmorphism: true,
  defaultMode: "dark" as const,
};
