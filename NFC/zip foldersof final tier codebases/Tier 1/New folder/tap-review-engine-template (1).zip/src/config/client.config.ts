// Client Configuration — Edit ONLY this file to change business identity and webhook URLs
// Do NOT modify components to change business logic — they read from this config

import type { ClientConfig } from "../types/template.types";

export const clientConfig: ClientConfig = {
  businessName: "The Grand Bistro",
  subtitle: "Thanks for dining with us today",
  activeMode: "REVIEW" as const,
  googleReviewUrl: "https://maps.google.com/?q=your_place_id",
  n8nWebhookUrl: "https://n8n.yourdomain.com/webhook/tier1-analytics",
  n8nFeedbackWebhook: "https://n8n.yourdomain.com/webhook/tier1-feedback",
};
