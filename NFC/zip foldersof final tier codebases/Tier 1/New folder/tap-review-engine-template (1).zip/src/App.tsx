// App.tsx — Root shell with AnimatePresence route/mode transitions, suspense boundary
// Edit /src/config/client.config.ts to change activeMode — do not modify this file

import { Suspense, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Utensils } from "lucide-react";
import { AppShell } from "./components/layout/AppShell";
import { NFCContextBanner } from "./components/layout/NFCContextBanner";
import { FooterBrand } from "./components/layout/FooterBrand";
import { ReviewRouter } from "./components/touchpoints/ReviewRouter";
import { SocialHub } from "./components/touchpoints/SocialHub";
import { Skeleton } from "./components/ui/Skeleton";
import { Card, CardContent } from "./components/ui/Card";
import { clientConfig } from "./config/client.config";
import { themeConfig } from "./config/theme.config";
import { motionConfig } from "./config/motion.config";
import { useTapAnalytics } from "./hooks/useTapAnalytics";

function ModeSkeleton() {
  return (
    <Card glass className="p-6">
      <CardContent className="p-0 space-y-4">
        <div className="flex items-center gap-3">
          <Skeleton className="h-12 w-12 rounded-xl" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        </div>
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      </CardContent>
    </Card>
  );
}

function BrandHeader() {
  const [hasLoaded, setHasLoaded] = useState(false);

  useEffect(() => {
    setHasLoaded(true);
  }, []);

  return (
    <motion.div
      className="flex flex-col items-center pt-8 pb-6 px-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={motionConfig.springs.smooth}
    >
      {/* Animated brand icon — subtle 6deg rotate-settle on load */}
      <motion.div
        className="p-4 rounded-2xl mb-4"
        style={{
          background: `linear-gradient(135deg, ${themeConfig.primaryColor}20 0%, ${themeConfig.secondaryAccent}20 100%)`,
          border: `1px solid ${themeConfig.primaryColor}30`,
          boxShadow: `0 0 40px ${themeConfig.accentGlow}`,
        }}
        initial={{ rotate: -6, scale: 0.8, opacity: 0 }}
        animate={{ rotate: 0, scale: 1, opacity: 1 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 14,
          mass: 1.2,
        }}
      >
        <Utensils className="w-8 h-8" style={{ color: themeConfig.primaryColor }} />
      </motion.div>

      <motion.h1
        className="text-3xl font-semibold mb-2 text-center"
        style={{
          fontFamily: themeConfig.fontFamily,
          letterSpacing: "-0.02em",
        }}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ ...motionConfig.springs.smooth, delay: 0.1 }}
      >
        {clientConfig.businessName}
      </motion.h1>

      <motion.p
        className="text-sm text-white/60 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        {hasLoaded ? clientConfig.subtitle : "Setting your table..."}
      </motion.p>
    </motion.div>
  );
}



function QuickNav({
  current,
  onChange,
}: {
  current: string;
  onChange: (mode: "REVIEW" | "HUB") => void;
}) {
  const tabs = [
    { id: "REVIEW" as const, label: "Review" },
    { id: "HUB" as const, label: "Quick Links" },
  ];

  return (
    <div className="flex justify-center gap-2 px-4 py-4">
      {tabs.map((tab) => (
        <motion.button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className="px-4 py-2 text-sm rounded-full transition-colors"
          style={{
            background: current === tab.id ? `${themeConfig.primaryColor}20` : "transparent",
            color: current === tab.id ? themeConfig.primaryColor : "hsl(0 0% 70%)",
            border: `1px solid ${current === tab.id ? `${themeConfig.primaryColor}40` : "hsl(224 20% 20%)"}`,
          }}
          whileTap={{ scale: motionConfig.press.scale }}
          transition={motionConfig.springs.snappy}
        >
          {tab.label}
        </motion.button>
      ))}
    </div>
  );
}

function App() {
  useTapAnalytics("app_load");
  const [activeMode, setActiveMode] = useState<"REVIEW" | "HUB">(
    clientConfig.activeMode === "HUB" ? "HUB" : "REVIEW"
  );

  // Allow dynamic mode switching while preserving the original activeMode default
  const effectiveMode = activeMode;

  return (
    <AppShell>
      <NFCContextBanner />

      <div className="flex-1 flex flex-col items-center">
        <BrandHeader />

        <QuickNav current={effectiveMode} onChange={setActiveMode} />

        <Suspense fallback={<ModeSkeleton />}>
          <AnimatePresence mode="wait">
            <motion.div
              key={effectiveMode}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={motionConfig.springs.smooth}
              className="px-4 w-full max-w-md mx-auto"
            >
              {effectiveMode === "REVIEW" && <ReviewRouter />}
              {effectiveMode === "HUB" && <SocialHub />}
            </motion.div>
          </AnimatePresence>
        </Suspense>
      </div>

      <FooterBrand />
    </AppShell>
  );
}

export default App;
