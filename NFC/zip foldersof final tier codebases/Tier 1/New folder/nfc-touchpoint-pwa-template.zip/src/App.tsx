import { useEffect, useState } from "react";
import { AnimatePresence, motion, type PanInfo } from "framer-motion";
import { LayoutGrid, Star, Utensils } from "lucide-react";
import { AppShell } from "./components/layout/AppShell";
import { NFCContextBanner } from "./components/layout/NFCContextBanner";
import { ReviewRouter } from "./components/touchpoints/ReviewRouter";
import { SocialHub } from "./components/touchpoints/SocialHub";
import { Skeleton } from "./components/ui/skeleton";
import { clientConfig } from "./config/client.config";
import { motionConfig } from "./config/motion.config";
import { touchpointsConfig } from "./config/touchpoints.config";
import { useSpringPress } from "./hooks/useSpringPress";
import { useTapAnalytics } from "./hooks/useTapAnalytics";
import { useAdaptiveSpring, useReducedMotion } from "./hooks/useReducedMotion";
import type { TouchpointMode } from "./types/template.types";
import { cn } from "./utils/cn";

/**
 * TAP Tier-1 root shell. Orchestration only: REVIEW is the landing panel
 * (client.config.activeMode), HUB is the secondary swipeable panel.
 * All physics, copy, identity and content resolve from /src/config/* —
 * re-skin the whole app by editing config alone. Do not hardcode here.
 */

const PANELS: TouchpointMode[] = ["REVIEW", "HUB"];

/** "Setting your table…" — skeleton shimmer while config hydrates. */
function SettingTableScreen() {
  const reduced = useReducedMotion();
  return (
    <div className="space-y-5">
      <Skeleton className="h-[46px]" />
      <div className="flex items-center gap-3.5">
        <Skeleton className="size-12" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-2/3" />
          <Skeleton className="h-3.5 w-4/5" />
        </div>
      </div>
      <div className="flex flex-col items-center gap-4 py-10">
        <motion.div
          animate={reduced ? undefined : { rotate: [0, -6, 0], opacity: [0.55, 1, 0.55] }}
          transition={reduced ? undefined : { duration: 1.7, repeat: Infinity, ease: "easeInOut" }}
          className="grid size-14 place-items-center rounded-[calc(var(--tap-radius)+4px)] border border-[var(--tap-primary)]/25 bg-[var(--tap-primary)]/10 text-[var(--tap-primary)]"
        >
          <Utensils size={24} aria-hidden />
        </motion.div>
        <p
          className="text-[17px] font-medium tracking-[-0.01em] text-[var(--tap-muted)]"
          style={{ fontFamily: "var(--tap-display-font)" }}
        >
          {touchpointsConfig.copy.loading}
        </p>
      </div>
      <Skeleton className="h-44" />
      <div className="space-y-3">
        <Skeleton className="h-16" />
        <Skeleton className="h-16" />
        <Skeleton className="h-16" />
      </div>
    </div>
  );
}

export default function App() {
  const [ready, setReady] = useState(false);
  const [mode, setMode] = useState<TouchpointMode>(clientConfig.activeMode);
  const { trackTap } = useTapAnalytics();
  const reduced = useReducedMotion();
  const panelSpring = useAdaptiveSpring(motionConfig.springs.smooth);
  const snappy = useAdaptiveSpring(motionConfig.springs.snappy);
  const tabPress = useSpringPress({ withHover: false });

  // Simulated config hydration — skeletons hold the layout, no blank flash.
  useEffect(() => {
    const t = window.setTimeout(() => setReady(true), 620);
    return () => window.clearTimeout(t);
  }, []);

  const index = mode === "HUB" ? 1 : 0;

  const switchMode = (next: TouchpointMode) => {
    if (next === mode) return;
    setMode(next);
    trackTap(`mode_${next.toLowerCase()}`);
  };

  // Horizontal flick navigates REVIEW ↔ HUB; the visible transition is the
  // config-defined 20px vertical slide + fade (AnimatePresence mode="wait").
  const handleSwipe = (_event: unknown, info: PanInfo) => {
    const { distance, velocity } = motionConfig.gestures.swipe;
    if (info.offset.x < -distance || info.velocity.x < -velocity) switchMode("HUB");
    else if (info.offset.x > distance || info.velocity.x > velocity) switchMode("REVIEW");
  };

  return (
    <AppShell>
      <AnimatePresence mode="wait">
        {!ready ? (
          <motion.div
            key="setting-table"
            exit={{ opacity: 0, y: -motionConfig.entrance.y, transition: { duration: 0.18, ease: "easeOut" } }}
            className="flex-1"
          >
            <SettingTableScreen />
          </motion.div>
        ) : (
          <motion.div
            key="touchpoint"
            initial={{ opacity: 0, y: motionConfig.entrance.y }}
            animate={{ opacity: 1, y: 0 }}
            transition={panelSpring}
            className="flex flex-1 flex-col"
          >
            <NFCContextBanner />

            {/* Brand mark — the menu "opening": 6° rotate-settle spring */}
            <header className="mt-5 flex items-center gap-3.5">
              <motion.div
                initial={reduced ? false : { rotate: -6, scale: 0.8, opacity: 0 }}
                animate={{ rotate: 0, scale: 1, opacity: 1 }}
                transition={panelSpring}
                className="grid size-12 shrink-0 place-items-center rounded-[var(--tap-radius)] border border-[var(--tap-primary)]/30 bg-[var(--tap-primary)]/12 text-[var(--tap-primary)] shadow-[0_0_34px_var(--tap-accent-glow)]"
              >
                <Utensils size={22} strokeWidth={2} aria-hidden />
              </motion.div>
              <div className="min-w-0">
                <h1
                  className="truncate text-[22px] font-semibold tracking-[-0.02em] text-[var(--tap-text)]"
                  style={{ fontFamily: "var(--tap-display-font)" }}
                >
                  {clientConfig.businessName}
                </h1>
                <p className="truncate text-[13px] text-[var(--tap-muted)]">
                  {clientConfig.subtitle} · {clientConfig.locationLine}
                </p>
              </div>
            </header>

            {/* Segmented mode switch */}
            <div
              role="tablist"
              aria-label="Touchpoint panels"
              className="relative mt-6 grid grid-cols-2 rounded-[var(--tap-radius)] border border-white/[0.07] bg-white/[0.03] p-1"
            >
              <motion.span
                aria-hidden
                className="absolute inset-y-1 left-1 w-[calc(50%-4px)] rounded-[calc(var(--tap-radius)-3px)] border border-white/10 bg-[var(--tap-surface)] shadow-[0_4px_16px_rgba(0,0,0,0.35)]"
                animate={{ x: index === 1 ? "100%" : "0%" }}
                transition={snappy}
              />
              {PANELS.map((panel, i) => (
                <motion.button
                  key={panel}
                  type="button"
                  role="tab"
                  aria-selected={i === index}
                  onClick={() => switchMode(panel)}
                  whileTap={tabPress.whileTap}
                  transition={tabPress.transition}
                  onTapStart={tabPress.onTapStart}
                  className={cn(
                    "relative z-10 flex h-9 items-center justify-center gap-1.5 rounded-[calc(var(--tap-radius)-3px)] text-[13px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--tap-primary)]/50",
                    i === index ? "text-[var(--tap-text)]" : "text-[var(--tap-muted)]"
                  )}
                >
                  {panel === "REVIEW" ? <Star size={14} aria-hidden /> : <LayoutGrid size={14} aria-hidden />}
                  {panel === "REVIEW"
                    ? touchpointsConfig.copy.segmented.review
                    : touchpointsConfig.copy.segmented.hub}
                </motion.button>
              ))}
            </div>

            {/* Swipeable panel area */}
            <div className="flex-1">
              <AnimatePresence mode="wait">
                <motion.div
                  key={mode}
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.08}
                  onDragEnd={handleSwipe}
                  initial={{ opacity: 0, y: motionConfig.entrance.y }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{
                    opacity: 0,
                    y: -motionConfig.entrance.y / 2,
                    transition: { duration: 0.16, ease: "easeOut" },
                  }}
                  transition={panelSpring}
                  className="h-full select-none pt-4"
                >
                  {mode === "REVIEW" ? (
                    <ReviewRouter />
                  ) : (
                    <SocialHub onGoReview={() => switchMode("REVIEW")} />
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Panel position dots */}
            <div className="mt-4 flex items-center justify-center gap-1.5" aria-hidden>
              {PANELS.map((panel, i) => (
                <motion.span
                  key={panel}
                  animate={{ width: i === index ? 18 : 5, opacity: i === index ? 1 : 0.35 }}
                  transition={snappy}
                  className="h-[5px] rounded-full bg-[var(--tap-primary)]"
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </AppShell>
  );
}
