import type { TouchpointsConfig } from "../types/template.types";

/**
 * ── TAP Tier-1 · Vertical Content (RESTAURANT preset) ──────────────
 * EDIT THIS FILE to change everything the guest reads and taps:
 * hub rows, menu, WiFi credentials, vCard fields and all copywriting.
 * Icons are referenced by name (IconName) and resolved in ui/icon.tsx.
 * Do not modify /src/components — it only renders what lives here.
 */
export const touchpointsConfig: TouchpointsConfig = {
  vertical: "RESTAURANT",
  icons: {
    primary: "Utensils", // brand mark — menu "opening" settle animation
    secondary: "Star",
  },
  hub: [
    {
      label: "Reserve a Table",
      description: "WhatsApp · replies in minutes",
      icon: "MessageSquare",
      tint: "secondary",
      url: "https://wa.me/919876543210?text=Hi%20Grand%20Bistro%2C%20I%27d%20like%20to%20reserve%20a%20table.",
      external: true,
      action: null,
    },
    {
      label: "View Digital Menu",
      description: "Tonight's kitchen favourites",
      icon: "BookOpen",
      tint: "primary",
      external: false,
      action: "menu",
    },
    {
      label: "Connect to WiFi",
      description: "One tap, no front-desk run",
      icon: "Wifi",
      tint: "neutral",
      external: false,
      action: "wifi",
    },
    {
      label: "Leave a Review",
      description: "30 seconds, straight to the map",
      icon: "Star",
      tint: "primary",
      external: false,
      action: "review",
    },
  ],
  menu: {
    title: "Evening Favourites",
    note: "Prices inclusive of taxes · the menu rotates with the season",
    items: [
      { name: "Smoked Burrata", description: "Charred sourdough, basil oil, pepper honey", price: "₹649", tag: "Chef's pick" },
      { name: "Goan Prawn Balchão", description: "Coastal spice, coconut vinegar, steamed rice", price: "₹729" },
      { name: "Duck Moilee", description: "Kerala-style, curry leaf, tender coconut", price: "₹849" },
      { name: "Dahi Ke Kebab", description: "Hung curd, cashew, saffron aioli", price: "₹449", tag: "Vegetarian" },
      { name: "Molten Gulab Jamun", description: "Warm rabri, pistachio dust", price: "₹349" },
    ],
  },
  wifi: { ssid: "GrandBistro_Guest", password: "toast&butter24", band: "5 GHz" },
  vcard: {
    name: "The Grand Bistro",
    org: "Grand Hospitality Pvt. Ltd.",
    phone: "+91 98765 43210",
    email: "hello@grandbistro.in",
    url: "https://grandbistro.in",
    address: "12 Koregaon Park Lane, Pune 411001",
  },
  copy: {
    loading: "Setting your table…",
    banner: { status: "NFC · Table 01", badge: "Connected" },
    segmented: { review: "Rate", hub: "Explore" },
    review: {
      title: "How was everything tonight?",
      subtitle: "Your table, your tap, your honest word.",
      hintDefault: "Tap a star — honest is lovely.",
      // Indexed 1–5 by the star rating.
      ratingLabels: [
        "",
        "Not the evening we hoped for.",
        "We can do better than that.",
        "Good — tell us what would make it great.",
        "Lovely. Almost perfect.",
        "Exceptional — the chef is beaming.",
      ],
      highNote: "Wonderful. Would you share the love where it counts?",
      highCta: "Post on Google Maps",
      reset: "Change my rating",
      lowNote:
        "We're sorry. Tell us what went wrong — this goes straight to the owner, never public.",
      lowCta: "Tell the owner",
    },
    feedback: {
      title: "Straight to the owner",
      body: "Private by design — never posted, never public.",
      placeholder: "The prawns arrived cold and the music was loud…",
      cta: "Send to owner",
      privacy: "Private · read by the owner only",
      successTitle: "Noted with thanks",
      successBody: "The owner reads every word — usually before dessert.",
      close: "Back to your evening",
    },
    wifi: {
      title: "Table WiFi",
      body: "The network hides its name on some phones — pick the SSID below.",
      passwordLabel: "Password",
      reveal: "Show password",
      hide: "Hide password",
      copy: "Copy Password",
      copied: "Copied",
      qr: "WiFi QR",
      qrHint: "Point a phone camera here to join instantly.",
    },
    contact: {
      title: "Keep us in your pocket",
      body: "Save the bistro — reservations, events and Sunday roasts.",
      saveCta: "Save Contact",
      saved: "Saved to device",
      whatsapp: "WhatsApp",
      call: "Call",
    },
    hub: {
      title: "Everything at this table",
      body: "One card, the whole evening — tap through.",
    },
    menu: { badge: "Tonight", note: "Ask your server about today's off-menu special." },
    footer: "Powered by TAP · Tier 1 Touchpoint",
  },
};
