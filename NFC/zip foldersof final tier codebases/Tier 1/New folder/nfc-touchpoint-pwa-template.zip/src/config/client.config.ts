import type { ClientConfig } from "../types/template.types";

/**
 * ── TAP Tier-1 · Client Deployment ─────────────────────────────────
 * EDIT THIS FILE per deployment: business identity, landing mode and
 * n8n endpoints. Do not modify /src/components, /src/hooks or
 * /src/services — they only read from here.
 */
export const clientConfig: ClientConfig = {
  businessName: "The Grand Bistro",
  // Warm, hospitality-driven — shown under the brand mark.
  subtitle: "Thanks for dining with us tonight",
  locationLine: "Pune · Touchpoint #01",
  tableLabel: "Table 01",
  touchpointId: "GRAND-BISTRO-T01",
  // Default landing panel. "HUB" is the secondary swipeable panel.
  activeMode: "REVIEW",
  googleReviewUrl: "https://maps.google.com/?q=The+Grand+Bistro+Pune",
  n8nWebhookUrl: "https://n8n.yourdomain.com/webhook/tier1-analytics",
  n8nFeedbackWebhook: "https://n8n.yourdomain.com/webhook/tier1-feedback",
};
