import type { MotionSystemConfig } from "../types/template.types";

/**
 * ── TAP Tier-1 · Motion System ─────────────────────────────────────
 * Single source of truth for ALL animation physics.
 * EDIT THIS FILE to change how the app *feels* — springs, stagger,
 * press depth, gesture thresholds, haptic patterns. Components read
 * from here and never inline their own values — do not modify them.
 */
export const motionConfig: MotionSystemConfig = {
  springs: {
    snappy: { type: "spring", stiffness: 500, damping: 32, mass: 0.9 }, // buttons, taps
    smooth: { type: "spring", stiffness: 300, damping: 30, mass: 1 }, // card entrances
    elastic: { type: "spring", stiffness: 420, damping: 18, mass: 1 }, // star rating pop
    drawer: { type: "spring", stiffness: 380, damping: 38 }, // bottom sheets
  },
  stagger: {
    children: 0.045,
    delayChildren: 0.08,
    cascade: 0.04, // per-star ripple delay
  },
  press: { scale: 0.96, brightness: 0.94 },
  hover: { scale: 1.02, chevronNudge: 2 },
  entrance: { y: 20 }, // mode transitions: 20px vertical slide + fade
  reduced: { duration: 0.15, ease: "easeOut" }, // prefers-reduced-motion fallback
  gestures: {
    swipe: { distance: 56, velocity: 480 }, // REVIEW ↔ HUB panel flick
    drawer: { dismissDistance: 96, dismissVelocity: 620 }, // iOS-sheet snap logic
  },
  haptics: {
    tap: 8,
    selection: 12,
    success: [10, 40, 10],
    error: [20, 30, 20, 30],
  },
};
