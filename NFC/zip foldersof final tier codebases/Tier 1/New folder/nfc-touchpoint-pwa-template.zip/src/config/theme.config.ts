import type { ThemeConfig } from "../types/template.types";

/**
 * ── TAP Tier-1 · Theme ─────────────────────────────────────────────
 * EDIT THIS FILE to re-skin the entire experience (palette, radius,
 * type stacks, light/dark). Values are injected as --tap-* CSS vars at
 * boot — do not modify /src/components, /src/hooks or /src/services.
 */
export const themeConfig: ThemeConfig = {
  // Warm Amber — the "candlelight" primary.
  primaryColor: "hsl(38 92% 50%)",
  // Emerald — reserved for success / WhatsApp / private-feedback tints.
  secondaryAccent: "hsl(160 84% 39%)",
  // Ambient glow behind every primary CTA (the "premium tell").
  accentGlow: "hsl(38 92% 50% / 0.25)",
  // True-black-adjacent, never pure #000.
  backgroundColor: "hsl(224 71.4% 4.1%)",
  surfaceColor: "hsl(224 40% 8%)",
  textColor: "hsl(40 24% 95%)",
  mutedTextColor: "hsl(226 12% 62%)",
  borderColor: "hsl(224 22% 17%)",
  borderRadius: "0.75rem",
  fontFamily: "'Geist Variable', 'Inter', ui-sans-serif, system-ui, sans-serif",
  displayFontFamily: "'Fraunces Variable', Georgia, serif",
  enableGlassmorphism: true,
  defaultMode: "dark",
};
