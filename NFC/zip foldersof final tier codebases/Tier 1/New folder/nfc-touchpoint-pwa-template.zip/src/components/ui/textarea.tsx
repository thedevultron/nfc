import type { TextareaHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

/** Multi-line field — the private-feedback workhorse. */
export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        "w-full resize-none rounded-[var(--tap-radius)] border border-white/10 bg-white/[0.04] px-4 py-3 text-[15px] leading-relaxed text-[var(--tap-text)] transition-colors placeholder:text-[var(--tap-muted)]/60 focus:border-[var(--tap-primary)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--tap-primary)]/25",
        className
      )}
      {...props}
    />
  );
}
