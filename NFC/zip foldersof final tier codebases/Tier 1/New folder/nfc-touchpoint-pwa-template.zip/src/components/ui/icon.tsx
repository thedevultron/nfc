import {
  BookOpen,
  Check,
  ChevronRight,
  Clock,
  Copy,
  ExternalLink,
  Eye,
  EyeOff,
  LayoutGrid,
  MapPin,
  MessageCircle,
  MessageSquare,
  Phone,
  QrCode,
  ShieldCheck,
  Signal,
  Sparkles,
  Star,
  UserPlus,
  Utensils,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import type { LucideIcon, LucideProps } from "lucide-react";
import type { IconName } from "../../types/template.types";

/**
 * String → Lucide mark resolver. /src/config/touchpoints.config.ts refers
 * to icons by name ("Utensils", "Star"…) and this registry is the only
 * place a Lucide import is allowed to touch config content.
 */
const registry: Record<IconName, LucideIcon> = {
  Utensils,
  Star,
  Wifi,
  MessageSquare,
  MessageCircle,
  BookOpen,
  Phone,
  UserPlus,
  ChevronRight,
  ExternalLink,
  Sparkles,
  Eye,
  EyeOff,
  Copy,
  Check,
  MapPin,
  QrCode,
  X,
  Zap,
  LayoutGrid,
  Clock,
  Signal,
  ShieldCheck,
};

export interface IconProps extends LucideProps {
  name: IconName;
}

export function Icon({ name, ...props }: IconProps) {
  const Mark = registry[name] ?? Sparkles;
  return <Mark aria-hidden {...props} />;
}
