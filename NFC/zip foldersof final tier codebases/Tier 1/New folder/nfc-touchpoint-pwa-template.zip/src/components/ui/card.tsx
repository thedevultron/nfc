import type { HTMLAttributes } from "react";
import { cn } from "../../utils/cn";

/**
 * Glass surface primitive. Radius token from /src/config/theme.config.ts,
 * glass treatment applied when enableGlassmorphism is on (always, in this
 * preset). Do not modify — re-skin via the theme config instead.
 */

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-[var(--tap-radius)] border border-white/10 bg-[var(--tap-surface)]/70 shadow-[0_8px_30px_rgba(0,0,0,0.35)] backdrop-blur-xl",
        className
      )}
      {...props}
    />
  );
}

export function CardContent({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-5", className)} {...props} />;
}

export function CardTitle({ className, ...props }: HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3
      className={cn("text-lg font-semibold tracking-[-0.015em] text-[var(--tap-text)]", className)}
      {...props}
    />
  );
}

export function CardDescription({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("mt-0.5 text-sm text-[var(--tap-muted)]", className)} {...props} />;
}
