import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { motionConfig } from "../../config/motion.config";
import { useAdaptiveSpring } from "../../hooks/useReducedMotion";

/**
 * Centered modal (the menu, confirmations). Springs from
 * /src/config/motion.config.ts — do not modify this file.
 * Portaled to <body> so ancestor transforms never trap it.
 */

export interface DialogProps {
  open: boolean;
  onClose: () => void;
  labelledBy?: string;
  children: ReactNode;
}

export function Dialog({ open, onClose, labelledBy, children }: DialogProps) {
  const popSpring = useAdaptiveSpring(motionConfig.springs.snappy);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 grid place-items-center p-6" initial={false}>
          <motion.div
            className="absolute inset-0 bg-[hsl(224_71%_2%)]/70 backdrop-blur-[3px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.15, ease: "easeOut" } }}
            onClick={onClose}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby={labelledBy}
            initial={{ opacity: 0, scale: 0.92, y: 18 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10, transition: { duration: 0.15, ease: "easeOut" } }}
            transition={popSpring}
            className="relative w-full max-w-[400px] rounded-[calc(var(--tap-radius)+4px)] border border-white/10 bg-[var(--tap-surface)]/95 p-5 shadow-[0_24px_70px_rgba(0,0,0,0.6)] backdrop-blur-xl"
          >
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
