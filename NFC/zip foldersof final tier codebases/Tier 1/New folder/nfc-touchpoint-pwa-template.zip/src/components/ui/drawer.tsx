import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, type PanInfo } from "framer-motion";
import { X } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { themeConfig } from "../../config/theme.config";
import { useAdaptiveSpring } from "../../hooks/useReducedMotion";
import { Button } from "./button";

/**
 * iOS-style bottom sheet with REAL drag-to-dismiss: drag="y", clamped
 * constraints, rubber-band overscroll (dragElastic) and velocity-based
 * snap on release. All thresholds + spring come from
 * /src/config/motion.config.ts — do not modify this file.
 * Portaled to <body> so ancestor transforms never trap it.
 */

export interface DrawerProps {
  open: boolean;
  onClose: () => void;
  title: string;
  body?: string;
  children: ReactNode;
}

export function Drawer({ open, onClose, title, body, children }: DrawerProps) {
  const sheetSpring = useAdaptiveSpring(motionConfig.springs.drawer);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  const handleDragEnd = (_event: unknown, info: PanInfo) => {
    const { dismissDistance, dismissVelocity } = motionConfig.gestures.drawer;
    if (info.offset.y > dismissDistance || info.velocity.y > dismissVelocity) {
      onClose();
    }
  };

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50" initial={false}>
          <motion.div
            className="absolute inset-0 bg-[hsl(224_71%_2%)]/70 backdrop-blur-[3px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.18, ease: "easeOut" } }}
            onClick={onClose}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={title}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.55 }}
            dragDirectionLock
            onDragEnd={handleDragEnd}
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%", transition: { duration: 0.22, ease: "easeIn" } }}
            transition={sheetSpring}
            className="absolute inset-x-0 bottom-0 mx-auto max-h-[88dvh] w-full max-w-[420px] overflow-hidden rounded-t-[calc(var(--tap-radius)+10px)] border border-b-0 border-white/10 bg-[var(--tap-surface)]/95 shadow-[0_-16px_60px_rgba(0,0,0,0.55)] backdrop-blur-xl"
            style={{
              paddingBottom: "env(safe-area-inset-bottom)",
              borderRadius: themeConfig.enableGlassmorphism ? undefined : 0,
            }}
          >
            <div className="cursor-grab touch-none pb-1 pt-2.5 active:cursor-grabbing" style={{ display: "flex", justifyContent: "center" }}>
              <span className="h-1 w-10 rounded-full bg-white/20" />
            </div>
            <div className="flex items-start justify-between gap-4 px-5 pb-1 pt-2">
              <div className="min-w-0">
                <h2
                  className="text-[19px] font-semibold tracking-[-0.015em] text-[var(--tap-text)]"
                  style={{ fontFamily: "var(--tap-display-font)" }}
                >
                  {title}
                </h2>
                {body && <p className="mt-0.5 text-[13px] text-[var(--tap-muted)]">{body}</p>}
              </div>
              <Button variant="ghost" size="icon" onTap={onClose} aria-label="Close sheet" className="-mr-1.5 shrink-0">
                <X size={17} />
              </Button>
            </div>
            <div className="max-h-[62dvh] overflow-y-auto px-5 pb-6 pt-2">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
