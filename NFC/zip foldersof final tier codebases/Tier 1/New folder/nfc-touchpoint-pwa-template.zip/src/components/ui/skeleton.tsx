import type { HTMLAttributes } from "react";
import { cn } from "../../utils/cn";

/**
 * Shimmer block for the first 200–400ms of config hydration — the app
 * must never show a blank flash. Sweep animation lives in index.css
 * (.tap-skeleton) and is disabled under prefers-reduced-motion.
 */
export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("tap-skeleton rounded-[calc(var(--tap-radius)-2px)]", className)} {...props} />;
}
