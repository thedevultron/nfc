import type { HTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../utils/cn";

/** Status chip. Tints derive from /src/config/theme.config.ts tokens. */

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[11px] font-medium tracking-[-0.01em]",
  {
    variants: {
      variant: {
        default:
          "border-[var(--tap-primary)]/30 bg-[var(--tap-primary)]/12 text-[var(--tap-primary)]",
        secondary:
          "border-[var(--tap-secondary)]/30 bg-[var(--tap-secondary)]/12 text-[hsl(158_65%_62%)]",
        muted: "border-white/10 bg-white/[0.05] text-[var(--tap-muted)]",
      },
    },
    defaultVariants: { variant: "default" },
  }
);

export interface BadgeProps
  extends HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
