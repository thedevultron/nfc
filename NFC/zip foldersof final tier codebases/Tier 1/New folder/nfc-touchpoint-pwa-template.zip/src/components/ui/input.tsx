import type { InputHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

/** Field primitive — focus ring tinted by /src/config/theme.config.ts. */
export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-12 w-full rounded-[var(--tap-radius)] border border-white/10 bg-white/[0.04] px-4 text-[15px] text-[var(--tap-text)] transition-colors placeholder:text-[var(--tap-muted)]/60 focus:border-[var(--tap-primary)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--tap-primary)]/25",
        className
      )}
      {...props}
    />
  );
}
