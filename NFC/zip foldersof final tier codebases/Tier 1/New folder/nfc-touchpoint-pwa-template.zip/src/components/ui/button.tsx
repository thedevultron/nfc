import type { ComponentPropsWithoutRef } from "react";
import { motion } from "framer-motion";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../utils/cn";
import { useSpringPress } from "../../hooks/useSpringPress";

/**
 * Primary pressable. The spring press + haptic tick on touch-down are
 * baked in via useSpringPress (physics from /src/config/motion.config.ts,
 * palette from /src/config/theme.config.ts) — do not modify this file.
 */

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium tracking-[-0.01em] select-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--tap-primary)]/60 disabled:pointer-events-none disabled:opacity-45 [&_svg]:pointer-events-none [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-[var(--tap-primary)] text-[hsl(30_60%_8%)] shadow-[0_0_40px_var(--tap-accent-glow),0_2px_12px_rgba(0,0,0,0.4)] hover:bg-[var(--tap-primary-bright)]",
        secondary:
          "border border-white/10 bg-white/[0.07] text-[var(--tap-text)] backdrop-blur-xl hover:bg-white/[0.12]",
        ghost:
          "text-[var(--tap-muted)] hover:bg-white/[0.06] hover:text-[var(--tap-text)]",
        emerald:
          "border border-[var(--tap-secondary)]/30 bg-[var(--tap-secondary)]/15 text-[hsl(158_65%_65%)] shadow-[0_0_28px_var(--tap-secondary-glow)] hover:bg-[var(--tap-secondary)]/25",
        outline:
          "border border-white/[0.12] text-[var(--tap-text)] hover:bg-white/[0.05]",
      },
      size: {
        default: "h-12 px-5 text-[15px] rounded-[var(--tap-radius)]",
        sm: "h-9 px-3.5 text-[13px] rounded-[calc(var(--tap-radius)-2px)]",
        lg: "h-14 px-6 text-base rounded-[calc(var(--tap-radius)+2px)]",
        icon: "size-10 rounded-[var(--tap-radius)]",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
);

export interface ButtonProps
  extends Omit<
      ComponentPropsWithoutRef<typeof motion.button>,
      "transition" | "whileTap" | "whileHover" | "onTapStart"
    >,
    VariantProps<typeof buttonVariants> {
  /** Ambient glow intensity override for hero CTAs. */
  glow?: boolean;
}

export function Button({ className, variant, size, glow, ...props }: ButtonProps) {
  const press = useSpringPress();
  return (
    <motion.button
      type="button"
      className={cn(buttonVariants({ variant, size }), glow === false && "shadow-none", className)}
      {...press}
      {...props}
    />
  );
}
