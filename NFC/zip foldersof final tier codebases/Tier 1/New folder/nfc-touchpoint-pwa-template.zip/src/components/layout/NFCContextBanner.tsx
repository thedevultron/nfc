import { useState } from "react";
import { motion } from "framer-motion";
import { Clock } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { useAdaptiveSpring, useReducedMotion } from "../../hooks/useReducedMotion";
import { Badge } from "../ui/badge";

/**
 * "You just tapped" context strip — live dot, table id, tap time.
 * Copy lives in /src/config/touchpoints.config.ts (copy.banner) and the
 * table label in /src/config/client.config.ts. Do not modify this file.
 */
export function NFCContextBanner() {
  const reduced = useReducedMotion();
  const enterSpring = useAdaptiveSpring(motionConfig.springs.smooth);
  const [tappedAt] = useState(() =>
    new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  );
  const { banner } = touchpointsConfig.copy;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={enterSpring}
      className="flex items-center justify-between rounded-[var(--tap-radius)] border border-white/10 bg-white/[0.04] px-3.5 py-2.5 shadow-[0_8px_30px_rgba(0,0,0,0.35)] backdrop-blur-xl"
    >
      <span className="flex items-center gap-2.5">
        <span className="relative flex size-2">
          {!reduced && (
            <motion.span
              className="absolute inset-0 rounded-full bg-[var(--tap-primary)]"
              animate={{ scale: [1, 2.5], opacity: [0.65, 0] }}
              transition={{ duration: 1.7, repeat: Infinity, ease: "easeOut" }}
            />
          )}
          <span className="relative size-2 rounded-full bg-[var(--tap-primary)] shadow-[0_0_10px_var(--tap-accent-glow)]" />
        </span>
        <span className="text-[13px] font-medium tracking-[-0.01em] text-[var(--tap-text)]">
          {banner.status}
        </span>
      </span>
      <span className="flex items-center gap-2 text-xs text-[var(--tap-muted)]">
        <span className="flex items-center gap-1 tabular-nums">
          <Clock size={12} />
          {tappedAt}
        </span>
        <Badge variant="secondary">{banner.badge}</Badge>
      </span>
    </motion.div>
  );
}
