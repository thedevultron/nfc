import { Zap } from "lucide-react";
import { touchpointsConfig } from "../../config/touchpoints.config";

/**
 * Platform attribution, pinned above the home indicator.
 * Copy lives in /src/config/touchpoints.config.ts (copy.footer).
 * Do not modify this file.
 */
export function FooterBrand() {
  return (
    <footer
      className="mt-auto pt-8"
      style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 18px)" }}
    >
      <p className="flex items-center justify-center gap-1.5 text-[11px] text-[var(--tap-muted)]/70">
        <Zap size={11} className="text-[var(--tap-primary)]" aria-hidden />
        {touchpointsConfig.copy.footer}
      </p>
    </footer>
  );
}
