import { useEffect, type ReactNode } from "react";
import { motion } from "framer-motion";
import { themeConfig } from "../../config/theme.config";
import { useReducedMotion } from "../../hooks/useReducedMotion";
import { FooterBrand } from "./FooterBrand";

/**
 * Root shell: injects every /src/config/theme.config.ts value as --tap-*
 * CSS variables, paints the layered ambient background and frames the
 * touchpoint column (phone-width, status-bar + home-indicator safe).
 * Re-skin via theme.config.ts — do not modify this file.
 */

function applyThemeVars() {
  const s = document.documentElement.style;
  s.setProperty("--tap-primary", themeConfig.primaryColor);
  s.setProperty("--tap-secondary", themeConfig.secondaryAccent);
  s.setProperty("--tap-accent-glow", themeConfig.accentGlow);
  s.setProperty("--tap-bg", themeConfig.backgroundColor);
  s.setProperty("--tap-surface", themeConfig.surfaceColor);
  s.setProperty("--tap-text", themeConfig.textColor);
  s.setProperty("--tap-muted", themeConfig.mutedTextColor);
  s.setProperty("--tap-border", themeConfig.borderColor);
  s.setProperty("--tap-radius", themeConfig.borderRadius);
  s.setProperty("--tap-font", themeConfig.fontFamily);
  s.setProperty("--tap-display-font", themeConfig.displayFontFamily);
  s.setProperty("color-scheme", themeConfig.defaultMode);
}

const NOISE_URI =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.4'/%3E%3C/svg%3E\")";

const EMBERS = [
  { left: "20%", size: 3, delay: 0, duration: 7 },
  { left: "62%", size: 4, delay: 2.4, duration: 9.5 },
  { left: "40%", size: 2.5, delay: 4.2, duration: 8 },
  { left: "81%", size: 3, delay: 1.1, duration: 10.5 },
];

function AmbientBackground() {
  const reduced = useReducedMotion();
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* Candle-glow bloom, breathing slowly above the fold */}
      <motion.div
        className="absolute -top-52 left-1/2 size-[560px] -translate-x-1/2 rounded-full bg-[var(--tap-primary)] blur-[130px]"
        animate={reduced ? undefined : { scale: [1, 1.07, 1], opacity: [0.15, 0.21, 0.15] }}
        transition={reduced ? undefined : { duration: 9, repeat: Infinity, ease: "easeInOut" }}
        style={{ opacity: reduced ? 0.17 : undefined }}
      />
      {/* Emerald service-light counterpoint, bottom-left */}
      <div className="absolute -bottom-40 -left-32 size-[420px] rounded-full bg-[var(--tap-secondary)] opacity-[0.08] blur-[120px]" />
      {/* Rising embers */}
      {!reduced &&
        EMBERS.map((e, i) => (
          <motion.span
            key={i}
            className="absolute bottom-[26%] rounded-full bg-[var(--tap-primary)] blur-[1px]"
            style={{ left: e.left, width: e.size, height: e.size }}
            initial={{ y: 0, opacity: 0 }}
            animate={{ y: [8, -110], opacity: [0, 0.7, 0] }}
            transition={{ duration: e.duration, delay: e.delay, repeat: Infinity, ease: "easeOut" }}
          />
        ))}
      {/* Film grain */}
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{ backgroundImage: NOISE_URI, mixBlendMode: "overlay" }}
      />
      {/* Vignette to keep the column legible */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_52%,rgba(0,0,0,0.5))]" />
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  useEffect(() => {
    applyThemeVars();
  }, []);

  return (
    <div
      className="relative min-h-dvh overflow-x-clip bg-[var(--tap-bg)] text-[var(--tap-text)] antialiased"
      style={{ fontFamily: "var(--tap-font)" }}
    >
      <AmbientBackground />
      <div
        className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[420px] flex-col border-x border-white/[0.04] px-5"
        style={{ paddingTop: "calc(env(safe-area-inset-top) + 18px)" }}
      >
        {children}
        <FooterBrand />
      </div>
    </div>
  );
}
