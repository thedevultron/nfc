import { useMemo } from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { useReducedMotion } from "../../hooks/useReducedMotion";

/**
 * Confetti-lite micro burst: 8 Sparkle marks fly out, arc and fall,
 * gone inside 500ms. Deterministic per burstKey so re-taps re-burst.
 * Skipped entirely under prefers-reduced-motion. Do not modify —
 * retune feel via /src/config/motion.config.ts.
 */

const PARTICLE_COUNT = 8;

export function ConfettiBurst({ burstKey }: { burstKey: number }) {
  const reduced = useReducedMotion();

  const particles = useMemo(() => {
    if (burstKey === 0) return [];
    return Array.from({ length: PARTICLE_COUNT }, (_, i) => {
      const angle = (i / PARTICLE_COUNT) * Math.PI * 2 + (i % 2) * 0.35;
      const dist = 48 + ((i * 13) % 32);
      return {
        id: `${burstKey}-${i}`,
        dx: Math.cos(angle) * dist,
        dy: Math.sin(angle) * dist * 0.7 - 24,
        color:
          i % 3 === 0
            ? "var(--tap-secondary)"
            : i % 3 === 1
              ? "var(--tap-primary)"
              : "hsl(42 95% 78%)",
        size: 11 + (i % 3) * 4,
        rotate: ((i * 47) % 140) - 70,
      };
    });
  }, [burstKey]);

  if (reduced || particles.length === 0) return null;

  return (
    <span aria-hidden className="pointer-events-none absolute inset-0 z-20 grid place-items-center overflow-visible">
      {particles.map((p) => (
        <motion.span
          key={p.id}
          className="absolute"
          style={{ color: p.color }}
          initial={{ x: 0, y: 0, opacity: 1, scale: 0.3, rotate: 0 }}
          animate={{
            x: [0, p.dx, p.dx * 1.06],
            y: [0, p.dy, p.dy + 72],
            opacity: [1, 1, 0],
            scale: [0.3, 1, 0.75],
            rotate: p.rotate,
          }}
          transition={{ duration: 0.5, times: [0, 0.55, 1], ease: "easeOut" }}
        >
          <Sparkles size={p.size} />
        </motion.span>
      ))}
    </span>
  );
}
