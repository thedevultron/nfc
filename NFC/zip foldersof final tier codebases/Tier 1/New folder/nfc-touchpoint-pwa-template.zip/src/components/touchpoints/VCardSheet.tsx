import { useState } from "react";
import { motion, type Variants } from "framer-motion";
import { Check, MessageCircle, Phone, UserPlus } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { haptics } from "../../services/haptics.service";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";
import { useAdaptiveSpring } from "../../hooks/useReducedMotion";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Card } from "../ui/card";

/**
 * MODULE C — Dynamic contact / vCard. Generates a downloadable .vcf blob
 * entirely client-side. Fields live in /src/config/touchpoints.config.ts
 * (vcard) — edit that file to change who gets saved. Do not modify this file.
 */

export function VCardSheet() {
  const { trackTap } = useTapAnalytics({ fireOnMount: false });
  const itemSpring = useAdaptiveSpring(motionConfig.springs.smooth);
  const { vcard } = touchpointsConfig;
  const copy = touchpointsConfig.copy.contact;
  const [saved, setSaved] = useState(false);

  const container: Variants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: motionConfig.stagger.children,
        delayChildren: motionConfig.stagger.delayChildren,
      },
    },
  };
  const item: Variants = {
    hidden: { opacity: 0, y: 12 },
    show: { opacity: 1, y: 0, transition: itemSpring },
  };

  const buildVcf = () =>
    [
      "BEGIN:VCARD",
      "VERSION:3.0",
      `FN:${vcard.name}`,
      `ORG:${vcard.org}`,
      `TEL;TYPE=CELL:${vcard.phone}`,
      `EMAIL:${vcard.email}`,
      `URL:${vcard.url}`,
      `ADR:;;${vcard.address};;;;`,
      "END:VCARD",
    ].join("\n");

  const handleSave = () => {
    const blob = new Blob([buildVcf()], { type: "text/vcard;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "the-grand-bistro.vcf";
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
    haptics.success();
    trackTap("vcard_save");
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2400);
  };

  const waUrl = `https://wa.me/${vcard.phone.replace(/\D/g, "")}`;
  const telUrl = `tel:${vcard.phone.replace(/[^+\d]/g, "")}`;

  return (
    <Card className="p-5">
      <motion.div variants={container} initial="hidden" animate="show" className="space-y-4">
        <motion.div variants={item} className="flex items-center gap-3">
          <span className="grid size-11 shrink-0 place-items-center rounded-full border border-[var(--tap-primary)]/30 bg-[var(--tap-primary)]/12 text-[var(--tap-primary)]">
            <UserPlus size={18} aria-hidden />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[15px] font-medium text-[var(--tap-text)]">{vcard.name}</span>
            <span className="block truncate text-xs text-[var(--tap-muted)]">{vcard.org}</span>
          </span>
          <Badge variant="muted">vCard</Badge>
        </motion.div>

        <motion.div variants={item}>
          <h3
            className="text-[19px] font-semibold tracking-[-0.015em] text-[var(--tap-text)]"
            style={{ fontFamily: "var(--tap-display-font)" }}
          >
            {copy.title}
          </h3>
          <p className="mt-0.5 text-[13px] text-[var(--tap-muted)]">{copy.body}</p>
        </motion.div>

        <motion.div variants={item}>
          <Button className="w-full" onTap={handleSave}>
            {saved ? <Check size={18} aria-hidden /> : <UserPlus size={18} aria-hidden />}
            {saved ? copy.saved : copy.saveCta}
          </Button>
        </motion.div>

        {/* Secondary row — WhatsApp + Call, staggered in, brand-tint glows */}
        <motion.div variants={item} className="grid grid-cols-2 gap-3">
          <Button
            variant="emerald"
            onTap={() => {
              trackTap("whatsapp_open");
              window.open(waUrl, "_blank", "noopener,noreferrer");
            }}
          >
            <MessageCircle size={17} aria-hidden />
            {copy.whatsapp}
          </Button>
          <Button
            variant="secondary"
            className="shadow-[0_0_28px_var(--tap-accent-glow)]"
            onTap={() => {
              trackTap("phone_call");
              window.open(telUrl, "_self");
            }}
          >
            <Phone size={16} aria-hidden />
            {copy.call}
          </Button>
        </motion.div>
      </motion.div>
    </Card>
  );
}
