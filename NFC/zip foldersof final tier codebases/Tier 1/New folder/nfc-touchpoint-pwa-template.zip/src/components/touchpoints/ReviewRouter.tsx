import { useState } from "react";
import { AnimatePresence, motion, type Variants } from "framer-motion";
import { ExternalLink, MapPin, ShieldCheck } from "lucide-react";
import { clientConfig } from "../../config/client.config";
import { motionConfig } from "../../config/motion.config";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { haptics } from "../../services/haptics.service";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";
import { useAdaptiveSpring } from "../../hooks/useReducedMotion";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { ConfettiBurst } from "./ConfettiBurst";
import { FeedbackDrawer } from "./FeedbackDrawer";
import { StarRating } from "./StarRating";

/**
 * MODULE A — Smart Review Router.
 * rating ≥ 4 → staggered reveal of the glowing Google Maps CTA + confetti.
 * rating < 4 → the card morphs into the private FeedbackDrawer.
 * Copy: /src/config/touchpoints.config.ts · physics: motion.config.ts —
 * do not modify this file.
 */

export function ReviewRouter() {
  const { trackTap, trackRating } = useTapAnalytics({ fireOnMount: false });
  const itemSpring = useAdaptiveSpring(motionConfig.springs.smooth);
  const copy = touchpointsConfig.copy.review;

  const [rating, setRating] = useState(0);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [burstKey, setBurstKey] = useState(0);

  const container: Variants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: motionConfig.stagger.children,
        delayChildren: motionConfig.stagger.delayChildren,
      },
    },
  };
  const item: Variants = {
    hidden: { opacity: 0, y: 14 },
    show: { opacity: 1, y: 0, transition: itemSpring },
  };

  const handleRating = (r: number) => {
    setRating(r);
    trackRating(r);
    if (r < 4) setFeedbackOpen(true); // morph into the private sheet
  };

  const handleGoogleCta = () => {
    setBurstKey((k) => k + 1);
    haptics.success();
    trackTap("google_review_cta");
    // Let the burst + haptic land before the browser swaps context.
    window.setTimeout(() => {
      window.open(clientConfig.googleReviewUrl, "_blank", "noopener,noreferrer");
    }, 240);
  };

  return (
    <motion.section variants={container} initial="hidden" animate="show" className="space-y-4">
      <motion.div variants={item}>
        <Card className="px-5 pb-6 pt-6">
          <div className="flex items-start justify-between gap-3">
            <h2
              className="text-[26px] font-semibold leading-[1.12] tracking-[-0.02em] text-[var(--tap-text)]"
              style={{ fontFamily: "var(--tap-display-font)" }}
            >
              {copy.title}
            </h2>
            <Badge variant="muted" className="mt-1.5 shrink-0">
              {touchpointsConfig.vertical}
            </Badge>
          </div>
          <p className="mt-1.5 text-sm text-[var(--tap-muted)]">{copy.subtitle}</p>

          <StarRating value={rating} onSelect={handleRating} />

          <AnimatePresence mode="wait">
            <motion.p
              key={rating}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.18, ease: "easeOut" }}
              className={`mt-4 text-center text-[13px] font-medium ${
                rating >= 4 ? "text-[var(--tap-primary)]" : "text-[var(--tap-muted)]"
              }`}
            >
              {rating === 0 ? copy.hintDefault : copy.ratingLabels[rating]}
              {rating > 0 && <span className="ml-1.5 tabular-nums opacity-70">{rating}/5</span>}
            </motion.p>
          </AnimatePresence>
        </Card>
      </motion.div>

      <AnimatePresence mode="wait">
        {rating >= 4 && (
          <motion.div
            key="reveal-high"
            variants={container}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: -10, transition: { duration: 0.15, ease: "easeOut" } }}
            className="space-y-3"
          >
            <motion.p variants={item} className="px-2 text-center text-sm text-[var(--tap-muted)]">
              {copy.highNote}
            </motion.p>
            <motion.div variants={item} className="relative">
              <Button size="lg" className="w-full text-[16px]" onTap={handleGoogleCta}>
                <MapPin size={19} aria-hidden />
                {copy.highCta}
                <ExternalLink size={15} className="opacity-70" aria-hidden />
              </Button>
              <ConfettiBurst burstKey={burstKey} />
            </motion.div>
            <motion.div variants={item} className="flex justify-center">
              <Button variant="ghost" size="sm" onTap={() => setRating(0)}>
                {copy.reset}
              </Button>
            </motion.div>
          </motion.div>
        )}

        {rating > 0 && rating < 4 && (
          <motion.div
            key="reveal-low"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10, transition: { duration: 0.15, ease: "easeOut" } }}
            transition={itemSpring}
          >
            <Card className="border-[var(--tap-secondary)]/25 p-4">
              <div className="flex items-start gap-3">
                <span className="grid size-9 shrink-0 place-items-center rounded-[calc(var(--tap-radius)-2px)] border border-[var(--tap-secondary)]/30 bg-[var(--tap-secondary)]/12 text-[hsl(158_65%_62%)]">
                  <ShieldCheck size={17} aria-hidden />
                </span>
                <p className="text-[13px] leading-relaxed text-[var(--tap-muted)]">{copy.lowNote}</p>
              </div>
              <Button
                variant="emerald"
                size="sm"
                className="mt-3.5 w-full"
                onTap={() => {
                  setFeedbackOpen(true);
                  trackTap("feedback_reopen");
                }}
              >
                {copy.lowCta}
              </Button>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <FeedbackDrawer open={feedbackOpen} onClose={() => setFeedbackOpen(false)} rating={rating} />
    </motion.section>
  );
}
