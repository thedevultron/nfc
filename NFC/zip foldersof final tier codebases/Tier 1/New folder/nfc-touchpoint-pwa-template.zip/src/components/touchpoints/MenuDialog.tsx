import { X } from "lucide-react";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Dialog } from "../ui/dialog";

/**
 * Digital menu dialog — content lives in /src/config/touchpoints.config.ts
 * (menu.items). Prices render tabular for scanability. Do not modify this
 * file; edit the config to change tonight's menu.
 */

export function MenuDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { menu } = touchpointsConfig;
  const copy = touchpointsConfig.copy.menu;

  return (
    <Dialog open={open} onClose={onClose} labelledBy="menu-title">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <Badge>{copy.badge}</Badge>
          <h2
            id="menu-title"
            className="mt-2 text-xl font-semibold tracking-[-0.015em] text-[var(--tap-text)]"
            style={{ fontFamily: "var(--tap-display-font)" }}
          >
            {menu.title}
          </h2>
        </div>
        <Button variant="ghost" size="icon" onTap={onClose} aria-label="Close menu" className="-mr-1 -mt-1 shrink-0">
          <X size={17} aria-hidden />
        </Button>
      </div>

      <ul className="mt-3 divide-y divide-white/[0.06]">
        {menu.items.map((item) => (
          <li key={item.name} className="flex items-baseline justify-between gap-4 py-3">
            <div className="min-w-0">
              <p className="flex flex-wrap items-center gap-2 text-[15px] font-medium text-[var(--tap-text)]">
                {item.name}
                {item.tag && <Badge variant="muted">{item.tag}</Badge>}
              </p>
              <p className="mt-0.5 truncate text-xs text-[var(--tap-muted)]">{item.description}</p>
            </div>
            <span className="shrink-0 text-[15px] font-semibold tabular-nums text-[var(--tap-primary)]">
              {item.price}
            </span>
          </li>
        ))}
      </ul>

      <p className="mt-3 text-center text-[11px] leading-relaxed text-[var(--tap-muted)]/80">
        {menu.note} · {copy.note}
      </p>
    </Dialog>
  );
}
