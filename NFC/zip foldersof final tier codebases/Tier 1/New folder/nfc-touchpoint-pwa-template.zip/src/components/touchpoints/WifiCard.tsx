import { lazy, Suspense, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy, Eye, EyeOff, QrCode, Signal, Wifi } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { haptics } from "../../services/haptics.service";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";
import { useAdaptiveSpring } from "../../hooks/useReducedMotion";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Drawer } from "../ui/drawer";
import { Skeleton } from "../ui/skeleton";

/* QR renderer is the one heavy dependency — lazy-load it, non-blocking. */
const QRCode = lazy(() => import("react-qr-code"));

/**
 * MODULE B — Instant WiFi touchpoint, rendered as an iOS-style drawer.
 * Credentials live in /src/config/touchpoints.config.ts (wifi) — edit
 * that file to change SSID/password. Do not modify this file.
 */

interface WifiCardProps {
  open: boolean;
  onClose: () => void;
}

async function copyText(value: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = value;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

export function WifiCard({ open, onClose }: WifiCardProps) {
  const { trackTap } = useTapAnalytics({ fireOnMount: false });
  const spring = useAdaptiveSpring(motionConfig.springs.snappy);
  const { wifi } = touchpointsConfig;
  const copy = touchpointsConfig.copy.wifi;

  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);

  useEffect(() => {
    if (!open) {
      const t = window.setTimeout(() => {
        setRevealed(false);
        setCopied(false);
        setQrOpen(false);
      }, 300);
      return () => window.clearTimeout(t);
    }
  }, [open]);

  const payload = `WIFI:T:WPA;S:${wifi.ssid};P:${wifi.password};;`;

  const handleCopy = async () => {
    const ok = await copyText(wifi.password);
    if (ok) {
      setCopied(true);
      haptics.success();
      trackTap("wifi_copy_password");
      window.setTimeout(() => setCopied(false), 2200);
    } else {
      haptics.error();
    }
  };

  return (
    <Drawer open={open} onClose={onClose} title={copy.title} body={copy.body}>
      <div className="space-y-4">
        {/* Network identity row */}
        <div className="flex items-center gap-3.5 rounded-[var(--tap-radius)] border border-white/[0.07] bg-white/[0.03] p-3.5">
          <span className="grid size-11 shrink-0 place-items-center rounded-[calc(var(--tap-radius)-2px)] border border-[var(--tap-primary)]/25 bg-[var(--tap-primary)]/12 text-[var(--tap-primary)]">
            <Wifi size={19} aria-hidden />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[15px] font-medium text-[var(--tap-text)]">{wifi.ssid}</span>
            <span className="block text-xs text-[var(--tap-muted)]">WPA2 · guest network</span>
          </span>
          <span className="flex items-center gap-2">
            <Badge variant="muted">{wifi.band}</Badge>
            <Signal size={15} className="text-[var(--tap-secondary)]" aria-hidden />
          </span>
        </div>

        {/* Password with reveal toggle */}
        <div>
          <p className="mb-1.5 text-[11px] font-medium text-[var(--tap-muted)]">{copy.passwordLabel}</p>
          <div className="flex h-12 items-center justify-between rounded-[var(--tap-radius)] border border-white/10 bg-white/[0.04] pl-4 pr-1.5">
            <span className="truncate text-[15px] font-medium tracking-wide text-[var(--tap-text)] tabular-nums">
              {revealed ? wifi.password : "••••••••••••"}
            </span>
            <Button
              variant="ghost"
              size="icon"
              aria-label={revealed ? copy.hide : copy.reveal}
              onTap={() => {
                setRevealed((v) => !v);
                trackTap(revealed ? "wifi_hide" : "wifi_reveal");
              }}
            >
              {revealed ? <EyeOff size={17} aria-hidden /> : <Eye size={17} aria-hidden />}
            </Button>
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <Button onTap={handleCopy}>
            {copied ? <Check size={17} aria-hidden /> : <Copy size={17} aria-hidden />}
            {copied ? copy.copied : copy.copy}
          </Button>
          <Button
            variant="secondary"
            onTap={() => {
              setQrOpen((v) => !v);
              trackTap("wifi_qr_toggle");
            }}
            aria-expanded={qrOpen}
          >
            <QrCode size={17} aria-hidden />
            {copy.qr}
          </Button>
        </div>

        {/* QR payload panel */}
        <AnimatePresence initial={false}>
          {qrOpen && (
            <motion.div
              key="qr"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={spring}
              className="overflow-hidden"
            >
              <div className="rounded-[var(--tap-radius)] border border-white/[0.08] bg-white/[0.03] p-4">
                <div className="flex justify-center rounded-[calc(var(--tap-radius)-2px)] bg-[hsl(224_50%_5%)] py-4">
                  <Suspense fallback={<Skeleton className="size-[140px]" />}>
                    <QRCode value={payload} size={140} bgColor="transparent" fgColor="hsl(42 72% 88%)" />
                  </Suspense>
                </div>
                <p className="mt-3 text-center text-[11px] text-[var(--tap-muted)]">{copy.qrHint}</p>
                <p className="mt-2 truncate rounded-md bg-black/30 px-2.5 py-1.5 text-center font-mono text-[10px] text-[var(--tap-muted)]/80">
                  {payload}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Drawer>
  );
}
