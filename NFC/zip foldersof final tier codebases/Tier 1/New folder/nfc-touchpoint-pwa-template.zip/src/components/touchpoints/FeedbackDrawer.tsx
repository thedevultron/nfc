import { useEffect, useState } from "react";
import { MessageSquare, Star } from "lucide-react";
import { api } from "../../services/api.service";
import { haptics } from "../../services/haptics.service";
import { clientConfig } from "../../config/client.config";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Drawer } from "../ui/drawer";
import { Textarea } from "../ui/textarea";
import { SuccessRing } from "./SuccessRing";

/**
 * Private low-rating path (rating < 4): the star card morphs into this
 * sheet. Submit is optimistic — the success ring springs in instantly,
 * the n8n POST rides behind it (api.service). Copy from
 * /src/config/touchpoints.config.ts — do not modify this file.
 */

interface FeedbackDrawerProps {
  open: boolean;
  onClose: () => void;
  rating: number;
}

const MAX_LENGTH = 400;

export function FeedbackDrawer({ open, onClose, rating }: FeedbackDrawerProps) {
  const { trackFeedback } = useTapAnalytics({ fireOnMount: false });
  const [text, setText] = useState("");
  const [phase, setPhase] = useState<"editing" | "done">("editing");
  const copy = touchpointsConfig.copy.feedback;

  // Reset once the exit animation has played.
  useEffect(() => {
    if (!open) {
      const t = window.setTimeout(() => {
        setPhase("editing");
        setText("");
      }, 280);
      return () => window.clearTimeout(t);
    }
  }, [open]);

  const submit = () => {
    if (!text.trim()) return;
    haptics.success();
    trackFeedback(rating);
    setPhase("done"); // optimistic — ring first, network after
    void api.submitFeedback({
      rating,
      feedbackText: text.trim(),
      timestamp: new Date().toISOString(),
      touchpointId: clientConfig.touchpointId,
    });
  };

  return (
    <Drawer open={open} onClose={onClose} title={copy.title} body={copy.body}>
      {phase === "editing" ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between rounded-[var(--tap-radius)] border border-white/[0.07] bg-white/[0.03] px-4 py-2.5">
            <span className="flex items-center gap-0.5" aria-hidden>
              {[1, 2, 3, 4, 5].map((i) => (
                <Star
                  key={i}
                  size={15}
                  className={
                    i <= rating
                      ? "fill-[var(--tap-primary)] text-[var(--tap-primary)]"
                      : "fill-transparent text-[var(--tap-muted)]/40"
                  }
                />
              ))}
            </span>
            <Badge variant="muted" className="tabular-nums">
              {rating}/5
            </Badge>
          </div>
          <Textarea
            rows={4}
            maxLength={MAX_LENGTH}
            value={text}
            autoFocus
            onChange={(e) => setText(e.target.value)}
            placeholder={copy.placeholder}
          />
          <div className="flex items-center justify-between text-[11px] text-[var(--tap-muted)]">
            <span>{copy.privacy}</span>
            <span className="tabular-nums">{text.length}/{MAX_LENGTH}</span>
          </div>
          <Button className="w-full" disabled={text.trim().length === 0} onTap={submit}>
            <MessageSquare size={17} aria-hidden />
            {copy.cta}
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          <SuccessRing title={copy.successTitle} body={copy.successBody} />
          <Button variant="secondary" className="w-full" onTap={onClose}>
            {copy.close}
          </Button>
        </div>
      )}
    </Drawer>
  );
}
