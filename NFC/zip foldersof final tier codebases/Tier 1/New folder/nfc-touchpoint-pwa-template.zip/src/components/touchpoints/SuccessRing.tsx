import { motion } from "framer-motion";
import { Check, X } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { useAdaptiveSpring, useReducedMotion } from "../../hooks/useReducedMotion";

/**
 * Optimistic outcome state: a circular progress-ring wipe draws in, then
 * the check/x mark springs in elastically over its center. Replaces toast
 * spam across the engine. Timing from /src/config/motion.config.ts —
 * do not modify this file.
 */

interface SuccessRingProps {
  state?: "success" | "error";
  title: string;
  body: string;
}

export function SuccessRing({ state = "success", title, body }: SuccessRingProps) {
  const reduced = useReducedMotion();
  const iconSpring = useAdaptiveSpring(motionConfig.springs.elastic);
  const color = state === "success" ? "var(--tap-primary)" : "hsl(0 72% 58%)";

  return (
    <div className="flex flex-col items-center py-5 text-center">
      <div className="relative grid place-items-center">
        <span
          aria-hidden
          className="absolute inset-2 rounded-full opacity-25 blur-2xl"
          style={{ background: color }}
        />
        <svg width="92" height="92" viewBox="0 0 92 92" className="-rotate-90">
          <circle cx="46" cy="46" r="40" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="3" />
          <motion.circle
            cx="46"
            cy="46"
            r="40"
            fill="none"
            strokeWidth="3.5"
            strokeLinecap="round"
            style={{ stroke: color }}
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: reduced ? motionConfig.reduced.duration : 0.45, ease: "easeOut" }}
          />
        </svg>
        <motion.span
          className="absolute inset-0 grid place-items-center"
          style={{ color }}
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ ...iconSpring, delay: reduced ? 0 : 0.16 }}
        >
          {state === "success" ? <Check size={36} strokeWidth={2.5} aria-hidden /> : <X size={36} strokeWidth={2.5} aria-hidden />}
        </motion.span>
      </div>
      <motion.h3
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2, ease: "easeOut", delay: reduced ? 0 : 0.2 }}
        className="mt-4 text-xl font-semibold tracking-[-0.015em] text-[var(--tap-text)]"
        style={{ fontFamily: "var(--tap-display-font)" }}
      >
        {title}
      </motion.h3>
      <motion.p
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2, ease: "easeOut", delay: reduced ? 0 : 0.28 }}
        className="mt-1 max-w-[28ch] text-sm text-[var(--tap-muted)]"
      >
        {body}
      </motion.p>
    </div>
  );
}
