import { useState, type CSSProperties } from "react";
import { motion, type Variants } from "framer-motion";
import { ChevronRight, ExternalLink } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { touchpointsConfig } from "../../config/touchpoints.config";
import { useSpringPress } from "../../hooks/useSpringPress";
import { useTapAnalytics } from "../../hooks/useTapAnalytics";
import { useAdaptiveSpring } from "../../hooks/useReducedMotion";
import type { HubLink } from "../../types/template.types";
import { Icon } from "../ui/icon";
import { MenuDialog } from "./MenuDialog";
import { VCardSheet } from "./VCardSheet";
import { WifiCard } from "./WifiCard";

/**
 * MODULE D — Multi-link social hub: staggered pill rows driven entirely
 * by /src/config/touchpoints.config.ts (hub[]). Rows open external URLs,
 * the menu dialog, the WiFi drawer, or route back to the Review panel.
 * Do not modify this file — add/edit rows in the touchpoints config.
 */

const TINTS: Record<HubLink["tint"], string> = {
  primary: "border-[var(--tap-primary)]/25 bg-[var(--tap-primary)]/12 text-[var(--tap-primary)]",
  secondary: "border-[var(--tap-secondary)]/30 bg-[var(--tap-secondary)]/12 text-[hsl(158_65%_62%)]",
  neutral: "border-white/10 bg-white/[0.06] text-[var(--tap-text)]",
};

export function SocialHub({ onGoReview }: { onGoReview: () => void }) {
  const { trackTap } = useTapAnalytics({ fireOnMount: false });
  const press = useSpringPress();
  const itemSpring = useAdaptiveSpring(motionConfig.springs.smooth);
  const [wifiOpen, setWifiOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const copy = touchpointsConfig.copy.hub;

  const container: Variants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: motionConfig.stagger.children,
        delayChildren: motionConfig.stagger.delayChildren,
      },
    },
  };
  const item: Variants = {
    hidden: { opacity: 0, y: 14 },
    show: { opacity: 1, y: 0, transition: itemSpring },
  };

  const handle = (row: HubLink) => {
    trackTap(row.label.toLowerCase().replace(/\s+/g, "_"));
    if (row.action === "wifi") setWifiOpen(true);
    else if (row.action === "menu") setMenuOpen(true);
    else if (row.action === "review") onGoReview();
    else if (row.url) window.open(row.url, "_blank", "noopener,noreferrer");
  };

  return (
    <motion.section variants={container} initial="hidden" animate="show" className="space-y-3">
      <motion.header variants={item}>
        <h2
          className="text-2xl font-semibold tracking-[-0.02em] text-[var(--tap-text)]"
          style={{ fontFamily: "var(--tap-display-font)" }}
        >
          {copy.title}
        </h2>
        <p className="mt-0.5 text-sm text-[var(--tap-muted)]">{copy.body}</p>
      </motion.header>

      {touchpointsConfig.hub.map((row) => (
        <motion.div variants={item} key={row.label}>
          <motion.button
            type="button"
            onClick={() => handle(row)}
            whileTap={press.whileTap}
            whileHover={press.whileHover}
            transition={press.transition}
            onTapStart={press.onTapStart}
            className="group flex w-full items-center gap-3.5 rounded-[var(--tap-radius)] border border-white/10 bg-[var(--tap-surface)]/70 p-3.5 text-left shadow-[0_8px_30px_rgba(0,0,0,0.35)] backdrop-blur-xl transition-colors hover:border-white/[0.17] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--tap-primary)]/50"
            style={{ "--nudge": `${motionConfig.hover.chevronNudge}px` } as CSSProperties}
          >
            <span
              className={`grid size-11 shrink-0 place-items-center rounded-[calc(var(--tap-radius)-2px)] border ${TINTS[row.tint]}`}
            >
              <Icon name={row.icon} size={19} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[15px] font-medium tracking-[-0.01em] text-[var(--tap-text)]">
                {row.label}
              </span>
              <span className="block truncate text-xs text-[var(--tap-muted)]">{row.description}</span>
            </span>
            {row.external && <ExternalLink size={13} className="shrink-0 text-[var(--tap-muted)]/60" aria-hidden />}
            <ChevronRight
              size={17}
              aria-hidden
              className="shrink-0 text-[var(--tap-muted)] transition-transform duration-150 group-hover:translate-x-(--nudge)"
            />
          </motion.button>
        </motion.div>
      ))}

      <motion.div variants={item}>
        <VCardSheet />
      </motion.div>

      <WifiCard open={wifiOpen} onClose={() => setWifiOpen(false)} />
      <MenuDialog open={menuOpen} onClose={() => setMenuOpen(false)} />
    </motion.section>
  );
}
