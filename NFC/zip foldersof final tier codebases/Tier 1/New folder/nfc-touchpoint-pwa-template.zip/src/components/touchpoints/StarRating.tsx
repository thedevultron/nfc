import { useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { motionConfig } from "../../config/motion.config";
import { haptics } from "../../services/haptics.service";
import { useReducedMotion } from "../../hooks/useReducedMotion";

/**
 * Five-star selector with the signature elastic pop: on select, each star
 * ripples [1 → 1.35 → 1] with a per-adjacent-star cascade delay. Physics +
 * cascade timing from /src/config/motion.config.ts — do not modify this file.
 */

interface StarRatingProps {
  value: number;
  onSelect: (rating: number) => void;
}

export function StarRating({ value, onSelect }: StarRatingProps) {
  const reduced = useReducedMotion();
  const [pulse, setPulse] = useState<{ center: number; key: number } | null>(null);

  const handleSelect = (rating: number) => {
    onSelect(rating);
    haptics.selection();
    if (!reduced) setPulse({ center: rating, key: Date.now() });
  };

  return (
    <div role="radiogroup" aria-label="Star rating" className="mt-5 flex items-center justify-center gap-1.5">
      {[1, 2, 3, 4, 5].map((star) => {
        const filled = star <= value;
        const cascadeDelay = pulse
          ? Math.abs(star - pulse.center) * motionConfig.stagger.cascade
          : 0;
        return (
          <motion.button
            key={star}
            type="button"
            role="radio"
            aria-checked={filled}
            aria-label={`${star} star${star > 1 ? "s" : ""}`}
            onClick={() => handleSelect(star)}
            whileTap={reduced ? undefined : { scale: motionConfig.press.scale }}
            className="-m-0.5 rounded-full p-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--tap-primary)]/50"
          >
            <motion.span
              key={pulse ? `pulse-${pulse.key}-${star}` : `idle-${star}-${filled}`}
              className="block"
              initial={pulse ? { scale: 0.55 } : false}
              animate={pulse ? { scale: [0.55, 1.35, 1] } : { scale: 1 }}
              transition={
                pulse
                  ? { ...motionConfig.springs.elastic, delay: cascadeDelay }
                  : { duration: motionConfig.reduced.duration, ease: "easeOut" }
              }
            >
              <Star
                size={34}
                strokeWidth={1.8}
                aria-hidden
                className={`transition-colors duration-200 ${
                  filled
                    ? "fill-[var(--tap-primary)] text-[var(--tap-primary)] drop-shadow-[0_0_14px_var(--tap-accent-glow)]"
                    : "fill-transparent text-[var(--tap-muted)]/70"
                }`}
              />
            </motion.span>
          </motion.button>
        );
      })}
    </div>
  );
}
