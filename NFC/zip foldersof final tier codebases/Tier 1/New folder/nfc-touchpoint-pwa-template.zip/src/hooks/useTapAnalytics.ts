import { useCallback, useEffect, useRef } from "react";
import { api } from "../services/api.service";

/**
 * Touchpoint telemetry: fires `touchpoint_view` once on mount and exposes
 * debounce-guarded tap/rating trackers for every CTA. Fully non-blocking —
 * events ride requestIdleCallback + keepalive fetch (see api.service).
 * Webhook target is configured in /src/config/client.config.ts.
 */

const DEBOUNCE_MS = 300;

export function useTapAnalytics(options: { fireOnMount?: boolean } = {}) {
  const { fireOnMount = true } = options;
  const lastSentAt = useRef(0);

  useEffect(() => {
    if (!fireOnMount) return;
    const t = window.setTimeout(() => api.track("touchpoint_view"), 120);
    return () => window.clearTimeout(t);
  }, [fireOnMount]);

  /** CTA tap — debounced so a double-tap never double-fires. */
  const trackTap = useCallback((label: string) => {
    const now = Date.now();
    if (now - lastSentAt.current < DEBOUNCE_MS) return;
    lastSentAt.current = now;
    api.track("cta_tap", label);
  }, []);

  const trackRating = useCallback((rating: number) => {
    api.track("rating_set", `rating_${rating}`, rating);
  }, []);

  const trackFeedback = useCallback((rating: number) => {
    api.track("feedback_submit", "private_feedback", rating);
  }, []);

  return { trackTap, trackRating, trackFeedback };
}
