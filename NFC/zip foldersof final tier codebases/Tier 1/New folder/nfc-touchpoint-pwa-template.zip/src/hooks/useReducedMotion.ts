import { useReducedMotion as useFramerReducedMotion } from "framer-motion";
import type { Transition } from "framer-motion";
import { motionConfig } from "../config/motion.config";
import type { SpringPreset } from "../types/template.types";

/**
 * Motion accessibility layer. When the OS asks for reduced motion,
 * every spring collapses to a short 150ms ease-out fade.
 * Fallback timing lives in /src/config/motion.config.ts (`reduced`).
 */

export function useReducedMotion(): boolean {
  return useFramerReducedMotion() ?? false;
}

/** Resolve a config spring into a Transition that respects reduced motion. */
export function useAdaptiveSpring(spring: SpringPreset): Transition {
  const reduced = useReducedMotion();
  if (reduced) {
    return { duration: motionConfig.reduced.duration, ease: motionConfig.reduced.ease };
  }
  return { ...spring };
}
