import type { Transition } from "framer-motion";
import { motionConfig } from "../config/motion.config";
import { haptics } from "../services/haptics.service";
import { useReducedMotion } from "./useReducedMotion";

/**
 * The reusable "press-down" interaction: whileTap scale + brightness dip,
 * gentle hover lift, snappy spring back, and a haptic tick on touch-down.
 * All physics come from /src/config/motion.config.ts — spread the result
 * onto any motion element. Do not inline animation values in components.
 */

export interface SpringPressProps {
  whileTap?: { scale: number; filter: string };
  whileHover?: { scale: number };
  transition: Transition;
  onTapStart: () => void;
}

export function useSpringPress(options: { withHover?: boolean } = {}): SpringPressProps {
  const { withHover = true } = options;
  const reduced = useReducedMotion();

  return {
    whileTap: reduced
      ? undefined
      : { scale: motionConfig.press.scale, filter: `brightness(${motionConfig.press.brightness})` },
    whileHover: reduced || !withHover ? undefined : { scale: motionConfig.hover.scale },
    transition: reduced
      ? { duration: motionConfig.reduced.duration, ease: motionConfig.reduced.ease }
      : { ...motionConfig.springs.snappy },
    onTapStart: () => haptics.tap(),
  };
}
