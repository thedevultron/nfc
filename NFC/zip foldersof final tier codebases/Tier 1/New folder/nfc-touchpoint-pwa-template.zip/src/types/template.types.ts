/**
 * Shared type contracts for the TAP Tier-1 Touchpoint Engine.
 * Values live exclusively in /src/config/*.ts — do not hardcode them in
 * components, hooks or services.
 */

export type TouchpointMode = "REVIEW" | "WIFI" | "CONTACT" | "HUB";

/** Internal, config-driven navigation actions a hub row can trigger. */
export type HubAction = "menu" | "wifi" | "review" | null;

/** The only Lucide marks the engine knows how to resolve from config strings. */
export type IconName =
  | "Utensils"
  | "Star"
  | "Wifi"
  | "MessageSquare"
  | "MessageCircle"
  | "BookOpen"
  | "Phone"
  | "UserPlus"
  | "ChevronRight"
  | "ExternalLink"
  | "Sparkles"
  | "Eye"
  | "EyeOff"
  | "Copy"
  | "Check"
  | "MapPin"
  | "QrCode"
  | "X"
  | "Zap"
  | "LayoutGrid"
  | "Clock"
  | "Signal"
  | "ShieldCheck";

export interface SpringPreset {
  type: "spring";
  stiffness: number;
  damping: number;
  mass?: number;
}

export interface ThemeConfig {
  primaryColor: string;
  secondaryAccent: string;
  accentGlow: string;
  backgroundColor: string;
  surfaceColor: string;
  textColor: string;
  mutedTextColor: string;
  borderColor: string;
  borderRadius: string;
  fontFamily: string;
  displayFontFamily: string;
  enableGlassmorphism: boolean;
  defaultMode: "dark" | "light";
}

export interface MotionSystemConfig {
  springs: {
    snappy: SpringPreset;
    smooth: SpringPreset;
    elastic: SpringPreset;
    drawer: SpringPreset;
  };
  stagger: { children: number; delayChildren: number; cascade: number };
  press: { scale: number; brightness: number };
  hover: { scale: number; chevronNudge: number };
  entrance: { y: number };
  reduced: { duration: number; ease: "easeOut" };
  gestures: {
    swipe: { distance: number; velocity: number };
    drawer: { dismissDistance: number; dismissVelocity: number };
  };
  haptics: {
    tap: number;
    selection: number;
    success: number[];
    error: number[];
  };
}

export interface ClientConfig {
  businessName: string;
  subtitle: string;
  locationLine: string;
  tableLabel: string;
  touchpointId: string;
  activeMode: TouchpointMode;
  googleReviewUrl: string;
  n8nWebhookUrl: string;
  n8nFeedbackWebhook: string;
}

export interface HubLink {
  label: string;
  description: string;
  icon: IconName;
  tint: "primary" | "secondary" | "neutral";
  url?: string;
  external: boolean;
  action: HubAction;
}

export interface MenuItem {
  name: string;
  description: string;
  price: string;
  tag?: string;
}

export interface TouchpointsConfig {
  vertical: string;
  icons: { primary: IconName; secondary: IconName };
  hub: HubLink[];
  menu: { title: string; note: string; items: MenuItem[] };
  wifi: { ssid: string; password: string; band: string };
  vcard: {
    name: string;
    org: string;
    phone: string;
    email: string;
    url: string;
    address: string;
  };
  copy: {
    loading: string;
    banner: { status: string; badge: string };
    segmented: { review: string; hub: string };
    review: {
      title: string;
      subtitle: string;
      hintDefault: string;
      ratingLabels: string[];
      highNote: string;
      highCta: string;
      reset: string;
      lowNote: string;
      lowCta: string;
    };
    feedback: {
      title: string;
      body: string;
      placeholder: string;
      cta: string;
      privacy: string;
      successTitle: string;
      successBody: string;
      close: string;
    };
    wifi: {
      title: string;
      body: string;
      passwordLabel: string;
      reveal: string;
      hide: string;
      copy: string;
      copied: string;
      qr: string;
      qrHint: string;
    };
    contact: {
      title: string;
      body: string;
      saveCta: string;
      saved: string;
      whatsapp: string;
      call: string;
    };
    hub: { title: string; body: string };
    menu: { badge: string; note: string };
    footer: string;
  };
}

export interface TapAnalyticsEvent {
  eventType: "touchpoint_view" | "cta_tap" | "rating_set" | "feedback_submit";
  touchpointId: string;
  business: string;
  label?: string;
  rating?: number;
  timestamp: string;
}

export interface FeedbackPayload {
  rating: number;
  feedbackText: string;
  timestamp: string;
  touchpointId: string;
}
