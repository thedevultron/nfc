import { motionConfig } from "../config/motion.config";

/**
 * navigator.vibrate abstraction for the TAP Tier-1 engine.
 * Patterns live in /src/config/motion.config.ts (haptics section) —
 * edit that file to re-tune the feel. Do not modify this file.
 * Silently no-ops on devices without a vibrator (iOS Safari, desktops).
 */

export type HapticPreset = keyof typeof motionConfig.haptics;

export function haptic(preset: HapticPreset): void {
  if (typeof navigator === "undefined" || !("vibrate" in navigator)) return;
  try {
    navigator.vibrate(motionConfig.haptics[preset]);
  } catch {
    /* non-haptic environment — ignore */
  }
}

export const haptics = {
  tap: () => haptic("tap"),
  selection: () => haptic("selection"),
  success: () => haptic("success"),
  error: () => haptic("error"),
};
