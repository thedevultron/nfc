import { clientConfig } from "../config/client.config";
import type {
  FeedbackPayload,
  TapAnalyticsEvent,
} from "../types/template.types";

/**
 * n8n webhook transport for the TAP Tier-1 engine.
 * Retry-safe (1 retry w/ backoff), optimistic-UI friendly: resolves fast,
 * never throws, never blocks render. Uses `keepalive` so a tap that opens
 * a new page still delivers its event.
 *
 * While a webhook URL still contains a placeholder host, the call is
 * stubbed with a simulated healthy response — swap in real n8n URLs in
 * /src/config/client.config.ts to go live. Do not modify this file.
 */

const PLACEHOLDER_HOST = /yourdomain\.com|example\.com|localhost|your_place_id/i;
const isConfigured = (url: string) => url.length > 0 && !PLACEHOLDER_HOST.test(url);

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** Fire when the main thread is idle — analytics must never fight the springs. */
function whenIdle(callback: () => void) {
  if (typeof window !== "undefined" && "requestIdleCallback" in window) {
    window.requestIdleCallback(() => callback(), { timeout: 800 });
  } else {
    setTimeout(callback, 90);
  }
}

async function postWithRetry(url: string, body: unknown, attempt = 0): Promise<boolean> {
  if (!isConfigured(url)) {
    await delay(320); // simulated healthy n8n round-trip for dev/preview
    return true;
  }
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      keepalive: true,
    });
    if (res.ok) return true;
    throw new Error(`HTTP ${res.status}`);
  } catch {
    if (attempt < 1) {
      await delay(600);
      return postWithRetry(url, body, attempt + 1);
    }
    return false; // swallow — telemetry must never surface in the console or UI
  }
}

function stamp(
  eventType: TapAnalyticsEvent["eventType"],
  label?: string,
  rating?: number
): TapAnalyticsEvent {
  return {
    eventType,
    touchpointId: clientConfig.touchpointId,
    business: clientConfig.businessName,
    label,
    rating,
    timestamp: new Date().toISOString(),
  };
}

export const api = {
  /** Non-blocking analytics event, debounced upstream by useTapAnalytics. */
  track(eventType: TapAnalyticsEvent["eventType"], label?: string, rating?: number): void {
    const event = stamp(eventType, label, rating);
    whenIdle(() => {
      void postWithRetry(clientConfig.n8nWebhookUrl, event);
    });
  },

  /** Private feedback → owner webhook. Resolves true on accept; never throws. */
  submitFeedback(payload: FeedbackPayload): Promise<boolean> {
    return postWithRetry(clientConfig.n8nFeedbackWebhook, payload);
  },
};
